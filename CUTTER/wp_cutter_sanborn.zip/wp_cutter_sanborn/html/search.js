 var data = [{
    "nome": "a",
    "codigo": "A111"
  },
  {
    "nome": "aa",
    "codigo": "A111"
  },
  {
    "nome": "aal",
    "codigo": "A112"
  },
  {
    "nome": "aar",
    "codigo": "A113"
  },
  {
    "nome": "aars",
    "codigo": "A114"
  },
  {
    "nome": "aas",
    "codigo": "A115"
  },
  {
    "nome": "aba",
    "codigo": "A116"
  },
  {
    "nome": "abal",
    "codigo": "A117"
  },
  {
    "nome": "abar",
    "codigo": "A118"
  },
  {
    "nome": "abat",
    "codigo": "A119"
  },
  {
    "nome": "abau",
    "codigo": "A121"
  },
  {
    "nome": "abb",
    "codigo": "A122"
  },
  {
    "nome": "abbat",
    "codigo": "A123"
  },
  {
    "nome": "abbe",
    "codigo": "A124"
  },
  {
    "nome": "abbo",
    "codigo": "A125"
  },
  {
    "nome": "abbot",
    "codigo": "A126"
  },
  {
    "nome": "abbot j",
    "codigo": "A127"
  },
  {
    "nome": "abbot m",
    "codigo": "A128"
  },
  {
    "nome": "abbot s",
    "codigo": "A129"
  },
  {
    "nome": "abbott",
    "codigo": "A131"
  },
  {
    "nome": "abbott j",
    "codigo": "A132"
  },
  {
    "nome": "abbott m",
    "codigo": "A133"
  },
  {
    "nome": "abbott s",
    "codigo": "A134"
  },
  {
    "nome": "abd",
    "codigo": "A135"
  },
  {
    "nome": "abdul",
    "codigo": "A136"
  },
  {
    "nome": "abdy",
    "codigo": "A137"
  },
  {
    "nome": "abe",
    "codigo": "A138"
  },
  {
    "nome": "abel",
    "codigo": "A139"
  },
  {
    "nome": "abel l",
    "codigo": "A141"
  },
  {
    "nome": "aben",
    "codigo": "A142"
  },
  {
    "nome": "aber",
    "codigo": "A143"
  },
  {
    "nome": "abercr",
    "codigo": "A144"
  },
  {
    "nome": "aberd",
    "codigo": "A145"
  },
  {
    "nome": "abern",
    "codigo": "A146"
  },
  {
    "nome": "abert",
    "codigo": "A147"
  },
  {
    "nome": "abi",
    "codigo": "A148"
  },
  {
    "nome": "abing",
    "codigo": "A149"
  },
  {
    "nome": "abk",
    "codigo": "A151"
  },
  {
    "nome": "abl",
    "codigo": "A152"
  },
  {
    "nome": "abn",
    "codigo": "A153"
  },
  {
    "nome": "abo",
    "codigo": "A154"
  },
  {
    "nome": "abou",
    "codigo": "A155"
  },
  {
    "nome": "about",
    "codigo": "A156"
  },
  {
    "nome": "abov",
    "codigo": "A157"
  },
  {
    "nome": "abr",
    "codigo": "A158"
  },
  {
    "nome": "abrah",
    "codigo": "A159"
  },
  {
    "nome": "abrai",
    "codigo": "A161"
  },
  {
    "nome": "abre",
    "codigo": "A162"
  },
  {
    "nome": "abri",
    "codigo": "A163"
  },
  {
    "nome": "abru",
    "codigo": "A164"
  },
  {
    "nome": "abu",
    "codigo": "A165"
  },
  {
    "nome": "abul",
    "codigo": "A166"
  },
  {
    "nome": "abur",
    "codigo": "A167"
  },
  {
    "nome": "aca",
    "codigo": "A168"
  },
  {
    "nome": "acc",
    "codigo": "A169"
  },
  {
    "nome": "acci",
    "codigo": "A171"
  },
  {
    "nome": "acco",
    "codigo": "A172"
  },
  {
    "nome": "ace",
    "codigo": "A173"
  },
  {
    "nome": "aces",
    "codigo": "A174"
  },
  {
    "nome": "ach",
    "codigo": "A175"
  },
  {
    "nome": "achar",
    "codigo": "A176"
  },
  {
    "nome": "ache",
    "codigo": "A177"
  },
  {
    "nome": "achi",
    "codigo": "A178"
  },
  {
    "nome": "achm",
    "codigo": "A179"
  },
  {
    "nome": "aci",
    "codigo": "A181"
  },
  {
    "nome": "ack",
    "codigo": "A182"
  },
  {
    "nome": "ackw",
    "codigo": "A183"
  },
  {
    "nome": "acl",
    "codigo": "A184"
  },
  {
    "nome": "aco",
    "codigo": "A185"
  },
  {
    "nome": "acq",
    "codigo": "A186"
  },
  {
    "nome": "acr",
    "codigo": "A187"
  },
  {
    "nome": "act",
    "codigo": "A188"
  },
  {
    "nome": "acu",
    "codigo": "A189"
  },
  {
    "nome": "ada",
    "codigo": "A191"
  },
  {
    "nome": "adal",
    "codigo": "A192"
  },
  {
    "nome": "adam",
    "codigo": "A193"
  },
  {
    "nome": "adam j",
    "codigo": "A194"
  },
  {
    "nome": "adam m",
    "codigo": "A195"
  },
  {
    "nome": "adam s",
    "codigo": "A196"
  },
  {
    "nome": "adam w",
    "codigo": "A197"
  },
  {
    "nome": "adami",
    "codigo": "A198"
  },
  {
    "nome": "adamo",
    "codigo": "A199"
  },
  {
    "nome": "adams",
    "codigo": "A211"
  },
  {
    "nome": "adams f",
    "codigo": "A212"
  },
  {
    "nome": "adams g",
    "codigo": "A213"
  },
  {
    "nome": "adams j",
    "codigo": "A214"
  },
  {
    "nome": "adams m",
    "codigo": "A215"
  },
  {
    "nome": "adams n",
    "codigo": "A216"
  },
  {
    "nome": "adams s",
    "codigo": "A217"
  },
  {
    "nome": "adams t",
    "codigo": "A218"
  },
  {
    "nome": "adams w",
    "codigo": "A219"
  },
  {
    "nome": "adamson",
    "codigo": "A221"
  },
  {
    "nome": "add",
    "codigo": "A222"
  },
  {
    "nome": "adde",
    "codigo": "A223"
  },
  {
    "nome": "addi",
    "codigo": "A224"
  },
  {
    "nome": "addison",
    "codigo": "A225"
  },
  {
    "nome": "addison m",
    "codigo": "A226"
  },
  {
    "nome": "addison s",
    "codigo": "A227"
  },
  {
    "nome": "ade",
    "codigo": "A228"
  },
  {
    "nome": "adelh",
    "codigo": "A229"
  },
  {
    "nome": "adelo",
    "codigo": "A231"
  },
  {
    "nome": "aden",
    "codigo": "A232"
  },
  {
    "nome": "adet",
    "codigo": "A233"
  },
  {
    "nome": "adh",
    "codigo": "A234"
  },
  {
    "nome": "adi",
    "codigo": "A235"
  },
  {
    "nome": "adk",
    "codigo": "A236"
  },
  {
    "nome": "adl",
    "codigo": "A237"
  },
  {
    "nome": "adm",
    "codigo": "A238"
  },
  {
    "nome": "ado",
    "codigo": "A239"
  },
  {
    "nome": "ador",
    "codigo": "A241"
  },
  {
    "nome": "adr",
    "codigo": "A242"
  },
  {
    "nome": "adri",
    "codigo": "A243"
  },
  {
    "nome": "ads",
    "codigo": "A244"
  },
  {
    "nome": "ady",
    "codigo": "A245"
  },
  {
    "nome": "ae",
    "codigo": "A246"
  },
  {
    "nome": "aeg",
    "codigo": "A247"
  },
  {
    "nome": "ael",
    "codigo": "A248"
  },
  {
    "nome": "aem",
    "codigo": "A249"
  },
  {
    "nome": "aen",
    "codigo": "A251"
  },
  {
    "nome": "aer",
    "codigo": "A252"
  },
  {
    "nome": "aes",
    "codigo": "A253"
  },
  {
    "nome": "aeso",
    "codigo": "A254"
  },
  {
    "nome": "aet",
    "codigo": "A255"
  },
  {
    "nome": "afa",
    "codigo": "A256"
  },
  {
    "nome": "affl",
    "codigo": "A257"
  },
  {
    "nome": "afr",
    "codigo": "A258"
  },
  {
    "nome": "aga",
    "codigo": "A259"
  },
  {
    "nome": "agar",
    "codigo": "A261"
  },
  {
    "nome": "agas",
    "codigo": "A262"
  },
  {
    "nome": "agat",
    "codigo": "A263"
  },
  {
    "nome": "agay",
    "codigo": "A264"
  },
  {
    "nome": "age",
    "codigo": "A265"
  },
  {
    "nome": "agg",
    "codigo": "A266"
  },
  {
    "nome": "agi",
    "codigo": "A267"
  },
  {
    "nome": "agis",
    "codigo": "A268"
  },
  {
    "nome": "agl",
    "codigo": "A269"
  },
  {
    "nome": "agn",
    "codigo": "A271"
  },
  {
    "nome": "agnes",
    "codigo": "A272"
  },
  {
    "nome": "agnew",
    "codigo": "A273"
  },
  {
    "nome": "agno",
    "codigo": "A274"
  },
  {
    "nome": "ago",
    "codigo": "A275"
  },
  {
    "nome": "agou",
    "codigo": "A276"
  },
  {
    "nome": "agr",
    "codigo": "A277"
  },
  {
    "nome": "agri",
    "codigo": "A278"
  },
  {
    "nome": "agrip",
    "codigo": "A279"
  },
  {
    "nome": "agro",
    "codigo": "A281"
  },
  {
    "nome": "agu",
    "codigo": "A282"
  },
  {
    "nome": "aguil",
    "codigo": "A283"
  },
  {
    "nome": "aguir",
    "codigo": "A284"
  },
  {
    "nome": "ah",
    "codigo": "A285"
  },
  {
    "nome": "ahm",
    "codigo": "A286"
  },
  {
    "nome": "ahr",
    "codigo": "A287"
  },
  {
    "nome": "ai",
    "codigo": "A288"
  },
  {
    "nome": "aig",
    "codigo": "A289"
  },
  {
    "nome": "aik",
    "codigo": "A291"
  },
  {
    "nome": "aiki",
    "codigo": "A292"
  },
  {
    "nome": "ail",
    "codigo": "A293"
  },
  {
    "nome": "aim",
    "codigo": "A294"
  },
  {
    "nome": "ain",
    "codigo": "A295"
  },
  {
    "nome": "ains",
    "codigo": "A296"
  },
  {
    "nome": "ainsw",
    "codigo": "A297"
  },
  {
    "nome": "air",
    "codigo": "A298"
  },
  {
    "nome": "ais",
    "codigo": "A299"
  },
  {
    "nome": "ait",
    "codigo": "A311"
  },
  {
    "nome": "aj",
    "codigo": "A312"
  },
  {
    "nome": "ak",
    "codigo": "A313"
  },
  {
    "nome": "aker",
    "codigo": "A314"
  },
  {
    "nome": "akers",
    "codigo": "A315"
  },
  {
    "nome": "al",
    "codigo": "A316"
  },
  {
    "nome": "alain",
    "codigo": "A317"
  },
  {
    "nome": "alam",
    "codigo": "A318"
  },
  {
    "nome": "alan",
    "codigo": "A319"
  },
  {
    "nome": "alar",
    "codigo": "A321"
  },
  {
    "nome": "alard",
    "codigo": "A322"
  },
  {
    "nome": "alary",
    "codigo": "A323"
  },
  {
    "nome": "alav",
    "codigo": "A324"
  },
  {
    "nome": "alb",
    "codigo": "A325"
  },
  {
    "nome": "alban",
    "codigo": "A326"
  },
  {
    "nome": "albar",
    "codigo": "A327"
  },
  {
    "nome": "albe",
    "codigo": "A328"
  },
  {
    "nome": "alber",
    "codigo": "A329"
  },
  {
    "nome": "alberi",
    "codigo": "A331"
  },
  {
    "nome": "albero",
    "codigo": "A332"
  },
  {
    "nome": "albert",
    "codigo": "A333"
  },
  {
    "nome": "alberti",
    "codigo": "A334"
  },
  {
    "nome": "albi",
    "codigo": "A335"
  },
  {
    "nome": "albini",
    "codigo": "A336"
  },
  {
    "nome": "albinu",
    "codigo": "A337"
  },
  {
    "nome": "albiz",
    "codigo": "A338"
  },
  {
    "nome": "albo",
    "codigo": "A339"
  },
  {
    "nome": "albr",
    "codigo": "A341"
  },
  {
    "nome": "albri",
    "codigo": "A342"
  },
  {
    "nome": "albriz",
    "codigo": "A343"
  },
  {
    "nome": "albro",
    "codigo": "A344"
  },
  {
    "nome": "albu",
    "codigo": "A345"
  },
  {
    "nome": "alc",
    "codigo": "A346"
  },
  {
    "nome": "alcan",
    "codigo": "A347"
  },
  {
    "nome": "alcar",
    "codigo": "A348"
  },
  {
    "nome": "alcaz",
    "codigo": "A349"
  },
  {
    "nome": "alce",
    "codigo": "A351"
  },
  {
    "nome": "alci",
    "codigo": "A352"
  },
  {
    "nome": "alcip",
    "codigo": "A353"
  },
  {
    "nome": "alco",
    "codigo": "A354"
  },
  {
    "nome": "alcot",
    "codigo": "A355"
  },
  {
    "nome": "alcu",
    "codigo": "A356"
  },
  {
    "nome": "ald",
    "codigo": "A357"
  },
  {
    "nome": "alden",
    "codigo": "A358"
  },
  {
    "nome": "alden s",
    "codigo": "A359"
  },
  {
    "nome": "alder",
    "codigo": "A361"
  },
  {
    "nome": "alders",
    "codigo": "A362"
  },
  {
    "nome": "aldi",
    "codigo": "A363"
  },
  {
    "nome": "aldo",
    "codigo": "A364"
  },
  {
    "nome": "aldr",
    "codigo": "A365"
  },
  {
    "nome": "ale",
    "codigo": "A366"
  },
  {
    "nome": "alem",
    "codigo": "A367"
  },
  {
    "nome": "alen",
    "codigo": "A368"
  },
  {
    "nome": "alep",
    "codigo": "A369"
  },
  {
    "nome": "ales",
    "codigo": "A371"
  },
  {
    "nome": "alessi",
    "codigo": "A372"
  },
  {
    "nome": "alew",
    "codigo": "A373"
  },
  {
    "nome": "alex",
    "codigo": "A374"
  },
  {
    "nome": "alexander c",
    "codigo": "A375"
  },
  {
    "nome": "alexander j",
    "codigo": "A376"
  },
  {
    "nome": "alexander m",
    "codigo": "A377"
  },
  {
    "nome": "alexander s",
    "codigo": "A378"
  },
  {
    "nome": "alexander w",
    "codigo": "A379"
  },
  {
    "nome": "alexandre",
    "codigo": "A381"
  },
  {
    "nome": "alexandre m",
    "codigo": "A382"
  },
  {
    "nome": "alexandro",
    "codigo": "A383"
  },
  {
    "nome": "alexi",
    "codigo": "A384"
  },
  {
    "nome": "alfa",
    "codigo": "A385"
  },
  {
    "nome": "alfe",
    "codigo": "A386"
  },
  {
    "nome": "alfi",
    "codigo": "A387"
  },
  {
    "nome": "alfo",
    "codigo": "A388"
  },
  {
    "nome": "alford",
    "codigo": "A389"
  },
  {
    "nome": "alfr",
    "codigo": "A391"
  },
  {
    "nome": "alfred",
    "codigo": "A392"
  },
  {
    "nome": "alfri",
    "codigo": "A393"
  },
  {
    "nome": "alg",
    "codigo": "A394"
  },
  {
    "nome": "alger",
    "codigo": "A395"
  },
  {
    "nome": "algh",
    "codigo": "A396"
  },
  {
    "nome": "alh",
    "codigo": "A397"
  },
  {
    "nome": "ali",
    "codigo": "A398"
  },
  {
    "nome": "alif",
    "codigo": "A399"
  },
  {
    "nome": "alig",
    "codigo": "A411"
  },
  {
    "nome": "alip",
    "codigo": "A412"
  },
  {
    "nome": "alis",
    "codigo": "A413"
  },
  {
    "nome": "alisonm",
    "codigo": "A414"
  },
  {
    "nome": "alk",
    "codigo": "A415"
  },
  {
    "nome": "all",
    "codigo": "A416"
  },
  {
    "nome": "allan",
    "codigo": "A417"
  },
  {
    "nome": "allan m",
    "codigo": "A418"
  },
  {
    "nome": "allard",
    "codigo": "A419"
  },
  {
    "nome": "allas",
    "codigo": "A421"
  },
  {
    "nome": "alle",
    "codigo": "A422"
  },
  {
    "nome": "allein",
    "codigo": "A423"
  },
  {
    "nome": "allem",
    "codigo": "A424"
  },
  {
    "nome": "allen",
    "codigo": "A425"
  },
  {
    "nome": "allen h",
    "codigo": "A426"
  },
  {
    "nome": "allen j",
    "codigo": "A427"
  },
  {
    "nome": "allen n",
    "codigo": "A428"
  },
  {
    "nome": "allen s",
    "codigo": "A429"
  },
  {
    "nome": "allen t",
    "codigo": "A431"
  },
  {
    "nome": "allen w",
    "codigo": "A432"
  },
  {
    "nome": "allens",
    "codigo": "A433"
  },
  {
    "nome": "aller",
    "codigo": "A434"
  },
  {
    "nome": "alley",
    "codigo": "A435"
  },
  {
    "nome": "alli",
    "codigo": "A436"
  },
  {
    "nome": "alling",
    "codigo": "A437"
  },
  {
    "nome": "allis",
    "codigo": "A438"
  },
  {
    "nome": "allison m",
    "codigo": "A439"
  },
  {
    "nome": "allo",
    "codigo": "A441"
  },
  {
    "nome": "alls",
    "codigo": "A442"
  },
  {
    "nome": "ally",
    "codigo": "A443"
  },
  {
    "nome": "alm",
    "codigo": "A444"
  },
  {
    "nome": "alman",
    "codigo": "A445"
  },
  {
    "nome": "almas",
    "codigo": "A446"
  },
  {
    "nome": "alme",
    "codigo": "A447"
  },
  {
    "nome": "almen",
    "codigo": "A448"
  },
  {
    "nome": "almi",
    "codigo": "A449"
  },
  {
    "nome": "almo",
    "codigo": "A451"
  },
  {
    "nome": "almon",
    "codigo": "A452"
  },
  {
    "nome": "alo",
    "codigo": "A453"
  },
  {
    "nome": "alon",
    "codigo": "A454"
  },
  {
    "nome": "alos",
    "codigo": "A455"
  },
  {
    "nome": "alp",
    "codigo": "A456"
  },
  {
    "nome": "alpi",
    "codigo": "A457"
  },
  {
    "nome": "alq",
    "codigo": "A458"
  },
  {
    "nome": "alr",
    "codigo": "A459"
  },
  {
    "nome": "als",
    "codigo": "A461"
  },
  {
    "nome": "alsop",
    "codigo": "A462"
  },
  {
    "nome": "alste",
    "codigo": "A463"
  },
  {
    "nome": "alsto",
    "codigo": "A464"
  },
  {
    "nome": "alt",
    "codigo": "A465"
  },
  {
    "nome": "alte",
    "codigo": "A466"
  },
  {
    "nome": "alth",
    "codigo": "A467"
  },
  {
    "nome": "alti",
    "codigo": "A468"
  },
  {
    "nome": "alto",
    "codigo": "A469"
  },
  {
    "nome": "alu",
    "codigo": "A471"
  },
  {
    "nome": "alv",
    "codigo": "A472"
  },
  {
    "nome": "alvare",
    "codigo": "A473"
  },
  {
    "nome": "alve",
    "codigo": "A474"
  },
  {
    "nome": "alvi",
    "codigo": "A475"
  },
  {
    "nome": "alvo",
    "codigo": "A476"
  },
  {
    "nome": "alw",
    "codigo": "A477"
  },
  {
    "nome": "alz",
    "codigo": "A478"
  },
  {
    "nome": "ama",
    "codigo": "A479"
  },
  {
    "nome": "amad",
    "codigo": "A481"
  },
  {
    "nome": "amal",
    "codigo": "A482"
  },
  {
    "nome": "amalt",
    "codigo": "A483"
  },
  {
    "nome": "aman",
    "codigo": "A484"
  },
  {
    "nome": "amar",
    "codigo": "A485"
  },
  {
    "nome": "amas",
    "codigo": "A486"
  },
  {
    "nome": "amat",
    "codigo": "A487"
  },
  {
    "nome": "amato",
    "codigo": "A488"
  },
  {
    "nome": "amau",
    "codigo": "A489"
  },
  {
    "nome": "amb",
    "codigo": "A491"
  },
  {
    "nome": "ambi",
    "codigo": "A492"
  },
  {
    "nome": "ambl",
    "codigo": "A493"
  },
  {
    "nome": "ambo",
    "codigo": "A494"
  },
  {
    "nome": "ambr",
    "codigo": "A495"
  },
  {
    "nome": "ambros",
    "codigo": "A496"
  },
  {
    "nome": "ambu",
    "codigo": "A497"
  },
  {
    "nome": "ame",
    "codigo": "A498"
  },
  {
    "nome": "amelo",
    "codigo": "A499"
  },
  {
    "nome": "amen",
    "codigo": "A511"
  },
  {
    "nome": "amer",
    "codigo": "A512"
  },
  {
    "nome": "ames",
    "codigo": "A513"
  },
  {
    "nome": "ames m",
    "codigo": "A514"
  },
  {
    "nome": "amh",
    "codigo": "A515"
  },
  {
    "nome": "ami",
    "codigo": "A516"
  },
  {
    "nome": "amin",
    "codigo": "A517"
  },
  {
    "nome": "amm",
    "codigo": "A518"
  },
  {
    "nome": "ammir",
    "codigo": "A519"
  },
  {
    "nome": "ammo",
    "codigo": "A521"
  },
  {
    "nome": "amn",
    "codigo": "A522"
  },
  {
    "nome": "amo",
    "codigo": "A523"
  },
  {
    "nome": "amor",
    "codigo": "A524"
  },
  {
    "nome": "amos",
    "codigo": "A525"
  },
  {
    "nome": "amp",
    "codigo": "A526"
  },
  {
    "nome": "amps",
    "codigo": "A527"
  },
  {
    "nome": "ams",
    "codigo": "A528"
  },
  {
    "nome": "amu",
    "codigo": "A529"
  },
  {
    "nome": "amy",
    "codigo": "A531"
  },
  {
    "nome": "ana",
    "codigo": "A532"
  },
  {
    "nome": "anam",
    "codigo": "A533"
  },
  {
    "nome": "anas",
    "codigo": "A534"
  },
  {
    "nome": "anat",
    "codigo": "A535"
  },
  {
    "nome": "anax",
    "codigo": "A536"
  },
  {
    "nome": "anb",
    "codigo": "A537"
  },
  {
    "nome": "anc",
    "codigo": "A538"
  },
  {
    "nome": "anch",
    "codigo": "A539"
  },
  {
    "nome": "anci",
    "codigo": "A541"
  },
  {
    "nome": "anco",
    "codigo": "A542"
  },
  {
    "nome": "and",
    "codigo": "A543"
  },
  {
    "nome": "anders",
    "codigo": "A544"
  },
  {
    "nome": "anderson",
    "codigo": "A545"
  },
  {
    "nome": "anderson d",
    "codigo": "A546"
  },
  {
    "nome": "anderson j",
    "codigo": "A547"
  },
  {
    "nome": "anderson m",
    "codigo": "A548"
  },
  {
    "nome": "anderson r",
    "codigo": "A549"
  },
  {
    "nome": "anderson t",
    "codigo": "A551"
  },
  {
    "nome": "anderson w",
    "codigo": "A552"
  },
  {
    "nome": "andr",
    "codigo": "A553"
  },
  {
    "nome": "andral",
    "codigo": "A554"
  },
  {
    "nome": "andre",
    "codigo": "A555"
  },
  {
    "nome": "andrea",
    "codigo": "A556"
  },
  {
    "nome": "andreas",
    "codigo": "A557"
  },
  {
    "nome": "andree",
    "codigo": "A558"
  },
  {
    "nome": "andrei",
    "codigo": "A559"
  },
  {
    "nome": "andres",
    "codigo": "A561"
  },
  {
    "nome": "andrew",
    "codigo": "A562"
  },
  {
    "nome": "andrew m",
    "codigo": "A563"
  },
  {
    "nome": "andrewe",
    "codigo": "A564"
  },
  {
    "nome": "andrews",
    "codigo": "A565"
  },
  {
    "nome": "andrews e",
    "codigo": "A566"
  },
  {
    "nome": "andrews j",
    "codigo": "A567"
  },
  {
    "nome": "andrews m",
    "codigo": "A568"
  },
  {
    "nome": "andrews r",
    "codigo": "A569"
  },
  {
    "nome": "andrews t",
    "codigo": "A571"
  },
  {
    "nome": "andrews w",
    "codigo": "A572"
  },
  {
    "nome": "andri",
    "codigo": "A573"
  },
  {
    "nome": "andro",
    "codigo": "A574"
  },
  {
    "nome": "andron",
    "codigo": "A575"
  },
  {
    "nome": "andros",
    "codigo": "A576"
  },
  {
    "nome": "andry",
    "codigo": "A577"
  },
  {
    "nome": "ane",
    "codigo": "A578"
  },
  {
    "nome": "aner",
    "codigo": "A579"
  },
  {
    "nome": "ang",
    "codigo": "A581"
  },
  {
    "nome": "angeli",
    "codigo": "A582"
  },
  {
    "nome": "angell",
    "codigo": "A583"
  },
  {
    "nome": "angelo",
    "codigo": "A584"
  },
  {
    "nome": "angelu",
    "codigo": "A585"
  },
  {
    "nome": "angen",
    "codigo": "A586"
  },
  {
    "nome": "anger",
    "codigo": "A587"
  },
  {
    "nome": "angi",
    "codigo": "A588"
  },
  {
    "nome": "angl",
    "codigo": "A589"
  },
  {
    "nome": "anglu",
    "codigo": "A591"
  },
  {
    "nome": "ango",
    "codigo": "A592"
  },
  {
    "nome": "angou",
    "codigo": "A593"
  },
  {
    "nome": "angu",
    "codigo": "A594"
  },
  {
    "nome": "angus",
    "codigo": "A595"
  },
  {
    "nome": "anh",
    "codigo": "A596"
  },
  {
    "nome": "ani",
    "codigo": "A597"
  },
  {
    "nome": "anim",
    "codigo": "A598"
  },
  {
    "nome": "anis",
    "codigo": "A599"
  },
  {
    "nome": "ank",
    "codigo": "A611"
  },
  {
    "nome": "anl",
    "codigo": "A612"
  },
  {
    "nome": "ann",
    "codigo": "A613"
  },
  {
    "nome": "annes",
    "codigo": "A614"
  },
  {
    "nome": "anni",
    "codigo": "A615"
  },
  {
    "nome": "anq",
    "codigo": "A616"
  },
  {
    "nome": "ans",
    "codigo": "A617"
  },
  {
    "nome": "ansel",
    "codigo": "A618"
  },
  {
    "nome": "ansi",
    "codigo": "A619"
  },
  {
    "nome": "ansl",
    "codigo": "A621"
  },
  {
    "nome": "anso",
    "codigo": "A622"
  },
  {
    "nome": "ansp",
    "codigo": "A623"
  },
  {
    "nome": "anst",
    "codigo": "A624"
  },
  {
    "nome": "anstey",
    "codigo": "A625"
  },
  {
    "nome": "ansti",
    "codigo": "A626"
  },
  {
    "nome": "ant",
    "codigo": "A627"
  },
  {
    "nome": "antho",
    "codigo": "A628"
  },
  {
    "nome": "anti",
    "codigo": "A629"
  },
  {
    "nome": "antim",
    "codigo": "A631"
  },
  {
    "nome": "antio",
    "codigo": "A632"
  },
  {
    "nome": "antip",
    "codigo": "A633"
  },
  {
    "nome": "anto",
    "codigo": "A634"
  },
  {
    "nome": "antoni",
    "codigo": "A635"
  },
  {
    "nome": "antr",
    "codigo": "A636"
  },
  {
    "nome": "anv",
    "codigo": "A637"
  },
  {
    "nome": "ao",
    "codigo": "A638"
  },
  {
    "nome": "ap",
    "codigo": "A639"
  },
  {
    "nome": "apel",
    "codigo": "A641"
  },
  {
    "nome": "api",
    "codigo": "A642"
  },
  {
    "nome": "apo",
    "codigo": "A643"
  },
  {
    "nome": "apollo",
    "codigo": "A644"
  },
  {
    "nome": "apos",
    "codigo": "A645"
  },
  {
    "nome": "app",
    "codigo": "A646"
  },
  {
    "nome": "appi",
    "codigo": "A647"
  },
  {
    "nome": "appl",
    "codigo": "A648"
  },
  {
    "nome": "appleton",
    "codigo": "A649"
  },
  {
    "nome": "appleton j",
    "codigo": "A651"
  },
  {
    "nome": "appleton t",
    "codigo": "A652"
  },
  {
    "nome": "appu",
    "codigo": "A653"
  },
  {
    "nome": "apr",
    "codigo": "A654"
  },
  {
    "nome": "apt",
    "codigo": "A655"
  },
  {
    "nome": "aqu",
    "codigo": "A656"
  },
  {
    "nome": "aquin",
    "codigo": "A657"
  },
  {
    "nome": "ara",
    "codigo": "A658"
  },
  {
    "nome": "arag",
    "codigo": "A659"
  },
  {
    "nome": "aram",
    "codigo": "A661"
  },
  {
    "nome": "aran",
    "codigo": "A662"
  },
  {
    "nome": "arat",
    "codigo": "A663"
  },
  {
    "nome": "arb",
    "codigo": "A664"
  },
  {
    "nome": "arbl",
    "codigo": "A665"
  },
  {
    "nome": "arbo",
    "codigo": "A666"
  },
  {
    "nome": "arbu",
    "codigo": "A667"
  },
  {
    "nome": "arc",
    "codigo": "A668"
  },
  {
    "nome": "arch",
    "codigo": "A669"
  },
  {
    "nome": "archer",
    "codigo": "A671"
  },
  {
    "nome": "archer m",
    "codigo": "A672"
  },
  {
    "nome": "archi",
    "codigo": "A673"
  },
  {
    "nome": "arci",
    "codigo": "A674"
  },
  {
    "nome": "arco",
    "codigo": "A675"
  },
  {
    "nome": "ard",
    "codigo": "A676"
  },
  {
    "nome": "ardo",
    "codigo": "A677"
  },
  {
    "nome": "are",
    "codigo": "A678"
  },
  {
    "nome": "areh",
    "codigo": "A679"
  },
  {
    "nome": "aren",
    "codigo": "A681"
  },
  {
    "nome": "aret",
    "codigo": "A682"
  },
  {
    "nome": "aretin",
    "codigo": "A683"
  },
  {
    "nome": "arez",
    "codigo": "A684"
  },
  {
    "nome": "arf",
    "codigo": "A685"
  },
  {
    "nome": "arg",
    "codigo": "A686"
  },
  {
    "nome": "argel",
    "codigo": "A687"
  },
  {
    "nome": "argen",
    "codigo": "A688"
  },
  {
    "nome": "argent",
    "codigo": "A689"
  },
  {
    "nome": "argenti",
    "codigo": "A691"
  },
  {
    "nome": "argi",
    "codigo": "A692"
  },
  {
    "nome": "argo",
    "codigo": "A693"
  },
  {
    "nome": "argu",
    "codigo": "A694"
  },
  {
    "nome": "argy",
    "codigo": "A695"
  },
  {
    "nome": "ari",
    "codigo": "A696"
  },
  {
    "nome": "arib",
    "codigo": "A697"
  },
  {
    "nome": "arid",
    "codigo": "A698"
  },
  {
    "nome": "arig",
    "codigo": "A699"
  },
  {
    "nome": "arin",
    "codigo": "A711"
  },
  {
    "nome": "ario",
    "codigo": "A712"
  },
  {
    "nome": "arip",
    "codigo": "A713"
  },
  {
    "nome": "aris",
    "codigo": "A714"
  },
  {
    "nome": "aristi",
    "codigo": "A715"
  },
  {
    "nome": "aristo",
    "codigo": "A716"
  },
  {
    "nome": "aristop",
    "codigo": "A717"
  },
  {
    "nome": "ariu",
    "codigo": "A718"
  },
  {
    "nome": "ariz",
    "codigo": "A719"
  },
  {
    "nome": "ark",
    "codigo": "A721"
  },
  {
    "nome": "arkw",
    "codigo": "A722"
  },
  {
    "nome": "arl",
    "codigo": "A723"
  },
  {
    "nome": "arling",
    "codigo": "A724"
  },
  {
    "nome": "arlo",
    "codigo": "A725"
  },
  {
    "nome": "arlu",
    "codigo": "A726"
  },
  {
    "nome": "arm",
    "codigo": "A727"
  },
  {
    "nome": "arme",
    "codigo": "A728"
  },
  {
    "nome": "armi",
    "codigo": "A729"
  },
  {
    "nome": "armis",
    "codigo": "A731"
  },
  {
    "nome": "armit",
    "codigo": "A732"
  },
  {
    "nome": "armitage m",
    "codigo": "A733"
  },
  {
    "nome": "arms",
    "codigo": "A734"
  },
  {
    "nome": "armstrong",
    "codigo": "A735"
  },
  {
    "nome": "armstrong j",
    "codigo": "A736"
  },
  {
    "nome": "armstrong m",
    "codigo": "A737"
  },
  {
    "nome": "armstrong s",
    "codigo": "A738"
  },
  {
    "nome": "armstrong w",
    "codigo": "A739"
  },
  {
    "nome": "army",
    "codigo": "A741"
  },
  {
    "nome": "arn",
    "codigo": "A742"
  },
  {
    "nome": "arnal",
    "codigo": "A743"
  },
  {
    "nome": "arnau",
    "codigo": "A744"
  },
  {
    "nome": "arnaul",
    "codigo": "A745"
  },
  {
    "nome": "arnay",
    "codigo": "A746"
  },
  {
    "nome": "arnd",
    "codigo": "A747"
  },
  {
    "nome": "arni",
    "codigo": "A749"
  },
  {
    "nome": "arno",
    "codigo": "A751"
  },
  {
    "nome": "arnold",
    "codigo": "A752"
  },
  {
    "nome": "arnold d",
    "codigo": "A753"
  },
  {
    "nome": "arnold g",
    "codigo": "A754"
  },
  {
    "nome": "arnold h",
    "codigo": "A755"
  },
  {
    "nome": "arnold j",
    "codigo": "A756"
  },
  {
    "nome": "arnold m",
    "codigo": "A757"
  },
  {
    "nome": "arnold r",
    "codigo": "A758"
  },
  {
    "nome": "arnold t",
    "codigo": "A759"
  },
  {
    "nome": "arnold w",
    "codigo": "A761"
  },
  {
    "nome": "arnoldi",
    "codigo": "A762"
  },
  {
    "nome": "arnon",
    "codigo": "A763"
  },
  {
    "nome": "arnot",
    "codigo": "A764"
  },
  {
    "nome": "arnou",
    "codigo": "A765"
  },
  {
    "nome": "arnoult",
    "codigo": "A766"
  },
  {
    "nome": "arns",
    "codigo": "A767"
  },
  {
    "nome": "arnu",
    "codigo": "A768"
  },
  {
    "nome": "aro",
    "codigo": "A769"
  },
  {
    "nome": "arou",
    "codigo": "A771"
  },
  {
    "nome": "arp",
    "codigo": "A772"
  },
  {
    "nome": "arr",
    "codigo": "A773"
  },
  {
    "nome": "arre",
    "codigo": "A774"
  },
  {
    "nome": "arri",
    "codigo": "A775"
  },
  {
    "nome": "arrig",
    "codigo": "A776"
  },
  {
    "nome": "arriv",
    "codigo": "A777"
  },
  {
    "nome": "arro",
    "codigo": "A778"
  },
  {
    "nome": "arrows",
    "codigo": "A779"
  },
  {
    "nome": "ars",
    "codigo": "A781"
  },
  {
    "nome": "arsi",
    "codigo": "A782"
  },
  {
    "nome": "arsl",
    "codigo": "A783"
  },
  {
    "nome": "art",
    "codigo": "A784"
  },
  {
    "nome": "artau",
    "codigo": "A785"
  },
  {
    "nome": "arte",
    "codigo": "A786"
  },
  {
    "nome": "arth",
    "codigo": "A787"
  },
  {
    "nome": "arthur",
    "codigo": "A788"
  },
  {
    "nome": "arthur m",
    "codigo": "A789"
  },
  {
    "nome": "arthur s",
    "codigo": "A791"
  },
  {
    "nome": "arto",
    "codigo": "A792"
  },
  {
    "nome": "aru",
    "codigo": "A793"
  },
  {
    "nome": "arunt",
    "codigo": "A794"
  },
  {
    "nome": "arv",
    "codigo": "A795"
  },
  {
    "nome": "arw",
    "codigo": "A796"
  },
  {
    "nome": "arz",
    "codigo": "A797"
  },
  {
    "nome": "asa",
    "codigo": "A798"
  },
  {
    "nome": "asb",
    "codigo": "A799"
  },
  {
    "nome": "asc",
    "codigo": "A811"
  },
  {
    "nome": "asch",
    "codigo": "A812"
  },
  {
    "nome": "aschen",
    "codigo": "A813"
  },
  {
    "nome": "ascl",
    "codigo": "A814"
  },
  {
    "nome": "asco",
    "codigo": "A815"
  },
  {
    "nome": "ase",
    "codigo": "A816"
  },
  {
    "nome": "asf",
    "codigo": "A817"
  },
  {
    "nome": "asg",
    "codigo": "A818"
  },
  {
    "nome": "ash",
    "codigo": "A819"
  },
  {
    "nome": "ashbu",
    "codigo": "A821"
  },
  {
    "nome": "ashburt",
    "codigo": "A822"
  },
  {
    "nome": "ashby",
    "codigo": "A823"
  },
  {
    "nome": "ashe",
    "codigo": "A824"
  },
  {
    "nome": "asher",
    "codigo": "A825"
  },
  {
    "nome": "ashl",
    "codigo": "A826"
  },
  {
    "nome": "ashm",
    "codigo": "A827"
  },
  {
    "nome": "asht",
    "codigo": "A828"
  },
  {
    "nome": "ashton m",
    "codigo": "A829"
  },
  {
    "nome": "ashw",
    "codigo": "A831"
  },
  {
    "nome": "asi",
    "codigo": "A832"
  },
  {
    "nome": "asio",
    "codigo": "A833"
  },
  {
    "nome": "ask",
    "codigo": "A834"
  },
  {
    "nome": "askew",
    "codigo": "A835"
  },
  {
    "nome": "asm",
    "codigo": "A836"
  },
  {
    "nome": "aso",
    "codigo": "A837"
  },
  {
    "nome": "asp",
    "codigo": "A838"
  },
  {
    "nome": "asper",
    "codigo": "A839"
  },
  {
    "nome": "aspi",
    "codigo": "A841"
  },
  {
    "nome": "aspl",
    "codigo": "A842"
  },
  {
    "nome": "aspr",
    "codigo": "A843"
  },
  {
    "nome": "ass",
    "codigo": "A844"
  },
  {
    "nome": "assen",
    "codigo": "A845"
  },
  {
    "nome": "asser",
    "codigo": "A846"
  },
  {
    "nome": "assh",
    "codigo": "A847"
  },
  {
    "nome": "assi",
    "codigo": "A848"
  },
  {
    "nome": "asso",
    "codigo": "A849"
  },
  {
    "nome": "assu",
    "codigo": "A851"
  },
  {
    "nome": "ast",
    "codigo": "A852"
  },
  {
    "nome": "aste",
    "codigo": "A853"
  },
  {
    "nome": "asti",
    "codigo": "A854"
  },
  {
    "nome": "astl",
    "codigo": "A855"
  },
  {
    "nome": "asto",
    "codigo": "A856"
  },
  {
    "nome": "aston",
    "codigo": "A857"
  },
  {
    "nome": "astor",
    "codigo": "A858"
  },
  {
    "nome": "astr",
    "codigo": "A859"
  },
  {
    "nome": "asu",
    "codigo": "A861"
  },
  {
    "nome": "ata",
    "codigo": "A862"
  },
  {
    "nome": "atch",
    "codigo": "A863"
  },
  {
    "nome": "ate",
    "codigo": "A864"
  },
  {
    "nome": "ath",
    "codigo": "A865"
  },
  {
    "nome": "athe",
    "codigo": "A866"
  },
  {
    "nome": "athen",
    "codigo": "A867"
  },
  {
    "nome": "ather",
    "codigo": "A868"
  },
  {
    "nome": "atherton m",
    "codigo": "A869"
  },
  {
    "nome": "athi",
    "codigo": "A871"
  },
  {
    "nome": "ati",
    "codigo": "A872"
  },
  {
    "nome": "atk",
    "codigo": "A873"
  },
  {
    "nome": "atkins m",
    "codigo": "A874"
  },
  {
    "nome": "atkinson",
    "codigo": "A875"
  },
  {
    "nome": "atkinson j",
    "codigo": "A876"
  },
  {
    "nome": "atkinson m",
    "codigo": "A877"
  },
  {
    "nome": "atkinson t",
    "codigo": "A878"
  },
  {
    "nome": "atky",
    "codigo": "A879"
  },
  {
    "nome": "atl",
    "codigo": "A881"
  },
  {
    "nome": "atr",
    "codigo": "A882"
  },
  {
    "nome": "att",
    "codigo": "A883"
  },
  {
    "nome": "atter",
    "codigo": "A884"
  },
  {
    "nome": "atti",
    "codigo": "A885"
  },
  {
    "nome": "attw",
    "codigo": "A886"
  },
  {
    "nome": "atw",
    "codigo": "A887"
  },
  {
    "nome": "aub",
    "codigo": "A888"
  },
  {
    "nome": "aubert",
    "codigo": "A889"
  },
  {
    "nome": "aubery",
    "codigo": "A891"
  },
  {
    "nome": "aubes",
    "codigo": "A892"
  },
  {
    "nome": "aubi",
    "codigo": "A893"
  },
  {
    "nome": "aubin",
    "codigo": "A894"
  },
  {
    "nome": "aubr",
    "codigo": "A895"
  },
  {
    "nome": "aubry",
    "codigo": "A896"
  },
  {
    "nome": "aubu",
    "codigo": "A897"
  },
  {
    "nome": "auc",
    "codigo": "A898"
  },
  {
    "nome": "aud",
    "codigo": "A899"
  },
  {
    "nome": "audi",
    "codigo": "A911"
  },
  {
    "nome": "audin",
    "codigo": "A912"
  },
  {
    "nome": "audl",
    "codigo": "A913"
  },
  {
    "nome": "audo",
    "codigo": "A914"
  },
  {
    "nome": "audr",
    "codigo": "A915"
  },
  {
    "nome": "audu",
    "codigo": "A916"
  },
  {
    "nome": "aue",
    "codigo": "A917"
  },
  {
    "nome": "auf",
    "codigo": "A918"
  },
  {
    "nome": "aug",
    "codigo": "A919"
  },
  {
    "nome": "augi",
    "codigo": "A921"
  },
  {
    "nome": "augu",
    "codigo": "A922"
  },
  {
    "nome": "augus",
    "codigo": "A923"
  },
  {
    "nome": "aul",
    "codigo": "A924"
  },
  {
    "nome": "aum",
    "codigo": "A925"
  },
  {
    "nome": "aun",
    "codigo": "A926"
  },
  {
    "nome": "aur",
    "codigo": "A927"
  },
  {
    "nome": "auri",
    "codigo": "A928"
  },
  {
    "nome": "auriv",
    "codigo": "A929"
  },
  {
    "nome": "auro",
    "codigo": "A931"
  },
  {
    "nome": "aus",
    "codigo": "A932"
  },
  {
    "nome": "austen",
    "codigo": "A933"
  },
  {
    "nome": "austen m",
    "codigo": "A934"
  },
  {
    "nome": "austin",
    "codigo": "A935"
  },
  {
    "nome": "austin j",
    "codigo": "A936"
  },
  {
    "nome": "austin m",
    "codigo": "A937"
  },
  {
    "nome": "austin t",
    "codigo": "A938"
  },
  {
    "nome": "aut",
    "codigo": "A939"
  },
  {
    "nome": "autr",
    "codigo": "A941"
  },
  {
    "nome": "auv",
    "codigo": "A942"
  },
  {
    "nome": "aux",
    "codigo": "A943"
  },
  {
    "nome": "auz",
    "codigo": "A944"
  },
  {
    "nome": "ava",
    "codigo": "A945"
  },
  {
    "nome": "avan",
    "codigo": "A946"
  },
  {
    "nome": "avau",
    "codigo": "A947"
  },
  {
    "nome": "ave",
    "codigo": "A948"
  },
  {
    "nome": "avell",
    "codigo": "A949"
  },
  {
    "nome": "aven",
    "codigo": "A951"
  },
  {
    "nome": "aver",
    "codigo": "A952"
  },
  {
    "nome": "avero",
    "codigo": "A953"
  },
  {
    "nome": "avery",
    "codigo": "A954"
  },
  {
    "nome": "avery m",
    "codigo": "A955"
  },
  {
    "nome": "avez",
    "codigo": "A956"
  },
  {
    "nome": "avi",
    "codigo": "A957"
  },
  {
    "nome": "avil",
    "codigo": "A958"
  },
  {
    "nome": "avit",
    "codigo": "A959"
  },
  {
    "nome": "avo",
    "codigo": "A961"
  },
  {
    "nome": "avos",
    "codigo": "A962"
  },
  {
    "nome": "avr",
    "codigo": "A963"
  },
  {
    "nome": "awa",
    "codigo": "A964"
  },
  {
    "nome": "awb",
    "codigo": "A965"
  },
  {
    "nome": "awd",
    "codigo": "A966"
  },
  {
    "nome": "awi",
    "codigo": "A967"
  },
  {
    "nome": "ax",
    "codigo": "A968"
  },
  {
    "nome": "axel",
    "codigo": "A969"
  },
  {
    "nome": "axo",
    "codigo": "A971"
  },
  {
    "nome": "axt",
    "codigo": "A972"
  },
  {
    "nome": "aya",
    "codigo": "A973"
  },
  {
    "nome": "ayc",
    "codigo": "A974"
  },
  {
    "nome": "ayd",
    "codigo": "A975"
  },
  {
    "nome": "aye",
    "codigo": "A976"
  },
  {
    "nome": "ayers",
    "codigo": "A977"
  },
  {
    "nome": "ayl",
    "codigo": "A978"
  },
  {
    "nome": "aylm",
    "codigo": "A979"
  },
  {
    "nome": "aylw",
    "codigo": "A981"
  },
  {
    "nome": "aym",
    "codigo": "A982"
  },
  {
    "nome": "ayn",
    "codigo": "A983"
  },
  {
    "nome": "ayr",
    "codigo": "A984"
  },
  {
    "nome": "ayres",
    "codigo": "A985"
  },
  {
    "nome": "ayrt",
    "codigo": "A986"
  },
  {
    "nome": "ays",
    "codigo": "A987"
  },
  {
    "nome": "ayt",
    "codigo": "A988"
  },
  {
    "nome": "ayton",
    "codigo": "A989"
  },
  {
    "nome": "aza",
    "codigo": "A991"
  },
  {
    "nome": "azar",
    "codigo": "A992"
  },
  {
    "nome": "aze",
    "codigo": "A993"
  },
  {
    "nome": "azev",
    "codigo": "A994"
  },
  {
    "nome": "azi",
    "codigo": "A995"
  },
  {
    "nome": "azo",
    "codigo": "A996"
  },
  {
    "nome": "azr",
    "codigo": "A997"
  },
  {
    "nome": "azy",
    "codigo": "A998"
  },
  {
    "nome": "azz",
    "codigo": "A999"
  },
  {
    "nome": "b",
    "codigo": "B111"
  },
  {
    "nome": "ba",
    "codigo": "B111"
  },
  {
    "nome": "bab",
    "codigo": "B112"
  },
  {
    "nome": "babe",
    "codigo": "B113"
  },
  {
    "nome": "babi",
    "codigo": "B114"
  },
  {
    "nome": "babr",
    "codigo": "B115"
  },
  {
    "nome": "bac",
    "codigo": "B116"
  },
  {
    "nome": "bacci",
    "codigo": "B117"
  },
  {
    "nome": "bach",
    "codigo": "B118"
  },
  {
    "nome": "bache",
    "codigo": "B119"
  },
  {
    "nome": "bachell",
    "codigo": "B121"
  },
  {
    "nome": "bachet",
    "codigo": "B122"
  },
  {
    "nome": "bachi",
    "codigo": "B123"
  },
  {
    "nome": "bachm",
    "codigo": "B124"
  },
  {
    "nome": "baci",
    "codigo": "B125"
  },
  {
    "nome": "back",
    "codigo": "B126"
  },
  {
    "nome": "bacm",
    "codigo": "B127"
  },
  {
    "nome": "baco",
    "codigo": "B128"
  },
  {
    "nome": "bacon m",
    "codigo": "B129"
  },
  {
    "nome": "bacr",
    "codigo": "B131"
  },
  {
    "nome": "bad",
    "codigo": "B132"
  },
  {
    "nome": "bade",
    "codigo": "B133"
  },
  {
    "nome": "baden",
    "codigo": "B134"
  },
  {
    "nome": "badg",
    "codigo": "B135"
  },
  {
    "nome": "badi",
    "codigo": "B136"
  },
  {
    "nome": "bado",
    "codigo": "B137"
  },
  {
    "nome": "badr",
    "codigo": "B138"
  },
  {
    "nome": "bae",
    "codigo": "B139"
  },
  {
    "nome": "baer",
    "codigo": "B141"
  },
  {
    "nome": "baert",
    "codigo": "B142"
  },
  {
    "nome": "baf",
    "codigo": "B143"
  },
  {
    "nome": "bag",
    "codigo": "B144"
  },
  {
    "nome": "bagi",
    "codigo": "B145"
  },
  {
    "nome": "bagl",
    "codigo": "B146"
  },
  {
    "nome": "bagn",
    "codigo": "B147"
  },
  {
    "nome": "bago",
    "codigo": "B148"
  },
  {
    "nome": "bags",
    "codigo": "B149"
  },
  {
    "nome": "bah",
    "codigo": "B151"
  },
  {
    "nome": "bai",
    "codigo": "B152"
  },
  {
    "nome": "bail",
    "codigo": "B153"
  },
  {
    "nome": "baile",
    "codigo": "B154"
  },
  {
    "nome": "bailey l",
    "codigo": "B155"
  },
  {
    "nome": "bailey s",
    "codigo": "B156"
  },
  {
    "nome": "baill",
    "codigo": "B157"
  },
  {
    "nome": "baillo",
    "codigo": "B158"
  },
  {
    "nome": "bails",
    "codigo": "B159"
  },
  {
    "nome": "baily",
    "codigo": "B161"
  },
  {
    "nome": "bain",
    "codigo": "B162"
  },
  {
    "nome": "bair",
    "codigo": "B163"
  },
  {
    "nome": "bait",
    "codigo": "B164"
  },
  {
    "nome": "baj",
    "codigo": "B165"
  },
  {
    "nome": "bak",
    "codigo": "B166"
  },
  {
    "nome": "bake",
    "codigo": "B167"
  },
  {
    "nome": "baker m",
    "codigo": "B168"
  },
  {
    "nome": "baks",
    "codigo": "B169"
  },
  {
    "nome": "bal",
    "codigo": "B171"
  },
  {
    "nome": "balb",
    "codigo": "B172"
  },
  {
    "nome": "balbo",
    "codigo": "B173"
  },
  {
    "nome": "balc",
    "codigo": "B174"
  },
  {
    "nome": "bald",
    "codigo": "B175"
  },
  {
    "nome": "balder",
    "codigo": "B176"
  },
  {
    "nome": "baldi",
    "codigo": "B177"
  },
  {
    "nome": "baldo",
    "codigo": "B178"
  },
  {
    "nome": "baldu",
    "codigo": "B179"
  },
  {
    "nome": "baldw",
    "codigo": "B181"
  },
  {
    "nome": "baldwin m",
    "codigo": "B182"
  },
  {
    "nome": "bale",
    "codigo": "B183"
  },
  {
    "nome": "bales",
    "codigo": "B184"
  },
  {
    "nome": "balf",
    "codigo": "B185"
  },
  {
    "nome": "bali",
    "codigo": "B186"
  },
  {
    "nome": "ball",
    "codigo": "B187"
  },
  {
    "nome": "balla",
    "codigo": "B188"
  },
  {
    "nome": "ballar",
    "codigo": "B189"
  },
  {
    "nome": "balle",
    "codigo": "B191"
  },
  {
    "nome": "balli",
    "codigo": "B192"
  },
  {
    "nome": "ballo",
    "codigo": "B193"
  },
  {
    "nome": "balm",
    "codigo": "B194"
  },
  {
    "nome": "balo",
    "codigo": "B195"
  },
  {
    "nome": "bals",
    "codigo": "B196"
  },
  {
    "nome": "balt",
    "codigo": "B197"
  },
  {
    "nome": "balu",
    "codigo": "B198"
  },
  {
    "nome": "bam",
    "codigo": "B199"
  },
  {
    "nome": "bamp",
    "codigo": "B211"
  },
  {
    "nome": "ban",
    "codigo": "B212"
  },
  {
    "nome": "banc",
    "codigo": "B213"
  },
  {
    "nome": "band",
    "codigo": "B214"
  },
  {
    "nome": "bane",
    "codigo": "B215"
  },
  {
    "nome": "bang",
    "codigo": "B216"
  },
  {
    "nome": "bani",
    "codigo": "B217"
  },
  {
    "nome": "bank",
    "codigo": "B218"
  },
  {
    "nome": "bann",
    "codigo": "B219"
  },
  {
    "nome": "bao",
    "codigo": "B221"
  },
  {
    "nome": "bap",
    "codigo": "B222"
  },
  {
    "nome": "bar",
    "codigo": "B223"
  },
  {
    "nome": "barag",
    "codigo": "B224"
  },
  {
    "nome": "baran",
    "codigo": "B225"
  },
  {
    "nome": "barat",
    "codigo": "B226"
  },
  {
    "nome": "barau",
    "codigo": "B227"
  },
  {
    "nome": "barb",
    "codigo": "B228"
  },
  {
    "nome": "barbar",
    "codigo": "B229"
  },
  {
    "nome": "barbat",
    "codigo": "B231"
  },
  {
    "nome": "barbau",
    "codigo": "B232"
  },
  {
    "nome": "barbe",
    "codigo": "B233"
  },
  {
    "nome": "barber",
    "codigo": "B234"
  },
  {
    "nome": "barbet",
    "codigo": "B235"
  },
  {
    "nome": "barbi",
    "codigo": "B236"
  },
  {
    "nome": "barbil",
    "codigo": "B237"
  },
  {
    "nome": "barbo",
    "codigo": "B238"
  },
  {
    "nome": "barbou",
    "codigo": "B239"
  },
  {
    "nome": "barbu",
    "codigo": "B241"
  },
  {
    "nome": "barc",
    "codigo": "B242"
  },
  {
    "nome": "barch",
    "codigo": "B243"
  },
  {
    "nome": "barcl",
    "codigo": "B244"
  },
  {
    "nome": "bard",
    "codigo": "B245"
  },
  {
    "nome": "bardi",
    "codigo": "B246"
  },
  {
    "nome": "bardo",
    "codigo": "B247"
  },
  {
    "nome": "bare",
    "codigo": "B248"
  },
  {
    "nome": "barf",
    "codigo": "B249"
  },
  {
    "nome": "barg",
    "codigo": "B251"
  },
  {
    "nome": "bari",
    "codigo": "B252"
  },
  {
    "nome": "barin",
    "codigo": "B253"
  },
  {
    "nome": "bark",
    "codigo": "B254"
  },
  {
    "nome": "barker",
    "codigo": "B255"
  },
  {
    "nome": "barki",
    "codigo": "B256"
  },
  {
    "nome": "barl",
    "codigo": "B257"
  },
  {
    "nome": "barlo",
    "codigo": "B258"
  },
  {
    "nome": "barn",
    "codigo": "B259"
  },
  {
    "nome": "barnes",
    "codigo": "B261"
  },
  {
    "nome": "barnh",
    "codigo": "B262"
  },
  {
    "nome": "barnu",
    "codigo": "B263"
  },
  {
    "nome": "baro",
    "codigo": "B264"
  },
  {
    "nome": "baron",
    "codigo": "B265"
  },
  {
    "nome": "baroni",
    "codigo": "B266"
  },
  {
    "nome": "barot",
    "codigo": "B267"
  },
  {
    "nome": "barr",
    "codigo": "B268"
  },
  {
    "nome": "barras",
    "codigo": "B269"
  },
  {
    "nome": "barre",
    "codigo": "B271"
  },
  {
    "nome": "barrer",
    "codigo": "B272"
  },
  {
    "nome": "barret",
    "codigo": "B273"
  },
  {
    "nome": "barrett",
    "codigo": "B274"
  },
  {
    "nome": "barri",
    "codigo": "B275"
  },
  {
    "nome": "barrin",
    "codigo": "B276"
  },
  {
    "nome": "barro",
    "codigo": "B277"
  },
  {
    "nome": "barrow",
    "codigo": "B278"
  },
  {
    "nome": "barry",
    "codigo": "B279"
  },
  {
    "nome": "barry l",
    "codigo": "B281"
  },
  {
    "nome": "bars",
    "codigo": "B282"
  },
  {
    "nome": "bart",
    "codigo": "B283"
  },
  {
    "nome": "barth",
    "codigo": "B284"
  },
  {
    "nome": "barthel",
    "codigo": "B285"
  },
  {
    "nome": "bartho",
    "codigo": "B286"
  },
  {
    "nome": "bartholo",
    "codigo": "B287"
  },
  {
    "nome": "barti",
    "codigo": "B288"
  },
  {
    "nome": "bartl",
    "codigo": "B289"
  },
  {
    "nome": "bartlett m",
    "codigo": "B291"
  },
  {
    "nome": "barto",
    "codigo": "B292"
  },
  {
    "nome": "barton",
    "codigo": "B293"
  },
  {
    "nome": "bartr",
    "codigo": "B294"
  },
  {
    "nome": "baru",
    "codigo": "B295"
  },
  {
    "nome": "barw",
    "codigo": "B296"
  },
  {
    "nome": "bas",
    "codigo": "B297"
  },
  {
    "nome": "basc",
    "codigo": "B298"
  },
  {
    "nome": "base",
    "codigo": "B299"
  },
  {
    "nome": "basi",
    "codigo": "B311"
  },
  {
    "nome": "basili",
    "codigo": "B312"
  },
  {
    "nome": "basin",
    "codigo": "B313"
  },
  {
    "nome": "basir",
    "codigo": "B314"
  },
  {
    "nome": "bask",
    "codigo": "B315"
  },
  {
    "nome": "basn",
    "codigo": "B316"
  },
  {
    "nome": "bass",
    "codigo": "B317"
  },
  {
    "nome": "basse",
    "codigo": "B318"
  },
  {
    "nome": "basset",
    "codigo": "B319"
  },
  {
    "nome": "bassi",
    "codigo": "B321"
  },
  {
    "nome": "basso",
    "codigo": "B322"
  },
  {
    "nome": "bassu",
    "codigo": "B323"
  },
  {
    "nome": "bast",
    "codigo": "B324"
  },
  {
    "nome": "baste",
    "codigo": "B325"
  },
  {
    "nome": "basti",
    "codigo": "B326"
  },
  {
    "nome": "basto",
    "codigo": "B327"
  },
  {
    "nome": "bat",
    "codigo": "B328"
  },
  {
    "nome": "bates",
    "codigo": "B329"
  },
  {
    "nome": "bath",
    "codigo": "B331"
  },
  {
    "nome": "bathu",
    "codigo": "B332"
  },
  {
    "nome": "bati",
    "codigo": "B333"
  },
  {
    "nome": "bato",
    "codigo": "B334"
  },
  {
    "nome": "batt",
    "codigo": "B335"
  },
  {
    "nome": "batti",
    "codigo": "B336"
  },
  {
    "nome": "bau",
    "codigo": "B337"
  },
  {
    "nome": "baud",
    "codigo": "B338"
  },
  {
    "nome": "baudio",
    "codigo": "B339"
  },
  {
    "nome": "baudo",
    "codigo": "B341"
  },
  {
    "nome": "baudr",
    "codigo": "B342"
  },
  {
    "nome": "baudu",
    "codigo": "B343"
  },
  {
    "nome": "baue",
    "codigo": "B344"
  },
  {
    "nome": "bauf",
    "codigo": "B345"
  },
  {
    "nome": "baug",
    "codigo": "B346"
  },
  {
    "nome": "baum",
    "codigo": "B347"
  },
  {
    "nome": "baumg",
    "codigo": "B348"
  },
  {
    "nome": "baun",
    "codigo": "B349"
  },
  {
    "nome": "baur",
    "codigo": "B351"
  },
  {
    "nome": "baut",
    "codigo": "B352"
  },
  {
    "nome": "bav",
    "codigo": "B353"
  },
  {
    "nome": "bavi",
    "codigo": "B354"
  },
  {
    "nome": "bax",
    "codigo": "B355"
  },
  {
    "nome": "bay",
    "codigo": "B356"
  },
  {
    "nome": "baye",
    "codigo": "B357"
  },
  {
    "nome": "bayl",
    "codigo": "B358"
  },
  {
    "nome": "bayly",
    "codigo": "B359"
  },
  {
    "nome": "bayn",
    "codigo": "B361"
  },
  {
    "nome": "baz",
    "codigo": "B362"
  },
  {
    "nome": "bazi",
    "codigo": "B363"
  },
  {
    "nome": "bazo",
    "codigo": "B364"
  },
  {
    "nome": "be",
    "codigo": "B365"
  },
  {
    "nome": "beal",
    "codigo": "B366"
  },
  {
    "nome": "bean",
    "codigo": "B367"
  },
  {
    "nome": "bear",
    "codigo": "B368"
  },
  {
    "nome": "beat",
    "codigo": "B369"
  },
  {
    "nome": "beau",
    "codigo": "B371"
  },
  {
    "nome": "beauch",
    "codigo": "B372"
  },
  {
    "nome": "beaucl",
    "codigo": "B373"
  },
  {
    "nome": "beauf",
    "codigo": "B374"
  },
  {
    "nome": "beaug",
    "codigo": "B375"
  },
  {
    "nome": "beauh",
    "codigo": "B376"
  },
  {
    "nome": "beaul",
    "codigo": "B377"
  },
  {
    "nome": "beaum",
    "codigo": "B378"
  },
  {
    "nome": "beaumo",
    "codigo": "B379"
  },
  {
    "nome": "beaun",
    "codigo": "B381"
  },
  {
    "nome": "beaup",
    "codigo": "B382"
  },
  {
    "nome": "beaur",
    "codigo": "B383"
  },
  {
    "nome": "beaus",
    "codigo": "B384"
  },
  {
    "nome": "beauv",
    "codigo": "B385"
  },
  {
    "nome": "beauvo",
    "codigo": "B386"
  },
  {
    "nome": "beb",
    "codigo": "B387"
  },
  {
    "nome": "bec",
    "codigo": "B388"
  },
  {
    "nome": "bece",
    "codigo": "B389"
  },
  {
    "nome": "bech",
    "codigo": "B391"
  },
  {
    "nome": "bechs",
    "codigo": "B392"
  },
  {
    "nome": "beck",
    "codigo": "B393"
  },
  {
    "nome": "becke",
    "codigo": "B394"
  },
  {
    "nome": "becker",
    "codigo": "B395"
  },
  {
    "nome": "becker p",
    "codigo": "B396"
  },
  {
    "nome": "becki",
    "codigo": "B397"
  },
  {
    "nome": "becm",
    "codigo": "B398"
  },
  {
    "nome": "bed",
    "codigo": "B399"
  },
  {
    "nome": "bede",
    "codigo": "B411"
  },
  {
    "nome": "bedi",
    "codigo": "B412"
  },
  {
    "nome": "bedr",
    "codigo": "B413"
  },
  {
    "nome": "bee",
    "codigo": "B414"
  },
  {
    "nome": "beer",
    "codigo": "B415"
  },
  {
    "nome": "beg",
    "codigo": "B416"
  },
  {
    "nome": "begi",
    "codigo": "B417"
  },
  {
    "nome": "begu",
    "codigo": "B418"
  },
  {
    "nome": "beh",
    "codigo": "B419"
  },
  {
    "nome": "behr",
    "codigo": "B421"
  },
  {
    "nome": "bei",
    "codigo": "B422"
  },
  {
    "nome": "beis",
    "codigo": "B423"
  },
  {
    "nome": "bek",
    "codigo": "B424"
  },
  {
    "nome": "bel",
    "codigo": "B425"
  },
  {
    "nome": "belan",
    "codigo": "B426"
  },
  {
    "nome": "belch",
    "codigo": "B427"
  },
  {
    "nome": "bele",
    "codigo": "B428"
  },
  {
    "nome": "belg",
    "codigo": "B429"
  },
  {
    "nome": "beli",
    "codigo": "B431"
  },
  {
    "nome": "belk",
    "codigo": "B432"
  },
  {
    "nome": "bell",
    "codigo": "B433"
  },
  {
    "nome": "bell l",
    "codigo": "B434"
  },
  {
    "nome": "bell r",
    "codigo": "B435"
  },
  {
    "nome": "bellan",
    "codigo": "B436"
  },
  {
    "nome": "bellav",
    "codigo": "B437"
  },
  {
    "nome": "belle",
    "codigo": "B438"
  },
  {
    "nome": "belleg",
    "codigo": "B439"
  },
  {
    "nome": "bellen",
    "codigo": "B441"
  },
  {
    "nome": "beller",
    "codigo": "B442"
  },
  {
    "nome": "belli",
    "codigo": "B443"
  },
  {
    "nome": "bellin",
    "codigo": "B444"
  },
  {
    "nome": "bellm",
    "codigo": "B445"
  },
  {
    "nome": "bello",
    "codigo": "B446"
  },
  {
    "nome": "bellon",
    "codigo": "B447"
  },
  {
    "nome": "bellow",
    "codigo": "B448"
  },
  {
    "nome": "bellu",
    "codigo": "B449"
  },
  {
    "nome": "belm",
    "codigo": "B451"
  },
  {
    "nome": "belo",
    "codigo": "B452"
  },
  {
    "nome": "belt",
    "codigo": "B453"
  },
  {
    "nome": "belv",
    "codigo": "B454"
  },
  {
    "nome": "bem",
    "codigo": "B455"
  },
  {
    "nome": "ben",
    "codigo": "B456"
  },
  {
    "nome": "benc",
    "codigo": "B457"
  },
  {
    "nome": "bend",
    "codigo": "B458"
  },
  {
    "nome": "bendo",
    "codigo": "B459"
  },
  {
    "nome": "bene",
    "codigo": "B461"
  },
  {
    "nome": "benede",
    "codigo": "B462"
  },
  {
    "nome": "benedi",
    "codigo": "B463"
  },
  {
    "nome": "benef",
    "codigo": "B464"
  },
  {
    "nome": "benel",
    "codigo": "B465"
  },
  {
    "nome": "beng",
    "codigo": "B466"
  },
  {
    "nome": "beni",
    "codigo": "B467"
  },
  {
    "nome": "benj",
    "codigo": "B468"
  },
  {
    "nome": "benn",
    "codigo": "B469"
  },
  {
    "nome": "bennett",
    "codigo": "B471"
  },
  {
    "nome": "bennett m",
    "codigo": "B472"
  },
  {
    "nome": "beno",
    "codigo": "B473"
  },
  {
    "nome": "bens",
    "codigo": "B474"
  },
  {
    "nome": "bent",
    "codigo": "B475"
  },
  {
    "nome": "benth",
    "codigo": "B476"
  },
  {
    "nome": "bentl",
    "codigo": "B477"
  },
  {
    "nome": "bento",
    "codigo": "B478"
  },
  {
    "nome": "benw",
    "codigo": "B479"
  },
  {
    "nome": "beo",
    "codigo": "B481"
  },
  {
    "nome": "ber",
    "codigo": "B482"
  },
  {
    "nome": "berar",
    "codigo": "B483"
  },
  {
    "nome": "berau",
    "codigo": "B484"
  },
  {
    "nome": "berc",
    "codigo": "B485"
  },
  {
    "nome": "berck",
    "codigo": "B486"
  },
  {
    "nome": "bere",
    "codigo": "B487"
  },
  {
    "nome": "beren",
    "codigo": "B488"
  },
  {
    "nome": "berens",
    "codigo": "B489"
  },
  {
    "nome": "beres",
    "codigo": "B491"
  },
  {
    "nome": "beret",
    "codigo": "B492"
  },
  {
    "nome": "berg",
    "codigo": "B493"
  },
  {
    "nome": "bergan",
    "codigo": "B494"
  },
  {
    "nome": "berge",
    "codigo": "B495"
  },
  {
    "nome": "berger",
    "codigo": "B496"
  },
  {
    "nome": "berh",
    "codigo": "B497"
  },
  {
    "nome": "bergi",
    "codigo": "B498"
  },
  {
    "nome": "bergm",
    "codigo": "B499"
  },
  {
    "nome": "beri",
    "codigo": "B511"
  },
  {
    "nome": "berk",
    "codigo": "B512"
  },
  {
    "nome": "berkl",
    "codigo": "B513"
  },
  {
    "nome": "berl",
    "codigo": "B514"
  },
  {
    "nome": "berlin",
    "codigo": "B515"
  },
  {
    "nome": "berm",
    "codigo": "B516"
  },
  {
    "nome": "bern",
    "codigo": "B517"
  },
  {
    "nome": "bernar",
    "codigo": "B518"
  },
  {
    "nome": "bernard j",
    "codigo": "B519"
  },
  {
    "nome": "bernard m",
    "codigo": "B521"
  },
  {
    "nome": "bernard t",
    "codigo": "B522"
  },
  {
    "nome": "bernardi",
    "codigo": "B523"
  },
  {
    "nome": "bernat",
    "codigo": "B524"
  },
  {
    "nome": "berne",
    "codigo": "B525"
  },
  {
    "nome": "bernet",
    "codigo": "B526"
  },
  {
    "nome": "bernh",
    "codigo": "B527"
  },
  {
    "nome": "berni",
    "codigo": "B528"
  },
  {
    "nome": "berno",
    "codigo": "B529"
  },
  {
    "nome": "berns",
    "codigo": "B531"
  },
  {
    "nome": "bero",
    "codigo": "B532"
  },
  {
    "nome": "berr",
    "codigo": "B533"
  },
  {
    "nome": "berry",
    "codigo": "B534"
  },
  {
    "nome": "bers",
    "codigo": "B535"
  },
  {
    "nome": "bert",
    "codigo": "B536"
  },
  {
    "nome": "berte",
    "codigo": "B537"
  },
  {
    "nome": "berth",
    "codigo": "B538"
  },
  {
    "nome": "berthe",
    "codigo": "B539"
  },
  {
    "nome": "berthi",
    "codigo": "B541"
  },
  {
    "nome": "bertho",
    "codigo": "B542"
  },
  {
    "nome": "berti",
    "codigo": "B543"
  },
  {
    "nome": "bertin",
    "codigo": "B544"
  },
  {
    "nome": "berto",
    "codigo": "B545"
  },
  {
    "nome": "bertol",
    "codigo": "B546"
  },
  {
    "nome": "berton",
    "codigo": "B547"
  },
  {
    "nome": "bertr",
    "codigo": "B548"
  },
  {
    "nome": "bertrand f",
    "codigo": "B549"
  },
  {
    "nome": "bertrand n",
    "codigo": "B551"
  },
  {
    "nome": "bertu",
    "codigo": "B552"
  },
  {
    "nome": "berw",
    "codigo": "B553"
  },
  {
    "nome": "bes",
    "codigo": "B554"
  },
  {
    "nome": "besl",
    "codigo": "B555"
  },
  {
    "nome": "beso",
    "codigo": "B556"
  },
  {
    "nome": "bess",
    "codigo": "B557"
  },
  {
    "nome": "bessem",
    "codigo": "B558"
  },
  {
    "nome": "bessi",
    "codigo": "B559"
  },
  {
    "nome": "best",
    "codigo": "B561"
  },
  {
    "nome": "bet",
    "codigo": "B562"
  },
  {
    "nome": "bethm",
    "codigo": "B563"
  },
  {
    "nome": "beto",
    "codigo": "B564"
  },
  {
    "nome": "bett",
    "codigo": "B565"
  },
  {
    "nome": "beu",
    "codigo": "B566"
  },
  {
    "nome": "beul",
    "codigo": "B567"
  },
  {
    "nome": "beus",
    "codigo": "B568"
  },
  {
    "nome": "beut",
    "codigo": "B569"
  },
  {
    "nome": "bev",
    "codigo": "B571"
  },
  {
    "nome": "bew",
    "codigo": "B572"
  },
  {
    "nome": "bey",
    "codigo": "B573"
  },
  {
    "nome": "bez",
    "codigo": "B574"
  },
  {
    "nome": "bh",
    "codigo": "B575"
  },
  {
    "nome": "bi",
    "codigo": "B576"
  },
  {
    "nome": "bian",
    "codigo": "B577"
  },
  {
    "nome": "bianco",
    "codigo": "B578"
  },
  {
    "nome": "biar",
    "codigo": "B579"
  },
  {
    "nome": "bib",
    "codigo": "B581"
  },
  {
    "nome": "bibl",
    "codigo": "B582"
  },
  {
    "nome": "bic",
    "codigo": "B583"
  },
  {
    "nome": "bid",
    "codigo": "B584"
  },
  {
    "nome": "bide",
    "codigo": "B585"
  },
  {
    "nome": "bie",
    "codigo": "B586"
  },
  {
    "nome": "biel",
    "codigo": "B587"
  },
  {
    "nome": "bien",
    "codigo": "B588"
  },
  {
    "nome": "bies",
    "codigo": "B589"
  },
  {
    "nome": "bif",
    "codigo": "B591"
  },
  {
    "nome": "big",
    "codigo": "B592"
  },
  {
    "nome": "bigl",
    "codigo": "B593"
  },
  {
    "nome": "bigo",
    "codigo": "B594"
  },
  {
    "nome": "bil",
    "codigo": "B595"
  },
  {
    "nome": "bill",
    "codigo": "B596"
  },
  {
    "nome": "bille",
    "codigo": "B597"
  },
  {
    "nome": "billi",
    "codigo": "B598"
  },
  {
    "nome": "billo",
    "codigo": "B599"
  },
  {
    "nome": "bim",
    "codigo": "B611"
  },
  {
    "nome": "bin",
    "codigo": "B612"
  },
  {
    "nome": "bing",
    "codigo": "B613"
  },
  {
    "nome": "binn",
    "codigo": "B614"
  },
  {
    "nome": "bio",
    "codigo": "B615"
  },
  {
    "nome": "bior",
    "codigo": "B616"
  },
  {
    "nome": "bir",
    "codigo": "B617"
  },
  {
    "nome": "bird",
    "codigo": "B618"
  },
  {
    "nome": "birk",
    "codigo": "B619"
  },
  {
    "nome": "bis",
    "codigo": "B621"
  },
  {
    "nome": "bish",
    "codigo": "B622"
  },
  {
    "nome": "biss",
    "codigo": "B623"
  },
  {
    "nome": "bit",
    "codigo": "B624"
  },
  {
    "nome": "biz",
    "codigo": "B625"
  },
  {
    "nome": "bj",
    "codigo": "B626"
  },
  {
    "nome": "bl",
    "codigo": "B627"
  },
  {
    "nome": "blackb",
    "codigo": "B628"
  },
  {
    "nome": "blackm",
    "codigo": "B629"
  },
  {
    "nome": "blacks",
    "codigo": "B631"
  },
  {
    "nome": "blackw",
    "codigo": "B632"
  },
  {
    "nome": "blag",
    "codigo": "B633"
  },
  {
    "nome": "blai",
    "codigo": "B634"
  },
  {
    "nome": "blair",
    "codigo": "B635"
  },
  {
    "nome": "blak",
    "codigo": "B636"
  },
  {
    "nome": "blakes",
    "codigo": "B637"
  },
  {
    "nome": "blan",
    "codigo": "B638"
  },
  {
    "nome": "blanch",
    "codigo": "B639"
  },
  {
    "nome": "blanche",
    "codigo": "B641"
  },
  {
    "nome": "bland",
    "codigo": "B642"
  },
  {
    "nome": "blanq",
    "codigo": "B643"
  },
  {
    "nome": "blas",
    "codigo": "B644"
  },
  {
    "nome": "blau",
    "codigo": "B645"
  },
  {
    "nome": "ble",
    "codigo": "B646"
  },
  {
    "nome": "blen",
    "codigo": "B647"
  },
  {
    "nome": "bli",
    "codigo": "B648"
  },
  {
    "nome": "dugo",
    "codigo": "D867"
  },
  {
    "nome": "dugu",
    "codigo": "D868"
  },
  {
    "nome": "duh",
    "codigo": "D869"
  },
  {
    "nome": "duhe",
    "codigo": "D871"
  },
  {
    "nome": "duho",
    "codigo": "D872"
  },
  {
    "nome": "dui",
    "codigo": "D873"
  },
  {
    "nome": "duil",
    "codigo": "D874"
  },
  {
    "nome": "duis",
    "codigo": "D875"
  },
  {
    "nome": "duj",
    "codigo": "D876"
  },
  {
    "nome": "duk",
    "codigo": "D877"
  },
  {
    "nome": "dul",
    "codigo": "D878"
  },
  {
    "nome": "dulau",
    "codigo": "D879"
  },
  {
    "nome": "dulc",
    "codigo": "D881"
  },
  {
    "nome": "duli",
    "codigo": "D882"
  },
  {
    "nome": "dull",
    "codigo": "D883"
  },
  {
    "nome": "dulo",
    "codigo": "D884"
  },
  {
    "nome": "dum",
    "codigo": "D885"
  },
  {
    "nome": "dumas",
    "codigo": "D886"
  },
  {
    "nome": "dumay",
    "codigo": "D887"
  },
  {
    "nome": "dume",
    "codigo": "D888"
  },
  {
    "nome": "dumm",
    "codigo": "D889"
  },
  {
    "nome": "dumo",
    "codigo": "D891"
  },
  {
    "nome": "dumon",
    "codigo": "D892"
  },
  {
    "nome": "dumont",
    "codigo": "D893"
  },
  {
    "nome": "dumor",
    "codigo": "D894"
  },
  {
    "nome": "dumou",
    "codigo": "D895"
  },
  {
    "nome": "dumour",
    "codigo": "D896"
  },
  {
    "nome": "dun",
    "codigo": "D897"
  },
  {
    "nome": "dunb",
    "codigo": "D898"
  },
  {
    "nome": "dunbar m",
    "codigo": "D899"
  },
  {
    "nome": "dunc",
    "codigo": "D911"
  },
  {
    "nome": "duncan m",
    "codigo": "D912"
  },
  {
    "nome": "dunco",
    "codigo": "D913"
  },
  {
    "nome": "dund",
    "codigo": "D914"
  },
  {
    "nome": "dundo",
    "codigo": "D915"
  },
  {
    "nome": "dung",
    "codigo": "D916"
  },
  {
    "nome": "dunh",
    "codigo": "D917"
  },
  {
    "nome": "duni",
    "codigo": "D918"
  },
  {
    "nome": "dunk",
    "codigo": "D919"
  },
  {
    "nome": "dunl",
    "codigo": "D921"
  },
  {
    "nome": "dunlo",
    "codigo": "D922"
  },
  {
    "nome": "dunn",
    "codigo": "D923"
  },
  {
    "nome": "dunni",
    "codigo": "D924"
  },
  {
    "nome": "duno",
    "codigo": "D925"
  },
  {
    "nome": "duns",
    "codigo": "D926"
  },
  {
    "nome": "dunt",
    "codigo": "D927"
  },
  {
    "nome": "dunu",
    "codigo": "D928"
  },
  {
    "nome": "dup",
    "codigo": "D929"
  },
  {
    "nome": "dupar",
    "codigo": "D931"
  },
  {
    "nome": "dupe",
    "codigo": "D932"
  },
  {
    "nome": "duperr",
    "codigo": "D933"
  },
  {
    "nome": "dupi",
    "codigo": "D934"
  },
  {
    "nome": "dupl",
    "codigo": "D935"
  },
  {
    "nome": "duples",
    "codigo": "D936"
  },
  {
    "nome": "dupo",
    "codigo": "D937"
  },
  {
    "nome": "dupont",
    "codigo": "D938"
  },
  {
    "nome": "dupor",
    "codigo": "D939"
  },
  {
    "nome": "dupp",
    "codigo": "D941"
  },
  {
    "nome": "dupr",
    "codigo": "D942"
  },
  {
    "nome": "dupres",
    "codigo": "D943"
  },
  {
    "nome": "dupu",
    "codigo": "D944"
  },
  {
    "nome": "dupuy",
    "codigo": "D945"
  },
  {
    "nome": "duq",
    "codigo": "D946"
  },
  {
    "nome": "dur",
    "codigo": "D947"
  },
  {
    "nome": "duran",
    "codigo": "D948"
  },
  {
    "nome": "durand m",
    "codigo": "D949"
  },
  {
    "nome": "durant",
    "codigo": "D951"
  },
  {
    "nome": "duras",
    "codigo": "D952"
  },
  {
    "nome": "duraz",
    "codigo": "D953"
  },
  {
    "nome": "durd",
    "codigo": "D954"
  },
  {
    "nome": "dure",
    "codigo": "D955"
  },
  {
    "nome": "duret",
    "codigo": "D956"
  },
  {
    "nome": "durey",
    "codigo": "D957"
  },
  {
    "nome": "durf",
    "codigo": "D958"
  },
  {
    "nome": "durfo",
    "codigo": "D959"
  },
  {
    "nome": "durh",
    "codigo": "D961"
  },
  {
    "nome": "duri",
    "codigo": "D962"
  },
  {
    "nome": "duriv",
    "codigo": "D963"
  },
  {
    "nome": "duro",
    "codigo": "D964"
  },
  {
    "nome": "durr",
    "codigo": "D965"
  },
  {
    "nome": "durs",
    "codigo": "D966"
  },
  {
    "nome": "duru",
    "codigo": "D967"
  },
  {
    "nome": "duruy",
    "codigo": "D968"
  },
  {
    "nome": "dury",
    "codigo": "D969"
  },
  {
    "nome": "dus",
    "codigo": "D971"
  },
  {
    "nome": "duse",
    "codigo": "D972"
  },
  {
    "nome": "dusi",
    "codigo": "D973"
  },
  {
    "nome": "duss",
    "codigo": "D974"
  },
  {
    "nome": "dut",
    "codigo": "D975"
  },
  {
    "nome": "duti",
    "codigo": "D976"
  },
  {
    "nome": "duto",
    "codigo": "D977"
  },
  {
    "nome": "dutr",
    "codigo": "D978"
  },
  {
    "nome": "dutt",
    "codigo": "D979"
  },
  {
    "nome": "dutton",
    "codigo": "D981"
  },
  {
    "nome": "duv",
    "codigo": "D982"
  },
  {
    "nome": "duval",
    "codigo": "D983"
  },
  {
    "nome": "duvau",
    "codigo": "D984"
  },
  {
    "nome": "duve",
    "codigo": "D985"
  },
  {
    "nome": "duvet",
    "codigo": "D986"
  },
  {
    "nome": "duvi",
    "codigo": "D987"
  },
  {
    "nome": "duy",
    "codigo": "D988"
  },
  {
    "nome": "dw",
    "codigo": "D989"
  },
  {
    "nome": "dwi",
    "codigo": "D991"
  },
  {
    "nome": "dwight j",
    "codigo": "D992"
  },
  {
    "nome": "dwight s",
    "codigo": "D993"
  },
  {
    "nome": "dy",
    "codigo": "D994"
  },
  {
    "nome": "dye",
    "codigo": "D995"
  },
  {
    "nome": "dyer",
    "codigo": "D996"
  },
  {
    "nome": "dym",
    "codigo": "D997"
  },
  {
    "nome": "dyr",
    "codigo": "D998"
  },
  {
    "nome": "dz",
    "codigo": "D999"
  },
  {
    "nome": "e",
    "codigo": "E11"
  },
  {
    "nome": "ea",
    "codigo": "E11"
  },
  {
    "nome": "eam",
    "codigo": "E12"
  },
  {
    "nome": "eas",
    "codigo": "E13"
  },
  {
    "nome": "eat",
    "codigo": "E14"
  },
  {
    "nome": "eb",
    "codigo": "E15"
  },
  {
    "nome": "eber",
    "codigo": "E16"
  },
  {
    "nome": "ec",
    "codigo": "E17"
  },
  {
    "nome": "ech",
    "codigo": "E18"
  },
  {
    "nome": "eck",
    "codigo": "E19"
  },
  {
    "nome": "ed",
    "codigo": "E21"
  },
  {
    "nome": "ede",
    "codigo": "E22"
  },
  {
    "nome": "edg",
    "codigo": "E23"
  },
  {
    "nome": "edm",
    "codigo": "E24"
  },
  {
    "nome": "edw",
    "codigo": "E25"
  },
  {
    "nome": "edwards",
    "codigo": "E26"
  },
  {
    "nome": "ef",
    "codigo": "E27"
  },
  {
    "nome": "eg",
    "codigo": "E28"
  },
  {
    "nome": "ege",
    "codigo": "E29"
  },
  {
    "nome": "egl",
    "codigo": "E31"
  },
  {
    "nome": "egr",
    "codigo": "E32"
  },
  {
    "nome": "eh",
    "codigo": "E33"
  },
  {
    "nome": "ei",
    "codigo": "E34"
  },
  {
    "nome": "ein",
    "codigo": "E35"
  },
  {
    "nome": "eis",
    "codigo": "E36"
  },
  {
    "nome": "el",
    "codigo": "E37"
  },
  {
    "nome": "elea",
    "codigo": "E38"
  },
  {
    "nome": "elen",
    "codigo": "E39"
  },
  {
    "nome": "elg",
    "codigo": "E41"
  },
  {
    "nome": "eli",
    "codigo": "E42"
  },
  {
    "nome": "elis",
    "codigo": "E43"
  },
  {
    "nome": "ell",
    "codigo": "E44"
  },
  {
    "nome": "elle",
    "codigo": "E45"
  },
  {
    "nome": "elli",
    "codigo": "E46"
  },
  {
    "nome": "ellis",
    "codigo": "E47"
  },
  {
    "nome": "elm",
    "codigo": "E48"
  },
  {
    "nome": "els",
    "codigo": "E49"
  },
  {
    "nome": "elt",
    "codigo": "E51"
  },
  {
    "nome": "elw",
    "codigo": "E52"
  },
  {
    "nome": "em",
    "codigo": "E53"
  },
  {
    "nome": "emm",
    "codigo": "E54"
  },
  {
    "nome": "emp",
    "codigo": "E55"
  },
  {
    "nome": "en",
    "codigo": "E56"
  },
  {
    "nome": "eng",
    "codigo": "E57"
  },
  {
    "nome": "engl",
    "codigo": "E58"
  },
  {
    "nome": "enn",
    "codigo": "E59"
  },
  {
    "nome": "ent",
    "codigo": "E61"
  },
  {
    "nome": "eo",
    "codigo": "E62"
  },
  {
    "nome": "ep",
    "codigo": "E63"
  },
  {
    "nome": "epi",
    "codigo": "E64"
  },
  {
    "nome": "er",
    "codigo": "E65"
  },
  {
    "nome": "erd",
    "codigo": "E66"
  },
  {
    "nome": "ere",
    "codigo": "E67"
  },
  {
    "nome": "eri",
    "codigo": "E68"
  },
  {
    "nome": "erl",
    "codigo": "E69"
  },
  {
    "nome": "erm",
    "codigo": "E71"
  },
  {
    "nome": "err",
    "codigo": "E72"
  },
  {
    "nome": "ers",
    "codigo": "E73"
  },
  {
    "nome": "es",
    "codigo": "E74"
  },
  {
    "nome": "esd",
    "codigo": "E75"
  },
  {
    "nome": "esl",
    "codigo": "E76"
  },
  {
    "nome": "esp",
    "codigo": "E77"
  },
  {
    "nome": "ess",
    "codigo": "E78"
  },
  {
    "nome": "est",
    "codigo": "E79"
  },
  {
    "nome": "esti",
    "codigo": "E81"
  },
  {
    "nome": "estr",
    "codigo": "E82"
  },
  {
    "nome": "et",
    "codigo": "E83"
  },
  {
    "nome": "eth",
    "codigo": "E84"
  },
  {
    "nome": "eto",
    "codigo": "E85"
  },
  {
    "nome": "eu",
    "codigo": "E86"
  },
  {
    "nome": "eug",
    "codigo": "E87"
  },
  {
    "nome": "eul",
    "codigo": "E88"
  },
  {
    "nome": "eup",
    "codigo": "E89"
  },
  {
    "nome": "eus",
    "codigo": "E91"
  },
  {
    "nome": "ev",
    "codigo": "E92"
  },
  {
    "nome": "eve",
    "codigo": "E93"
  },
  {
    "nome": "ew",
    "codigo": "E94"
  },
  {
    "nome": "ewi",
    "codigo": "E95"
  },
  {
    "nome": "ex",
    "codigo": "E96"
  },
  {
    "nome": "ey",
    "codigo": "E97"
  },
  {
    "nome": "eyr",
    "codigo": "E98"
  },
  {
    "nome": "ez",
    "codigo": "E99"
  },
  {
    "nome": "f",
    "codigo": "F111"
  },
  {
    "nome": "fa",
    "codigo": "F111"
  },
  {
    "nome": "fab",
    "codigo": "F112"
  },
  {
    "nome": "fabb",
    "codigo": "F113"
  },
  {
    "nome": "fabe",
    "codigo": "F114"
  },
  {
    "nome": "faber",
    "codigo": "F115"
  },
  {
    "nome": "faberi",
    "codigo": "F116"
  },
  {
    "nome": "fabert",
    "codigo": "F117"
  },
  {
    "nome": "fabi",
    "codigo": "F118"
  },
  {
    "nome": "fabil",
    "codigo": "F119"
  },
  {
    "nome": "fabiu",
    "codigo": "F121"
  },
  {
    "nome": "fabr",
    "codigo": "F122"
  },
  {
    "nome": "fabre",
    "codigo": "F123"
  },
  {
    "nome": "fabri",
    "codigo": "F124"
  },
  {
    "nome": "fabrian",
    "codigo": "F125"
  },
  {
    "nome": "fabric",
    "codigo": "F126"
  },
  {
    "nome": "fabrin",
    "codigo": "F127"
  },
  {
    "nome": "fabris",
    "codigo": "F128"
  },
  {
    "nome": "fabriz",
    "codigo": "F129"
  },
  {
    "nome": "fabro",
    "codigo": "F131"
  },
  {
    "nome": "fabrot",
    "codigo": "F132"
  },
  {
    "nome": "fabry",
    "codigo": "F133"
  },
  {
    "nome": "fabu",
    "codigo": "F134"
  },
  {
    "nome": "fabv",
    "codigo": "F135"
  },
  {
    "nome": "faby",
    "codigo": "F136"
  },
  {
    "nome": "fac",
    "codigo": "F137"
  },
  {
    "nome": "faccio",
    "codigo": "F138"
  },
  {
    "nome": "fach",
    "codigo": "F139"
  },
  {
    "nome": "faci",
    "codigo": "F141"
  },
  {
    "nome": "facis",
    "codigo": "F142"
  },
  {
    "nome": "facu",
    "codigo": "F143"
  },
  {
    "nome": "fad",
    "codigo": "F144"
  },
  {
    "nome": "fadi",
    "codigo": "F145"
  },
  {
    "nome": "fadl",
    "codigo": "F146"
  },
  {
    "nome": "fae",
    "codigo": "F147"
  },
  {
    "nome": "faen",
    "codigo": "F148"
  },
  {
    "nome": "faes",
    "codigo": "F149"
  },
  {
    "nome": "fag",
    "codigo": "F151"
  },
  {
    "nome": "fage",
    "codigo": "F152"
  },
  {
    "nome": "fagel",
    "codigo": "F153"
  },
  {
    "nome": "fagg",
    "codigo": "F154"
  },
  {
    "nome": "blis",
    "codigo": "B649"
  },
  {
    "nome": "blo",
    "codigo": "B651"
  },
  {
    "nome": "blod",
    "codigo": "B652"
  },
  {
    "nome": "blom",
    "codigo": "B653"
  },
  {
    "nome": "blon",
    "codigo": "B654"
  },
  {
    "nome": "bloo",
    "codigo": "B655"
  },
  {
    "nome": "blos",
    "codigo": "B656"
  },
  {
    "nome": "blou",
    "codigo": "B657"
  },
  {
    "nome": "blu",
    "codigo": "B658"
  },
  {
    "nome": "blunt",
    "codigo": "B659"
  },
  {
    "nome": "bly",
    "codigo": "B661"
  },
  {
    "nome": "bo",
    "codigo": "B662"
  },
  {
    "nome": "bob",
    "codigo": "B663"
  },
  {
    "nome": "boc",
    "codigo": "B664"
  },
  {
    "nome": "bock",
    "codigo": "B665"
  },
  {
    "nome": "bod",
    "codigo": "B666"
  },
  {
    "nome": "bodi",
    "codigo": "B667"
  },
  {
    "nome": "bodl",
    "codigo": "B668"
  },
  {
    "nome": "boe",
    "codigo": "B669"
  },
  {
    "nome": "boeh",
    "codigo": "B671"
  },
  {
    "nome": "boer",
    "codigo": "B672"
  },
  {
    "nome": "boet",
    "codigo": "B673"
  },
  {
    "nome": "bog",
    "codigo": "B674"
  },
  {
    "nome": "bogi",
    "codigo": "B675"
  },
  {
    "nome": "boh",
    "codigo": "B676"
  },
  {
    "nome": "bohn",
    "codigo": "B677"
  },
  {
    "nome": "boi",
    "codigo": "B678"
  },
  {
    "nome": "boil",
    "codigo": "B679"
  },
  {
    "nome": "boin",
    "codigo": "B681"
  },
  {
    "nome": "bois",
    "codigo": "B682"
  },
  {
    "nome": "boisg",
    "codigo": "B683"
  },
  {
    "nome": "boiss",
    "codigo": "B684"
  },
  {
    "nome": "boit",
    "codigo": "B685"
  },
  {
    "nome": "bok",
    "codigo": "B686"
  },
  {
    "nome": "bol",
    "codigo": "B687"
  },
  {
    "nome": "bole",
    "codigo": "B688"
  },
  {
    "nome": "boli",
    "codigo": "B689"
  },
  {
    "nome": "boll",
    "codigo": "B691"
  },
  {
    "nome": "bolli",
    "codigo": "B692"
  },
  {
    "nome": "bolo",
    "codigo": "B693"
  },
  {
    "nome": "bolt",
    "codigo": "B694"
  },
  {
    "nome": "bom",
    "codigo": "B695"
  },
  {
    "nome": "boml",
    "codigo": "B696"
  },
  {
    "nome": "bon",
    "codigo": "B697"
  },
  {
    "nome": "bonap",
    "codigo": "B698"
  },
  {
    "nome": "bonar",
    "codigo": "B699"
  },
  {
    "nome": "bond",
    "codigo": "B711"
  },
  {
    "nome": "bone",
    "codigo": "B712"
  },
  {
    "nome": "bonf",
    "codigo": "B713"
  },
  {
    "nome": "bonh",
    "codigo": "B714"
  },
  {
    "nome": "boni",
    "codigo": "B715"
  },
  {
    "nome": "bonn",
    "codigo": "B716"
  },
  {
    "nome": "bonnet",
    "codigo": "B717"
  },
  {
    "nome": "bonni",
    "codigo": "B718"
  },
  {
    "nome": "bono",
    "codigo": "B719"
  },
  {
    "nome": "bons",
    "codigo": "B721"
  },
  {
    "nome": "bont",
    "codigo": "B722"
  },
  {
    "nome": "bonv",
    "codigo": "B723"
  },
  {
    "nome": "boo",
    "codigo": "B724"
  },
  {
    "nome": "boot",
    "codigo": "B725"
  },
  {
    "nome": "bor",
    "codigo": "B726"
  },
  {
    "nome": "bord",
    "codigo": "B727"
  },
  {
    "nome": "borden",
    "codigo": "B728"
  },
  {
    "nome": "bordi",
    "codigo": "B729"
  },
  {
    "nome": "bore",
    "codigo": "B731"
  },
  {
    "nome": "borg",
    "codigo": "B732"
  },
  {
    "nome": "borgi",
    "codigo": "B733"
  },
  {
    "nome": "borgo",
    "codigo": "B734"
  },
  {
    "nome": "borl",
    "codigo": "B735"
  },
  {
    "nome": "born",
    "codigo": "B736"
  },
  {
    "nome": "borr",
    "codigo": "B737"
  },
  {
    "nome": "bors",
    "codigo": "B738"
  },
  {
    "nome": "bort",
    "codigo": "B739"
  },
  {
    "nome": "bos",
    "codigo": "B741"
  },
  {
    "nome": "bosch",
    "codigo": "B742"
  },
  {
    "nome": "bose",
    "codigo": "B743"
  },
  {
    "nome": "boso",
    "codigo": "B744"
  },
  {
    "nome": "boss",
    "codigo": "B745"
  },
  {
    "nome": "bossu",
    "codigo": "B746"
  },
  {
    "nome": "bost",
    "codigo": "B747"
  },
  {
    "nome": "bot",
    "codigo": "B748"
  },
  {
    "nome": "both",
    "codigo": "B749"
  },
  {
    "nome": "bott",
    "codigo": "B751"
  },
  {
    "nome": "bou",
    "codigo": "B752"
  },
  {
    "nome": "bouche",
    "codigo": "B753"
  },
  {
    "nome": "bouchi",
    "codigo": "B754"
  },
  {
    "nome": "boucho",
    "codigo": "B755"
  },
  {
    "nome": "boud",
    "codigo": "B756"
  },
  {
    "nome": "bouf",
    "codigo": "B757"
  },
  {
    "nome": "boug",
    "codigo": "B758"
  },
  {
    "nome": "bouh",
    "codigo": "B759"
  },
  {
    "nome": "boui",
    "codigo": "B761"
  },
  {
    "nome": "bouil",
    "codigo": "B762"
  },
  {
    "nome": "boul",
    "codigo": "B763"
  },
  {
    "nome": "boull",
    "codigo": "B764"
  },
  {
    "nome": "boun",
    "codigo": "B765"
  },
  {
    "nome": "bour",
    "codigo": "B766"
  },
  {
    "nome": "bourc",
    "codigo": "B767"
  },
  {
    "nome": "bourd",
    "codigo": "B768"
  },
  {
    "nome": "bourdi",
    "codigo": "B769"
  },
  {
    "nome": "boure",
    "codigo": "B771"
  },
  {
    "nome": "bourg",
    "codigo": "B772"
  },
  {
    "nome": "bourgo",
    "codigo": "B773"
  },
  {
    "nome": "bouri",
    "codigo": "B774"
  },
  {
    "nome": "bourn",
    "codigo": "B775"
  },
  {
    "nome": "bourr",
    "codigo": "B776"
  },
  {
    "nome": "bous",
    "codigo": "B777"
  },
  {
    "nome": "bout",
    "codigo": "B778"
  },
  {
    "nome": "bouth",
    "codigo": "B779"
  },
  {
    "nome": "bouto",
    "codigo": "B781"
  },
  {
    "nome": "bouv",
    "codigo": "B782"
  },
  {
    "nome": "bov",
    "codigo": "B783"
  },
  {
    "nome": "bow",
    "codigo": "B784"
  },
  {
    "nome": "bowdi",
    "codigo": "B785"
  },
  {
    "nome": "bowe",
    "codigo": "B786"
  },
  {
    "nome": "bowl",
    "codigo": "B787"
  },
  {
    "nome": "bowr",
    "codigo": "B788"
  },
  {
    "nome": "boy",
    "codigo": "B789"
  },
  {
    "nome": "boye",
    "codigo": "B791"
  },
  {
    "nome": "boyl",
    "codigo": "B792"
  },
  {
    "nome": "boys",
    "codigo": "B793"
  },
  {
    "nome": "br",
    "codigo": "B794"
  },
  {
    "nome": "brab",
    "codigo": "B795"
  },
  {
    "nome": "brac",
    "codigo": "B796"
  },
  {
    "nome": "brack",
    "codigo": "B797"
  },
  {
    "nome": "brad",
    "codigo": "B798"
  },
  {
    "nome": "bradf",
    "codigo": "B799"
  },
  {
    "nome": "bradl",
    "codigo": "B811"
  },
  {
    "nome": "brads",
    "codigo": "B812"
  },
  {
    "nome": "brag",
    "codigo": "B813"
  },
  {
    "nome": "brai",
    "codigo": "B814"
  },
  {
    "nome": "bram",
    "codigo": "B815"
  },
  {
    "nome": "bran",
    "codigo": "B816"
  },
  {
    "nome": "brand",
    "codigo": "B817"
  },
  {
    "nome": "brandi",
    "codigo": "B818"
  },
  {
    "nome": "brando",
    "codigo": "B819"
  },
  {
    "nome": "brandt",
    "codigo": "B821"
  },
  {
    "nome": "brar",
    "codigo": "B822"
  },
  {
    "nome": "bras",
    "codigo": "B823"
  },
  {
    "nome": "brat",
    "codigo": "B824"
  },
  {
    "nome": "brau",
    "codigo": "B825"
  },
  {
    "nome": "brav",
    "codigo": "B826"
  },
  {
    "nome": "bray",
    "codigo": "B827"
  },
  {
    "nome": "bre",
    "codigo": "B828"
  },
  {
    "nome": "brec",
    "codigo": "B829"
  },
  {
    "nome": "bred",
    "codigo": "B831"
  },
  {
    "nome": "bree",
    "codigo": "B832"
  },
  {
    "nome": "breg",
    "codigo": "B833"
  },
  {
    "nome": "breh",
    "codigo": "B834"
  },
  {
    "nome": "brei",
    "codigo": "B835"
  },
  {
    "nome": "brem",
    "codigo": "B836"
  },
  {
    "nome": "bren",
    "codigo": "B837"
  },
  {
    "nome": "brenn",
    "codigo": "B838"
  },
  {
    "nome": "brent",
    "codigo": "B839"
  },
  {
    "nome": "brer",
    "codigo": "B841"
  },
  {
    "nome": "bres",
    "codigo": "B842"
  },
  {
    "nome": "bress",
    "codigo": "B843"
  },
  {
    "nome": "bret",
    "codigo": "B844"
  },
  {
    "nome": "brett",
    "codigo": "B845"
  },
  {
    "nome": "breu",
    "codigo": "B846"
  },
  {
    "nome": "brew",
    "codigo": "B847"
  },
  {
    "nome": "brews",
    "codigo": "B848"
  },
  {
    "nome": "bri",
    "codigo": "B849"
  },
  {
    "nome": "brid",
    "codigo": "B851"
  },
  {
    "nome": "bridgm",
    "codigo": "B852"
  },
  {
    "nome": "brie",
    "codigo": "B853"
  },
  {
    "nome": "brig",
    "codigo": "B854"
  },
  {
    "nome": "brigh",
    "codigo": "B855"
  },
  {
    "nome": "brighto",
    "codigo": "B856"
  },
  {
    "nome": "bril",
    "codigo": "B857"
  },
  {
    "nome": "brin",
    "codigo": "B858"
  },
  {
    "nome": "bris",
    "codigo": "B859"
  },
  {
    "nome": "brist",
    "codigo": "B861"
  },
  {
    "nome": "brit",
    "codigo": "B862"
  },
  {
    "nome": "bro",
    "codigo": "B863"
  },
  {
    "nome": "brock",
    "codigo": "B864"
  },
  {
    "nome": "broe",
    "codigo": "B865"
  },
  {
    "nome": "brog",
    "codigo": "B866"
  },
  {
    "nome": "brok",
    "codigo": "B867"
  },
  {
    "nome": "brom",
    "codigo": "B868"
  },
  {
    "nome": "bron",
    "codigo": "B869"
  },
  {
    "nome": "broo",
    "codigo": "B871"
  },
  {
    "nome": "brooke",
    "codigo": "B872"
  },
  {
    "nome": "brooks",
    "codigo": "B873"
  },
  {
    "nome": "bros",
    "codigo": "B874"
  },
  {
    "nome": "brou",
    "codigo": "B875"
  },
  {
    "nome": "brous",
    "codigo": "B876"
  },
  {
    "nome": "brow",
    "codigo": "B877"
  },
  {
    "nome": "brown h",
    "codigo": "B878"
  },
  {
    "nome": "brown m",
    "codigo": "B879"
  },
  {
    "nome": "brown t",
    "codigo": "B881"
  },
  {
    "nome": "browne",
    "codigo": "B882"
  },
  {
    "nome": "browne m",
    "codigo": "B883"
  },
  {
    "nome": "browne s",
    "codigo": "B884"
  },
  {
    "nome": "browni",
    "codigo": "B885"
  },
  {
    "nome": "bru",
    "codigo": "B886"
  },
  {
    "nome": "bruce j",
    "codigo": "B887"
  },
  {
    "nome": "bruck",
    "codigo": "B888"
  },
  {
    "nome": "brue",
    "codigo": "B889"
  },
  {
    "nome": "brug",
    "codigo": "B891"
  },
  {
    "nome": "bruh",
    "codigo": "B892"
  },
  {
    "nome": "brum",
    "codigo": "B893"
  },
  {
    "nome": "brun",
    "codigo": "B894"
  },
  {
    "nome": "brunet",
    "codigo": "B895"
  },
  {
    "nome": "bruni",
    "codigo": "B896"
  },
  {
    "nome": "brunn",
    "codigo": "B897"
  },
  {
    "nome": "bruno",
    "codigo": "B898"
  },
  {
    "nome": "bruns",
    "codigo": "B899"
  },
  {
    "nome": "brunsw",
    "codigo": "B911"
  },
  {
    "nome": "brus",
    "codigo": "B912"
  },
  {
    "nome": "brut",
    "codigo": "B913"
  },
  {
    "nome": "bruy",
    "codigo": "B914"
  },
  {
    "nome": "bry",
    "codigo": "B915"
  },
  {
    "nome": "bryc",
    "codigo": "B916"
  },
  {
    "nome": "bu",
    "codigo": "B917"
  },
  {
    "nome": "buc",
    "codigo": "B918"
  },
  {
    "nome": "buche",
    "codigo": "B919"
  },
  {
    "nome": "bucho",
    "codigo": "B921"
  },
  {
    "nome": "buck",
    "codigo": "B922"
  },
  {
    "nome": "bucki",
    "codigo": "B923"
  },
  {
    "nome": "buckl",
    "codigo": "B924"
  },
  {
    "nome": "buckm",
    "codigo": "B925"
  },
  {
    "nome": "bucks",
    "codigo": "B926"
  },
  {
    "nome": "bud",
    "codigo": "B927"
  },
  {
    "nome": "bue",
    "codigo": "B928"
  },
  {
    "nome": "buf",
    "codigo": "B929"
  },
  {
    "nome": "bug",
    "codigo": "B931"
  },
  {
    "nome": "bui",
    "codigo": "B932"
  },
  {
    "nome": "bul",
    "codigo": "B933"
  },
  {
    "nome": "bulk",
    "codigo": "B934"
  },
  {
    "nome": "bull",
    "codigo": "B935"
  },
  {
    "nome": "bulle",
    "codigo": "B936"
  },
  {
    "nome": "bulli",
    "codigo": "B937"
  },
  {
    "nome": "bullo",
    "codigo": "B938"
  },
  {
    "nome": "bulo",
    "codigo": "B939"
  },
  {
    "nome": "bulw",
    "codigo": "B941"
  },
  {
    "nome": "bun",
    "codigo": "B942"
  },
  {
    "nome": "buo",
    "codigo": "B943"
  },
  {
    "nome": "buoni",
    "codigo": "B944"
  },
  {
    "nome": "bur",
    "codigo": "B945"
  },
  {
    "nome": "burb",
    "codigo": "B946"
  },
  {
    "nome": "burc",
    "codigo": "B947"
  },
  {
    "nome": "burck",
    "codigo": "B948"
  },
  {
    "nome": "burd",
    "codigo": "B949"
  },
  {
    "nome": "burdet",
    "codigo": "B951"
  },
  {
    "nome": "bure",
    "codigo": "B952"
  },
  {
    "nome": "burf",
    "codigo": "B953"
  },
  {
    "nome": "burg",
    "codigo": "B954"
  },
  {
    "nome": "burges",
    "codigo": "B955"
  },
  {
    "nome": "burgh",
    "codigo": "B956"
  },
  {
    "nome": "burgo",
    "codigo": "B957"
  },
  {
    "nome": "burh",
    "codigo": "B958"
  },
  {
    "nome": "burk",
    "codigo": "B959"
  },
  {
    "nome": "burl",
    "codigo": "B961"
  },
  {
    "nome": "burm",
    "codigo": "B962"
  },
  {
    "nome": "burn",
    "codigo": "B963"
  },
  {
    "nome": "burnet",
    "codigo": "B964"
  },
  {
    "nome": "burney",
    "codigo": "B965"
  },
  {
    "nome": "burnh",
    "codigo": "B966"
  },
  {
    "nome": "burns",
    "codigo": "B967"
  },
  {
    "nome": "burr",
    "codigo": "B968"
  },
  {
    "nome": "burre",
    "codigo": "B969"
  },
  {
    "nome": "burri",
    "codigo": "B971"
  },
  {
    "nome": "burro",
    "codigo": "B972"
  },
  {
    "nome": "burt",
    "codigo": "B973"
  },
  {
    "nome": "burto",
    "codigo": "B974"
  },
  {
    "nome": "bury",
    "codigo": "B975"
  },
  {
    "nome": "bus",
    "codigo": "B976"
  },
  {
    "nome": "busch",
    "codigo": "B977"
  },
  {
    "nome": "bush",
    "codigo": "B978"
  },
  {
    "nome": "bushn",
    "codigo": "B979"
  },
  {
    "nome": "buss",
    "codigo": "B981"
  },
  {
    "nome": "bust",
    "codigo": "B982"
  },
  {
    "nome": "but",
    "codigo": "B983"
  },
  {
    "nome": "buti",
    "codigo": "B984"
  },
  {
    "nome": "butl",
    "codigo": "B985"
  },
  {
    "nome": "butler m",
    "codigo": "B986"
  },
  {
    "nome": "butler t",
    "codigo": "B987"
  },
  {
    "nome": "butt",
    "codigo": "B988"
  },
  {
    "nome": "butto",
    "codigo": "B989"
  },
  {
    "nome": "bux",
    "codigo": "B991"
  },
  {
    "nome": "buy",
    "codigo": "B992"
  },
  {
    "nome": "by",
    "codigo": "B993"
  },
  {
    "nome": "byn",
    "codigo": "B994"
  },
  {
    "nome": "byr",
    "codigo": "B995"
  },
  {
    "nome": "byro",
    "codigo": "B996"
  },
  {
    "nome": "bys",
    "codigo": "B997"
  },
  {
    "nome": "byt",
    "codigo": "B998"
  },
  {
    "nome": "bz",
    "codigo": "B999"
  },
  {
    "nome": "c",
    "codigo": "C111"
  },
  {
    "nome": "ca",
    "codigo": "C111"
  },
  {
    "nome": "cab",
    "codigo": "C112"
  },
  {
    "nome": "cabas",
    "codigo": "C113"
  },
  {
    "nome": "cabe",
    "codigo": "C114"
  },
  {
    "nome": "cabi",
    "codigo": "C115"
  },
  {
    "nome": "cabo",
    "codigo": "C116"
  },
  {
    "nome": "cabr",
    "codigo": "C117"
  },
  {
    "nome": "cac",
    "codigo": "C118"
  },
  {
    "nome": "cach",
    "codigo": "C119"
  },
  {
    "nome": "cad",
    "codigo": "C121"
  },
  {
    "nome": "cade",
    "codigo": "C122"
  },
  {
    "nome": "cadet",
    "codigo": "C123"
  },
  {
    "nome": "cadi",
    "codigo": "C124"
  },
  {
    "nome": "cado",
    "codigo": "C125"
  },
  {
    "nome": "cadr",
    "codigo": "C126"
  },
  {
    "nome": "cae",
    "codigo": "C127"
  },
  {
    "nome": "caes",
    "codigo": "C128"
  },
  {
    "nome": "caf",
    "codigo": "C129"
  },
  {
    "nome": "cag",
    "codigo": "C131"
  },
  {
    "nome": "cah",
    "codigo": "C132"
  },
  {
    "nome": "cai",
    "codigo": "C133"
  },
  {
    "nome": "cail",
    "codigo": "C134"
  },
  {
    "nome": "cain",
    "codigo": "C135"
  },
  {
    "nome": "cair",
    "codigo": "C136"
  },
  {
    "nome": "cais",
    "codigo": "C137"
  },
  {
    "nome": "caiu",
    "codigo": "C138"
  },
  {
    "nome": "caj",
    "codigo": "C139"
  },
  {
    "nome": "cal",
    "codigo": "C141"
  },
  {
    "nome": "calan",
    "codigo": "C142"
  },
  {
    "nome": "calas",
    "codigo": "C143"
  },
  {
    "nome": "calc",
    "codigo": "C144"
  },
  {
    "nome": "cald",
    "codigo": "C145"
  },
  {
    "nome": "calde",
    "codigo": "C146"
  },
  {
    "nome": "caldw",
    "codigo": "C147"
  },
  {
    "nome": "cale",
    "codigo": "C148"
  },
  {
    "nome": "calen",
    "codigo": "C149"
  },
  {
    "nome": "calf",
    "codigo": "C151"
  },
  {
    "nome": "calh",
    "codigo": "C152"
  },
  {
    "nome": "cali",
    "codigo": "C153"
  },
  {
    "nome": "calin",
    "codigo": "C154"
  },
  {
    "nome": "calk",
    "codigo": "C155"
  },
  {
    "nome": "call",
    "codigo": "C156"
  },
  {
    "nome": "calle",
    "codigo": "C157"
  },
  {
    "nome": "calli",
    "codigo": "C158"
  },
  {
    "nome": "callim",
    "codigo": "C159"
  },
  {
    "nome": "callin",
    "codigo": "C161"
  },
  {
    "nome": "callis",
    "codigo": "C162"
  },
  {
    "nome": "callo",
    "codigo": "C163"
  },
  {
    "nome": "calm",
    "codigo": "C164"
  },
  {
    "nome": "calo",
    "codigo": "C165"
  },
  {
    "nome": "calt",
    "codigo": "C166"
  },
  {
    "nome": "calv",
    "codigo": "C167"
  },
  {
    "nome": "calvi",
    "codigo": "C168"
  },
  {
    "nome": "calvo",
    "codigo": "C169"
  },
  {
    "nome": "calz",
    "codigo": "C171"
  },
  {
    "nome": "cam",
    "codigo": "C172"
  },
  {
    "nome": "camas",
    "codigo": "C173"
  },
  {
    "nome": "camb",
    "codigo": "C174"
  },
  {
    "nome": "cambi",
    "codigo": "C175"
  },
  {
    "nome": "cambo",
    "codigo": "C176"
  },
  {
    "nome": "cambr",
    "codigo": "C177"
  },
  {
    "nome": "cambri",
    "codigo": "C178"
  },
  {
    "nome": "camd",
    "codigo": "C179"
  },
  {
    "nome": "came",
    "codigo": "C181"
  },
  {
    "nome": "camer",
    "codigo": "C182"
  },
  {
    "nome": "cami",
    "codigo": "C183"
  },
  {
    "nome": "camm",
    "codigo": "C184"
  },
  {
    "nome": "camo",
    "codigo": "C185"
  },
  {
    "nome": "camp",
    "codigo": "C186"
  },
  {
    "nome": "campbell",
    "codigo": "C187"
  },
  {
    "nome": "campbell h",
    "codigo": "C188"
  },
  {
    "nome": "campbell m",
    "codigo": "C189"
  },
  {
    "nome": "campbell s",
    "codigo": "C191"
  },
  {
    "nome": "campbell w",
    "codigo": "C192"
  },
  {
    "nome": "campe",
    "codigo": "C193"
  },
  {
    "nome": "campen",
    "codigo": "C194"
  },
  {
    "nome": "camper",
    "codigo": "C195"
  },
  {
    "nome": "campi",
    "codigo": "C196"
  },
  {
    "nome": "campis",
    "codigo": "C197"
  },
  {
    "nome": "campo",
    "codigo": "C198"
  },
  {
    "nome": "campr",
    "codigo": "C199"
  },
  {
    "nome": "camu",
    "codigo": "C211"
  },
  {
    "nome": "can",
    "codigo": "C212"
  },
  {
    "nome": "canan",
    "codigo": "C213"
  },
  {
    "nome": "canb",
    "codigo": "C214"
  },
  {
    "nome": "canc",
    "codigo": "C215"
  },
  {
    "nome": "cand",
    "codigo": "C216"
  },
  {
    "nome": "candi",
    "codigo": "C217"
  },
  {
    "nome": "candl",
    "codigo": "C218"
  },
  {
    "nome": "cando",
    "codigo": "C219"
  },
  {
    "nome": "cane",
    "codigo": "C221"
  },
  {
    "nome": "canf",
    "codigo": "C222"
  },
  {
    "nome": "cani",
    "codigo": "C223"
  },
  {
    "nome": "cann",
    "codigo": "C224"
  },
  {
    "nome": "canni",
    "codigo": "C225"
  },
  {
    "nome": "canno",
    "codigo": "C226"
  },
  {
    "nome": "cano",
    "codigo": "C227"
  },
  {
    "nome": "cans",
    "codigo": "C228"
  },
  {
    "nome": "cant",
    "codigo": "C229"
  },
  {
    "nome": "canti",
    "codigo": "C231"
  },
  {
    "nome": "canto",
    "codigo": "C232"
  },
  {
    "nome": "cantr",
    "codigo": "C233"
  },
  {
    "nome": "cantw",
    "codigo": "C234"
  },
  {
    "nome": "canu",
    "codigo": "C235"
  },
  {
    "nome": "cap",
    "codigo": "C236"
  },
  {
    "nome": "cape",
    "codigo": "C237"
  },
  {
    "nome": "capel",
    "codigo": "C238"
  },
  {
    "nome": "capen",
    "codigo": "C239"
  },
  {
    "nome": "capet",
    "codigo": "C241"
  },
  {
    "nome": "capg",
    "codigo": "C242"
  },
  {
    "nome": "capi",
    "codigo": "C243"
  },
  {
    "nome": "capit",
    "codigo": "C244"
  },
  {
    "nome": "capo",
    "codigo": "C245"
  },
  {
    "nome": "capon",
    "codigo": "C246"
  },
  {
    "nome": "capp",
    "codigo": "C247"
  },
  {
    "nome": "capper",
    "codigo": "C248"
  },
  {
    "nome": "cappo",
    "codigo": "C249"
  },
  {
    "nome": "capr",
    "codigo": "C251"
  },
  {
    "nome": "capre",
    "codigo": "C252"
  },
  {
    "nome": "capri",
    "codigo": "C253"
  },
  {
    "nome": "capro",
    "codigo": "C254"
  },
  {
    "nome": "capu",
    "codigo": "C255"
  },
  {
    "nome": "caq",
    "codigo": "C256"
  },
  {
    "nome": "car",
    "codigo": "C257"
  },
  {
    "nome": "caraf",
    "codigo": "C258"
  },
  {
    "nome": "caram",
    "codigo": "C259"
  },
  {
    "nome": "caran",
    "codigo": "C261"
  },
  {
    "nome": "carat",
    "codigo": "C262"
  },
  {
    "nome": "carb",
    "codigo": "C263"
  },
  {
    "nome": "carbo",
    "codigo": "C264"
  },
  {
    "nome": "carc",
    "codigo": "C265"
  },
  {
    "nome": "card",
    "codigo": "C266"
  },
  {
    "nome": "cardi",
    "codigo": "C267"
  },
  {
    "nome": "cardo",
    "codigo": "C268"
  },
  {
    "nome": "cardw",
    "codigo": "C269"
  },
  {
    "nome": "care",
    "codigo": "C271"
  },
  {
    "nome": "carew",
    "codigo": "C272"
  },
  {
    "nome": "carey",
    "codigo": "C273"
  },
  {
    "nome": "carey h",
    "codigo": "C274"
  },
  {
    "nome": "carey m",
    "codigo": "C275"
  },
  {
    "nome": "carey s",
    "codigo": "C276"
  },
  {
    "nome": "cari",
    "codigo": "C277"
  },
  {
    "nome": "carl",
    "codigo": "C278"
  },
  {
    "nome": "carlet",
    "codigo": "C279"
  },
  {
    "nome": "carleton",
    "codigo": "C281"
  },
  {
    "nome": "carli",
    "codigo": "C282"
  },
  {
    "nome": "carlis",
    "codigo": "C283"
  },
  {
    "nome": "carlo",
    "codigo": "C284"
  },
  {
    "nome": "carlt",
    "codigo": "C285"
  },
  {
    "nome": "carly",
    "codigo": "C286"
  },
  {
    "nome": "carm",
    "codigo": "C287"
  },
  {
    "nome": "carn",
    "codigo": "C288"
  },
  {
    "nome": "carne",
    "codigo": "C289"
  },
  {
    "nome": "carno",
    "codigo": "C291"
  },
  {
    "nome": "caro",
    "codigo": "C292"
  },
  {
    "nome": "caron",
    "codigo": "C293"
  },
  {
    "nome": "carp",
    "codigo": "C294"
  },
  {
    "nome": "carpenter",
    "codigo": "C295"
  },
  {
    "nome": "carpenter l",
    "codigo": "C296"
  },
  {
    "nome": "carpenter s",
    "codigo": "C297"
  },
  {
    "nome": "carpi",
    "codigo": "C298"
  },
  {
    "nome": "carpo",
    "codigo": "C299"
  },
  {
    "nome": "carr",
    "codigo": "C311"
  },
  {
    "nome": "carr m",
    "codigo": "C312"
  },
  {
    "nome": "carrar",
    "codigo": "C313"
  },
  {
    "nome": "carre",
    "codigo": "C314"
  },
  {
    "nome": "carret",
    "codigo": "C315"
  },
  {
    "nome": "carri",
    "codigo": "C316"
  },
  {
    "nome": "carril",
    "codigo": "C317"
  },
  {
    "nome": "carrin",
    "codigo": "C318"
  },
  {
    "nome": "carro",
    "codigo": "C319"
  },
  {
    "nome": "cars",
    "codigo": "C321"
  },
  {
    "nome": "cart",
    "codigo": "C322"
  },
  {
    "nome": "carter",
    "codigo": "C323"
  },
  {
    "nome": "carter l",
    "codigo": "C324"
  },
  {
    "nome": "carter s",
    "codigo": "C325"
  },
  {
    "nome": "carth",
    "codigo": "C326"
  },
  {
    "nome": "carti",
    "codigo": "C327"
  },
  {
    "nome": "carto",
    "codigo": "C328"
  },
  {
    "nome": "cartw",
    "codigo": "C329"
  },
  {
    "nome": "carv",
    "codigo": "C331"
  },
  {
    "nome": "cary",
    "codigo": "C332"
  },
  {
    "nome": "cary m",
    "codigo": "C333"
  },
  {
    "nome": "cas",
    "codigo": "C334"
  },
  {
    "nome": "casan",
    "codigo": "C335"
  },
  {
    "nome": "casat",
    "codigo": "C336"
  },
  {
    "nome": "case",
    "codigo": "C337"
  },
  {
    "nome": "casen",
    "codigo": "C338"
  },
  {
    "nome": "casi",
    "codigo": "C339"
  },
  {
    "nome": "caso",
    "codigo": "C341"
  },
  {
    "nome": "casp",
    "codigo": "C342"
  },
  {
    "nome": "cass",
    "codigo": "C343"
  },
  {
    "nome": "casse",
    "codigo": "C344"
  },
  {
    "nome": "cassi",
    "codigo": "C345"
  },
  {
    "nome": "cast",
    "codigo": "C346"
  },
  {
    "nome": "caste",
    "codigo": "C347"
  },
  {
    "nome": "castel",
    "codigo": "C348"
  },
  {
    "nome": "casteln",
    "codigo": "C349"
  },
  {
    "nome": "casti",
    "codigo": "C351"
  },
  {
    "nome": "castil",
    "codigo": "C352"
  },
  {
    "nome": "castl",
    "codigo": "C353"
  },
  {
    "nome": "casto",
    "codigo": "C354"
  },
  {
    "nome": "castr",
    "codigo": "C355"
  },
  {
    "nome": "casw",
    "codigo": "C356"
  },
  {
    "nome": "cat",
    "codigo": "C357"
  },
  {
    "nome": "catel",
    "codigo": "C358"
  },
  {
    "nome": "caten",
    "codigo": "C359"
  },
  {
    "nome": "cath",
    "codigo": "C361"
  },
  {
    "nome": "cathc",
    "codigo": "C362"
  },
  {
    "nome": "cathe",
    "codigo": "C363"
  },
  {
    "nome": "cati",
    "codigo": "C364"
  },
  {
    "nome": "catl",
    "codigo": "C365"
  },
  {
    "nome": "cato",
    "codigo": "C366"
  },
  {
    "nome": "catr",
    "codigo": "C367"
  },
  {
    "nome": "catt",
    "codigo": "C368"
  },
  {
    "nome": "catto",
    "codigo": "C369"
  },
  {
    "nome": "cau",
    "codigo": "C371"
  },
  {
    "nome": "caul",
    "codigo": "C372"
  },
  {
    "nome": "caum",
    "codigo": "C373"
  },
  {
    "nome": "caus",
    "codigo": "C374"
  },
  {
    "nome": "caut",
    "codigo": "C375"
  },
  {
    "nome": "cav",
    "codigo": "C376"
  },
  {
    "nome": "cavall",
    "codigo": "C377"
  },
  {
    "nome": "cave",
    "codigo": "C378"
  },
  {
    "nome": "caven",
    "codigo": "C379"
  },
  {
    "nome": "cavendish l",
    "codigo": "C381"
  },
  {
    "nome": "cavi",
    "codigo": "C382"
  },
  {
    "nome": "cavo",
    "codigo": "C383"
  },
  {
    "nome": "cax",
    "codigo": "C384"
  },
  {
    "nome": "cay",
    "codigo": "C385"
  },
  {
    "nome": "caz",
    "codigo": "C386"
  },
  {
    "nome": "ce",
    "codigo": "C387"
  },
  {
    "nome": "ceci",
    "codigo": "C388"
  },
  {
    "nome": "ced",
    "codigo": "C389"
  },
  {
    "nome": "cei",
    "codigo": "C391"
  },
  {
    "nome": "cel",
    "codigo": "C392"
  },
  {
    "nome": "cell",
    "codigo": "C393"
  },
  {
    "nome": "cels",
    "codigo": "C394"
  },
  {
    "nome": "cen",
    "codigo": "C395"
  },
  {
    "nome": "cens",
    "codigo": "C396"
  },
  {
    "nome": "cent",
    "codigo": "C397"
  },
  {
    "nome": "ceo",
    "codigo": "C398"
  },
  {
    "nome": "cep",
    "codigo": "C399"
  },
  {
    "nome": "cer",
    "codigo": "C411"
  },
  {
    "nome": "cerc",
    "codigo": "C412"
  },
  {
    "nome": "cerd",
    "codigo": "C413"
  },
  {
    "nome": "cere",
    "codigo": "C414"
  },
  {
    "nome": "ceri",
    "codigo": "C415"
  },
  {
    "nome": "cero",
    "codigo": "C416"
  },
  {
    "nome": "cerr",
    "codigo": "C417"
  },
  {
    "nome": "cert",
    "codigo": "C418"
  },
  {
    "nome": "cerv",
    "codigo": "C419"
  },
  {
    "nome": "ces",
    "codigo": "C421"
  },
  {
    "nome": "ceso",
    "codigo": "C422"
  },
  {
    "nome": "cet",
    "codigo": "C423"
  },
  {
    "nome": "cev",
    "codigo": "C424"
  },
  {
    "nome": "cey",
    "codigo": "C425"
  },
  {
    "nome": "ch",
    "codigo": "C426"
  },
  {
    "nome": "chabe",
    "codigo": "C427"
  },
  {
    "nome": "chabo",
    "codigo": "C428"
  },
  {
    "nome": "chabr",
    "codigo": "C429"
  },
  {
    "nome": "chac",
    "codigo": "C431"
  },
  {
    "nome": "chad",
    "codigo": "C432"
  },
  {
    "nome": "chaf",
    "codigo": "C433"
  },
  {
    "nome": "chai",
    "codigo": "C434"
  },
  {
    "nome": "chais",
    "codigo": "C435"
  },
  {
    "nome": "chal",
    "codigo": "C436"
  },
  {
    "nome": "chall",
    "codigo": "C437"
  },
  {
    "nome": "chalm",
    "codigo": "C438"
  },
  {
    "nome": "chalo",
    "codigo": "C439"
  },
  {
    "nome": "chalt",
    "codigo": "C441"
  },
  {
    "nome": "cham",
    "codigo": "C442"
  },
  {
    "nome": "chamber",
    "codigo": "C443"
  },
  {
    "nome": "chambers",
    "codigo": "C444"
  },
  {
    "nome": "chambers m",
    "codigo": "C445"
  },
  {
    "nome": "chambo",
    "codigo": "C446"
  },
  {
    "nome": "chambr",
    "codigo": "C447"
  },
  {
    "nome": "chami",
    "codigo": "C448"
  },
  {
    "nome": "champ",
    "codigo": "C449"
  },
  {
    "nome": "champe",
    "codigo": "C451"
  },
  {
    "nome": "champi",
    "codigo": "C452"
  },
  {
    "nome": "champl",
    "codigo": "C453"
  },
  {
    "nome": "chan",
    "codigo": "C454"
  },
  {
    "nome": "chandl",
    "codigo": "C455"
  },
  {
    "nome": "chandler m",
    "codigo": "C456"
  },
  {
    "nome": "chanl",
    "codigo": "C457"
  },
  {
    "nome": "chann",
    "codigo": "C458"
  },
  {
    "nome": "chant",
    "codigo": "C459"
  },
  {
    "nome": "chao",
    "codigo": "C461"
  },
  {
    "nome": "chap",
    "codigo": "C462"
  },
  {
    "nome": "chapi",
    "codigo": "C463"
  },
  {
    "nome": "chapl",
    "codigo": "C464"
  },
  {
    "nome": "chapm",
    "codigo": "C465"
  },
  {
    "nome": "chapman",
    "codigo": "C466"
  },
  {
    "nome": "chapp",
    "codigo": "C467"
  },
  {
    "nome": "chapu",
    "codigo": "C468"
  },
  {
    "nome": "char",
    "codigo": "C469"
  },
  {
    "nome": "chard",
    "codigo": "C471"
  },
  {
    "nome": "chare",
    "codigo": "C472"
  },
  {
    "nome": "chari",
    "codigo": "C473"
  },
  {
    "nome": "charl",
    "codigo": "C474"
  },
  {
    "nome": "charles",
    "codigo": "C475"
  },
  {
    "nome": "charles m",
    "codigo": "C476"
  },
  {
    "nome": "charles s",
    "codigo": "C477"
  },
  {
    "nome": "charlet",
    "codigo": "C478"
  },
  {
    "nome": "charlo",
    "codigo": "C479"
  },
  {
    "nome": "charlt",
    "codigo": "C481"
  },
  {
    "nome": "charm",
    "codigo": "C482"
  },
  {
    "nome": "charn",
    "codigo": "C483"
  },
  {
    "nome": "charp",
    "codigo": "C484"
  },
  {
    "nome": "charr",
    "codigo": "C485"
  },
  {
    "nome": "chart",
    "codigo": "C486"
  },
  {
    "nome": "chas",
    "codigo": "C487"
  },
  {
    "nome": "chass",
    "codigo": "C488"
  },
  {
    "nome": "chast",
    "codigo": "C489"
  },
  {
    "nome": "chastil",
    "codigo": "C491"
  },
  {
    "nome": "chat",
    "codigo": "C492"
  },
  {
    "nome": "chath",
    "codigo": "C493"
  },
  {
    "nome": "chathi",
    "codigo": "C494"
  },
  {
    "nome": "chatt",
    "codigo": "C495"
  },
  {
    "nome": "chau",
    "codigo": "C496"
  },
  {
    "nome": "chaul",
    "codigo": "C497"
  },
  {
    "nome": "chaun",
    "codigo": "C498"
  },
  {
    "nome": "chaus",
    "codigo": "C499"
  },
  {
    "nome": "chauv",
    "codigo": "C511"
  },
  {
    "nome": "chav",
    "codigo": "C512"
  },
  {
    "nome": "chaz",
    "codigo": "C513"
  },
  {
    "nome": "che",
    "codigo": "C514"
  },
  {
    "nome": "chee",
    "codigo": "C515"
  },
  {
    "nome": "chel",
    "codigo": "C516"
  },
  {
    "nome": "chem",
    "codigo": "C517"
  },
  {
    "nome": "chen",
    "codigo": "C518"
  },
  {
    "nome": "chep",
    "codigo": "C519"
  },
  {
    "nome": "cher",
    "codigo": "C521"
  },
  {
    "nome": "chero",
    "codigo": "C522"
  },
  {
    "nome": "cheru",
    "codigo": "C523"
  },
  {
    "nome": "ches",
    "codigo": "C524"
  },
  {
    "nome": "chest",
    "codigo": "C525"
  },
  {
    "nome": "chet",
    "codigo": "C526"
  },
  {
    "nome": "chev",
    "codigo": "C527"
  },
  {
    "nome": "chevi",
    "codigo": "C528"
  },
  {
    "nome": "chevr",
    "codigo": "C529"
  },
  {
    "nome": "chey",
    "codigo": "C531"
  },
  {
    "nome": "chi",
    "codigo": "C532"
  },
  {
    "nome": "chich",
    "codigo": "C533"
  },
  {
    "nome": "chif",
    "codigo": "C534"
  },
  {
    "nome": "chil",
    "codigo": "C535"
  },
  {
    "nome": "child",
    "codigo": "C536"
  },
  {
    "nome": "childs",
    "codigo": "C537"
  },
  {
    "nome": "chill",
    "codigo": "C538"
  },
  {
    "nome": "chin",
    "codigo": "C539"
  },
  {
    "nome": "chip",
    "codigo": "C541"
  },
  {
    "nome": "chis",
    "codigo": "C542"
  },
  {
    "nome": "chit",
    "codigo": "C543"
  },
  {
    "nome": "chla",
    "codigo": "C544"
  },
  {
    "nome": "cho",
    "codigo": "C545"
  },
  {
    "nome": "chois",
    "codigo": "C546"
  },
  {
    "nome": "chol",
    "codigo": "C547"
  },
  {
    "nome": "chom",
    "codigo": "C548"
  },
  {
    "nome": "chop",
    "codigo": "C549"
  },
  {
    "nome": "chor",
    "codigo": "C551"
  },
  {
    "nome": "chou",
    "codigo": "C552"
  },
  {
    "nome": "chr",
    "codigo": "C553"
  },
  {
    "nome": "chri",
    "codigo": "C554"
  },
  {
    "nome": "christi",
    "codigo": "C555"
  },
  {
    "nome": "christo",
    "codigo": "C556"
  },
  {
    "nome": "chro",
    "codigo": "C557"
  },
  {
    "nome": "chry",
    "codigo": "C558"
  },
  {
    "nome": "chu",
    "codigo": "C559"
  },
  {
    "nome": "church",
    "codigo": "C561"
  },
  {
    "nome": "church m",
    "codigo": "C562"
  },
  {
    "nome": "churchill",
    "codigo": "C563"
  },
  {
    "nome": "chut",
    "codigo": "C564"
  },
  {
    "nome": "ci",
    "codigo": "C565"
  },
  {
    "nome": "cian",
    "codigo": "C566"
  },
  {
    "nome": "cib",
    "codigo": "C567"
  },
  {
    "nome": "cic",
    "codigo": "C568"
  },
  {
    "nome": "cie",
    "codigo": "C569"
  },
  {
    "nome": "cig",
    "codigo": "C571"
  },
  {
    "nome": "cil",
    "codigo": "C572"
  },
  {
    "nome": "cim",
    "codigo": "C573"
  },
  {
    "nome": "cin",
    "codigo": "C574"
  },
  {
    "nome": "cini",
    "codigo": "C575"
  },
  {
    "nome": "cio",
    "codigo": "C576"
  },
  {
    "nome": "cip",
    "codigo": "C577"
  },
  {
    "nome": "cir",
    "codigo": "C578"
  },
  {
    "nome": "cis",
    "codigo": "C579"
  },
  {
    "nome": "cit",
    "codigo": "C581"
  },
  {
    "nome": "civ",
    "codigo": "C582"
  },
  {
    "nome": "cl",
    "codigo": "C583"
  },
  {
    "nome": "clag",
    "codigo": "C584"
  },
  {
    "nome": "clai",
    "codigo": "C585"
  },
  {
    "nome": "clam",
    "codigo": "C586"
  },
  {
    "nome": "clan",
    "codigo": "C587"
  },
  {
    "nome": "clap",
    "codigo": "C588"
  },
  {
    "nome": "clapp",
    "codigo": "C589"
  },
  {
    "nome": "clar",
    "codigo": "C591"
  },
  {
    "nome": "clark",
    "codigo": "C592"
  },
  {
    "nome": "clark g",
    "codigo": "C593"
  },
  {
    "nome": "clark m",
    "codigo": "C594"
  },
  {
    "nome": "clark s",
    "codigo": "C595"
  },
  {
    "nome": "clark w",
    "codigo": "C596"
  },
  {
    "nome": "clarke",
    "codigo": "C597"
  },
  {
    "nome": "clarke g",
    "codigo": "C598"
  },
  {
    "nome": "clarke m",
    "codigo": "C599"
  },
  {
    "nome": "clarke s",
    "codigo": "C611"
  },
  {
    "nome": "clarke w",
    "codigo": "C612"
  },
  {
    "nome": "clarks",
    "codigo": "C613"
  },
  {
    "nome": "clary",
    "codigo": "C614"
  },
  {
    "nome": "clau",
    "codigo": "C615"
  },
  {
    "nome": "claus",
    "codigo": "C616"
  },
  {
    "nome": "clav",
    "codigo": "C617"
  },
  {
    "nome": "clax",
    "codigo": "C618"
  },
  {
    "nome": "clay",
    "codigo": "C619"
  },
  {
    "nome": "clay m",
    "codigo": "C621"
  },
  {
    "nome": "clay t",
    "codigo": "C622"
  },
  {
    "nome": "cle",
    "codigo": "C623"
  },
  {
    "nome": "clee",
    "codigo": "C624"
  },
  {
    "nome": "clem",
    "codigo": "C625"
  },
  {
    "nome": "clement",
    "codigo": "C626"
  },
  {
    "nome": "clen",
    "codigo": "C627"
  },
  {
    "nome": "cleo",
    "codigo": "C628"
  },
  {
    "nome": "cler",
    "codigo": "C629"
  },
  {
    "nome": "clerk",
    "codigo": "C631"
  },
  {
    "nome": "clerke",
    "codigo": "C632"
  },
  {
    "nome": "clerm",
    "codigo": "C633"
  },
  {
    "nome": "cles",
    "codigo": "C634"
  },
  {
    "nome": "clev",
    "codigo": "C635"
  },
  {
    "nome": "cli",
    "codigo": "C636"
  },
  {
    "nome": "clif",
    "codigo": "C637"
  },
  {
    "nome": "clifford m",
    "codigo": "C638"
  },
  {
    "nome": "clift",
    "codigo": "C639"
  },
  {
    "nome": "clin",
    "codigo": "C641"
  },
  {
    "nome": "cliv",
    "codigo": "C642"
  },
  {
    "nome": "clo",
    "codigo": "C643"
  },
  {
    "nome": "clon",
    "codigo": "C644"
  },
  {
    "nome": "clos",
    "codigo": "C645"
  },
  {
    "nome": "clot",
    "codigo": "C646"
  },
  {
    "nome": "clou",
    "codigo": "C647"
  },
  {
    "nome": "clow",
    "codigo": "C648"
  },
  {
    "nome": "clu",
    "codigo": "C649"
  },
  {
    "nome": "cn",
    "codigo": "C651"
  },
  {
    "nome": "co",
    "codigo": "C652"
  },
  {
    "nome": "cobb",
    "codigo": "C653"
  },
  {
    "nome": "cobbet",
    "codigo": "C654"
  },
  {
    "nome": "cobd",
    "codigo": "C655"
  },
  {
    "nome": "cobh",
    "codigo": "C656"
  },
  {
    "nome": "cobo",
    "codigo": "C657"
  },
  {
    "nome": "cobu",
    "codigo": "C658"
  },
  {
    "nome": "coc",
    "codigo": "C659"
  },
  {
    "nome": "coch",
    "codigo": "C661"
  },
  {
    "nome": "cochin",
    "codigo": "C662"
  },
  {
    "nome": "cochr",
    "codigo": "C663"
  },
  {
    "nome": "cock",
    "codigo": "C664"
  },
  {
    "nome": "cockb",
    "codigo": "C665"
  },
  {
    "nome": "cocke",
    "codigo": "C666"
  },
  {
    "nome": "coco",
    "codigo": "C667"
  },
  {
    "nome": "cocq",
    "codigo": "C668"
  },
  {
    "nome": "cod",
    "codigo": "C669"
  },
  {
    "nome": "codm",
    "codigo": "C671"
  },
  {
    "nome": "coe",
    "codigo": "C672"
  },
  {
    "nome": "coes",
    "codigo": "C673"
  },
  {
    "nome": "cof",
    "codigo": "C674"
  },
  {
    "nome": "coffin",
    "codigo": "C675"
  },
  {
    "nome": "cog",
    "codigo": "C676"
  },
  {
    "nome": "cogs",
    "codigo": "C677"
  },
  {
    "nome": "coh",
    "codigo": "C678"
  },
  {
    "nome": "coig",
    "codigo": "C679"
  },
  {
    "nome": "coit",
    "codigo": "C681"
  },
  {
    "nome": "cok",
    "codigo": "C682"
  },
  {
    "nome": "col",
    "codigo": "C683"
  },
  {
    "nome": "colb",
    "codigo": "C684"
  },
  {
    "nome": "colbu",
    "codigo": "C685"
  },
  {
    "nome": "colby",
    "codigo": "C686"
  },
  {
    "nome": "colc",
    "codigo": "C687"
  },
  {
    "nome": "cold",
    "codigo": "C688"
  },
  {
    "nome": "cole",
    "codigo": "C689"
  },
  {
    "nome": "coleb",
    "codigo": "C691"
  },
  {
    "nome": "colem",
    "codigo": "C692"
  },
  {
    "nome": "coler",
    "codigo": "C693"
  },
  {
    "nome": "colet",
    "codigo": "C694"
  },
  {
    "nome": "colev",
    "codigo": "C695"
  },
  {
    "nome": "coli",
    "codigo": "C696"
  },
  {
    "nome": "coll",
    "codigo": "C697"
  },
  {
    "nome": "collet",
    "codigo": "C698"
  },
  {
    "nome": "colli",
    "codigo": "C699"
  },
  {
    "nome": "colling",
    "codigo": "C711"
  },
  {
    "nome": "collins",
    "codigo": "C712"
  },
  {
    "nome": "collins s",
    "codigo": "C713"
  },
  {
    "nome": "collo",
    "codigo": "C714"
  },
  {
    "nome": "colly",
    "codigo": "C715"
  },
  {
    "nome": "colm",
    "codigo": "C716"
  },
  {
    "nome": "coln",
    "codigo": "C717"
  },
  {
    "nome": "colo",
    "codigo": "C718"
  },
  {
    "nome": "colon",
    "codigo": "C719"
  },
  {
    "nome": "colp",
    "codigo": "C721"
  },
  {
    "nome": "colq",
    "codigo": "C722"
  },
  {
    "nome": "cols",
    "codigo": "C723"
  },
  {
    "nome": "colt",
    "codigo": "C724"
  },
  {
    "nome": "colto",
    "codigo": "C725"
  },
  {
    "nome": "colu",
    "codigo": "C726"
  },
  {
    "nome": "colv",
    "codigo": "C727"
  },
  {
    "nome": "com",
    "codigo": "C728"
  },
  {
    "nome": "comb",
    "codigo": "C729"
  },
  {
    "nome": "combes",
    "codigo": "C731"
  },
  {
    "nome": "come",
    "codigo": "C732"
  },
  {
    "nome": "comi",
    "codigo": "C733"
  },
  {
    "nome": "comm",
    "codigo": "C734"
  },
  {
    "nome": "como",
    "codigo": "C735"
  },
  {
    "nome": "comp",
    "codigo": "C736"
  },
  {
    "nome": "compan",
    "codigo": "C737"
  },
  {
    "nome": "compt",
    "codigo": "C738"
  },
  {
    "nome": "coms",
    "codigo": "C739"
  },
  {
    "nome": "comt",
    "codigo": "C741"
  },
  {
    "nome": "comy",
    "codigo": "C742"
  },
  {
    "nome": "con",
    "codigo": "C743"
  },
  {
    "nome": "conc",
    "codigo": "C744"
  },
  {
    "nome": "cond",
    "codigo": "C745"
  },
  {
    "nome": "condo",
    "codigo": "C746"
  },
  {
    "nome": "cone",
    "codigo": "C747"
  },
  {
    "nome": "conf",
    "codigo": "C748"
  },
  {
    "nome": "cong",
    "codigo": "C749"
  },
  {
    "nome": "coni",
    "codigo": "C751"
  },
  {
    "nome": "conk",
    "codigo": "C752"
  },
  {
    "nome": "cono",
    "codigo": "C753"
  },
  {
    "nome": "conr",
    "codigo": "C754"
  },
  {
    "nome": "cons",
    "codigo": "C755"
  },
  {
    "nome": "const",
    "codigo": "C756"
  },
  {
    "nome": "constan",
    "codigo": "C757"
  },
  {
    "nome": "constanti",
    "codigo": "C758"
  },
  {
    "nome": "cont",
    "codigo": "C759"
  },
  {
    "nome": "conte",
    "codigo": "C761"
  },
  {
    "nome": "conti",
    "codigo": "C762"
  },
  {
    "nome": "conto",
    "codigo": "C763"
  },
  {
    "nome": "contr",
    "codigo": "C764"
  },
  {
    "nome": "contu",
    "codigo": "C765"
  },
  {
    "nome": "conv",
    "codigo": "C766"
  },
  {
    "nome": "conw",
    "codigo": "C767"
  },
  {
    "nome": "cony",
    "codigo": "C768"
  },
  {
    "nome": "coo",
    "codigo": "C769"
  },
  {
    "nome": "cook",
    "codigo": "C771"
  },
  {
    "nome": "cooke",
    "codigo": "C772"
  },
  {
    "nome": "cooke m",
    "codigo": "C773"
  },
  {
    "nome": "cool",
    "codigo": "C774"
  },
  {
    "nome": "coom",
    "codigo": "C775"
  },
  {
    "nome": "coop",
    "codigo": "C776"
  },
  {
    "nome": "cooper h",
    "codigo": "C777"
  },
  {
    "nome": "cooper o",
    "codigo": "C778"
  },
  {
    "nome": "coot",
    "codigo": "C779"
  },
  {
    "nome": "cop",
    "codigo": "C781"
  },
  {
    "nome": "cope",
    "codigo": "C782"
  },
  {
    "nome": "copi",
    "codigo": "C783"
  },
  {
    "nome": "copl",
    "codigo": "C784"
  },
  {
    "nome": "copp",
    "codigo": "C785"
  },
  {
    "nome": "coq",
    "codigo": "C786"
  },
  {
    "nome": "cor",
    "codigo": "C787"
  },
  {
    "nome": "coran",
    "codigo": "C788"
  },
  {
    "nome": "corb",
    "codigo": "C789"
  },
  {
    "nome": "corbin",
    "codigo": "C791"
  },
  {
    "nome": "corbo",
    "codigo": "C792"
  },
  {
    "nome": "corc",
    "codigo": "C793"
  },
  {
    "nome": "cord",
    "codigo": "C794"
  },
  {
    "nome": "cordi",
    "codigo": "C795"
  },
  {
    "nome": "cordo",
    "codigo": "C796"
  },
  {
    "nome": "core",
    "codigo": "C797"
  },
  {
    "nome": "cori",
    "codigo": "C798"
  },
  {
    "nome": "cork",
    "codigo": "C799"
  },
  {
    "nome": "corm",
    "codigo": "C811"
  },
  {
    "nome": "corn",
    "codigo": "C812"
  },
  {
    "nome": "corne",
    "codigo": "C813"
  },
  {
    "nome": "cornel",
    "codigo": "C814"
  },
  {
    "nome": "corner",
    "codigo": "C815"
  },
  {
    "nome": "cornet",
    "codigo": "C816"
  },
  {
    "nome": "cornh",
    "codigo": "C817"
  },
  {
    "nome": "corni",
    "codigo": "C818"
  },
  {
    "nome": "corno",
    "codigo": "C819"
  },
  {
    "nome": "cornw",
    "codigo": "C821"
  },
  {
    "nome": "coro",
    "codigo": "C822"
  },
  {
    "nome": "corr",
    "codigo": "C823"
  },
  {
    "nome": "corre",
    "codigo": "C824"
  },
  {
    "nome": "corri",
    "codigo": "C825"
  },
  {
    "nome": "cors",
    "codigo": "C826"
  },
  {
    "nome": "cort",
    "codigo": "C827"
  },
  {
    "nome": "cortes",
    "codigo": "C828"
  },
  {
    "nome": "corti",
    "codigo": "C829"
  },
  {
    "nome": "corto",
    "codigo": "C831"
  },
  {
    "nome": "corv",
    "codigo": "C832"
  },
  {
    "nome": "cory",
    "codigo": "C833"
  },
  {
    "nome": "cos",
    "codigo": "C834"
  },
  {
    "nome": "cosp",
    "codigo": "C835"
  },
  {
    "nome": "coss",
    "codigo": "C836"
  },
  {
    "nome": "cost",
    "codigo": "C837"
  },
  {
    "nome": "costan",
    "codigo": "C838"
  },
  {
    "nome": "coste",
    "codigo": "C839"
  },
  {
    "nome": "costel",
    "codigo": "C841"
  },
  {
    "nome": "coster",
    "codigo": "C842"
  },
  {
    "nome": "cot",
    "codigo": "C843"
  },
  {
    "nome": "coti",
    "codigo": "C844"
  },
  {
    "nome": "coto",
    "codigo": "C845"
  },
  {
    "nome": "cott",
    "codigo": "C846"
  },
  {
    "nome": "cotter",
    "codigo": "C847"
  },
  {
    "nome": "cotti",
    "codigo": "C848"
  },
  {
    "nome": "cottl",
    "codigo": "C849"
  },
  {
    "nome": "cotto",
    "codigo": "C851"
  },
  {
    "nome": "coty",
    "codigo": "C852"
  },
  {
    "nome": "cou",
    "codigo": "C853"
  },
  {
    "nome": "coud",
    "codigo": "C854"
  },
  {
    "nome": "coul",
    "codigo": "C855"
  },
  {
    "nome": "coup",
    "codigo": "C856"
  },
  {
    "nome": "coupl",
    "codigo": "C857"
  },
  {
    "nome": "cour",
    "codigo": "C858"
  },
  {
    "nome": "courc",
    "codigo": "C859"
  },
  {
    "nome": "courl",
    "codigo": "C861"
  },
  {
    "nome": "court",
    "codigo": "C862"
  },
  {
    "nome": "courte",
    "codigo": "C863"
  },
  {
    "nome": "courti",
    "codigo": "C864"
  },
  {
    "nome": "courtn",
    "codigo": "C865"
  },
  {
    "nome": "courto",
    "codigo": "C866"
  },
  {
    "nome": "cous",
    "codigo": "C867"
  },
  {
    "nome": "couss",
    "codigo": "C868"
  },
  {
    "nome": "coust",
    "codigo": "C869"
  },
  {
    "nome": "cout",
    "codigo": "C871"
  },
  {
    "nome": "coutu",
    "codigo": "C872"
  },
  {
    "nome": "cov",
    "codigo": "C873"
  },
  {
    "nome": "cow",
    "codigo": "C874"
  },
  {
    "nome": "cowl",
    "codigo": "C875"
  },
  {
    "nome": "cowp",
    "codigo": "C876"
  },
  {
    "nome": "cox",
    "codigo": "C877"
  },
  {
    "nome": "cox r",
    "codigo": "C878"
  },
  {
    "nome": "coxe",
    "codigo": "C879"
  },
  {
    "nome": "coy",
    "codigo": "C881"
  },
  {
    "nome": "coz",
    "codigo": "C882"
  },
  {
    "nome": "cr",
    "codigo": "C883"
  },
  {
    "nome": "crad",
    "codigo": "C884"
  },
  {
    "nome": "craf",
    "codigo": "C885"
  },
  {
    "nome": "crai",
    "codigo": "C886"
  },
  {
    "nome": "craik",
    "codigo": "C887"
  },
  {
    "nome": "crak",
    "codigo": "C888"
  },
  {
    "nome": "cram",
    "codigo": "C889"
  },
  {
    "nome": "cran",
    "codigo": "C891"
  },
  {
    "nome": "crao",
    "codigo": "C892"
  },
  {
    "nome": "crap",
    "codigo": "C893"
  },
  {
    "nome": "cras",
    "codigo": "C894"
  },
  {
    "nome": "crat",
    "codigo": "C895"
  },
  {
    "nome": "crato",
    "codigo": "C896"
  },
  {
    "nome": "crau",
    "codigo": "C897"
  },
  {
    "nome": "crav",
    "codigo": "C898"
  },
  {
    "nome": "craw",
    "codigo": "C899"
  },
  {
    "nome": "crawl",
    "codigo": "C911"
  },
  {
    "nome": "cre",
    "codigo": "C912"
  },
  {
    "nome": "cree",
    "codigo": "C913"
  },
  {
    "nome": "crei",
    "codigo": "C914"
  },
  {
    "nome": "crel",
    "codigo": "C915"
  },
  {
    "nome": "creo",
    "codigo": "C916"
  },
  {
    "nome": "crep",
    "codigo": "C917"
  },
  {
    "nome": "creq",
    "codigo": "C918"
  },
  {
    "nome": "cres",
    "codigo": "C919"
  },
  {
    "nome": "cresp",
    "codigo": "C921"
  },
  {
    "nome": "cress",
    "codigo": "C922"
  },
  {
    "nome": "cresw",
    "codigo": "C923"
  },
  {
    "nome": "cret",
    "codigo": "C924"
  },
  {
    "nome": "creu",
    "codigo": "C925"
  },
  {
    "nome": "crev",
    "codigo": "C926"
  },
  {
    "nome": "crew",
    "codigo": "C927"
  },
  {
    "nome": "cri",
    "codigo": "C928"
  },
  {
    "nome": "cril",
    "codigo": "C929"
  },
  {
    "nome": "crin",
    "codigo": "C931"
  },
  {
    "nome": "cris",
    "codigo": "C932"
  },
  {
    "nome": "crist",
    "codigo": "C933"
  },
  {
    "nome": "crit",
    "codigo": "C934"
  },
  {
    "nome": "critt",
    "codigo": "C935"
  },
  {
    "nome": "criv",
    "codigo": "C936"
  },
  {
    "nome": "cro",
    "codigo": "C937"
  },
  {
    "nome": "crock",
    "codigo": "C938"
  },
  {
    "nome": "croe",
    "codigo": "C939"
  },
  {
    "nome": "crof",
    "codigo": "C941"
  },
  {
    "nome": "croi",
    "codigo": "C942"
  },
  {
    "nome": "crok",
    "codigo": "C943"
  },
  {
    "nome": "crol",
    "codigo": "C944"
  },
  {
    "nome": "crom",
    "codigo": "C945"
  },
  {
    "nome": "cromw",
    "codigo": "C946"
  },
  {
    "nome": "cron",
    "codigo": "C947"
  },
  {
    "nome": "croo",
    "codigo": "C948"
  },
  {
    "nome": "cros",
    "codigo": "C949"
  },
  {
    "nome": "cross",
    "codigo": "C951"
  },
  {
    "nome": "crou",
    "codigo": "C952"
  },
  {
    "nome": "crow",
    "codigo": "C953"
  },
  {
    "nome": "croy",
    "codigo": "C954"
  },
  {
    "nome": "cru",
    "codigo": "C955"
  },
  {
    "nome": "crum",
    "codigo": "C956"
  },
  {
    "nome": "crus",
    "codigo": "C957"
  },
  {
    "nome": "cs",
    "codigo": "C958"
  },
  {
    "nome": "ct",
    "codigo": "C959"
  },
  {
    "nome": "cu",
    "codigo": "C961"
  },
  {
    "nome": "cub",
    "codigo": "C962"
  },
  {
    "nome": "cuc",
    "codigo": "C963"
  },
  {
    "nome": "cud",
    "codigo": "C964"
  },
  {
    "nome": "cue",
    "codigo": "C965"
  },
  {
    "nome": "cui",
    "codigo": "C966"
  },
  {
    "nome": "cul",
    "codigo": "C967"
  },
  {
    "nome": "culp",
    "codigo": "C968"
  },
  {
    "nome": "cum",
    "codigo": "C969"
  },
  {
    "nome": "cumm",
    "codigo": "C971"
  },
  {
    "nome": "cun",
    "codigo": "C972"
  },
  {
    "nome": "cunn",
    "codigo": "C973"
  },
  {
    "nome": "cup",
    "codigo": "C974"
  },
  {
    "nome": "cur",
    "codigo": "C975"
  },
  {
    "nome": "curr",
    "codigo": "C976"
  },
  {
    "nome": "curs",
    "codigo": "C977"
  },
  {
    "nome": "curt",
    "codigo": "C978"
  },
  {
    "nome": "curtis j",
    "codigo": "C979"
  },
  {
    "nome": "curtis p",
    "codigo": "C981"
  },
  {
    "nome": "curw",
    "codigo": "C982"
  },
  {
    "nome": "curz",
    "codigo": "C983"
  },
  {
    "nome": "cus",
    "codigo": "C984"
  },
  {
    "nome": "cushing m",
    "codigo": "C985"
  },
  {
    "nome": "cushm",
    "codigo": "C986"
  },
  {
    "nome": "cust",
    "codigo": "C987"
  },
  {
    "nome": "cut",
    "codigo": "C988"
  },
  {
    "nome": "cutl",
    "codigo": "C989"
  },
  {
    "nome": "cutt",
    "codigo": "C991"
  },
  {
    "nome": "cuv",
    "codigo": "C992"
  },
  {
    "nome": "cuy",
    "codigo": "C993"
  },
  {
    "nome": "cy",
    "codigo": "C994"
  },
  {
    "nome": "cyc",
    "codigo": "C995"
  },
  {
    "nome": "cyl",
    "codigo": "C996"
  },
  {
    "nome": "cyr",
    "codigo": "C997"
  },
  {
    "nome": "cz",
    "codigo": "C998"
  },
  {
    "nome": "czo",
    "codigo": "C999"
  },
  {
    "nome": "d",
    "codigo": "D111"
  },
  {
    "nome": "da",
    "codigo": "D111"
  },
  {
    "nome": "dabi",
    "codigo": "D112"
  },
  {
    "nome": "dabl",
    "codigo": "D113"
  },
  {
    "nome": "dabn",
    "codigo": "D114"
  },
  {
    "nome": "dabo",
    "codigo": "D115"
  },
  {
    "nome": "dabr",
    "codigo": "D116"
  },
  {
    "nome": "dac",
    "codigo": "D117"
  },
  {
    "nome": "daci",
    "codigo": "D118"
  },
  {
    "nome": "dacr",
    "codigo": "D119"
  },
  {
    "nome": "dad",
    "codigo": "D121"
  },
  {
    "nome": "dae",
    "codigo": "D122"
  },
  {
    "nome": "dael",
    "codigo": "D123"
  },
  {
    "nome": "daf",
    "codigo": "D124"
  },
  {
    "nome": "dag",
    "codigo": "D125"
  },
  {
    "nome": "dagi",
    "codigo": "D126"
  },
  {
    "nome": "dago",
    "codigo": "D127"
  },
  {
    "nome": "dagu",
    "codigo": "D128"
  },
  {
    "nome": "dah",
    "codigo": "D129"
  },
  {
    "nome": "dahl",
    "codigo": "D131"
  },
  {
    "nome": "dai",
    "codigo": "D132"
  },
  {
    "nome": "dail",
    "codigo": "D133"
  },
  {
    "nome": "dair",
    "codigo": "D134"
  },
  {
    "nome": "dak",
    "codigo": "D135"
  },
  {
    "nome": "dal",
    "codigo": "D136"
  },
  {
    "nome": "dalb",
    "codigo": "D137"
  },
  {
    "nome": "dalc",
    "codigo": "D138"
  },
  {
    "nome": "dale",
    "codigo": "D139"
  },
  {
    "nome": "dales",
    "codigo": "D141"
  },
  {
    "nome": "dalg",
    "codigo": "D142"
  },
  {
    "nome": "dalh",
    "codigo": "D143"
  },
  {
    "nome": "dall",
    "codigo": "D144"
  },
  {
    "nome": "dallas",
    "codigo": "D145"
  },
  {
    "nome": "dalle",
    "codigo": "D146"
  },
  {
    "nome": "dalli",
    "codigo": "D147"
  },
  {
    "nome": "dalm",
    "codigo": "D148"
  },
  {
    "nome": "dalp",
    "codigo": "D149"
  },
  {
    "nome": "dalr",
    "codigo": "D151"
  },
  {
    "nome": "dalt",
    "codigo": "D152"
  },
  {
    "nome": "daly",
    "codigo": "D153"
  },
  {
    "nome": "dam",
    "codigo": "D154"
  },
  {
    "nome": "damas",
    "codigo": "D155"
  },
  {
    "nome": "damb",
    "codigo": "D156"
  },
  {
    "nome": "dame",
    "codigo": "D157"
  },
  {
    "nome": "dami",
    "codigo": "D158"
  },
  {
    "nome": "damin",
    "codigo": "D159"
  },
  {
    "nome": "damis",
    "codigo": "D161"
  },
  {
    "nome": "damm",
    "codigo": "D162"
  },
  {
    "nome": "damo",
    "codigo": "D163"
  },
  {
    "nome": "damop",
    "codigo": "D164"
  },
  {
    "nome": "damp",
    "codigo": "D165"
  },
  {
    "nome": "dampi",
    "codigo": "D166"
  },
  {
    "nome": "dan",
    "codigo": "D167"
  },
  {
    "nome": "dana h",
    "codigo": "D168"
  },
  {
    "nome": "dana m",
    "codigo": "D169"
  },
  {
    "nome": "dana s",
    "codigo": "D171"
  },
  {
    "nome": "danb",
    "codigo": "D172"
  },
  {
    "nome": "danc",
    "codigo": "D173"
  },
  {
    "nome": "danck",
    "codigo": "D174"
  },
  {
    "nome": "danco",
    "codigo": "D175"
  },
  {
    "nome": "dand",
    "codigo": "D176"
  },
  {
    "nome": "dando",
    "codigo": "D177"
  },
  {
    "nome": "dandr",
    "codigo": "D178"
  },
  {
    "nome": "dane",
    "codigo": "D179"
  },
  {
    "nome": "danf",
    "codigo": "D181"
  },
  {
    "nome": "dang",
    "codigo": "D182"
  },
  {
    "nome": "dani",
    "codigo": "D183"
  },
  {
    "nome": "daniel",
    "codigo": "D184"
  },
  {
    "nome": "daniell",
    "codigo": "D185"
  },
  {
    "nome": "daniels",
    "codigo": "D186"
  },
  {
    "nome": "dank",
    "codigo": "D187"
  },
  {
    "nome": "dann",
    "codigo": "D188"
  },
  {
    "nome": "danp",
    "codigo": "D189"
  },
  {
    "nome": "dans",
    "codigo": "D191"
  },
  {
    "nome": "dant",
    "codigo": "D192"
  },
  {
    "nome": "danti",
    "codigo": "D193"
  },
  {
    "nome": "danto",
    "codigo": "D194"
  },
  {
    "nome": "dantz",
    "codigo": "D195"
  },
  {
    "nome": "danv",
    "codigo": "D196"
  },
  {
    "nome": "danvi",
    "codigo": "D197"
  },
  {
    "nome": "dany",
    "codigo": "D198"
  },
  {
    "nome": "danz",
    "codigo": "D199"
  },
  {
    "nome": "dao",
    "codigo": "D211"
  },
  {
    "nome": "dap",
    "codigo": "D212"
  },
  {
    "nome": "dar",
    "codigo": "D213"
  },
  {
    "nome": "darc",
    "codigo": "D214"
  },
  {
    "nome": "dard",
    "codigo": "D215"
  },
  {
    "nome": "darde",
    "codigo": "D216"
  },
  {
    "nome": "dare",
    "codigo": "D217"
  },
  {
    "nome": "dari",
    "codigo": "D218"
  },
  {
    "nome": "dark",
    "codigo": "D219"
  },
  {
    "nome": "darl",
    "codigo": "D221"
  },
  {
    "nome": "darm",
    "codigo": "D222"
  },
  {
    "nome": "darn",
    "codigo": "D223"
  },
  {
    "nome": "daro",
    "codigo": "D224"
  },
  {
    "nome": "darr",
    "codigo": "D225"
  },
  {
    "nome": "dart",
    "codigo": "D226"
  },
  {
    "nome": "daru",
    "codigo": "D227"
  },
  {
    "nome": "darw",
    "codigo": "D228"
  },
  {
    "nome": "das",
    "codigo": "D229"
  },
  {
    "nome": "dass",
    "codigo": "D231"
  },
  {
    "nome": "dat",
    "codigo": "D232"
  },
  {
    "nome": "dath",
    "codigo": "D233"
  },
  {
    "nome": "dati",
    "codigo": "D234"
  },
  {
    "nome": "dau",
    "codigo": "D235"
  },
  {
    "nome": "daubi",
    "codigo": "D236"
  },
  {
    "nome": "dauc",
    "codigo": "D237"
  },
  {
    "nome": "daud",
    "codigo": "D238"
  },
  {
    "nome": "daul",
    "codigo": "D239"
  },
  {
    "nome": "daum",
    "codigo": "D241"
  },
  {
    "nome": "daun",
    "codigo": "D242"
  },
  {
    "nome": "daur",
    "codigo": "D243"
  },
  {
    "nome": "daus",
    "codigo": "D244"
  },
  {
    "nome": "dav",
    "codigo": "D245"
  },
  {
    "nome": "dave",
    "codigo": "D246"
  },
  {
    "nome": "davenp",
    "codigo": "D247"
  },
  {
    "nome": "daves",
    "codigo": "D248"
  },
  {
    "nome": "davi",
    "codigo": "D249"
  },
  {
    "nome": "davids",
    "codigo": "D251"
  },
  {
    "nome": "davidson",
    "codigo": "D252"
  },
  {
    "nome": "davidson m",
    "codigo": "D253"
  },
  {
    "nome": "davie",
    "codigo": "D254"
  },
  {
    "nome": "davies",
    "codigo": "D255"
  },
  {
    "nome": "davies j",
    "codigo": "D256"
  },
  {
    "nome": "davies p",
    "codigo": "D257"
  },
  {
    "nome": "davig",
    "codigo": "D258"
  },
  {
    "nome": "davil",
    "codigo": "D259"
  },
  {
    "nome": "davis",
    "codigo": "D261"
  },
  {
    "nome": "davis h",
    "codigo": "D262"
  },
  {
    "nome": "davis m",
    "codigo": "D263"
  },
  {
    "nome": "davis s",
    "codigo": "D264"
  },
  {
    "nome": "davis w",
    "codigo": "D265"
  },
  {
    "nome": "davo",
    "codigo": "D266"
  },
  {
    "nome": "davr",
    "codigo": "D267"
  },
  {
    "nome": "davy",
    "codigo": "D268"
  },
  {
    "nome": "daw",
    "codigo": "D269"
  },
  {
    "nome": "dawk",
    "codigo": "D271"
  },
  {
    "nome": "daws",
    "codigo": "D272"
  },
  {
    "nome": "day",
    "codigo": "D273"
  },
  {
    "nome": "day j",
    "codigo": "D274"
  },
  {
    "nome": "day s",
    "codigo": "D275"
  },
  {
    "nome": "dayt",
    "codigo": "D276"
  },
  {
    "nome": "daz",
    "codigo": "D277"
  },
  {
    "nome": "de",
    "codigo": "D278"
  },
  {
    "nome": "deal",
    "codigo": "D279"
  },
  {
    "nome": "dean",
    "codigo": "D281"
  },
  {
    "nome": "dean m",
    "codigo": "D282"
  },
  {
    "nome": "deane",
    "codigo": "D283"
  },
  {
    "nome": "deane m",
    "codigo": "D284"
  },
  {
    "nome": "dear",
    "codigo": "D285"
  },
  {
    "nome": "deb",
    "codigo": "D286"
  },
  {
    "nome": "debo",
    "codigo": "D287"
  },
  {
    "nome": "debr",
    "codigo": "D288"
  },
  {
    "nome": "debu",
    "codigo": "D289"
  },
  {
    "nome": "dec",
    "codigo": "D291"
  },
  {
    "nome": "dece",
    "codigo": "D292"
  },
  {
    "nome": "dech",
    "codigo": "D293"
  },
  {
    "nome": "deci",
    "codigo": "D294"
  },
  {
    "nome": "deck",
    "codigo": "D295"
  },
  {
    "nome": "deco",
    "codigo": "D296"
  },
  {
    "nome": "decour",
    "codigo": "D297"
  },
  {
    "nome": "decr",
    "codigo": "D298"
  },
  {
    "nome": "ded",
    "codigo": "D299"
  },
  {
    "nome": "dee",
    "codigo": "D311"
  },
  {
    "nome": "deer",
    "codigo": "D312"
  },
  {
    "nome": "def",
    "codigo": "D313"
  },
  {
    "nome": "defo",
    "codigo": "D314"
  },
  {
    "nome": "defor",
    "codigo": "D315"
  },
  {
    "nome": "defr",
    "codigo": "D316"
  },
  {
    "nome": "deg",
    "codigo": "D317"
  },
  {
    "nome": "degl",
    "codigo": "D318"
  },
  {
    "nome": "dego",
    "codigo": "D319"
  },
  {
    "nome": "degr",
    "codigo": "D321"
  },
  {
    "nome": "deh",
    "codigo": "D322"
  },
  {
    "nome": "deho",
    "codigo": "D323"
  },
  {
    "nome": "dei",
    "codigo": "D324"
  },
  {
    "nome": "deis",
    "codigo": "D325"
  },
  {
    "nome": "dej",
    "codigo": "D326"
  },
  {
    "nome": "dejo",
    "codigo": "D327"
  },
  {
    "nome": "dek",
    "codigo": "D328"
  },
  {
    "nome": "dekr",
    "codigo": "D329"
  },
  {
    "nome": "del",
    "codigo": "D331"
  },
  {
    "nome": "delac",
    "codigo": "D332"
  },
  {
    "nome": "delaf",
    "codigo": "D333"
  },
  {
    "nome": "delai",
    "codigo": "D334"
  },
  {
    "nome": "delal",
    "codigo": "D335"
  },
  {
    "nome": "delam",
    "codigo": "D336"
  },
  {
    "nome": "delan",
    "codigo": "D337"
  },
  {
    "nome": "delap",
    "codigo": "D338"
  },
  {
    "nome": "delar",
    "codigo": "D339"
  },
  {
    "nome": "delat",
    "codigo": "D341"
  },
  {
    "nome": "delau",
    "codigo": "D342"
  },
  {
    "nome": "delav",
    "codigo": "D343"
  },
  {
    "nome": "delb",
    "codigo": "D344"
  },
  {
    "nome": "delc",
    "codigo": "D345"
  },
  {
    "nome": "dele",
    "codigo": "D346"
  },
  {
    "nome": "deles",
    "codigo": "D347"
  },
  {
    "nome": "deleu",
    "codigo": "D348"
  },
  {
    "nome": "delf",
    "codigo": "D349"
  },
  {
    "nome": "delfo",
    "codigo": "D351"
  },
  {
    "nome": "delg",
    "codigo": "D352"
  },
  {
    "nome": "deli",
    "codigo": "D353"
  },
  {
    "nome": "delis",
    "codigo": "D354"
  },
  {
    "nome": "deliu",
    "codigo": "D355"
  },
  {
    "nome": "delk",
    "codigo": "D356"
  },
  {
    "nome": "dell",
    "codigo": "D357"
  },
  {
    "nome": "dello",
    "codigo": "D358"
  },
  {
    "nome": "delm",
    "codigo": "D359"
  },
  {
    "nome": "delo",
    "codigo": "D361"
  },
  {
    "nome": "delor",
    "codigo": "D362"
  },
  {
    "nome": "delp",
    "codigo": "D363"
  },
  {
    "nome": "delr",
    "codigo": "D364"
  },
  {
    "nome": "dels",
    "codigo": "D365"
  },
  {
    "nome": "delt",
    "codigo": "D366"
  },
  {
    "nome": "delv",
    "codigo": "D367"
  },
  {
    "nome": "delz",
    "codigo": "D368"
  },
  {
    "nome": "dem",
    "codigo": "D369"
  },
  {
    "nome": "deman",
    "codigo": "D371"
  },
  {
    "nome": "demar",
    "codigo": "D372"
  },
  {
    "nome": "demau",
    "codigo": "D373"
  },
  {
    "nome": "demb",
    "codigo": "D374"
  },
  {
    "nome": "dembo",
    "codigo": "D375"
  },
  {
    "nome": "deme",
    "codigo": "D376"
  },
  {
    "nome": "demet",
    "codigo": "D377"
  },
  {
    "nome": "demi",
    "codigo": "D378"
  },
  {
    "nome": "demid",
    "codigo": "D379"
  },
  {
    "nome": "demil",
    "codigo": "D381"
  },
  {
    "nome": "demm",
    "codigo": "D382"
  },
  {
    "nome": "demo",
    "codigo": "D383"
  },
  {
    "nome": "demon",
    "codigo": "D384"
  },
  {
    "nome": "demop",
    "codigo": "D385"
  },
  {
    "nome": "demor",
    "codigo": "D386"
  },
  {
    "nome": "demos",
    "codigo": "D387"
  },
  {
    "nome": "demou",
    "codigo": "D388"
  },
  {
    "nome": "demp",
    "codigo": "D389"
  },
  {
    "nome": "den",
    "codigo": "D391"
  },
  {
    "nome": "dene",
    "codigo": "D392"
  },
  {
    "nome": "denh",
    "codigo": "D393"
  },
  {
    "nome": "deni",
    "codigo": "D394"
  },
  {
    "nome": "denis",
    "codigo": "D395"
  },
  {
    "nome": "denison",
    "codigo": "D396"
  },
  {
    "nome": "denm",
    "codigo": "D397"
  },
  {
    "nome": "denn",
    "codigo": "D398"
  },
  {
    "nome": "denner",
    "codigo": "D399"
  },
  {
    "nome": "denni",
    "codigo": "D411"
  },
  {
    "nome": "denny",
    "codigo": "D412"
  },
  {
    "nome": "deno",
    "codigo": "D413"
  },
  {
    "nome": "dent",
    "codigo": "D414"
  },
  {
    "nome": "denton",
    "codigo": "D415"
  },
  {
    "nome": "denv",
    "codigo": "D416"
  },
  {
    "nome": "deny",
    "codigo": "D417"
  },
  {
    "nome": "deo",
    "codigo": "D418"
  },
  {
    "nome": "dep",
    "codigo": "D419"
  },
  {
    "nome": "depl",
    "codigo": "D421"
  },
  {
    "nome": "depo",
    "codigo": "D422"
  },
  {
    "nome": "depp",
    "codigo": "D423"
  },
  {
    "nome": "depr",
    "codigo": "D424"
  },
  {
    "nome": "depu",
    "codigo": "D425"
  },
  {
    "nome": "deq",
    "codigo": "D426"
  },
  {
    "nome": "der",
    "codigo": "D427"
  },
  {
    "nome": "derby m",
    "codigo": "D428"
  },
  {
    "nome": "derc",
    "codigo": "D429"
  },
  {
    "nome": "dere",
    "codigo": "D431"
  },
  {
    "nome": "derh",
    "codigo": "D432"
  },
  {
    "nome": "deri",
    "codigo": "D433"
  },
  {
    "nome": "derl",
    "codigo": "D434"
  },
  {
    "nome": "derm",
    "codigo": "D435"
  },
  {
    "nome": "dern",
    "codigo": "D436"
  },
  {
    "nome": "dero",
    "codigo": "D437"
  },
  {
    "nome": "derr",
    "codigo": "D438"
  },
  {
    "nome": "derw",
    "codigo": "D439"
  },
  {
    "nome": "des",
    "codigo": "D441"
  },
  {
    "nome": "desau",
    "codigo": "D442"
  },
  {
    "nome": "desb",
    "codigo": "D443"
  },
  {
    "nome": "desbo",
    "codigo": "D444"
  },
  {
    "nome": "desc",
    "codigo": "D445"
  },
  {
    "nome": "desch",
    "codigo": "D446"
  },
  {
    "nome": "descl",
    "codigo": "D447"
  },
  {
    "nome": "desco",
    "codigo": "D448"
  },
  {
    "nome": "descr",
    "codigo": "D449"
  },
  {
    "nome": "dese",
    "codigo": "D451"
  },
  {
    "nome": "deses",
    "codigo": "D452"
  },
  {
    "nome": "desf",
    "codigo": "D453"
  },
  {
    "nome": "desg",
    "codigo": "D454"
  },
  {
    "nome": "desgr",
    "codigo": "D455"
  },
  {
    "nome": "desh",
    "codigo": "D456"
  },
  {
    "nome": "desi",
    "codigo": "D457"
  },
  {
    "nome": "desit",
    "codigo": "D458"
  },
  {
    "nome": "desj",
    "codigo": "D459"
  },
  {
    "nome": "desl",
    "codigo": "D461"
  },
  {
    "nome": "deslo",
    "codigo": "D462"
  },
  {
    "nome": "desm",
    "codigo": "D463"
  },
  {
    "nome": "desmo",
    "codigo": "D464"
  },
  {
    "nome": "desmou",
    "codigo": "D465"
  },
  {
    "nome": "desn",
    "codigo": "D466"
  },
  {
    "nome": "deso",
    "codigo": "D467"
  },
  {
    "nome": "desp",
    "codigo": "D468"
  },
  {
    "nome": "despl",
    "codigo": "D469"
  },
  {
    "nome": "despo",
    "codigo": "D471"
  },
  {
    "nome": "despor",
    "codigo": "D472"
  },
  {
    "nome": "despr",
    "codigo": "D473"
  },
  {
    "nome": "desr",
    "codigo": "D474"
  },
  {
    "nome": "dess",
    "codigo": "D475"
  },
  {
    "nome": "dest",
    "codigo": "D476"
  },
  {
    "nome": "destr",
    "codigo": "D477"
  },
  {
    "nome": "desv",
    "codigo": "D478"
  },
  {
    "nome": "det",
    "codigo": "D479"
  },
  {
    "nome": "deti",
    "codigo": "D481"
  },
  {
    "nome": "deto",
    "codigo": "D482"
  },
  {
    "nome": "detr",
    "codigo": "D483"
  },
  {
    "nome": "detz",
    "codigo": "D484"
  },
  {
    "nome": "deu",
    "codigo": "D485"
  },
  {
    "nome": "deus",
    "codigo": "D486"
  },
  {
    "nome": "deux",
    "codigo": "D487"
  },
  {
    "nome": "dev",
    "codigo": "D488"
  },
  {
    "nome": "deve",
    "codigo": "D489"
  },
  {
    "nome": "dever",
    "codigo": "D491"
  },
  {
    "nome": "devi",
    "codigo": "D492"
  },
  {
    "nome": "devig",
    "codigo": "D493"
  },
  {
    "nome": "devil",
    "codigo": "D494"
  },
  {
    "nome": "devin",
    "codigo": "D495"
  },
  {
    "nome": "devis",
    "codigo": "D496"
  },
  {
    "nome": "devl",
    "codigo": "D497"
  },
  {
    "nome": "devo",
    "codigo": "D498"
  },
  {
    "nome": "devon",
    "codigo": "D499"
  },
  {
    "nome": "devons",
    "codigo": "D511"
  },
  {
    "nome": "devos",
    "codigo": "D512"
  },
  {
    "nome": "devot",
    "codigo": "D513"
  },
  {
    "nome": "devr",
    "codigo": "D514"
  },
  {
    "nome": "dew",
    "codigo": "D515"
  },
  {
    "nome": "dewe",
    "codigo": "D516"
  },
  {
    "nome": "dewes",
    "codigo": "D517"
  },
  {
    "nome": "dewet",
    "codigo": "D518"
  },
  {
    "nome": "dewey",
    "codigo": "D519"
  },
  {
    "nome": "dewi",
    "codigo": "D521"
  },
  {
    "nome": "dewitt",
    "codigo": "D522"
  },
  {
    "nome": "dewitt m",
    "codigo": "D523"
  },
  {
    "nome": "dewl",
    "codigo": "D524"
  },
  {
    "nome": "dex",
    "codigo": "D525"
  },
  {
    "nome": "dext",
    "codigo": "D526"
  },
  {
    "nome": "dexter m",
    "codigo": "D527"
  },
  {
    "nome": "dey",
    "codigo": "D528"
  },
  {
    "nome": "deyn",
    "codigo": "D529"
  },
  {
    "nome": "deys",
    "codigo": "D531"
  },
  {
    "nome": "dez",
    "codigo": "D532"
  },
  {
    "nome": "dh",
    "codigo": "D533"
  },
  {
    "nome": "dhe",
    "codigo": "D534"
  },
  {
    "nome": "dho",
    "codigo": "D535"
  },
  {
    "nome": "di",
    "codigo": "D536"
  },
  {
    "nome": "diam",
    "codigo": "D537"
  },
  {
    "nome": "dian",
    "codigo": "D538"
  },
  {
    "nome": "diap",
    "codigo": "D539"
  },
  {
    "nome": "dias",
    "codigo": "D541"
  },
  {
    "nome": "diaz",
    "codigo": "D542"
  },
  {
    "nome": "dib",
    "codigo": "D543"
  },
  {
    "nome": "dibd",
    "codigo": "D544"
  },
  {
    "nome": "dic",
    "codigo": "D545"
  },
  {
    "nome": "dice",
    "codigo": "D546"
  },
  {
    "nome": "dick",
    "codigo": "D547"
  },
  {
    "nome": "dicke",
    "codigo": "D548"
  },
  {
    "nome": "dicker",
    "codigo": "D549"
  },
  {
    "nome": "dickey",
    "codigo": "D551"
  },
  {
    "nome": "dicki",
    "codigo": "D552"
  },
  {
    "nome": "dickinso",
    "codigo": "D553"
  },
  {
    "nome": "dicks",
    "codigo": "D554"
  },
  {
    "nome": "did",
    "codigo": "D555"
  },
  {
    "nome": "didi",
    "codigo": "D556"
  },
  {
    "nome": "dido",
    "codigo": "D557"
  },
  {
    "nome": "didr",
    "codigo": "D558"
  },
  {
    "nome": "die",
    "codigo": "D559"
  },
  {
    "nome": "diel",
    "codigo": "D561"
  },
  {
    "nome": "dien",
    "codigo": "D562"
  },
  {
    "nome": "dier",
    "codigo": "D563"
  },
  {
    "nome": "dies",
    "codigo": "D564"
  },
  {
    "nome": "diet",
    "codigo": "D565"
  },
  {
    "nome": "dietr",
    "codigo": "D566"
  },
  {
    "nome": "dieu",
    "codigo": "D567"
  },
  {
    "nome": "diez",
    "codigo": "D568"
  },
  {
    "nome": "dif",
    "codigo": "D569"
  },
  {
    "nome": "dig",
    "codigo": "D571"
  },
  {
    "nome": "dige",
    "codigo": "D572"
  },
  {
    "nome": "digg",
    "codigo": "D573"
  },
  {
    "nome": "digh",
    "codigo": "D574"
  },
  {
    "nome": "dign",
    "codigo": "D575"
  },
  {
    "nome": "dil",
    "codigo": "D576"
  },
  {
    "nome": "dilk",
    "codigo": "D577"
  },
  {
    "nome": "dill",
    "codigo": "D578"
  },
  {
    "nome": "dillo",
    "codigo": "D579"
  },
  {
    "nome": "dilw",
    "codigo": "D581"
  },
  {
    "nome": "dim",
    "codigo": "D582"
  },
  {
    "nome": "din",
    "codigo": "D583"
  },
  {
    "nome": "ding",
    "codigo": "D584"
  },
  {
    "nome": "dini",
    "codigo": "D585"
  },
  {
    "nome": "dino",
    "codigo": "D586"
  },
  {
    "nome": "dins",
    "codigo": "D587"
  },
  {
    "nome": "dio",
    "codigo": "D588"
  },
  {
    "nome": "diod",
    "codigo": "D589"
  },
  {
    "nome": "diog",
    "codigo": "D591"
  },
  {
    "nome": "dion",
    "codigo": "D592"
  },
  {
    "nome": "diop",
    "codigo": "D593"
  },
  {
    "nome": "dios",
    "codigo": "D594"
  },
  {
    "nome": "diot",
    "codigo": "D595"
  },
  {
    "nome": "dip",
    "codigo": "D596"
  },
  {
    "nome": "dir",
    "codigo": "D597"
  },
  {
    "nome": "dirc",
    "codigo": "D598"
  },
  {
    "nome": "dirk",
    "codigo": "D599"
  },
  {
    "nome": "dis",
    "codigo": "D611"
  },
  {
    "nome": "disn",
    "codigo": "D612"
  },
  {
    "nome": "disr",
    "codigo": "D613"
  },
  {
    "nome": "dist",
    "codigo": "D614"
  },
  {
    "nome": "dit",
    "codigo": "D615"
  },
  {
    "nome": "dits",
    "codigo": "D616"
  },
  {
    "nome": "ditt",
    "codigo": "D617"
  },
  {
    "nome": "div",
    "codigo": "D618"
  },
  {
    "nome": "dix",
    "codigo": "D619"
  },
  {
    "nome": "dixo",
    "codigo": "D621"
  },
  {
    "nome": "dixw",
    "codigo": "D622"
  },
  {
    "nome": "dj",
    "codigo": "D623"
  },
  {
    "nome": "dje",
    "codigo": "D624"
  },
  {
    "nome": "dji",
    "codigo": "D625"
  },
  {
    "nome": "djo",
    "codigo": "D626"
  },
  {
    "nome": "dm",
    "codigo": "D627"
  },
  {
    "nome": "dmi",
    "codigo": "D628"
  },
  {
    "nome": "dmo",
    "codigo": "D629"
  },
  {
    "nome": "do",
    "codigo": "D631"
  },
  {
    "nome": "dob",
    "codigo": "D632"
  },
  {
    "nome": "dobe",
    "codigo": "D633"
  },
  {
    "nome": "dobr",
    "codigo": "D634"
  },
  {
    "nome": "dobs",
    "codigo": "D635"
  },
  {
    "nome": "doc",
    "codigo": "D636"
  },
  {
    "nome": "doch",
    "codigo": "D637"
  },
  {
    "nome": "dod",
    "codigo": "D638"
  },
  {
    "nome": "dodd",
    "codigo": "D639"
  },
  {
    "nome": "doddr",
    "codigo": "D641"
  },
  {
    "nome": "dodds",
    "codigo": "D642"
  },
  {
    "nome": "dode",
    "codigo": "D643"
  },
  {
    "nome": "dodg",
    "codigo": "D644"
  },
  {
    "nome": "dodge m",
    "codigo": "D645"
  },
  {
    "nome": "dodi",
    "codigo": "D646"
  },
  {
    "nome": "dods",
    "codigo": "D647"
  },
  {
    "nome": "dodw",
    "codigo": "D648"
  },
  {
    "nome": "doe",
    "codigo": "D649"
  },
  {
    "nome": "doel",
    "codigo": "D651"
  },
  {
    "nome": "doer",
    "codigo": "D652"
  },
  {
    "nome": "does",
    "codigo": "D653"
  },
  {
    "nome": "dog",
    "codigo": "D654"
  },
  {
    "nome": "doh",
    "codigo": "D655"
  },
  {
    "nome": "dohn",
    "codigo": "D656"
  },
  {
    "nome": "doi",
    "codigo": "D657"
  },
  {
    "nome": "dois",
    "codigo": "D658"
  },
  {
    "nome": "dol",
    "codigo": "D659"
  },
  {
    "nome": "dolb",
    "codigo": "D661"
  },
  {
    "nome": "dolc",
    "codigo": "D662"
  },
  {
    "nome": "dole",
    "codigo": "D663"
  },
  {
    "nome": "dolg",
    "codigo": "D664"
  },
  {
    "nome": "doll",
    "codigo": "D665"
  },
  {
    "nome": "dom",
    "codigo": "D666"
  },
  {
    "nome": "domb",
    "codigo": "D667"
  },
  {
    "nome": "dome",
    "codigo": "D668"
  },
  {
    "nome": "domi",
    "codigo": "D669"
  },
  {
    "nome": "domin",
    "codigo": "D671"
  },
  {
    "nome": "domit",
    "codigo": "D672"
  },
  {
    "nome": "domn",
    "codigo": "D673"
  },
  {
    "nome": "don",
    "codigo": "D674"
  },
  {
    "nome": "donal",
    "codigo": "D675"
  },
  {
    "nome": "donalds",
    "codigo": "D676"
  },
  {
    "nome": "donat",
    "codigo": "D677"
  },
  {
    "nome": "donc",
    "codigo": "D678"
  },
  {
    "nome": "dond",
    "codigo": "D679"
  },
  {
    "nome": "done",
    "codigo": "D681"
  },
  {
    "nome": "dong",
    "codigo": "D682"
  },
  {
    "nome": "doni",
    "codigo": "D683"
  },
  {
    "nome": "donk",
    "codigo": "D684"
  },
  {
    "nome": "donn",
    "codigo": "D685"
  },
  {
    "nome": "donner",
    "codigo": "D686"
  },
  {
    "nome": "dono",
    "codigo": "D687"
  },
  {
    "nome": "dont",
    "codigo": "D688"
  },
  {
    "nome": "donz",
    "codigo": "D689"
  },
  {
    "nome": "doo",
    "codigo": "D691"
  },
  {
    "nome": "dop",
    "codigo": "D692"
  },
  {
    "nome": "dor",
    "codigo": "D693"
  },
  {
    "nome": "dorat",
    "codigo": "D694"
  },
  {
    "nome": "dore",
    "codigo": "D695"
  },
  {
    "nome": "dori",
    "codigo": "D696"
  },
  {
    "nome": "dorig",
    "codigo": "D697"
  },
  {
    "nome": "dorio",
    "codigo": "D698"
  },
  {
    "nome": "doris",
    "codigo": "D699"
  },
  {
    "nome": "dorl",
    "codigo": "D711"
  },
  {
    "nome": "dorm",
    "codigo": "D712"
  },
  {
    "nome": "dorn",
    "codigo": "D713"
  },
  {
    "nome": "dorni",
    "codigo": "D714"
  },
  {
    "nome": "doro",
    "codigo": "D715"
  },
  {
    "nome": "dorr",
    "codigo": "D716"
  },
  {
    "nome": "dors",
    "codigo": "D717"
  },
  {
    "nome": "dorse",
    "codigo": "D718"
  },
  {
    "nome": "dort",
    "codigo": "D719"
  },
  {
    "nome": "dorv",
    "codigo": "D721"
  },
  {
    "nome": "dos",
    "codigo": "D722"
  },
  {
    "nome": "dosi",
    "codigo": "D723"
  },
  {
    "nome": "doss",
    "codigo": "D724"
  },
  {
    "nome": "dot",
    "codigo": "D725"
  },
  {
    "nome": "dou",
    "codigo": "D726"
  },
  {
    "nome": "doubl",
    "codigo": "D727"
  },
  {
    "nome": "douc",
    "codigo": "D728"
  },
  {
    "nome": "doue",
    "codigo": "D729"
  },
  {
    "nome": "doug",
    "codigo": "D731"
  },
  {
    "nome": "dough",
    "codigo": "D732"
  },
  {
    "nome": "dougl",
    "codigo": "D733"
  },
  {
    "nome": "douglas g",
    "codigo": "D734"
  },
  {
    "nome": "douglas m",
    "codigo": "D735"
  },
  {
    "nome": "douglas s",
    "codigo": "D736"
  },
  {
    "nome": "douglas w",
    "codigo": "D737"
  },
  {
    "nome": "doul",
    "codigo": "D738"
  },
  {
    "nome": "dour",
    "codigo": "D739"
  },
  {
    "nome": "dous",
    "codigo": "D741"
  },
  {
    "nome": "douv",
    "codigo": "D742"
  },
  {
    "nome": "dov",
    "codigo": "D743"
  },
  {
    "nome": "dow",
    "codigo": "D744"
  },
  {
    "nome": "dowd",
    "codigo": "D745"
  },
  {
    "nome": "dowe",
    "codigo": "D746"
  },
  {
    "nome": "dowl",
    "codigo": "D747"
  },
  {
    "nome": "down",
    "codigo": "D748"
  },
  {
    "nome": "downh",
    "codigo": "D749"
  },
  {
    "nome": "downi",
    "codigo": "D751"
  },
  {
    "nome": "dows",
    "codigo": "D752"
  },
  {
    "nome": "doy",
    "codigo": "D753"
  },
  {
    "nome": "doyl",
    "codigo": "D754"
  },
  {
    "nome": "doz",
    "codigo": "D755"
  },
  {
    "nome": "dr",
    "codigo": "D756"
  },
  {
    "nome": "drac",
    "codigo": "D757"
  },
  {
    "nome": "drae",
    "codigo": "D758"
  },
  {
    "nome": "drag",
    "codigo": "D759"
  },
  {
    "nome": "drak",
    "codigo": "D761"
  },
  {
    "nome": "drake m",
    "codigo": "D762"
  },
  {
    "nome": "drake s",
    "codigo": "D763"
  },
  {
    "nome": "dran",
    "codigo": "D764"
  },
  {
    "nome": "drap",
    "codigo": "D765"
  },
  {
    "nome": "draper m",
    "codigo": "D766"
  },
  {
    "nome": "drapp",
    "codigo": "D767"
  },
  {
    "nome": "dray",
    "codigo": "D768"
  },
  {
    "nome": "drayt",
    "codigo": "D769"
  },
  {
    "nome": "dre",
    "codigo": "D771"
  },
  {
    "nome": "drel",
    "codigo": "D772"
  },
  {
    "nome": "dres",
    "codigo": "D773"
  },
  {
    "nome": "dreu",
    "codigo": "D774"
  },
  {
    "nome": "drev",
    "codigo": "D775"
  },
  {
    "nome": "drew",
    "codigo": "D776"
  },
  {
    "nome": "drex",
    "codigo": "D777"
  },
  {
    "nome": "drey",
    "codigo": "D778"
  },
  {
    "nome": "dri",
    "codigo": "D779"
  },
  {
    "nome": "drink",
    "codigo": "D781"
  },
  {
    "nome": "driv",
    "codigo": "D782"
  },
  {
    "nome": "dro",
    "codigo": "D783"
  },
  {
    "nome": "drog",
    "codigo": "D784"
  },
  {
    "nome": "drol",
    "codigo": "D785"
  },
  {
    "nome": "drom",
    "codigo": "D786"
  },
  {
    "nome": "dros",
    "codigo": "D787"
  },
  {
    "nome": "drou",
    "codigo": "D788"
  },
  {
    "nome": "drouo",
    "codigo": "D789"
  },
  {
    "nome": "drov",
    "codigo": "D791"
  },
  {
    "nome": "droy",
    "codigo": "D792"
  },
  {
    "nome": "droz",
    "codigo": "D793"
  },
  {
    "nome": "dru",
    "codigo": "D794"
  },
  {
    "nome": "drum",
    "codigo": "D795"
  },
  {
    "nome": "drur",
    "codigo": "D796"
  },
  {
    "nome": "drus",
    "codigo": "D797"
  },
  {
    "nome": "dry",
    "codigo": "D798"
  },
  {
    "nome": "dryd",
    "codigo": "D799"
  },
  {
    "nome": "drys",
    "codigo": "D811"
  },
  {
    "nome": "du",
    "codigo": "D812"
  },
  {
    "nome": "dub",
    "codigo": "D813"
  },
  {
    "nome": "dube",
    "codigo": "D814"
  },
  {
    "nome": "dubo",
    "codigo": "D815"
  },
  {
    "nome": "dubois m",
    "codigo": "D816"
  },
  {
    "nome": "dubos",
    "codigo": "D817"
  },
  {
    "nome": "dubou",
    "codigo": "D818"
  },
  {
    "nome": "dubr",
    "codigo": "D819"
  },
  {
    "nome": "dubu",
    "codigo": "D821"
  },
  {
    "nome": "duc",
    "codigo": "D822"
  },
  {
    "nome": "ducar",
    "codigo": "D823"
  },
  {
    "nome": "ducas",
    "codigo": "D824"
  },
  {
    "nome": "duce",
    "codigo": "D825"
  },
  {
    "nome": "duch",
    "codigo": "D826"
  },
  {
    "nome": "duchat",
    "codigo": "D827"
  },
  {
    "nome": "duche",
    "codigo": "D828"
  },
  {
    "nome": "duches",
    "codigo": "D829"
  },
  {
    "nome": "duchi",
    "codigo": "D831"
  },
  {
    "nome": "ducho",
    "codigo": "D832"
  },
  {
    "nome": "duci",
    "codigo": "D833"
  },
  {
    "nome": "duck",
    "codigo": "D834"
  },
  {
    "nome": "ducke",
    "codigo": "D835"
  },
  {
    "nome": "duckw",
    "codigo": "D836"
  },
  {
    "nome": "ducl",
    "codigo": "D837"
  },
  {
    "nome": "duclo",
    "codigo": "D838"
  },
  {
    "nome": "duco",
    "codigo": "D839"
  },
  {
    "nome": "ducon",
    "codigo": "D841"
  },
  {
    "nome": "ducr",
    "codigo": "D842"
  },
  {
    "nome": "ducro",
    "codigo": "D843"
  },
  {
    "nome": "dud",
    "codigo": "D844"
  },
  {
    "nome": "dude",
    "codigo": "D845"
  },
  {
    "nome": "dudi",
    "codigo": "D846"
  },
  {
    "nome": "dudl",
    "codigo": "D847"
  },
  {
    "nome": "dudley l",
    "codigo": "D848"
  },
  {
    "nome": "dudley s",
    "codigo": "D849"
  },
  {
    "nome": "dudo",
    "codigo": "D851"
  },
  {
    "nome": "due",
    "codigo": "D852"
  },
  {
    "nome": "duer",
    "codigo": "D853"
  },
  {
    "nome": "duf",
    "codigo": "D854"
  },
  {
    "nome": "duff",
    "codigo": "D855"
  },
  {
    "nome": "duffe",
    "codigo": "D856"
  },
  {
    "nome": "duffi",
    "codigo": "D857"
  },
  {
    "nome": "duffy",
    "codigo": "D858"
  },
  {
    "nome": "dufl",
    "codigo": "D859"
  },
  {
    "nome": "dufo",
    "codigo": "D861"
  },
  {
    "nome": "dufourn",
    "codigo": "D862"
  },
  {
    "nome": "dufr",
    "codigo": "D863"
  },
  {
    "nome": "dufres",
    "codigo": "D864"
  },
  {
    "nome": "dufu",
    "codigo": "D865"
  },
  {
    "nome": "dug",
    "codigo": "D866"
  },
  {
    "nome": "gad",
    "codigo": "G123"
  },
  {
    "nome": "gade",
    "codigo": "G124"
  },
  {
    "nome": "gado",
    "codigo": "G125"
  },
  {
    "nome": "gads",
    "codigo": "G126"
  },
  {
    "nome": "gae",
    "codigo": "G127"
  },
  {
    "nome": "gaer",
    "codigo": "G128"
  },
  {
    "nome": "gaet",
    "codigo": "G129"
  },
  {
    "nome": "gaf",
    "codigo": "G131"
  },
  {
    "nome": "gag",
    "codigo": "G132"
  },
  {
    "nome": "gage m",
    "codigo": "G133"
  },
  {
    "nome": "gagi",
    "codigo": "G134"
  },
  {
    "nome": "gagl",
    "codigo": "G135"
  },
  {
    "nome": "gago",
    "codigo": "G136"
  },
  {
    "nome": "gai",
    "codigo": "G137"
  },
  {
    "nome": "gail",
    "codigo": "G138"
  },
  {
    "nome": "gaill",
    "codigo": "G139"
  },
  {
    "nome": "gaim",
    "codigo": "G141"
  },
  {
    "nome": "gain",
    "codigo": "G142"
  },
  {
    "nome": "gains",
    "codigo": "G143"
  },
  {
    "nome": "gair",
    "codigo": "G144"
  },
  {
    "nome": "gaj",
    "codigo": "G145"
  },
  {
    "nome": "gal",
    "codigo": "G146"
  },
  {
    "nome": "galau",
    "codigo": "G147"
  },
  {
    "nome": "galb",
    "codigo": "G148"
  },
  {
    "nome": "gald",
    "codigo": "G149"
  },
  {
    "nome": "gale",
    "codigo": "G151"
  },
  {
    "nome": "gale m",
    "codigo": "G152"
  },
  {
    "nome": "galen",
    "codigo": "G153"
  },
  {
    "nome": "galer",
    "codigo": "G154"
  },
  {
    "nome": "galf",
    "codigo": "G155"
  },
  {
    "nome": "gali",
    "codigo": "G156"
  },
  {
    "nome": "galig",
    "codigo": "G157"
  },
  {
    "nome": "galil",
    "codigo": "G158"
  },
  {
    "nome": "galit",
    "codigo": "G159"
  },
  {
    "nome": "galitz",
    "codigo": "G161"
  },
  {
    "nome": "gall",
    "codigo": "G162"
  },
  {
    "nome": "gallan",
    "codigo": "G163"
  },
  {
    "nome": "gallat",
    "codigo": "G164"
  },
  {
    "nome": "gallau",
    "codigo": "G165"
  },
  {
    "nome": "galle",
    "codigo": "G166"
  },
  {
    "nome": "gallet",
    "codigo": "G167"
  },
  {
    "nome": "galli",
    "codigo": "G168"
  },
  {
    "nome": "gallim",
    "codigo": "G169"
  },
  {
    "nome": "gallio",
    "codigo": "G171"
  },
  {
    "nome": "gallo",
    "codigo": "G172"
  },
  {
    "nome": "gallois",
    "codigo": "G173"
  },
  {
    "nome": "gallow",
    "codigo": "G174"
  },
  {
    "nome": "gallu",
    "codigo": "G175"
  },
  {
    "nome": "gallus",
    "codigo": "G176"
  },
  {
    "nome": "gallw",
    "codigo": "G177"
  },
  {
    "nome": "galo",
    "codigo": "G178"
  },
  {
    "nome": "galt",
    "codigo": "G179"
  },
  {
    "nome": "galto",
    "codigo": "G181"
  },
  {
    "nome": "galv",
    "codigo": "G182"
  },
  {
    "nome": "galw",
    "codigo": "G183"
  },
  {
    "nome": "gam",
    "codigo": "G184"
  },
  {
    "nome": "gamai",
    "codigo": "G185"
  },
  {
    "nome": "gamal",
    "codigo": "G186"
  },
  {
    "nome": "gamb",
    "codigo": "G187"
  },
  {
    "nome": "gambar",
    "codigo": "G188"
  },
  {
    "nome": "gambe",
    "codigo": "G189"
  },
  {
    "nome": "gambi",
    "codigo": "G191"
  },
  {
    "nome": "gambo",
    "codigo": "G192"
  },
  {
    "nome": "gamm",
    "codigo": "G193"
  },
  {
    "nome": "gamo",
    "codigo": "G194"
  },
  {
    "nome": "gan",
    "codigo": "G195"
  },
  {
    "nome": "gando",
    "codigo": "G196"
  },
  {
    "nome": "gang",
    "codigo": "G197"
  },
  {
    "nome": "gann",
    "codigo": "G198"
  },
  {
    "nome": "gans",
    "codigo": "G199"
  },
  {
    "nome": "gant",
    "codigo": "G211"
  },
  {
    "nome": "gar",
    "codigo": "G212"
  },
  {
    "nome": "garb",
    "codigo": "G213"
  },
  {
    "nome": "garbo",
    "codigo": "G214"
  },
  {
    "nome": "garc",
    "codigo": "G215"
  },
  {
    "nome": "garci",
    "codigo": "G216"
  },
  {
    "nome": "gard",
    "codigo": "G217"
  },
  {
    "nome": "garde",
    "codigo": "G218"
  },
  {
    "nome": "gardi",
    "codigo": "G219"
  },
  {
    "nome": "gardiner",
    "codigo": "G221"
  },
  {
    "nome": "gardiner h",
    "codigo": "G222"
  },
  {
    "nome": "gardiner m",
    "codigo": "G223"
  },
  {
    "nome": "gardiner s",
    "codigo": "G224"
  },
  {
    "nome": "gardn",
    "codigo": "G225"
  },
  {
    "nome": "gardner",
    "codigo": "G226"
  },
  {
    "nome": "gardner h",
    "codigo": "G227"
  },
  {
    "nome": "gardner p",
    "codigo": "G228"
  },
  {
    "nome": "gare",
    "codigo": "G229"
  },
  {
    "nome": "garf",
    "codigo": "G231"
  },
  {
    "nome": "gari",
    "codigo": "G232"
  },
  {
    "nome": "garl",
    "codigo": "G233"
  },
  {
    "nome": "garn",
    "codigo": "G234"
  },
  {
    "nome": "garnet",
    "codigo": "G235"
  },
  {
    "nome": "garni",
    "codigo": "G236"
  },
  {
    "nome": "garo",
    "codigo": "G237"
  },
  {
    "nome": "garr",
    "codigo": "G238"
  },
  {
    "nome": "garre",
    "codigo": "G239"
  },
  {
    "nome": "garri",
    "codigo": "G241"
  },
  {
    "nome": "garris",
    "codigo": "G242"
  },
  {
    "nome": "garro",
    "codigo": "G243"
  },
  {
    "nome": "gart",
    "codigo": "G244"
  },
  {
    "nome": "garz",
    "codigo": "G245"
  },
  {
    "nome": "gas",
    "codigo": "G246"
  },
  {
    "nome": "gasco",
    "codigo": "G247"
  },
  {
    "nome": "gask",
    "codigo": "G248"
  },
  {
    "nome": "gasp",
    "codigo": "G249"
  },
  {
    "nome": "gass",
    "codigo": "G251"
  },
  {
    "nome": "gasset",
    "codigo": "G252"
  },
  {
    "nome": "gassi",
    "codigo": "G253"
  },
  {
    "nome": "gasso",
    "codigo": "G254"
  },
  {
    "nome": "gast",
    "codigo": "G255"
  },
  {
    "nome": "gaston",
    "codigo": "G256"
  },
  {
    "nome": "gastr",
    "codigo": "G257"
  },
  {
    "nome": "gat",
    "codigo": "G258"
  },
  {
    "nome": "gates",
    "codigo": "G259"
  },
  {
    "nome": "gati",
    "codigo": "G261"
  },
  {
    "nome": "gatt",
    "codigo": "G262"
  },
  {
    "nome": "gatti",
    "codigo": "G263"
  },
  {
    "nome": "gau",
    "codigo": "G264"
  },
  {
    "nome": "gauc",
    "codigo": "G265"
  },
  {
    "nome": "gaud",
    "codigo": "G266"
  },
  {
    "nome": "gaudi",
    "codigo": "G267"
  },
  {
    "nome": "gauf",
    "codigo": "G268"
  },
  {
    "nome": "gaul",
    "codigo": "G269"
  },
  {
    "nome": "gault",
    "codigo": "G271"
  },
  {
    "nome": "gaun",
    "codigo": "G272"
  },
  {
    "nome": "gaur",
    "codigo": "G273"
  },
  {
    "nome": "gaus",
    "codigo": "G274"
  },
  {
    "nome": "gaut",
    "codigo": "G275"
  },
  {
    "nome": "gauth",
    "codigo": "G276"
  },
  {
    "nome": "gauti",
    "codigo": "G277"
  },
  {
    "nome": "gauz",
    "codigo": "G278"
  },
  {
    "nome": "gav",
    "codigo": "G279"
  },
  {
    "nome": "gavau",
    "codigo": "G281"
  },
  {
    "nome": "gave",
    "codigo": "G282"
  },
  {
    "nome": "gavi",
    "codigo": "G283"
  },
  {
    "nome": "gaw",
    "codigo": "G284"
  },
  {
    "nome": "gay",
    "codigo": "G285"
  },
  {
    "nome": "gaye",
    "codigo": "G286"
  },
  {
    "nome": "gayl",
    "codigo": "G287"
  },
  {
    "nome": "gayo",
    "codigo": "G288"
  },
  {
    "nome": "gaz",
    "codigo": "G289"
  },
  {
    "nome": "gazo",
    "codigo": "G291"
  },
  {
    "nome": "ge",
    "codigo": "G292"
  },
  {
    "nome": "geb",
    "codigo": "G293"
  },
  {
    "nome": "gec",
    "codigo": "G294"
  },
  {
    "nome": "ged",
    "codigo": "G295"
  },
  {
    "nome": "gedi",
    "codigo": "G296"
  },
  {
    "nome": "gee",
    "codigo": "G297"
  },
  {
    "nome": "geer",
    "codigo": "G298"
  },
  {
    "nome": "gef",
    "codigo": "G299"
  },
  {
    "nome": "geh",
    "codigo": "G311"
  },
  {
    "nome": "gei",
    "codigo": "G312"
  },
  {
    "nome": "geis",
    "codigo": "G313"
  },
  {
    "nome": "gel",
    "codigo": "G314"
  },
  {
    "nome": "geld",
    "codigo": "G315"
  },
  {
    "nome": "gele",
    "codigo": "G316"
  },
  {
    "nome": "geli",
    "codigo": "G317"
  },
  {
    "nome": "gell",
    "codigo": "G318"
  },
  {
    "nome": "gelli",
    "codigo": "G319"
  },
  {
    "nome": "gelo",
    "codigo": "G321"
  },
  {
    "nome": "gem",
    "codigo": "G322"
  },
  {
    "nome": "gemm",
    "codigo": "G323"
  },
  {
    "nome": "gen",
    "codigo": "G324"
  },
  {
    "nome": "gend",
    "codigo": "G325"
  },
  {
    "nome": "gene",
    "codigo": "G326"
  },
  {
    "nome": "genes",
    "codigo": "G327"
  },
  {
    "nome": "genet",
    "codigo": "G328"
  },
  {
    "nome": "geng",
    "codigo": "G329"
  },
  {
    "nome": "geni",
    "codigo": "G331"
  },
  {
    "nome": "genl",
    "codigo": "G332"
  },
  {
    "nome": "genn",
    "codigo": "G333"
  },
  {
    "nome": "genne",
    "codigo": "G334"
  },
  {
    "nome": "geno",
    "codigo": "G335"
  },
  {
    "nome": "gens",
    "codigo": "G336"
  },
  {
    "nome": "gent",
    "codigo": "G337"
  },
  {
    "nome": "gentil",
    "codigo": "G338"
  },
  {
    "nome": "gentr",
    "codigo": "G339"
  },
  {
    "nome": "genu",
    "codigo": "G341"
  },
  {
    "nome": "geo",
    "codigo": "G342"
  },
  {
    "nome": "geof",
    "codigo": "G343"
  },
  {
    "nome": "geoffri",
    "codigo": "G344"
  },
  {
    "nome": "geoffro",
    "codigo": "G345"
  },
  {
    "nome": "geor",
    "codigo": "G346"
  },
  {
    "nome": "george",
    "codigo": "G347"
  },
  {
    "nome": "george h",
    "codigo": "G348"
  },
  {
    "nome": "george s",
    "codigo": "G349"
  },
  {
    "nome": "georges",
    "codigo": "G351"
  },
  {
    "nome": "georgi",
    "codigo": "G352"
  },
  {
    "nome": "gep",
    "codigo": "G353"
  },
  {
    "nome": "ger",
    "codigo": "G354"
  },
  {
    "nome": "geran",
    "codigo": "G355"
  },
  {
    "nome": "gerar",
    "codigo": "G356"
  },
  {
    "nome": "gerard m",
    "codigo": "G357"
  },
  {
    "nome": "gerardi",
    "codigo": "G358"
  },
  {
    "nome": "gerau",
    "codigo": "G359"
  },
  {
    "nome": "gerb",
    "codigo": "G361"
  },
  {
    "nome": "gerber",
    "codigo": "G362"
  },
  {
    "nome": "gerbi",
    "codigo": "G363"
  },
  {
    "nome": "gerbo",
    "codigo": "G364"
  },
  {
    "nome": "gerc",
    "codigo": "G365"
  },
  {
    "nome": "gerd",
    "codigo": "G366"
  },
  {
    "nome": "gere",
    "codigo": "G367"
  },
  {
    "nome": "gerh",
    "codigo": "G368"
  },
  {
    "nome": "geri",
    "codigo": "G369"
  },
  {
    "nome": "gerl",
    "codigo": "G371"
  },
  {
    "nome": "germ",
    "codigo": "G372"
  },
  {
    "nome": "german",
    "codigo": "G373"
  },
  {
    "nome": "germi",
    "codigo": "G374"
  },
  {
    "nome": "germo",
    "codigo": "G375"
  },
  {
    "nome": "gern",
    "codigo": "G376"
  },
  {
    "nome": "gero",
    "codigo": "G377"
  },
  {
    "nome": "gerr",
    "codigo": "G378"
  },
  {
    "nome": "gerry",
    "codigo": "G379"
  },
  {
    "nome": "gers",
    "codigo": "G381"
  },
  {
    "nome": "gerso",
    "codigo": "G382"
  },
  {
    "nome": "gerst",
    "codigo": "G383"
  },
  {
    "nome": "gert",
    "codigo": "G384"
  },
  {
    "nome": "gerv",
    "codigo": "G385"
  },
  {
    "nome": "gervas",
    "codigo": "G386"
  },
  {
    "nome": "gervi",
    "codigo": "G387"
  },
  {
    "nome": "gery",
    "codigo": "G388"
  },
  {
    "nome": "ges",
    "codigo": "G389"
  },
  {
    "nome": "gesn",
    "codigo": "G391"
  },
  {
    "nome": "gess",
    "codigo": "G392"
  },
  {
    "nome": "gest",
    "codigo": "G393"
  },
  {
    "nome": "get",
    "codigo": "G394"
  },
  {
    "nome": "geu",
    "codigo": "G395"
  },
  {
    "nome": "gev",
    "codigo": "G396"
  },
  {
    "nome": "gey",
    "codigo": "G397"
  },
  {
    "nome": "gez",
    "codigo": "G398"
  },
  {
    "nome": "gf",
    "codigo": "G399"
  },
  {
    "nome": "gh",
    "codigo": "G411"
  },
  {
    "nome": "ghei",
    "codigo": "G412"
  },
  {
    "nome": "gher",
    "codigo": "G413"
  },
  {
    "nome": "gherard",
    "codigo": "G414"
  },
  {
    "nome": "gherardi",
    "codigo": "G415"
  },
  {
    "nome": "gherardo",
    "codigo": "G416"
  },
  {
    "nome": "ghert",
    "codigo": "G417"
  },
  {
    "nome": "ghes",
    "codigo": "G418"
  },
  {
    "nome": "ghey",
    "codigo": "G419"
  },
  {
    "nome": "ghez",
    "codigo": "G421"
  },
  {
    "nome": "ghi",
    "codigo": "G422"
  },
  {
    "nome": "ghid",
    "codigo": "G423"
  },
  {
    "nome": "ghil",
    "codigo": "G424"
  },
  {
    "nome": "ghir",
    "codigo": "G425"
  },
  {
    "nome": "ghis",
    "codigo": "G426"
  },
  {
    "nome": "ghisli",
    "codigo": "G427"
  },
  {
    "nome": "gi",
    "codigo": "G428"
  },
  {
    "nome": "giac",
    "codigo": "G429"
  },
  {
    "nome": "gial",
    "codigo": "G431"
  },
  {
    "nome": "giam",
    "codigo": "G432"
  },
  {
    "nome": "gian",
    "codigo": "G433"
  },
  {
    "nome": "gianno",
    "codigo": "G434"
  },
  {
    "nome": "giar",
    "codigo": "G435"
  },
  {
    "nome": "giat",
    "codigo": "G436"
  },
  {
    "nome": "gib",
    "codigo": "G437"
  },
  {
    "nome": "gibbe",
    "codigo": "G438"
  },
  {
    "nome": "gibbo",
    "codigo": "G439"
  },
  {
    "nome": "gibbons",
    "codigo": "G441"
  },
  {
    "nome": "gibbs",
    "codigo": "G442"
  },
  {
    "nome": "gibbs h",
    "codigo": "G443"
  },
  {
    "nome": "gibbs s",
    "codigo": "G444"
  },
  {
    "nome": "gibe",
    "codigo": "G445"
  },
  {
    "nome": "gibi",
    "codigo": "G446"
  },
  {
    "nome": "gibn",
    "codigo": "G447"
  },
  {
    "nome": "gibs",
    "codigo": "G448"
  },
  {
    "nome": "gibson h",
    "codigo": "G449"
  },
  {
    "nome": "gibson s",
    "codigo": "G451"
  },
  {
    "nome": "gic",
    "codigo": "G452"
  },
  {
    "nome": "gid",
    "codigo": "G453"
  },
  {
    "nome": "gie",
    "codigo": "G454"
  },
  {
    "nome": "gies",
    "codigo": "G455"
  },
  {
    "nome": "gif",
    "codigo": "G456"
  },
  {
    "nome": "giffe",
    "codigo": "G457"
  },
  {
    "nome": "giffo",
    "codigo": "G458"
  },
  {
    "nome": "gig",
    "codigo": "G459"
  },
  {
    "nome": "gigo",
    "codigo": "G461"
  },
  {
    "nome": "gih",
    "codigo": "G462"
  },
  {
    "nome": "gil",
    "codigo": "G463"
  },
  {
    "nome": "gilbert",
    "codigo": "G464"
  },
  {
    "nome": "gilbert j",
    "codigo": "G465"
  },
  {
    "nome": "gilbert s",
    "codigo": "G466"
  },
  {
    "nome": "gilc",
    "codigo": "G467"
  },
  {
    "nome": "gild",
    "codigo": "G468"
  },
  {
    "nome": "gildo",
    "codigo": "G469"
  },
  {
    "nome": "gile",
    "codigo": "G471"
  },
  {
    "nome": "giles",
    "codigo": "G472"
  },
  {
    "nome": "gilf",
    "codigo": "G473"
  },
  {
    "nome": "gili",
    "codigo": "G474"
  },
  {
    "nome": "gill",
    "codigo": "G475"
  },
  {
    "nome": "gille",
    "codigo": "G476"
  },
  {
    "nome": "gilles",
    "codigo": "G477"
  },
  {
    "nome": "gillesp",
    "codigo": "G478"
  },
  {
    "nome": "gillet",
    "codigo": "G479"
  },
  {
    "nome": "gilli",
    "codigo": "G481"
  },
  {
    "nome": "gillm",
    "codigo": "G482"
  },
  {
    "nome": "gillo",
    "codigo": "G483"
  },
  {
    "nome": "gills",
    "codigo": "G484"
  },
  {
    "nome": "gilly",
    "codigo": "G485"
  },
  {
    "nome": "gilm",
    "codigo": "G486"
  },
  {
    "nome": "gilman",
    "codigo": "G487"
  },
  {
    "nome": "gilmo",
    "codigo": "G488"
  },
  {
    "nome": "gilp",
    "codigo": "G489"
  },
  {
    "nome": "gim",
    "codigo": "G491"
  },
  {
    "nome": "gin",
    "codigo": "G492"
  },
  {
    "nome": "gino",
    "codigo": "G493"
  },
  {
    "nome": "gio",
    "codigo": "G494"
  },
  {
    "nome": "giof",
    "codigo": "G495"
  },
  {
    "nome": "giol",
    "codigo": "G496"
  },
  {
    "nome": "gior",
    "codigo": "G497"
  },
  {
    "nome": "giorg",
    "codigo": "G498"
  },
  {
    "nome": "giorgio",
    "codigo": "G499"
  },
  {
    "nome": "giot",
    "codigo": "G511"
  },
  {
    "nome": "giov",
    "codigo": "G512"
  },
  {
    "nome": "giove",
    "codigo": "G513"
  },
  {
    "nome": "giovi",
    "codigo": "G514"
  },
  {
    "nome": "gir",
    "codigo": "G515"
  },
  {
    "nome": "giral",
    "codigo": "G516"
  },
  {
    "nome": "girar",
    "codigo": "G517"
  },
  {
    "nome": "girard m",
    "codigo": "G518"
  },
  {
    "nome": "girarde",
    "codigo": "G519"
  },
  {
    "nome": "girardi",
    "codigo": "G521"
  },
  {
    "nome": "girau",
    "codigo": "G522"
  },
  {
    "nome": "giraul",
    "codigo": "G523"
  },
  {
    "nome": "gird",
    "codigo": "G524"
  },
  {
    "nome": "giri",
    "codigo": "G525"
  },
  {
    "nome": "giro",
    "codigo": "G526"
  },
  {
    "nome": "giron",
    "codigo": "G527"
  },
  {
    "nome": "girou",
    "codigo": "G528"
  },
  {
    "nome": "girt",
    "codigo": "G529"
  },
  {
    "nome": "gis",
    "codigo": "G531"
  },
  {
    "nome": "gise",
    "codigo": "G532"
  },
  {
    "nome": "gisl",
    "codigo": "G533"
  },
  {
    "nome": "gism",
    "codigo": "G534"
  },
  {
    "nome": "giso",
    "codigo": "G535"
  },
  {
    "nome": "git",
    "codigo": "G536"
  },
  {
    "nome": "giu",
    "codigo": "G537"
  },
  {
    "nome": "gius",
    "codigo": "G538"
  },
  {
    "nome": "giv",
    "codigo": "G539"
  },
  {
    "nome": "gl",
    "codigo": "G541"
  },
  {
    "nome": "glad",
    "codigo": "G542"
  },
  {
    "nome": "glads",
    "codigo": "G543"
  },
  {
    "nome": "glai",
    "codigo": "G544"
  },
  {
    "nome": "glan",
    "codigo": "G545"
  },
  {
    "nome": "glanv",
    "codigo": "G546"
  },
  {
    "nome": "glap",
    "codigo": "G547"
  },
  {
    "nome": "glas",
    "codigo": "G548"
  },
  {
    "nome": "glass",
    "codigo": "G549"
  },
  {
    "nome": "glau",
    "codigo": "G551"
  },
  {
    "nome": "glauc",
    "codigo": "G552"
  },
  {
    "nome": "glaz",
    "codigo": "G553"
  },
  {
    "nome": "gle",
    "codigo": "G554"
  },
  {
    "nome": "gled",
    "codigo": "G555"
  },
  {
    "nome": "glei",
    "codigo": "G556"
  },
  {
    "nome": "gleig",
    "codigo": "G557"
  },
  {
    "nome": "glen",
    "codigo": "G558"
  },
  {
    "nome": "gli",
    "codigo": "G559"
  },
  {
    "nome": "glin",
    "codigo": "G561"
  },
  {
    "nome": "glo",
    "codigo": "G562"
  },
  {
    "nome": "glos",
    "codigo": "G563"
  },
  {
    "nome": "glou",
    "codigo": "G564"
  },
  {
    "nome": "glov",
    "codigo": "G565"
  },
  {
    "nome": "glover",
    "codigo": "G566"
  },
  {
    "nome": "glu",
    "codigo": "G567"
  },
  {
    "nome": "gly",
    "codigo": "G568"
  },
  {
    "nome": "gm",
    "codigo": "G569"
  },
  {
    "nome": "gn",
    "codigo": "G571"
  },
  {
    "nome": "gni",
    "codigo": "G572"
  },
  {
    "nome": "go",
    "codigo": "G573"
  },
  {
    "nome": "gob",
    "codigo": "G574"
  },
  {
    "nome": "gobi",
    "codigo": "G575"
  },
  {
    "nome": "goc",
    "codigo": "G576"
  },
  {
    "nome": "god",
    "codigo": "G577"
  },
  {
    "nome": "godd",
    "codigo": "G578"
  },
  {
    "nome": "gode",
    "codigo": "G579"
  },
  {
    "nome": "godef",
    "codigo": "G581"
  },
  {
    "nome": "godes",
    "codigo": "G582"
  },
  {
    "nome": "godf",
    "codigo": "G583"
  },
  {
    "nome": "godi",
    "codigo": "G584"
  },
  {
    "nome": "godin",
    "codigo": "G585"
  },
  {
    "nome": "godk",
    "codigo": "G586"
  },
  {
    "nome": "godm",
    "codigo": "G587"
  },
  {
    "nome": "godo",
    "codigo": "G588"
  },
  {
    "nome": "godon",
    "codigo": "G589"
  },
  {
    "nome": "godw",
    "codigo": "G591"
  },
  {
    "nome": "godwin m",
    "codigo": "G592"
  },
  {
    "nome": "goe",
    "codigo": "G593"
  },
  {
    "nome": "goed",
    "codigo": "G594"
  },
  {
    "nome": "goel",
    "codigo": "G595"
  },
  {
    "nome": "goep",
    "codigo": "G596"
  },
  {
    "nome": "goer",
    "codigo": "G597"
  },
  {
    "nome": "goes",
    "codigo": "G598"
  },
  {
    "nome": "goest",
    "codigo": "G599"
  },
  {
    "nome": "goetz",
    "codigo": "G611"
  },
  {
    "nome": "gof",
    "codigo": "G612"
  },
  {
    "nome": "gog",
    "codigo": "G613"
  },
  {
    "nome": "goh",
    "codigo": "G614"
  },
  {
    "nome": "goi",
    "codigo": "G615"
  },
  {
    "nome": "gois",
    "codigo": "G616"
  },
  {
    "nome": "gol",
    "codigo": "G617"
  },
  {
    "nome": "gold",
    "codigo": "G618"
  },
  {
    "nome": "goldi",
    "codigo": "G619"
  },
  {
    "nome": "goldo",
    "codigo": "G621"
  },
  {
    "nome": "golds",
    "codigo": "G622"
  },
  {
    "nome": "goldsc",
    "codigo": "G623"
  },
  {
    "nome": "goldsm",
    "codigo": "G624"
  },
  {
    "nome": "gole",
    "codigo": "G625"
  },
  {
    "nome": "goli",
    "codigo": "G626"
  },
  {
    "nome": "golo",
    "codigo": "G627"
  },
  {
    "nome": "golov",
    "codigo": "G628"
  },
  {
    "nome": "golt",
    "codigo": "G629"
  },
  {
    "nome": "gom",
    "codigo": "G631"
  },
  {
    "nome": "gombe",
    "codigo": "G632"
  },
  {
    "nome": "gome",
    "codigo": "G633"
  },
  {
    "nome": "gomm",
    "codigo": "G634"
  },
  {
    "nome": "gon",
    "codigo": "G635"
  },
  {
    "nome": "gond",
    "codigo": "G636"
  },
  {
    "nome": "gondi",
    "codigo": "G637"
  },
  {
    "nome": "gone",
    "codigo": "G638"
  },
  {
    "nome": "gonn",
    "codigo": "G639"
  },
  {
    "nome": "gont",
    "codigo": "G641"
  },
  {
    "nome": "gonz",
    "codigo": "G642"
  },
  {
    "nome": "gonzal",
    "codigo": "G643"
  },
  {
    "nome": "goo",
    "codigo": "G644"
  },
  {
    "nome": "gooc",
    "codigo": "G645"
  },
  {
    "nome": "good",
    "codigo": "G646"
  },
  {
    "nome": "goode",
    "codigo": "G647"
  },
  {
    "nome": "goodel",
    "codigo": "G648"
  },
  {
    "nome": "gooden",
    "codigo": "G649"
  },
  {
    "nome": "goodf",
    "codigo": "G651"
  },
  {
    "nome": "goodh",
    "codigo": "G652"
  },
  {
    "nome": "goodm",
    "codigo": "G653"
  },
  {
    "nome": "goodr",
    "codigo": "G654"
  },
  {
    "nome": "goodrich m",
    "codigo": "G655"
  },
  {
    "nome": "goodw",
    "codigo": "G656"
  },
  {
    "nome": "goodwin m",
    "codigo": "G657"
  },
  {
    "nome": "goody",
    "codigo": "G658"
  },
  {
    "nome": "gook",
    "codigo": "G659"
  },
  {
    "nome": "gor",
    "codigo": "G661"
  },
  {
    "nome": "gordon",
    "codigo": "G662"
  },
  {
    "nome": "gordon g",
    "codigo": "G663"
  },
  {
    "nome": "gordon m",
    "codigo": "G664"
  },
  {
    "nome": "gordon s",
    "codigo": "G665"
  },
  {
    "nome": "gore",
    "codigo": "G666"
  },
  {
    "nome": "gorg",
    "codigo": "G667"
  },
  {
    "nome": "gorh",
    "codigo": "G668"
  },
  {
    "nome": "gori",
    "codigo": "G669"
  },
  {
    "nome": "gorm",
    "codigo": "G671"
  },
  {
    "nome": "goro",
    "codigo": "G672"
  },
  {
    "nome": "gorr",
    "codigo": "G673"
  },
  {
    "nome": "gors",
    "codigo": "G674"
  },
  {
    "nome": "gort",
    "codigo": "G675"
  },
  {
    "nome": "gos",
    "codigo": "G676"
  },
  {
    "nome": "goss",
    "codigo": "G677"
  },
  {
    "nome": "gosse",
    "codigo": "G678"
  },
  {
    "nome": "gossel",
    "codigo": "G679"
  },
  {
    "nome": "gosso",
    "codigo": "G681"
  },
  {
    "nome": "gost",
    "codigo": "G682"
  },
  {
    "nome": "got",
    "codigo": "G683"
  },
  {
    "nome": "goth",
    "codigo": "G684"
  },
  {
    "nome": "gott",
    "codigo": "G685"
  },
  {
    "nome": "gotti",
    "codigo": "G686"
  },
  {
    "nome": "gotts",
    "codigo": "G687"
  },
  {
    "nome": "gou",
    "codigo": "G688"
  },
  {
    "nome": "gouf",
    "codigo": "G689"
  },
  {
    "nome": "goug",
    "codigo": "G691"
  },
  {
    "nome": "gough",
    "codigo": "G692"
  },
  {
    "nome": "gouj",
    "codigo": "G693"
  },
  {
    "nome": "goul",
    "codigo": "G694"
  },
  {
    "nome": "goulb",
    "codigo": "G695"
  },
  {
    "nome": "gould",
    "codigo": "G696"
  },
  {
    "nome": "gould j",
    "codigo": "G697"
  },
  {
    "nome": "gould s",
    "codigo": "G698"
  },
  {
    "nome": "gouls",
    "codigo": "G699"
  },
  {
    "nome": "goun",
    "codigo": "G711"
  },
  {
    "nome": "goup",
    "codigo": "G712"
  },
  {
    "nome": "gour",
    "codigo": "G713"
  },
  {
    "nome": "gourd",
    "codigo": "G714"
  },
  {
    "nome": "gourg",
    "codigo": "G715"
  },
  {
    "nome": "gouri",
    "codigo": "G716"
  },
  {
    "nome": "gous",
    "codigo": "G717"
  },
  {
    "nome": "gout",
    "codigo": "G718"
  },
  {
    "nome": "gouv",
    "codigo": "G719"
  },
  {
    "nome": "gov",
    "codigo": "G721"
  },
  {
    "nome": "gow",
    "codigo": "G722"
  },
  {
    "nome": "gower",
    "codigo": "G723"
  },
  {
    "nome": "goy",
    "codigo": "G724"
  },
  {
    "nome": "goz",
    "codigo": "G725"
  },
  {
    "nome": "gr",
    "codigo": "G726"
  },
  {
    "nome": "grab",
    "codigo": "G727"
  },
  {
    "nome": "graber",
    "codigo": "G728"
  },
  {
    "nome": "grac",
    "codigo": "G729"
  },
  {
    "nome": "graci",
    "codigo": "G731"
  },
  {
    "nome": "grad",
    "codigo": "G732"
  },
  {
    "nome": "grado",
    "codigo": "G733"
  },
  {
    "nome": "grae",
    "codigo": "G734"
  },
  {
    "nome": "graes",
    "codigo": "G735"
  },
  {
    "nome": "graf",
    "codigo": "G736"
  },
  {
    "nome": "graft",
    "codigo": "G737"
  },
  {
    "nome": "grah",
    "codigo": "G738"
  },
  {
    "nome": "graham g",
    "codigo": "G739"
  },
  {
    "nome": "graham m",
    "codigo": "G741"
  },
  {
    "nome": "graham s",
    "codigo": "G742"
  },
  {
    "nome": "grai",
    "codigo": "G743"
  },
  {
    "nome": "gral",
    "codigo": "G744"
  },
  {
    "nome": "gram",
    "codigo": "G745"
  },
  {
    "nome": "grammo",
    "codigo": "G746"
  },
  {
    "nome": "gramo",
    "codigo": "G747"
  },
  {
    "nome": "gran",
    "codigo": "G748"
  },
  {
    "nome": "granc",
    "codigo": "G749"
  },
  {
    "nome": "grand",
    "codigo": "G751"
  },
  {
    "nome": "grandes",
    "codigo": "G752"
  },
  {
    "nome": "grandi",
    "codigo": "G753"
  },
  {
    "nome": "grandm",
    "codigo": "G754"
  },
  {
    "nome": "grandv",
    "codigo": "G755"
  },
  {
    "nome": "grane",
    "codigo": "G756"
  },
  {
    "nome": "grang",
    "codigo": "G757"
  },
  {
    "nome": "granger",
    "codigo": "G758"
  },
  {
    "nome": "grani",
    "codigo": "G759"
  },
  {
    "nome": "grant",
    "codigo": "G761"
  },
  {
    "nome": "grant h",
    "codigo": "G762"
  },
  {
    "nome": "grant s",
    "codigo": "G763"
  },
  {
    "nome": "grantl",
    "codigo": "G764"
  },
  {
    "nome": "granv",
    "codigo": "G765"
  },
  {
    "nome": "grap",
    "codigo": "G766"
  },
  {
    "nome": "gras",
    "codigo": "G767"
  },
  {
    "nome": "grass",
    "codigo": "G768"
  },
  {
    "nome": "grassi",
    "codigo": "G769"
  },
  {
    "nome": "grat",
    "codigo": "G771"
  },
  {
    "nome": "grati",
    "codigo": "G772"
  },
  {
    "nome": "gratt",
    "codigo": "G773"
  },
  {
    "nome": "grau",
    "codigo": "G774"
  },
  {
    "nome": "grav",
    "codigo": "G775"
  },
  {
    "nome": "graves",
    "codigo": "G776"
  },
  {
    "nome": "gravi",
    "codigo": "G777"
  },
  {
    "nome": "gray",
    "codigo": "G778"
  },
  {
    "nome": "gray g",
    "codigo": "G779"
  },
  {
    "nome": "gray m",
    "codigo": "G781"
  },
  {
    "nome": "gray s",
    "codigo": "G782"
  },
  {
    "nome": "gray w",
    "codigo": "G783"
  },
  {
    "nome": "grays",
    "codigo": "G784"
  },
  {
    "nome": "graz",
    "codigo": "G785"
  },
  {
    "nome": "gre",
    "codigo": "G786"
  },
  {
    "nome": "greav",
    "codigo": "G787"
  },
  {
    "nome": "greb",
    "codigo": "G788"
  },
  {
    "nome": "grec",
    "codigo": "G789"
  },
  {
    "nome": "greco",
    "codigo": "G791"
  },
  {
    "nome": "gred",
    "codigo": "G792"
  },
  {
    "nome": "gree",
    "codigo": "G793"
  },
  {
    "nome": "greel",
    "codigo": "G794"
  },
  {
    "nome": "green",
    "codigo": "G795"
  },
  {
    "nome": "green g",
    "codigo": "G796"
  },
  {
    "nome": "green m",
    "codigo": "G797"
  },
  {
    "nome": "green s",
    "codigo": "G798"
  },
  {
    "nome": "greene",
    "codigo": "G799"
  },
  {
    "nome": "greene j",
    "codigo": "G811"
  },
  {
    "nome": "greene s",
    "codigo": "G812"
  },
  {
    "nome": "greenh",
    "codigo": "G813"
  },
  {
    "nome": "greenl",
    "codigo": "G814"
  },
  {
    "nome": "greeno",
    "codigo": "G815"
  },
  {
    "nome": "greenw",
    "codigo": "G816"
  },
  {
    "nome": "gref",
    "codigo": "G817"
  },
  {
    "nome": "greg",
    "codigo": "G818"
  },
  {
    "nome": "gregg",
    "codigo": "G819"
  },
  {
    "nome": "gregori",
    "codigo": "G821"
  },
  {
    "nome": "gregory",
    "codigo": "G822"
  },
  {
    "nome": "gregory m",
    "codigo": "G823"
  },
  {
    "nome": "grei",
    "codigo": "G824"
  },
  {
    "nome": "grel",
    "codigo": "G825"
  },
  {
    "nome": "gren",
    "codigo": "G826"
  },
  {
    "nome": "greni",
    "codigo": "G827"
  },
  {
    "nome": "grenv",
    "codigo": "G828"
  },
  {
    "nome": "grep",
    "codigo": "G829"
  },
  {
    "nome": "gres",
    "codigo": "G831"
  },
  {
    "nome": "gress",
    "codigo": "G832"
  },
  {
    "nome": "gresw",
    "codigo": "G833"
  },
  {
    "nome": "gret",
    "codigo": "G834"
  },
  {
    "nome": "gretto",
    "codigo": "G835"
  },
  {
    "nome": "greu",
    "codigo": "G836"
  },
  {
    "nome": "grev",
    "codigo": "G837"
  },
  {
    "nome": "grevi",
    "codigo": "G838"
  },
  {
    "nome": "grevy",
    "codigo": "G839"
  },
  {
    "nome": "grew",
    "codigo": "G841"
  },
  {
    "nome": "grey",
    "codigo": "G842"
  },
  {
    "nome": "grey g",
    "codigo": "G843"
  },
  {
    "nome": "grey m",
    "codigo": "G844"
  },
  {
    "nome": "grey s",
    "codigo": "G845"
  },
  {
    "nome": "gri",
    "codigo": "G846"
  },
  {
    "nome": "grid",
    "codigo": "G847"
  },
  {
    "nome": "grie",
    "codigo": "G848"
  },
  {
    "nome": "grif",
    "codigo": "G849"
  },
  {
    "nome": "griffin",
    "codigo": "G851"
  },
  {
    "nome": "griffin m",
    "codigo": "G852"
  },
  {
    "nome": "griffith",
    "codigo": "G853"
  },
  {
    "nome": "griffith m",
    "codigo": "G854"
  },
  {
    "nome": "griffiths",
    "codigo": "G855"
  },
  {
    "nome": "griffo",
    "codigo": "G856"
  },
  {
    "nome": "grig",
    "codigo": "G857"
  },
  {
    "nome": "gril",
    "codigo": "G858"
  },
  {
    "nome": "grillo",
    "codigo": "G859"
  },
  {
    "nome": "grim",
    "codigo": "G861"
  },
  {
    "nome": "grime",
    "codigo": "G862"
  },
  {
    "nome": "grimk",
    "codigo": "G863"
  },
  {
    "nome": "grimm",
    "codigo": "G864"
  },
  {
    "nome": "grimo",
    "codigo": "G865"
  },
  {
    "nome": "grin",
    "codigo": "G866"
  },
  {
    "nome": "grinf",
    "codigo": "G867"
  },
  {
    "nome": "grinn",
    "codigo": "G868"
  },
  {
    "nome": "gris",
    "codigo": "G869"
  },
  {
    "nome": "grisw",
    "codigo": "G871"
  },
  {
    "nome": "griv",
    "codigo": "G872"
  },
  {
    "nome": "gro",
    "codigo": "G873"
  },
  {
    "nome": "groe",
    "codigo": "G874"
  },
  {
    "nome": "grol",
    "codigo": "G875"
  },
  {
    "nome": "gron",
    "codigo": "G876"
  },
  {
    "nome": "gros",
    "codigo": "G877"
  },
  {
    "nome": "gross",
    "codigo": "G878"
  },
  {
    "nome": "grosv",
    "codigo": "G879"
  },
  {
    "nome": "grot",
    "codigo": "G881"
  },
  {
    "nome": "grou",
    "codigo": "G882"
  },
  {
    "nome": "grov",
    "codigo": "G883"
  },
  {
    "nome": "groves",
    "codigo": "G884"
  },
  {
    "nome": "gru",
    "codigo": "G885"
  },
  {
    "nome": "grue",
    "codigo": "G886"
  },
  {
    "nome": "grul",
    "codigo": "G887"
  },
  {
    "nome": "grun",
    "codigo": "G888"
  },
  {
    "nome": "grund",
    "codigo": "G889"
  },
  {
    "nome": "grune",
    "codigo": "G891"
  },
  {
    "nome": "grup",
    "codigo": "G892"
  },
  {
    "nome": "grut",
    "codigo": "G893"
  },
  {
    "nome": "gry",
    "codigo": "G894"
  },
  {
    "nome": "gryp",
    "codigo": "G895"
  },
  {
    "nome": "gu",
    "codigo": "G896"
  },
  {
    "nome": "guad",
    "codigo": "G897"
  },
  {
    "nome": "guai",
    "codigo": "G898"
  },
  {
    "nome": "gual",
    "codigo": "G899"
  },
  {
    "nome": "guald",
    "codigo": "G911"
  },
  {
    "nome": "gualt",
    "codigo": "G912"
  },
  {
    "nome": "guan",
    "codigo": "G913"
  },
  {
    "nome": "guar",
    "codigo": "G914"
  },
  {
    "nome": "guari",
    "codigo": "G915"
  },
  {
    "nome": "guarn",
    "codigo": "G916"
  },
  {
    "nome": "guas",
    "codigo": "G917"
  },
  {
    "nome": "guat",
    "codigo": "G918"
  },
  {
    "nome": "guaz",
    "codigo": "G919"
  },
  {
    "nome": "gub",
    "codigo": "G921"
  },
  {
    "nome": "gud",
    "codigo": "G922"
  },
  {
    "nome": "gudm",
    "codigo": "G923"
  },
  {
    "nome": "gue",
    "codigo": "G924"
  },
  {
    "nome": "guel",
    "codigo": "G925"
  },
  {
    "nome": "guen",
    "codigo": "G926"
  },
  {
    "nome": "gueno",
    "codigo": "G927"
  },
  {
    "nome": "guep",
    "codigo": "G928"
  },
  {
    "nome": "guer",
    "codigo": "G929"
  },
  {
    "nome": "guere",
    "codigo": "G931"
  },
  {
    "nome": "gueri",
    "codigo": "G932"
  },
  {
    "nome": "guern",
    "codigo": "G933"
  },
  {
    "nome": "guerr",
    "codigo": "G934"
  },
  {
    "nome": "guerri",
    "codigo": "G935"
  },
  {
    "nome": "gues",
    "codigo": "G936"
  },
  {
    "nome": "guet",
    "codigo": "G937"
  },
  {
    "nome": "gueu",
    "codigo": "G938"
  },
  {
    "nome": "guev",
    "codigo": "G939"
  },
  {
    "nome": "guf",
    "codigo": "G941"
  },
  {
    "nome": "gug",
    "codigo": "G942"
  },
  {
    "nome": "gui",
    "codigo": "G943"
  },
  {
    "nome": "guib",
    "codigo": "G944"
  },
  {
    "nome": "guic",
    "codigo": "G945"
  },
  {
    "nome": "guid",
    "codigo": "G946"
  },
  {
    "nome": "guidi",
    "codigo": "G947"
  },
  {
    "nome": "guido",
    "codigo": "G948"
  },
  {
    "nome": "guie",
    "codigo": "G949"
  },
  {
    "nome": "guig",
    "codigo": "G951"
  },
  {
    "nome": "guij",
    "codigo": "G952"
  },
  {
    "nome": "guil",
    "codigo": "G953"
  },
  {
    "nome": "guild",
    "codigo": "G954"
  },
  {
    "nome": "guild m",
    "codigo": "G955"
  },
  {
    "nome": "guile",
    "codigo": "G956"
  },
  {
    "nome": "guill",
    "codigo": "G957"
  },
  {
    "nome": "guille",
    "codigo": "G958"
  },
  {
    "nome": "guilli",
    "codigo": "G959"
  },
  {
    "nome": "guillo",
    "codigo": "G961"
  },
  {
    "nome": "guillot",
    "codigo": "G962"
  },
  {
    "nome": "guim",
    "codigo": "G963"
  },
  {
    "nome": "guin",
    "codigo": "G964"
  },
  {
    "nome": "guir",
    "codigo": "G965"
  },
  {
    "nome": "guis",
    "codigo": "G966"
  },
  {
    "nome": "guise",
    "codigo": "G967"
  },
  {
    "nome": "guit",
    "codigo": "G968"
  },
  {
    "nome": "guiz",
    "codigo": "G969"
  },
  {
    "nome": "gul",
    "codigo": "G971"
  },
  {
    "nome": "gulg",
    "codigo": "G972"
  },
  {
    "nome": "gull",
    "codigo": "G973"
  },
  {
    "nome": "gum",
    "codigo": "G974"
  },
  {
    "nome": "gun",
    "codigo": "G975"
  },
  {
    "nome": "gunn",
    "codigo": "G976"
  },
  {
    "nome": "gunt",
    "codigo": "G977"
  },
  {
    "nome": "gur",
    "codigo": "G978"
  },
  {
    "nome": "gure",
    "codigo": "G979"
  },
  {
    "nome": "gurn",
    "codigo": "G981"
  },
  {
    "nome": "gus",
    "codigo": "G982"
  },
  {
    "nome": "gut",
    "codigo": "G983"
  },
  {
    "nome": "guth",
    "codigo": "G984"
  },
  {
    "nome": "gutt",
    "codigo": "G985"
  },
  {
    "nome": "guy",
    "codigo": "G986"
  },
  {
    "nome": "guyar",
    "codigo": "G987"
  },
  {
    "nome": "guye",
    "codigo": "G988"
  },
  {
    "nome": "guyo",
    "codigo": "G989"
  },
  {
    "nome": "guys",
    "codigo": "G991"
  },
  {
    "nome": "guyt",
    "codigo": "G992"
  },
  {
    "nome": "guz",
    "codigo": "G993"
  },
  {
    "nome": "gw",
    "codigo": "G994"
  },
  {
    "nome": "gwy",
    "codigo": "G995"
  },
  {
    "nome": "gy",
    "codigo": "G996"
  },
  {
    "nome": "gyll",
    "codigo": "G997"
  },
  {
    "nome": "gys",
    "codigo": "G998"
  },
  {
    "nome": "gyz",
    "codigo": "G999"
  },
  {
    "nome": "h",
    "codigo": "H111"
  },
  {
    "nome": "ha",
    "codigo": "H111"
  },
  {
    "nome": "haas",
    "codigo": "H112"
  },
  {
    "nome": "hab",
    "codigo": "H113"
  },
  {
    "nome": "haber",
    "codigo": "H114"
  },
  {
    "nome": "habert",
    "codigo": "H115"
  },
  {
    "nome": "habi",
    "codigo": "H116"
  },
  {
    "nome": "hac",
    "codigo": "H117"
  },
  {
    "nome": "hack",
    "codigo": "H118"
  },
  {
    "nome": "hacket",
    "codigo": "H119"
  },
  {
    "nome": "hackett",
    "codigo": "H121"
  },
  {
    "nome": "hackl",
    "codigo": "H122"
  },
  {
    "nome": "hackm",
    "codigo": "H123"
  },
  {
    "nome": "haco",
    "codigo": "H124"
  },
  {
    "nome": "had",
    "codigo": "H125"
  },
  {
    "nome": "hadd",
    "codigo": "H126"
  },
  {
    "nome": "haddo",
    "codigo": "H127"
  },
  {
    "nome": "hade",
    "codigo": "H128"
  },
  {
    "nome": "hadf",
    "codigo": "H129"
  },
  {
    "nome": "hadl",
    "codigo": "H131"
  },
  {
    "nome": "hadr",
    "codigo": "H132"
  },
  {
    "nome": "hae",
    "codigo": "H133"
  },
  {
    "nome": "hael",
    "codigo": "H134"
  },
  {
    "nome": "haen",
    "codigo": "H135"
  },
  {
    "nome": "haer",
    "codigo": "H136"
  },
  {
    "nome": "haeu",
    "codigo": "H137"
  },
  {
    "nome": "haf",
    "codigo": "H138"
  },
  {
    "nome": "hafi",
    "codigo": "H139"
  },
  {
    "nome": "hag",
    "codigo": "H141"
  },
  {
    "nome": "hagem",
    "codigo": "H142"
  },
  {
    "nome": "hagen",
    "codigo": "H143"
  },
  {
    "nome": "hager",
    "codigo": "H144"
  },
  {
    "nome": "hagg",
    "codigo": "H145"
  },
  {
    "nome": "hags",
    "codigo": "H146"
  },
  {
    "nome": "hagu",
    "codigo": "H147"
  },
  {
    "nome": "hah",
    "codigo": "H148"
  },
  {
    "nome": "hai",
    "codigo": "H149"
  },
  {
    "nome": "hail",
    "codigo": "H151"
  },
  {
    "nome": "hain",
    "codigo": "H152"
  },
  {
    "nome": "haines",
    "codigo": "H153"
  },
  {
    "nome": "haj",
    "codigo": "H154"
  },
  {
    "nome": "hak",
    "codigo": "H155"
  },
  {
    "nome": "hakl",
    "codigo": "H156"
  },
  {
    "nome": "hal",
    "codigo": "H157"
  },
  {
    "nome": "hald",
    "codigo": "H158"
  },
  {
    "nome": "halde",
    "codigo": "H159"
  },
  {
    "nome": "hale",
    "codigo": "H161"
  },
  {
    "nome": "hale g",
    "codigo": "H162"
  },
  {
    "nome": "hale m",
    "codigo": "H163"
  },
  {
    "nome": "hale s",
    "codigo": "H164"
  },
  {
    "nome": "hale w",
    "codigo": "H165"
  },
  {
    "nome": "halen",
    "codigo": "H166"
  },
  {
    "nome": "hales",
    "codigo": "H167"
  },
  {
    "nome": "halet",
    "codigo": "H168"
  },
  {
    "nome": "half",
    "codigo": "H169"
  },
  {
    "nome": "halh",
    "codigo": "H171"
  },
  {
    "nome": "hali",
    "codigo": "H172"
  },
  {
    "nome": "halif",
    "codigo": "H173"
  },
  {
    "nome": "hall",
    "codigo": "H174"
  },
  {
    "nome": "hall d",
    "codigo": "H175"
  },
  {
    "nome": "hall g",
    "codigo": "H176"
  },
  {
    "nome": "hall j",
    "codigo": "H177"
  },
  {
    "nome": "hall m",
    "codigo": "H178"
  },
  {
    "nome": "hall s",
    "codigo": "H179"
  },
  {
    "nome": "hall w",
    "codigo": "H181"
  },
  {
    "nome": "hallam",
    "codigo": "H182"
  },
  {
    "nome": "halle",
    "codigo": "H183"
  },
  {
    "nome": "hallec",
    "codigo": "H184"
  },
  {
    "nome": "haller",
    "codigo": "H185"
  },
  {
    "nome": "hallet",
    "codigo": "H186"
  },
  {
    "nome": "halley",
    "codigo": "H187"
  },
  {
    "nome": "halli",
    "codigo": "H188"
  },
  {
    "nome": "hallig",
    "codigo": "H189"
  },
  {
    "nome": "halliw",
    "codigo": "H191"
  },
  {
    "nome": "hallo",
    "codigo": "H192"
  },
  {
    "nome": "hallow",
    "codigo": "H193"
  },
  {
    "nome": "halm",
    "codigo": "H194"
  },
  {
    "nome": "halp",
    "codigo": "H195"
  },
  {
    "nome": "hals",
    "codigo": "H196"
  },
  {
    "nome": "halt",
    "codigo": "H197"
  },
  {
    "nome": "ham",
    "codigo": "H198"
  },
  {
    "nome": "hamb",
    "codigo": "H199"
  },
  {
    "nome": "hamd",
    "codigo": "H211"
  },
  {
    "nome": "hame",
    "codigo": "H212"
  },
  {
    "nome": "hameli",
    "codigo": "H213"
  },
  {
    "nome": "hamer",
    "codigo": "H214"
  },
  {
    "nome": "hamert",
    "codigo": "H215"
  },
  {
    "nome": "hami",
    "codigo": "H216"
  },
  {
    "nome": "hamil",
    "codigo": "H217"
  },
  {
    "nome": "hamilton g",
    "codigo": "H218"
  },
  {
    "nome": "hamilton m",
    "codigo": "H219"
  },
  {
    "nome": "hamilton s",
    "codigo": "H221"
  },
  {
    "nome": "hamilton w",
    "codigo": "H222"
  },
  {
    "nome": "haml",
    "codigo": "H223"
  },
  {
    "nome": "hamm",
    "codigo": "H224"
  },
  {
    "nome": "hammo",
    "codigo": "H225"
  },
  {
    "nome": "hammond g",
    "codigo": "H226"
  },
  {
    "nome": "hammond m",
    "codigo": "H227"
  },
  {
    "nome": "hamo",
    "codigo": "H228"
  },
  {
    "nome": "hamp",
    "codigo": "H229"
  },
  {
    "nome": "hamps",
    "codigo": "H231"
  },
  {
    "nome": "hampt",
    "codigo": "H232"
  },
  {
    "nome": "han",
    "codigo": "H233"
  },
  {
    "nome": "hanc",
    "codigo": "H234"
  },
  {
    "nome": "hancock m",
    "codigo": "H235"
  },
  {
    "nome": "hand",
    "codigo": "H236"
  },
  {
    "nome": "hane",
    "codigo": "H237"
  },
  {
    "nome": "hanf",
    "codigo": "H238"
  },
  {
    "nome": "hang",
    "codigo": "H239"
  },
  {
    "nome": "hank",
    "codigo": "H241"
  },
  {
    "nome": "hanm",
    "codigo": "H242"
  },
  {
    "nome": "hann",
    "codigo": "H243"
  },
  {
    "nome": "hanne",
    "codigo": "H244"
  },
  {
    "nome": "hanni",
    "codigo": "H245"
  },
  {
    "nome": "hanno",
    "codigo": "H246"
  },
  {
    "nome": "hano",
    "codigo": "H247"
  },
  {
    "nome": "hanr",
    "codigo": "H248"
  },
  {
    "nome": "hans",
    "codigo": "H249"
  },
  {
    "nome": "hanso",
    "codigo": "H251"
  },
  {
    "nome": "hanw",
    "codigo": "H252"
  },
  {
    "nome": "haq",
    "codigo": "H253"
  },
  {
    "nome": "har",
    "codigo": "H254"
  },
  {
    "nome": "harb",
    "codigo": "H255"
  },
  {
    "nome": "harc",
    "codigo": "H256"
  },
  {
    "nome": "harcou",
    "codigo": "H257"
  },
  {
    "nome": "hard",
    "codigo": "H258"
  },
  {
    "nome": "harden",
    "codigo": "H259"
  },
  {
    "nome": "hardi",
    "codigo": "H261"
  },
  {
    "nome": "hardie",
    "codigo": "H262"
  },
  {
    "nome": "harding",
    "codigo": "H263"
  },
  {
    "nome": "hardinge",
    "codigo": "H264"
  },
  {
    "nome": "hardo",
    "codigo": "H265"
  },
  {
    "nome": "hardt",
    "codigo": "H266"
  },
  {
    "nome": "hardw",
    "codigo": "H267"
  },
  {
    "nome": "hardy",
    "codigo": "H268"
  },
  {
    "nome": "hardy g",
    "codigo": "H269"
  },
  {
    "nome": "hardy m",
    "codigo": "H271"
  },
  {
    "nome": "hardy s",
    "codigo": "H272"
  },
  {
    "nome": "hardy w",
    "codigo": "H273"
  },
  {
    "nome": "hare",
    "codigo": "H274"
  },
  {
    "nome": "hare m",
    "codigo": "H275"
  },
  {
    "nome": "haren",
    "codigo": "H276"
  },
  {
    "nome": "harew",
    "codigo": "H277"
  },
  {
    "nome": "harf",
    "codigo": "H278"
  },
  {
    "nome": "harg",
    "codigo": "H279"
  },
  {
    "nome": "hari",
    "codigo": "H281"
  },
  {
    "nome": "hario",
    "codigo": "H282"
  },
  {
    "nome": "harl",
    "codigo": "H283"
  },
  {
    "nome": "harle",
    "codigo": "H284"
  },
  {
    "nome": "harley",
    "codigo": "H285"
  },
  {
    "nome": "harlo",
    "codigo": "H286"
  },
  {
    "nome": "harm",
    "codigo": "H287"
  },
  {
    "nome": "harmo",
    "codigo": "H288"
  },
  {
    "nome": "harn",
    "codigo": "H289"
  },
  {
    "nome": "harni",
    "codigo": "H291"
  },
  {
    "nome": "haro",
    "codigo": "H292"
  },
  {
    "nome": "harp",
    "codigo": "H293"
  },
  {
    "nome": "harper g",
    "codigo": "H294"
  },
  {
    "nome": "harper w",
    "codigo": "H295"
  },
  {
    "nome": "harr",
    "codigo": "H296"
  },
  {
    "nome": "harri",
    "codigo": "H297"
  },
  {
    "nome": "harriman m",
    "codigo": "H298"
  },
  {
    "nome": "harrin",
    "codigo": "H299"
  },
  {
    "nome": "harrington m",
    "codigo": "H311"
  },
  {
    "nome": "harrio",
    "codigo": "H312"
  },
  {
    "nome": "harris",
    "codigo": "H313"
  },
  {
    "nome": "harris f",
    "codigo": "H314"
  },
  {
    "nome": "harris m",
    "codigo": "H315"
  },
  {
    "nome": "harris s",
    "codigo": "H316"
  },
  {
    "nome": "harris w",
    "codigo": "H317"
  },
  {
    "nome": "harrison",
    "codigo": "H318"
  },
  {
    "nome": "harrison f",
    "codigo": "H319"
  },
  {
    "nome": "harrison m",
    "codigo": "H321"
  },
  {
    "nome": "harrison s",
    "codigo": "H322"
  },
  {
    "nome": "harrison w",
    "codigo": "H323"
  },
  {
    "nome": "hars",
    "codigo": "H324"
  },
  {
    "nome": "hart",
    "codigo": "H325"
  },
  {
    "nome": "hart m",
    "codigo": "H326"
  },
  {
    "nome": "harte",
    "codigo": "H327"
  },
  {
    "nome": "harte m",
    "codigo": "H328"
  },
  {
    "nome": "harti",
    "codigo": "H329"
  },
  {
    "nome": "hartl",
    "codigo": "H331"
  },
  {
    "nome": "hartley",
    "codigo": "H332"
  },
  {
    "nome": "hartm",
    "codigo": "H333"
  },
  {
    "nome": "harto",
    "codigo": "H334"
  },
  {
    "nome": "harts",
    "codigo": "H335"
  },
  {
    "nome": "hartu",
    "codigo": "H336"
  },
  {
    "nome": "hartw",
    "codigo": "H337"
  },
  {
    "nome": "hartz",
    "codigo": "H338"
  },
  {
    "nome": "harv",
    "codigo": "H339"
  },
  {
    "nome": "harvey",
    "codigo": "H341"
  },
  {
    "nome": "harvey m",
    "codigo": "H342"
  },
  {
    "nome": "harw",
    "codigo": "H343"
  },
  {
    "nome": "has",
    "codigo": "H344"
  },
  {
    "nome": "hasd",
    "codigo": "H345"
  },
  {
    "nome": "hase",
    "codigo": "H346"
  },
  {
    "nome": "hasel",
    "codigo": "H347"
  },
  {
    "nome": "hasen",
    "codigo": "H348"
  },
  {
    "nome": "hask",
    "codigo": "H349"
  },
  {
    "nome": "haski",
    "codigo": "H351"
  },
  {
    "nome": "hasl",
    "codigo": "H352"
  },
  {
    "nome": "hass",
    "codigo": "H353"
  },
  {
    "nome": "hasse",
    "codigo": "H354"
  },
  {
    "nome": "hassel",
    "codigo": "H355"
  },
  {
    "nome": "hast",
    "codigo": "H356"
  },
  {
    "nome": "hastings",
    "codigo": "H357"
  },
  {
    "nome": "hastings m",
    "codigo": "H358"
  },
  {
    "nome": "hasw",
    "codigo": "H359"
  },
  {
    "nome": "hat",
    "codigo": "H361"
  },
  {
    "nome": "hatf",
    "codigo": "H362"
  },
  {
    "nome": "hath",
    "codigo": "H363"
  },
  {
    "nome": "hathert",
    "codigo": "H364"
  },
  {
    "nome": "hats",
    "codigo": "H365"
  },
  {
    "nome": "hatt",
    "codigo": "H366"
  },
  {
    "nome": "hatz",
    "codigo": "H367"
  },
  {
    "nome": "hau",
    "codigo": "H368"
  },
  {
    "nome": "hauf",
    "codigo": "H369"
  },
  {
    "nome": "haug",
    "codigo": "H371"
  },
  {
    "nome": "fagi",
    "codigo": "F155"
  },
  {
    "nome": "fagn",
    "codigo": "F156"
  },
  {
    "nome": "fah",
    "codigo": "F157"
  },
  {
    "nome": "fahr",
    "codigo": "F158"
  },
  {
    "nome": "fai",
    "codigo": "F159"
  },
  {
    "nome": "fail",
    "codigo": "F161"
  },
  {
    "nome": "fain",
    "codigo": "F162"
  },
  {
    "nome": "fair",
    "codigo": "F163"
  },
  {
    "nome": "fairban",
    "codigo": "F164"
  },
  {
    "nome": "fairc",
    "codigo": "F165"
  },
  {
    "nome": "fairf",
    "codigo": "F166"
  },
  {
    "nome": "fairfax m",
    "codigo": "F167"
  },
  {
    "nome": "fairfie",
    "codigo": "F168"
  },
  {
    "nome": "fairfield m",
    "codigo": "F169"
  },
  {
    "nome": "fairh",
    "codigo": "F171"
  },
  {
    "nome": "fairl",
    "codigo": "F172"
  },
  {
    "nome": "fais",
    "codigo": "F173"
  },
  {
    "nome": "fait",
    "codigo": "F174"
  },
  {
    "nome": "faiv",
    "codigo": "F175"
  },
  {
    "nome": "fak",
    "codigo": "F176"
  },
  {
    "nome": "fal",
    "codigo": "F177"
  },
  {
    "nome": "falc",
    "codigo": "F178"
  },
  {
    "nome": "falck",
    "codigo": "F179"
  },
  {
    "nome": "falco",
    "codigo": "F181"
  },
  {
    "nome": "falcone",
    "codigo": "F182"
  },
  {
    "nome": "falconer m",
    "codigo": "F183"
  },
  {
    "nome": "falconet",
    "codigo": "F184"
  },
  {
    "nome": "falcu",
    "codigo": "F185"
  },
  {
    "nome": "fald",
    "codigo": "F186"
  },
  {
    "nome": "fale",
    "codigo": "F187"
  },
  {
    "nome": "falg",
    "codigo": "F188"
  },
  {
    "nome": "fali",
    "codigo": "F189"
  },
  {
    "nome": "falk",
    "codigo": "F191"
  },
  {
    "nome": "falken",
    "codigo": "F192"
  },
  {
    "nome": "falkn",
    "codigo": "F193"
  },
  {
    "nome": "fall",
    "codigo": "F194"
  },
  {
    "nome": "fallet",
    "codigo": "F195"
  },
  {
    "nome": "fallo",
    "codigo": "F196"
  },
  {
    "nome": "fals",
    "codigo": "F197"
  },
  {
    "nome": "fam",
    "codigo": "F198"
  },
  {
    "nome": "fan",
    "codigo": "F199"
  },
  {
    "nome": "fane",
    "codigo": "F211"
  },
  {
    "nome": "fani",
    "codigo": "F212"
  },
  {
    "nome": "fann",
    "codigo": "F213"
  },
  {
    "nome": "fano",
    "codigo": "F214"
  },
  {
    "nome": "fans",
    "codigo": "F215"
  },
  {
    "nome": "fant",
    "codigo": "F216"
  },
  {
    "nome": "fanto",
    "codigo": "F217"
  },
  {
    "nome": "fantu",
    "codigo": "F218"
  },
  {
    "nome": "far",
    "codigo": "F219"
  },
  {
    "nome": "farc",
    "codigo": "F221"
  },
  {
    "nome": "fare",
    "codigo": "F222"
  },
  {
    "nome": "farg",
    "codigo": "F223"
  },
  {
    "nome": "fari",
    "codigo": "F224"
  },
  {
    "nome": "farin",
    "codigo": "F225"
  },
  {
    "nome": "faring",
    "codigo": "F226"
  },
  {
    "nome": "farini",
    "codigo": "F227"
  },
  {
    "nome": "faris",
    "codigo": "F228"
  },
  {
    "nome": "farj",
    "codigo": "F229"
  },
  {
    "nome": "farl",
    "codigo": "F231"
  },
  {
    "nome": "farley m",
    "codigo": "F232"
  },
  {
    "nome": "farm",
    "codigo": "F233"
  },
  {
    "nome": "farmer m",
    "codigo": "F234"
  },
  {
    "nome": "farn",
    "codigo": "F235"
  },
  {
    "nome": "farnh",
    "codigo": "F236"
  },
  {
    "nome": "faro",
    "codigo": "F237"
  },
  {
    "nome": "farq",
    "codigo": "F238"
  },
  {
    "nome": "farr",
    "codigo": "F239"
  },
  {
    "nome": "farran",
    "codigo": "F241"
  },
  {
    "nome": "farrar",
    "codigo": "F242"
  },
  {
    "nome": "farrar j",
    "codigo": "F243"
  },
  {
    "nome": "farrar s",
    "codigo": "F244"
  },
  {
    "nome": "farre",
    "codigo": "F245"
  },
  {
    "nome": "farri",
    "codigo": "F246"
  },
  {
    "nome": "fars",
    "codigo": "F247"
  },
  {
    "nome": "fas",
    "codigo": "F248"
  },
  {
    "nome": "fass",
    "codigo": "F249"
  },
  {
    "nome": "fast",
    "codigo": "F251"
  },
  {
    "nome": "fat",
    "codigo": "F252"
  },
  {
    "nome": "fati",
    "codigo": "F253"
  },
  {
    "nome": "fato",
    "codigo": "F254"
  },
  {
    "nome": "fau",
    "codigo": "F255"
  },
  {
    "nome": "fauch",
    "codigo": "F256"
  },
  {
    "nome": "fauci",
    "codigo": "F257"
  },
  {
    "nome": "faud",
    "codigo": "F258"
  },
  {
    "nome": "faug",
    "codigo": "F259"
  },
  {
    "nome": "faul",
    "codigo": "F261"
  },
  {
    "nome": "faulh",
    "codigo": "F262"
  },
  {
    "nome": "faulk",
    "codigo": "F263"
  },
  {
    "nome": "faun",
    "codigo": "F264"
  },
  {
    "nome": "faur",
    "codigo": "F265"
  },
  {
    "nome": "fauri",
    "codigo": "F266"
  },
  {
    "nome": "faus",
    "codigo": "F267"
  },
  {
    "nome": "fausti",
    "codigo": "F268"
  },
  {
    "nome": "faustu",
    "codigo": "F269"
  },
  {
    "nome": "fauv",
    "codigo": "F271"
  },
  {
    "nome": "fav",
    "codigo": "F272"
  },
  {
    "nome": "fave",
    "codigo": "F273"
  },
  {
    "nome": "favi",
    "codigo": "F274"
  },
  {
    "nome": "favo",
    "codigo": "F275"
  },
  {
    "nome": "favr",
    "codigo": "F276"
  },
  {
    "nome": "favre",
    "codigo": "F277"
  },
  {
    "nome": "faw",
    "codigo": "F278"
  },
  {
    "nome": "fawe",
    "codigo": "F279"
  },
  {
    "nome": "fawk",
    "codigo": "F281"
  },
  {
    "nome": "fay",
    "codigo": "F282"
  },
  {
    "nome": "faye",
    "codigo": "F283"
  },
  {
    "nome": "fayet",
    "codigo": "F284"
  },
  {
    "nome": "fayo",
    "codigo": "F285"
  },
  {
    "nome": "fayt",
    "codigo": "F286"
  },
  {
    "nome": "faz",
    "codigo": "F287"
  },
  {
    "nome": "fe",
    "codigo": "F288"
  },
  {
    "nome": "feb",
    "codigo": "F289"
  },
  {
    "nome": "fec",
    "codigo": "F291"
  },
  {
    "nome": "fed",
    "codigo": "F292"
  },
  {
    "nome": "feder",
    "codigo": "F293"
  },
  {
    "nome": "fedo",
    "codigo": "F294"
  },
  {
    "nome": "fee",
    "codigo": "F295"
  },
  {
    "nome": "feh",
    "codigo": "F296"
  },
  {
    "nome": "fei",
    "codigo": "F297"
  },
  {
    "nome": "feildi",
    "codigo": "F298"
  },
  {
    "nome": "fein",
    "codigo": "F299"
  },
  {
    "nome": "feit",
    "codigo": "F311"
  },
  {
    "nome": "feld",
    "codigo": "F312"
  },
  {
    "nome": "feli",
    "codigo": "F313"
  },
  {
    "nome": "felic",
    "codigo": "F314"
  },
  {
    "nome": "felin",
    "codigo": "F315"
  },
  {
    "nome": "felix",
    "codigo": "F316"
  },
  {
    "nome": "fell",
    "codigo": "F317"
  },
  {
    "nome": "felle",
    "codigo": "F318"
  },
  {
    "nome": "felli",
    "codigo": "F319"
  },
  {
    "nome": "fello",
    "codigo": "F321"
  },
  {
    "nome": "fellow",
    "codigo": "F322"
  },
  {
    "nome": "felo",
    "codigo": "F323"
  },
  {
    "nome": "fels",
    "codigo": "F324"
  },
  {
    "nome": "felt",
    "codigo": "F325"
  },
  {
    "nome": "felto",
    "codigo": "F326"
  },
  {
    "nome": "felton m",
    "codigo": "F327"
  },
  {
    "nome": "feltr",
    "codigo": "F328"
  },
  {
    "nome": "felv",
    "codigo": "F329"
  },
  {
    "nome": "fen",
    "codigo": "F331"
  },
  {
    "nome": "fene",
    "codigo": "F332"
  },
  {
    "nome": "feni",
    "codigo": "F333"
  },
  {
    "nome": "fenn",
    "codigo": "F334"
  },
  {
    "nome": "fennel",
    "codigo": "F335"
  },
  {
    "nome": "fenner",
    "codigo": "F336"
  },
  {
    "nome": "fenni",
    "codigo": "F337"
  },
  {
    "nome": "fenno",
    "codigo": "F338"
  },
  {
    "nome": "feno",
    "codigo": "F339"
  },
  {
    "nome": "fens",
    "codigo": "F341"
  },
  {
    "nome": "fent",
    "codigo": "F342"
  },
  {
    "nome": "fenw",
    "codigo": "F343"
  },
  {
    "nome": "feo",
    "codigo": "F344"
  },
  {
    "nome": "fer",
    "codigo": "F345"
  },
  {
    "nome": "ferb",
    "codigo": "F346"
  },
  {
    "nome": "ferd",
    "codigo": "F347"
  },
  {
    "nome": "ferdo",
    "codigo": "F348"
  },
  {
    "nome": "fere",
    "codigo": "F349"
  },
  {
    "nome": "ferg",
    "codigo": "F351"
  },
  {
    "nome": "fergu",
    "codigo": "F352"
  },
  {
    "nome": "ferguson m",
    "codigo": "F353"
  },
  {
    "nome": "ferguss",
    "codigo": "F354"
  },
  {
    "nome": "ferh",
    "codigo": "F355"
  },
  {
    "nome": "feri",
    "codigo": "F356"
  },
  {
    "nome": "ferl",
    "codigo": "F357"
  },
  {
    "nome": "ferm",
    "codigo": "F358"
  },
  {
    "nome": "ferme",
    "codigo": "F359"
  },
  {
    "nome": "fermo",
    "codigo": "F361"
  },
  {
    "nome": "fern",
    "codigo": "F362"
  },
  {
    "nome": "fernand",
    "codigo": "F363"
  },
  {
    "nome": "ferne",
    "codigo": "F364"
  },
  {
    "nome": "ferni",
    "codigo": "F365"
  },
  {
    "nome": "ferno",
    "codigo": "F366"
  },
  {
    "nome": "fero",
    "codigo": "F367"
  },
  {
    "nome": "ferr",
    "codigo": "F368"
  },
  {
    "nome": "ferral",
    "codigo": "F369"
  },
  {
    "nome": "ferram",
    "codigo": "F371"
  },
  {
    "nome": "ferran",
    "codigo": "F372"
  },
  {
    "nome": "ferrant",
    "codigo": "F373"
  },
  {
    "nome": "ferrar",
    "codigo": "F374"
  },
  {
    "nome": "ferrari",
    "codigo": "F375"
  },
  {
    "nome": "ferraro",
    "codigo": "F376"
  },
  {
    "nome": "ferrars",
    "codigo": "F377"
  },
  {
    "nome": "ferrary",
    "codigo": "F378"
  },
  {
    "nome": "ferrat",
    "codigo": "F379"
  },
  {
    "nome": "ferrau",
    "codigo": "F381"
  },
  {
    "nome": "ferre",
    "codigo": "F382"
  },
  {
    "nome": "ferrei",
    "codigo": "F383"
  },
  {
    "nome": "ferreo",
    "codigo": "F384"
  },
  {
    "nome": "ferrer",
    "codigo": "F385"
  },
  {
    "nome": "ferrero",
    "codigo": "F386"
  },
  {
    "nome": "ferret",
    "codigo": "F387"
  },
  {
    "nome": "ferri",
    "codigo": "F388"
  },
  {
    "nome": "ferrib",
    "codigo": "F389"
  },
  {
    "nome": "ferrie",
    "codigo": "F391"
  },
  {
    "nome": "ferrin",
    "codigo": "F392"
  },
  {
    "nome": "ferrio",
    "codigo": "F393"
  },
  {
    "nome": "ferris",
    "codigo": "F394"
  },
  {
    "nome": "ferro",
    "codigo": "F395"
  },
  {
    "nome": "ferron",
    "codigo": "F396"
  },
  {
    "nome": "ferrou",
    "codigo": "F397"
  },
  {
    "nome": "ferru",
    "codigo": "F398"
  },
  {
    "nome": "ferry",
    "codigo": "F399"
  },
  {
    "nome": "fert",
    "codigo": "F411"
  },
  {
    "nome": "feru",
    "codigo": "F412"
  },
  {
    "nome": "fes",
    "codigo": "F413"
  },
  {
    "nome": "fessen",
    "codigo": "F414"
  },
  {
    "nome": "fessenden m",
    "codigo": "F415"
  },
  {
    "nome": "fessi",
    "codigo": "F416"
  },
  {
    "nome": "fessl",
    "codigo": "F417"
  },
  {
    "nome": "fest",
    "codigo": "F418"
  },
  {
    "nome": "fet",
    "codigo": "F419"
  },
  {
    "nome": "fett",
    "codigo": "F421"
  },
  {
    "nome": "feu",
    "codigo": "F422"
  },
  {
    "nome": "feuer",
    "codigo": "F423"
  },
  {
    "nome": "feug",
    "codigo": "F424"
  },
  {
    "nome": "feui",
    "codigo": "F425"
  },
  {
    "nome": "feuill",
    "codigo": "F426"
  },
  {
    "nome": "feutv",
    "codigo": "F427"
  },
  {
    "nome": "fev",
    "codigo": "F428"
  },
  {
    "nome": "fevr",
    "codigo": "F429"
  },
  {
    "nome": "fevret",
    "codigo": "F431"
  },
  {
    "nome": "few",
    "codigo": "F432"
  },
  {
    "nome": "fey",
    "codigo": "F433"
  },
  {
    "nome": "feyer",
    "codigo": "F434"
  },
  {
    "nome": "feyn",
    "codigo": "F435"
  },
  {
    "nome": "ffa",
    "codigo": "F436"
  },
  {
    "nome": "ffo",
    "codigo": "F437"
  },
  {
    "nome": "fi",
    "codigo": "F438"
  },
  {
    "nome": "fiam",
    "codigo": "F439"
  },
  {
    "nome": "fian",
    "codigo": "F441"
  },
  {
    "nome": "fias",
    "codigo": "F442"
  },
  {
    "nome": "fib",
    "codigo": "F443"
  },
  {
    "nome": "fic",
    "codigo": "F444"
  },
  {
    "nome": "fich",
    "codigo": "F445"
  },
  {
    "nome": "fici",
    "codigo": "F446"
  },
  {
    "nome": "fick",
    "codigo": "F447"
  },
  {
    "nome": "fico",
    "codigo": "F448"
  },
  {
    "nome": "fid",
    "codigo": "F449"
  },
  {
    "nome": "fide",
    "codigo": "F451"
  },
  {
    "nome": "fie",
    "codigo": "F452"
  },
  {
    "nome": "field",
    "codigo": "F453"
  },
  {
    "nome": "field h",
    "codigo": "F454"
  },
  {
    "nome": "field m",
    "codigo": "F455"
  },
  {
    "nome": "field s",
    "codigo": "F456"
  },
  {
    "nome": "field w",
    "codigo": "F457"
  },
  {
    "nome": "fielde",
    "codigo": "F458"
  },
  {
    "nome": "fieldi",
    "codigo": "F459"
  },
  {
    "nome": "fields",
    "codigo": "F461"
  },
  {
    "nome": "fields j",
    "codigo": "F462"
  },
  {
    "nome": "fields s",
    "codigo": "F463"
  },
  {
    "nome": "fien",
    "codigo": "F464"
  },
  {
    "nome": "fier",
    "codigo": "F465"
  },
  {
    "nome": "fies",
    "codigo": "F466"
  },
  {
    "nome": "fiesco",
    "codigo": "F467"
  },
  {
    "nome": "fieso",
    "codigo": "F468"
  },
  {
    "nome": "fif",
    "codigo": "F469"
  },
  {
    "nome": "fig",
    "codigo": "F471"
  },
  {
    "nome": "figi",
    "codigo": "F472"
  },
  {
    "nome": "figo",
    "codigo": "F473"
  },
  {
    "nome": "figr",
    "codigo": "F474"
  },
  {
    "nome": "figu",
    "codigo": "F475"
  },
  {
    "nome": "figui",
    "codigo": "F476"
  },
  {
    "nome": "figul",
    "codigo": "F477"
  },
  {
    "nome": "fil",
    "codigo": "F478"
  },
  {
    "nome": "filas",
    "codigo": "F479"
  },
  {
    "nome": "file",
    "codigo": "F481"
  },
  {
    "nome": "fili",
    "codigo": "F482"
  },
  {
    "nome": "filip",
    "codigo": "F483"
  },
  {
    "nome": "fill",
    "codigo": "F484"
  },
  {
    "nome": "fille",
    "codigo": "F485"
  },
  {
    "nome": "filli",
    "codigo": "F486"
  },
  {
    "nome": "fillm",
    "codigo": "F487"
  },
  {
    "nome": "filo",
    "codigo": "F488"
  },
  {
    "nome": "fils",
    "codigo": "F489"
  },
  {
    "nome": "fin",
    "codigo": "F491"
  },
  {
    "nome": "finch",
    "codigo": "F492"
  },
  {
    "nome": "finck",
    "codigo": "F493"
  },
  {
    "nome": "find",
    "codigo": "F494"
  },
  {
    "nome": "fine",
    "codigo": "F495"
  },
  {
    "nome": "finet",
    "codigo": "F496"
  },
  {
    "nome": "fing",
    "codigo": "F497"
  },
  {
    "nome": "fini",
    "codigo": "F498"
  },
  {
    "nome": "fink",
    "codigo": "F499"
  },
  {
    "nome": "finl",
    "codigo": "F511"
  },
  {
    "nome": "finlays",
    "codigo": "F512"
  },
  {
    "nome": "finley",
    "codigo": "F513"
  },
  {
    "nome": "finn",
    "codigo": "F514"
  },
  {
    "nome": "fino",
    "codigo": "F515"
  },
  {
    "nome": "fins",
    "codigo": "F516"
  },
  {
    "nome": "fio",
    "codigo": "F517"
  },
  {
    "nome": "fiore",
    "codigo": "F518"
  },
  {
    "nome": "fiori",
    "codigo": "F519"
  },
  {
    "nome": "fiorin",
    "codigo": "F521"
  },
  {
    "nome": "fir",
    "codigo": "F522"
  },
  {
    "nome": "fire",
    "codigo": "F523"
  },
  {
    "nome": "firm",
    "codigo": "F524"
  },
  {
    "nome": "firmin",
    "codigo": "F525"
  },
  {
    "nome": "firn",
    "codigo": "F526"
  },
  {
    "nome": "firo",
    "codigo": "F527"
  },
  {
    "nome": "fis",
    "codigo": "F528"
  },
  {
    "nome": "fische",
    "codigo": "F529"
  },
  {
    "nome": "fise",
    "codigo": "F531"
  },
  {
    "nome": "fish",
    "codigo": "F532"
  },
  {
    "nome": "fisher",
    "codigo": "F533"
  },
  {
    "nome": "fisher j",
    "codigo": "F534"
  },
  {
    "nome": "fisher m",
    "codigo": "F535"
  },
  {
    "nome": "fisher s",
    "codigo": "F536"
  },
  {
    "nome": "fisher w",
    "codigo": "F537"
  },
  {
    "nome": "fisk",
    "codigo": "F538"
  },
  {
    "nome": "fisk m",
    "codigo": "F539"
  },
  {
    "nome": "fiske",
    "codigo": "F541"
  },
  {
    "nome": "fiske m",
    "codigo": "F542"
  },
  {
    "nome": "fiss",
    "codigo": "F543"
  },
  {
    "nome": "fit",
    "codigo": "F544"
  },
  {
    "nome": "fitch j",
    "codigo": "F545"
  },
  {
    "nome": "fitch s",
    "codigo": "F546"
  },
  {
    "nome": "fitt",
    "codigo": "F547"
  },
  {
    "nome": "fitz",
    "codigo": "F548"
  },
  {
    "nome": "fitza",
    "codigo": "F549"
  },
  {
    "nome": "fitzb",
    "codigo": "F551"
  },
  {
    "nome": "fitzc",
    "codigo": "F552"
  },
  {
    "nome": "fitzg",
    "codigo": "F553"
  },
  {
    "nome": "fitzgerald m",
    "codigo": "F554"
  },
  {
    "nome": "fitzh",
    "codigo": "F555"
  },
  {
    "nome": "fitzj",
    "codigo": "F556"
  },
  {
    "nome": "fitzm",
    "codigo": "F557"
  },
  {
    "nome": "fitzn",
    "codigo": "F558"
  },
  {
    "nome": "fitzp",
    "codigo": "F559"
  },
  {
    "nome": "fitzr",
    "codigo": "F561"
  },
  {
    "nome": "fitzs",
    "codigo": "F562"
  },
  {
    "nome": "fitzt",
    "codigo": "F563"
  },
  {
    "nome": "fitzw",
    "codigo": "F564"
  },
  {
    "nome": "fiu",
    "codigo": "F565"
  },
  {
    "nome": "fix",
    "codigo": "F566"
  },
  {
    "nome": "fiz",
    "codigo": "F567"
  },
  {
    "nome": "fl",
    "codigo": "F568"
  },
  {
    "nome": "flac",
    "codigo": "F569"
  },
  {
    "nome": "flach",
    "codigo": "F571"
  },
  {
    "nome": "flaco",
    "codigo": "F572"
  },
  {
    "nome": "flad",
    "codigo": "F573"
  },
  {
    "nome": "flag",
    "codigo": "F574"
  },
  {
    "nome": "flah",
    "codigo": "F575"
  },
  {
    "nome": "flai",
    "codigo": "F576"
  },
  {
    "nome": "flam",
    "codigo": "F577"
  },
  {
    "nome": "flamen",
    "codigo": "F578"
  },
  {
    "nome": "flami",
    "codigo": "F579"
  },
  {
    "nome": "flamm",
    "codigo": "F581"
  },
  {
    "nome": "flams",
    "codigo": "F582"
  },
  {
    "nome": "flan",
    "codigo": "F583"
  },
  {
    "nome": "fland",
    "codigo": "F584"
  },
  {
    "nome": "flandr",
    "codigo": "F585"
  },
  {
    "nome": "flat",
    "codigo": "F586"
  },
  {
    "nome": "flau",
    "codigo": "F587"
  },
  {
    "nome": "flav",
    "codigo": "F588"
  },
  {
    "nome": "flavi",
    "codigo": "F589"
  },
  {
    "nome": "flavu",
    "codigo": "F591"
  },
  {
    "nome": "flax",
    "codigo": "F592"
  },
  {
    "nome": "fle",
    "codigo": "F593"
  },
  {
    "nome": "flee",
    "codigo": "F594"
  },
  {
    "nome": "fleetw",
    "codigo": "F595"
  },
  {
    "nome": "flei",
    "codigo": "F596"
  },
  {
    "nome": "flem",
    "codigo": "F597"
  },
  {
    "nome": "fleming m",
    "codigo": "F598"
  },
  {
    "nome": "flemm",
    "codigo": "F599"
  },
  {
    "nome": "fles",
    "codigo": "F611"
  },
  {
    "nome": "flet",
    "codigo": "F612"
  },
  {
    "nome": "fletcher j",
    "codigo": "F613"
  },
  {
    "nome": "fletcher p",
    "codigo": "F614"
  },
  {
    "nome": "fletcher s",
    "codigo": "F615"
  },
  {
    "nome": "fleu",
    "codigo": "F616"
  },
  {
    "nome": "fleuri",
    "codigo": "F617"
  },
  {
    "nome": "fleury",
    "codigo": "F618"
  },
  {
    "nome": "flex",
    "codigo": "F619"
  },
  {
    "nome": "fli",
    "codigo": "F621"
  },
  {
    "nome": "flin",
    "codigo": "F622"
  },
  {
    "nome": "flint",
    "codigo": "F623"
  },
  {
    "nome": "flint j",
    "codigo": "F624"
  },
  {
    "nome": "flint s",
    "codigo": "F625"
  },
  {
    "nome": "flip",
    "codigo": "F626"
  },
  {
    "nome": "flit",
    "codigo": "F627"
  },
  {
    "nome": "flo",
    "codigo": "F628"
  },
  {
    "nome": "flog",
    "codigo": "F629"
  },
  {
    "nome": "floo",
    "codigo": "F631"
  },
  {
    "nome": "flor",
    "codigo": "F632"
  },
  {
    "nome": "florent",
    "codigo": "F633"
  },
  {
    "nome": "flores",
    "codigo": "F634"
  },
  {
    "nome": "flori",
    "codigo": "F635"
  },
  {
    "nome": "florid",
    "codigo": "F636"
  },
  {
    "nome": "florin",
    "codigo": "F637"
  },
  {
    "nome": "florio",
    "codigo": "F638"
  },
  {
    "nome": "floris",
    "codigo": "F639"
  },
  {
    "nome": "floru",
    "codigo": "F641"
  },
  {
    "nome": "flot",
    "codigo": "F642"
  },
  {
    "nome": "flott",
    "codigo": "F643"
  },
  {
    "nome": "flow",
    "codigo": "F644"
  },
  {
    "nome": "floy",
    "codigo": "F645"
  },
  {
    "nome": "flu",
    "codigo": "F646"
  },
  {
    "nome": "flur",
    "codigo": "F647"
  },
  {
    "nome": "fly",
    "codigo": "F648"
  },
  {
    "nome": "fo",
    "codigo": "F649"
  },
  {
    "nome": "fob",
    "codigo": "F651"
  },
  {
    "nome": "foc",
    "codigo": "F652"
  },
  {
    "nome": "fod",
    "codigo": "F653"
  },
  {
    "nome": "foe",
    "codigo": "F654"
  },
  {
    "nome": "fog",
    "codigo": "F655"
  },
  {
    "nome": "fogl",
    "codigo": "F656"
  },
  {
    "nome": "foh",
    "codigo": "F657"
  },
  {
    "nome": "foi",
    "codigo": "F658"
  },
  {
    "nome": "foin",
    "codigo": "F659"
  },
  {
    "nome": "foix",
    "codigo": "F661"
  },
  {
    "nome": "fok",
    "codigo": "F662"
  },
  {
    "nome": "fol",
    "codigo": "F663"
  },
  {
    "nome": "folg",
    "codigo": "F664"
  },
  {
    "nome": "foli",
    "codigo": "F665"
  },
  {
    "nome": "folk",
    "codigo": "F666"
  },
  {
    "nome": "foll",
    "codigo": "F667"
  },
  {
    "nome": "folli",
    "codigo": "F668"
  },
  {
    "nome": "folq",
    "codigo": "F669"
  },
  {
    "nome": "fols",
    "codigo": "F671"
  },
  {
    "nome": "fom",
    "codigo": "F672"
  },
  {
    "nome": "fon",
    "codigo": "F673"
  },
  {
    "nome": "fonf",
    "codigo": "F674"
  },
  {
    "nome": "fonn",
    "codigo": "F675"
  },
  {
    "nome": "fons",
    "codigo": "F676"
  },
  {
    "nome": "font",
    "codigo": "F677"
  },
  {
    "nome": "fontai",
    "codigo": "F678"
  },
  {
    "nome": "fontan",
    "codigo": "F679"
  },
  {
    "nome": "fontani",
    "codigo": "F681"
  },
  {
    "nome": "fonte",
    "codigo": "F682"
  },
  {
    "nome": "fonten",
    "codigo": "F683"
  },
  {
    "nome": "fonti",
    "codigo": "F684"
  },
  {
    "nome": "fontr",
    "codigo": "F685"
  },
  {
    "nome": "foo",
    "codigo": "F686"
  },
  {
    "nome": "foot",
    "codigo": "F687"
  },
  {
    "nome": "foote",
    "codigo": "F688"
  },
  {
    "nome": "foote m",
    "codigo": "F689"
  },
  {
    "nome": "fop",
    "codigo": "F691"
  },
  {
    "nome": "for",
    "codigo": "F692"
  },
  {
    "nome": "forbes h",
    "codigo": "F693"
  },
  {
    "nome": "forbes m",
    "codigo": "F694"
  },
  {
    "nome": "forbes s",
    "codigo": "F695"
  },
  {
    "nome": "forbi",
    "codigo": "F696"
  },
  {
    "nome": "forc",
    "codigo": "F697"
  },
  {
    "nome": "forch",
    "codigo": "F698"
  },
  {
    "nome": "ford",
    "codigo": "F699"
  },
  {
    "nome": "ford m",
    "codigo": "F711"
  },
  {
    "nome": "fordh",
    "codigo": "F712"
  },
  {
    "nome": "fordy",
    "codigo": "F713"
  },
  {
    "nome": "fore",
    "codigo": "F714"
  },
  {
    "nome": "forem",
    "codigo": "F715"
  },
  {
    "nome": "fores",
    "codigo": "F716"
  },
  {
    "nome": "forester",
    "codigo": "F717"
  },
  {
    "nome": "foresti",
    "codigo": "F718"
  },
  {
    "nome": "forf",
    "codigo": "F719"
  },
  {
    "nome": "forg",
    "codigo": "F721"
  },
  {
    "nome": "forl",
    "codigo": "F722"
  },
  {
    "nome": "form",
    "codigo": "F723"
  },
  {
    "nome": "forman",
    "codigo": "F724"
  },
  {
    "nome": "forme",
    "codigo": "F725"
  },
  {
    "nome": "formo",
    "codigo": "F726"
  },
  {
    "nome": "forn",
    "codigo": "F727"
  },
  {
    "nome": "forr",
    "codigo": "F728"
  },
  {
    "nome": "forrest m",
    "codigo": "F729"
  },
  {
    "nome": "forrester",
    "codigo": "F731"
  },
  {
    "nome": "fors",
    "codigo": "F732"
  },
  {
    "nome": "forst",
    "codigo": "F733"
  },
  {
    "nome": "forster m",
    "codigo": "F734"
  },
  {
    "nome": "forsy",
    "codigo": "F735"
  },
  {
    "nome": "fort",
    "codigo": "F736"
  },
  {
    "nome": "forte",
    "codigo": "F737"
  },
  {
    "nome": "fortes",
    "codigo": "F738"
  },
  {
    "nome": "forth",
    "codigo": "F739"
  },
  {
    "nome": "forti",
    "codigo": "F741"
  },
  {
    "nome": "fortin",
    "codigo": "F742"
  },
  {
    "nome": "fortis",
    "codigo": "F743"
  },
  {
    "nome": "forto",
    "codigo": "F744"
  },
  {
    "nome": "fortu",
    "codigo": "F745"
  },
  {
    "nome": "fos",
    "codigo": "F746"
  },
  {
    "nome": "fosc",
    "codigo": "F747"
  },
  {
    "nome": "fosd",
    "codigo": "F748"
  },
  {
    "nome": "fosg",
    "codigo": "F749"
  },
  {
    "nome": "foss",
    "codigo": "F751"
  },
  {
    "nome": "fosse",
    "codigo": "F752"
  },
  {
    "nome": "fost",
    "codigo": "F753"
  },
  {
    "nome": "foster",
    "codigo": "F754"
  },
  {
    "nome": "foster h",
    "codigo": "F755"
  },
  {
    "nome": "foster m",
    "codigo": "F756"
  },
  {
    "nome": "foster s",
    "codigo": "F757"
  },
  {
    "nome": "foster w",
    "codigo": "F758"
  },
  {
    "nome": "fot",
    "codigo": "F759"
  },
  {
    "nome": "fother",
    "codigo": "F761"
  },
  {
    "nome": "fou",
    "codigo": "F762"
  },
  {
    "nome": "fouch",
    "codigo": "F763"
  },
  {
    "nome": "foud",
    "codigo": "F764"
  },
  {
    "nome": "foug",
    "codigo": "F765"
  },
  {
    "nome": "foui",
    "codigo": "F766"
  },
  {
    "nome": "foul",
    "codigo": "F767"
  },
  {
    "nome": "foulo",
    "codigo": "F768"
  },
  {
    "nome": "foulq",
    "codigo": "F769"
  },
  {
    "nome": "foun",
    "codigo": "F771"
  },
  {
    "nome": "fouq",
    "codigo": "F772"
  },
  {
    "nome": "four",
    "codigo": "F773"
  },
  {
    "nome": "fourcr",
    "codigo": "F774"
  },
  {
    "nome": "fouri",
    "codigo": "F775"
  },
  {
    "nome": "fourm",
    "codigo": "F776"
  },
  {
    "nome": "fourn",
    "codigo": "F777"
  },
  {
    "nome": "fourni",
    "codigo": "F778"
  },
  {
    "nome": "fourniv",
    "codigo": "F779"
  },
  {
    "nome": "fourq",
    "codigo": "F781"
  },
  {
    "nome": "fout",
    "codigo": "F782"
  },
  {
    "nome": "fov",
    "codigo": "F783"
  },
  {
    "nome": "fow",
    "codigo": "F784"
  },
  {
    "nome": "fowl",
    "codigo": "F785"
  },
  {
    "nome": "fowler h",
    "codigo": "F786"
  },
  {
    "nome": "fowler m",
    "codigo": "F787"
  },
  {
    "nome": "fowler s",
    "codigo": "F788"
  },
  {
    "nome": "fowler w",
    "codigo": "F789"
  },
  {
    "nome": "fox",
    "codigo": "F791"
  },
  {
    "nome": "fox h",
    "codigo": "F792"
  },
  {
    "nome": "fox m",
    "codigo": "F793"
  },
  {
    "nome": "fox s",
    "codigo": "F794"
  },
  {
    "nome": "foxe",
    "codigo": "F795"
  },
  {
    "nome": "foy",
    "codigo": "F796"
  },
  {
    "nome": "fr",
    "codigo": "F797"
  },
  {
    "nome": "frach",
    "codigo": "F798"
  },
  {
    "nome": "frad",
    "codigo": "F799"
  },
  {
    "nome": "frag",
    "codigo": "F811"
  },
  {
    "nome": "frai",
    "codigo": "F812"
  },
  {
    "nome": "fram",
    "codigo": "F813"
  },
  {
    "nome": "fran",
    "codigo": "F814"
  },
  {
    "nome": "france",
    "codigo": "F815"
  },
  {
    "nome": "franch",
    "codigo": "F816"
  },
  {
    "nome": "franci",
    "codigo": "F817"
  },
  {
    "nome": "francis",
    "codigo": "F818"
  },
  {
    "nome": "francis m",
    "codigo": "F819"
  },
  {
    "nome": "franciu",
    "codigo": "F821"
  },
  {
    "nome": "franck",
    "codigo": "F822"
  },
  {
    "nome": "francke",
    "codigo": "F823"
  },
  {
    "nome": "franckl",
    "codigo": "F824"
  },
  {
    "nome": "franco",
    "codigo": "F825"
  },
  {
    "nome": "francon",
    "codigo": "F826"
  },
  {
    "nome": "frang",
    "codigo": "F827"
  },
  {
    "nome": "frank",
    "codigo": "F828"
  },
  {
    "nome": "franke",
    "codigo": "F829"
  },
  {
    "nome": "frankl",
    "codigo": "F831"
  },
  {
    "nome": "franklin h",
    "codigo": "F832"
  },
  {
    "nome": "franklin m",
    "codigo": "F833"
  },
  {
    "nome": "franklin s",
    "codigo": "F834"
  },
  {
    "nome": "franq",
    "codigo": "F835"
  },
  {
    "nome": "frant",
    "codigo": "F836"
  },
  {
    "nome": "franz",
    "codigo": "F837"
  },
  {
    "nome": "frap",
    "codigo": "F838"
  },
  {
    "nome": "frar",
    "codigo": "F839"
  },
  {
    "nome": "fras",
    "codigo": "F841"
  },
  {
    "nome": "fraser m",
    "codigo": "F842"
  },
  {
    "nome": "frass",
    "codigo": "F843"
  },
  {
    "nome": "frat",
    "codigo": "F844"
  },
  {
    "nome": "frau",
    "codigo": "F845"
  },
  {
    "nome": "frav",
    "codigo": "F846"
  },
  {
    "nome": "fray",
    "codigo": "F847"
  },
  {
    "nome": "fraz",
    "codigo": "F848"
  },
  {
    "nome": "fre",
    "codigo": "F849"
  },
  {
    "nome": "frec",
    "codigo": "F851"
  },
  {
    "nome": "fred",
    "codigo": "F852"
  },
  {
    "nome": "free",
    "codigo": "F853"
  },
  {
    "nome": "freel",
    "codigo": "F854"
  },
  {
    "nome": "freem",
    "codigo": "F855"
  },
  {
    "nome": "freer",
    "codigo": "F856"
  },
  {
    "nome": "frees",
    "codigo": "F857"
  },
  {
    "nome": "freg",
    "codigo": "F858"
  },
  {
    "nome": "frego",
    "codigo": "F859"
  },
  {
    "nome": "freh",
    "codigo": "F861"
  },
  {
    "nome": "frei",
    "codigo": "F862"
  },
  {
    "nome": "freig",
    "codigo": "F863"
  },
  {
    "nome": "freil",
    "codigo": "F864"
  },
  {
    "nome": "freim",
    "codigo": "F865"
  },
  {
    "nome": "freir",
    "codigo": "F866"
  },
  {
    "nome": "frek",
    "codigo": "F867"
  },
  {
    "nome": "frel",
    "codigo": "F868"
  },
  {
    "nome": "frem",
    "codigo": "F869"
  },
  {
    "nome": "fremi",
    "codigo": "F871"
  },
  {
    "nome": "fremo",
    "codigo": "F872"
  },
  {
    "nome": "fren",
    "codigo": "F873"
  },
  {
    "nome": "french h",
    "codigo": "F874"
  },
  {
    "nome": "french m",
    "codigo": "F875"
  },
  {
    "nome": "french s",
    "codigo": "F876"
  },
  {
    "nome": "french w",
    "codigo": "F877"
  },
  {
    "nome": "frend",
    "codigo": "F878"
  },
  {
    "nome": "freni",
    "codigo": "F879"
  },
  {
    "nome": "frer",
    "codigo": "F881"
  },
  {
    "nome": "freret",
    "codigo": "F882"
  },
  {
    "nome": "frero",
    "codigo": "F883"
  },
  {
    "nome": "fres",
    "codigo": "F884"
  },
  {
    "nome": "fresh",
    "codigo": "F885"
  },
  {
    "nome": "fresn",
    "codigo": "F886"
  },
  {
    "nome": "fress",
    "codigo": "F887"
  },
  {
    "nome": "fret",
    "codigo": "F888"
  },
  {
    "nome": "freu",
    "codigo": "F889"
  },
  {
    "nome": "frev",
    "codigo": "F891"
  },
  {
    "nome": "frew",
    "codigo": "F892"
  },
  {
    "nome": "frey",
    "codigo": "F893"
  },
  {
    "nome": "freyl",
    "codigo": "F894"
  },
  {
    "nome": "freyt",
    "codigo": "F895"
  },
  {
    "nome": "frez",
    "codigo": "F896"
  },
  {
    "nome": "fri",
    "codigo": "F897"
  },
  {
    "nome": "frid",
    "codigo": "F898"
  },
  {
    "nome": "frie",
    "codigo": "F899"
  },
  {
    "nome": "friedl",
    "codigo": "F911"
  },
  {
    "nome": "fries",
    "codigo": "F912"
  },
  {
    "nome": "fril",
    "codigo": "F913"
  },
  {
    "nome": "frin",
    "codigo": "F914"
  },
  {
    "nome": "frip",
    "codigo": "F915"
  },
  {
    "nome": "frir",
    "codigo": "F916"
  },
  {
    "nome": "fris",
    "codigo": "F917"
  },
  {
    "nome": "frisw",
    "codigo": "F918"
  },
  {
    "nome": "frit",
    "codigo": "F919"
  },
  {
    "nome": "friz",
    "codigo": "F921"
  },
  {
    "nome": "fro",
    "codigo": "F922"
  },
  {
    "nome": "frobi",
    "codigo": "F923"
  },
  {
    "nome": "froc",
    "codigo": "F924"
  },
  {
    "nome": "froe",
    "codigo": "F925"
  },
  {
    "nome": "froel",
    "codigo": "F926"
  },
  {
    "nome": "frog",
    "codigo": "F927"
  },
  {
    "nome": "froh",
    "codigo": "F928"
  },
  {
    "nome": "froi",
    "codigo": "F929"
  },
  {
    "nome": "from",
    "codigo": "F931"
  },
  {
    "nome": "fromm",
    "codigo": "F932"
  },
  {
    "nome": "fron",
    "codigo": "F933"
  },
  {
    "nome": "frons",
    "codigo": "F934"
  },
  {
    "nome": "front",
    "codigo": "F935"
  },
  {
    "nome": "fronto",
    "codigo": "F936"
  },
  {
    "nome": "fror",
    "codigo": "F937"
  },
  {
    "nome": "fros",
    "codigo": "F938"
  },
  {
    "nome": "frost",
    "codigo": "F939"
  },
  {
    "nome": "frot",
    "codigo": "F941"
  },
  {
    "nome": "frou",
    "codigo": "F942"
  },
  {
    "nome": "frow",
    "codigo": "F943"
  },
  {
    "nome": "fru",
    "codigo": "F944"
  },
  {
    "nome": "frun",
    "codigo": "F945"
  },
  {
    "nome": "fry",
    "codigo": "F946"
  },
  {
    "nome": "fry m",
    "codigo": "F947"
  },
  {
    "nome": "frye",
    "codigo": "F948"
  },
  {
    "nome": "fu",
    "codigo": "F949"
  },
  {
    "nome": "fuchs",
    "codigo": "F951"
  },
  {
    "nome": "fud",
    "codigo": "F952"
  },
  {
    "nome": "fue",
    "codigo": "F953"
  },
  {
    "nome": "fuen",
    "codigo": "F954"
  },
  {
    "nome": "fues",
    "codigo": "F955"
  },
  {
    "nome": "fuf",
    "codigo": "F956"
  },
  {
    "nome": "fug",
    "codigo": "F957"
  },
  {
    "nome": "fugg",
    "codigo": "F958"
  },
  {
    "nome": "fuh",
    "codigo": "F959"
  },
  {
    "nome": "fui",
    "codigo": "F961"
  },
  {
    "nome": "ful",
    "codigo": "F962"
  },
  {
    "nome": "fulg",
    "codigo": "F963"
  },
  {
    "nome": "fulk",
    "codigo": "F964"
  },
  {
    "nome": "full",
    "codigo": "F965"
  },
  {
    "nome": "fuller h",
    "codigo": "F966"
  },
  {
    "nome": "fuller m",
    "codigo": "F967"
  },
  {
    "nome": "fuller s",
    "codigo": "F968"
  },
  {
    "nome": "fuller w",
    "codigo": "F969"
  },
  {
    "nome": "fullert",
    "codigo": "F971"
  },
  {
    "nome": "fullo",
    "codigo": "F972"
  },
  {
    "nome": "fulm",
    "codigo": "F973"
  },
  {
    "nome": "fult",
    "codigo": "F974"
  },
  {
    "nome": "fulv",
    "codigo": "F975"
  },
  {
    "nome": "fum",
    "codigo": "F976"
  },
  {
    "nome": "fume",
    "codigo": "F977"
  },
  {
    "nome": "fumi",
    "codigo": "F978"
  },
  {
    "nome": "fun",
    "codigo": "F979"
  },
  {
    "nome": "fund",
    "codigo": "F981"
  },
  {
    "nome": "funk",
    "codigo": "F982"
  },
  {
    "nome": "funn",
    "codigo": "F943"
  },
  {
    "nome": "fur",
    "codigo": "F983"
  },
  {
    "nome": "furi",
    "codigo": "F984"
  },
  {
    "nome": "furl",
    "codigo": "F985"
  },
  {
    "nome": "furm",
    "codigo": "F986"
  },
  {
    "nome": "furn",
    "codigo": "F987"
  },
  {
    "nome": "furnes",
    "codigo": "F988"
  },
  {
    "nome": "furni",
    "codigo": "F989"
  },
  {
    "nome": "furs",
    "codigo": "F991"
  },
  {
    "nome": "furt",
    "codigo": "F992"
  },
  {
    "nome": "fus",
    "codigo": "F993"
  },
  {
    "nome": "fuss",
    "codigo": "F994"
  },
  {
    "nome": "fust",
    "codigo": "F995"
  },
  {
    "nome": "fusu",
    "codigo": "F996"
  },
  {
    "nome": "fy",
    "codigo": "F997"
  },
  {
    "nome": "fyo",
    "codigo": "F998"
  },
  {
    "nome": "fyr",
    "codigo": "F999"
  },
  {
    "nome": "g",
    "codigo": "G111"
  },
  {
    "nome": "ga",
    "codigo": "G111"
  },
  {
    "nome": "gab",
    "codigo": "G112"
  },
  {
    "nome": "gabi",
    "codigo": "G113"
  },
  {
    "nome": "gabio",
    "codigo": "G114"
  },
  {
    "nome": "gabl",
    "codigo": "G115"
  },
  {
    "nome": "gabo",
    "codigo": "G116"
  },
  {
    "nome": "gabr",
    "codigo": "G117"
  },
  {
    "nome": "gabriel",
    "codigo": "G118"
  },
  {
    "nome": "gabro",
    "codigo": "G119"
  },
  {
    "nome": "gac",
    "codigo": "G121"
  },
  {
    "nome": "gaco",
    "codigo": "G122"
  },
  {
    "nome": "mans",
    "codigo": "M286"
  },
  {
    "nome": "mansf",
    "codigo": "M287"
  },
  {
    "nome": "mansi",
    "codigo": "M288"
  },
  {
    "nome": "manso",
    "codigo": "M289"
  },
  {
    "nome": "mant",
    "codigo": "M291"
  },
  {
    "nome": "mantel",
    "codigo": "M292"
  },
  {
    "nome": "manto",
    "codigo": "M293"
  },
  {
    "nome": "manu",
    "codigo": "M294"
  },
  {
    "nome": "manv",
    "codigo": "M295"
  },
  {
    "nome": "manz",
    "codigo": "M296"
  },
  {
    "nome": "map",
    "codigo": "M297"
  },
  {
    "nome": "mar",
    "codigo": "M298"
  },
  {
    "nome": "marai",
    "codigo": "M299"
  },
  {
    "nome": "maran",
    "codigo": "M311"
  },
  {
    "nome": "marb",
    "codigo": "M312"
  },
  {
    "nome": "marc",
    "codigo": "M313"
  },
  {
    "nome": "marcel",
    "codigo": "M314"
  },
  {
    "nome": "march",
    "codigo": "M315"
  },
  {
    "nome": "marche",
    "codigo": "M316"
  },
  {
    "nome": "marchet",
    "codigo": "M317"
  },
  {
    "nome": "marchm",
    "codigo": "M318"
  },
  {
    "nome": "marci",
    "codigo": "M319"
  },
  {
    "nome": "marco",
    "codigo": "M321"
  },
  {
    "nome": "marcu",
    "codigo": "M322"
  },
  {
    "nome": "mare",
    "codigo": "M323"
  },
  {
    "nome": "maren",
    "codigo": "M324"
  },
  {
    "nome": "mares",
    "codigo": "M325"
  },
  {
    "nome": "maret",
    "codigo": "M326"
  },
  {
    "nome": "marg",
    "codigo": "M327"
  },
  {
    "nome": "marge",
    "codigo": "M328"
  },
  {
    "nome": "margo",
    "codigo": "M329"
  },
  {
    "nome": "margu",
    "codigo": "M331"
  },
  {
    "nome": "mari",
    "codigo": "M332"
  },
  {
    "nome": "marian",
    "codigo": "M333"
  },
  {
    "nome": "marie",
    "codigo": "M334"
  },
  {
    "nome": "marig",
    "codigo": "M335"
  },
  {
    "nome": "maril",
    "codigo": "M336"
  },
  {
    "nome": "marin",
    "codigo": "M337"
  },
  {
    "nome": "marine",
    "codigo": "M338"
  },
  {
    "nome": "marini",
    "codigo": "M339"
  },
  {
    "nome": "mario",
    "codigo": "M341"
  },
  {
    "nome": "mariot",
    "codigo": "M342"
  },
  {
    "nome": "mariu",
    "codigo": "M343"
  },
  {
    "nome": "marj",
    "codigo": "M344"
  },
  {
    "nome": "mark",
    "codigo": "M345"
  },
  {
    "nome": "markl",
    "codigo": "M346"
  },
  {
    "nome": "marl",
    "codigo": "M347"
  },
  {
    "nome": "marli",
    "codigo": "M348"
  },
  {
    "nome": "marlo",
    "codigo": "M349"
  },
  {
    "nome": "marm",
    "codigo": "M351"
  },
  {
    "nome": "marmon",
    "codigo": "M352"
  },
  {
    "nome": "marn",
    "codigo": "M353"
  },
  {
    "nome": "maro",
    "codigo": "M354"
  },
  {
    "nome": "marot",
    "codigo": "M355"
  },
  {
    "nome": "marou",
    "codigo": "M356"
  },
  {
    "nome": "marq",
    "codigo": "M357"
  },
  {
    "nome": "marr",
    "codigo": "M358"
  },
  {
    "nome": "marri",
    "codigo": "M359"
  },
  {
    "nome": "marro",
    "codigo": "M361"
  },
  {
    "nome": "marry",
    "codigo": "M362"
  },
  {
    "nome": "mars",
    "codigo": "M363"
  },
  {
    "nome": "marsd",
    "codigo": "M364"
  },
  {
    "nome": "marsh",
    "codigo": "M365"
  },
  {
    "nome": "marsh m",
    "codigo": "M366"
  },
  {
    "nome": "marshall",
    "codigo": "M367"
  },
  {
    "nome": "marshall g",
    "codigo": "M368"
  },
  {
    "nome": "marshall m",
    "codigo": "M369"
  },
  {
    "nome": "marshm",
    "codigo": "M371"
  },
  {
    "nome": "marsi",
    "codigo": "M372"
  },
  {
    "nome": "marso",
    "codigo": "M373"
  },
  {
    "nome": "marst",
    "codigo": "M374"
  },
  {
    "nome": "mart",
    "codigo": "M375"
  },
  {
    "nome": "martel",
    "codigo": "M376"
  },
  {
    "nome": "marten",
    "codigo": "M377"
  },
  {
    "nome": "marti",
    "codigo": "M378"
  },
  {
    "nome": "martin",
    "codigo": "M379"
  },
  {
    "nome": "martin g",
    "codigo": "M381"
  },
  {
    "nome": "martin m",
    "codigo": "M382"
  },
  {
    "nome": "martin s",
    "codigo": "M383"
  },
  {
    "nome": "martind",
    "codigo": "M384"
  },
  {
    "nome": "martine",
    "codigo": "M385"
  },
  {
    "nome": "martini",
    "codigo": "M386"
  },
  {
    "nome": "marto",
    "codigo": "M387"
  },
  {
    "nome": "marty",
    "codigo": "M388"
  },
  {
    "nome": "maru",
    "codigo": "M389"
  },
  {
    "nome": "marv",
    "codigo": "M391"
  },
  {
    "nome": "marx",
    "codigo": "M392"
  },
  {
    "nome": "mary",
    "codigo": "M393"
  },
  {
    "nome": "mas",
    "codigo": "M394"
  },
  {
    "nome": "masc",
    "codigo": "M395"
  },
  {
    "nome": "mase",
    "codigo": "M396"
  },
  {
    "nome": "mash",
    "codigo": "M397"
  },
  {
    "nome": "maso",
    "codigo": "M398"
  },
  {
    "nome": "mason g",
    "codigo": "M399"
  },
  {
    "nome": "mason m",
    "codigo": "M411"
  },
  {
    "nome": "mason s",
    "codigo": "M412"
  },
  {
    "nome": "masq",
    "codigo": "M413"
  },
  {
    "nome": "mass",
    "codigo": "M414"
  },
  {
    "nome": "masse",
    "codigo": "M415"
  },
  {
    "nome": "massey",
    "codigo": "M416"
  },
  {
    "nome": "massi",
    "codigo": "M417"
  },
  {
    "nome": "massing",
    "codigo": "M418"
  },
  {
    "nome": "masso",
    "codigo": "M419"
  },
  {
    "nome": "masson m",
    "codigo": "M421"
  },
  {
    "nome": "massu",
    "codigo": "M422"
  },
  {
    "nome": "mast",
    "codigo": "M423"
  },
  {
    "nome": "masu",
    "codigo": "M424"
  },
  {
    "nome": "mat",
    "codigo": "M425"
  },
  {
    "nome": "math",
    "codigo": "M426"
  },
  {
    "nome": "mather",
    "codigo": "M427"
  },
  {
    "nome": "mathew",
    "codigo": "M428"
  },
  {
    "nome": "mathews",
    "codigo": "M429"
  },
  {
    "nome": "mathi",
    "codigo": "M431"
  },
  {
    "nome": "matho",
    "codigo": "M432"
  },
  {
    "nome": "mati",
    "codigo": "M433"
  },
  {
    "nome": "mats",
    "codigo": "M434"
  },
  {
    "nome": "matt",
    "codigo": "M435"
  },
  {
    "nome": "matth",
    "codigo": "M436"
  },
  {
    "nome": "matthew",
    "codigo": "M437"
  },
  {
    "nome": "matthews",
    "codigo": "M438"
  },
  {
    "nome": "matthews c",
    "codigo": "M439"
  },
  {
    "nome": "matthews m",
    "codigo": "M441"
  },
  {
    "nome": "matthews s",
    "codigo": "M442"
  },
  {
    "nome": "matthi",
    "codigo": "M443"
  },
  {
    "nome": "matti",
    "codigo": "M444"
  },
  {
    "nome": "matu",
    "codigo": "M445"
  },
  {
    "nome": "maty",
    "codigo": "M446"
  },
  {
    "nome": "mau",
    "codigo": "M447"
  },
  {
    "nome": "mauds",
    "codigo": "M448"
  },
  {
    "nome": "maug",
    "codigo": "M449"
  },
  {
    "nome": "maun",
    "codigo": "M451"
  },
  {
    "nome": "maup",
    "codigo": "M452"
  },
  {
    "nome": "maur",
    "codigo": "M453"
  },
  {
    "nome": "mauri",
    "codigo": "M454"
  },
  {
    "nome": "maurice m",
    "codigo": "M455"
  },
  {
    "nome": "maurit",
    "codigo": "M456"
  },
  {
    "nome": "mauro",
    "codigo": "M457"
  },
  {
    "nome": "mauru",
    "codigo": "M458"
  },
  {
    "nome": "maury",
    "codigo": "M459"
  },
  {
    "nome": "mav",
    "codigo": "M461"
  },
  {
    "nome": "maw",
    "codigo": "M462"
  },
  {
    "nome": "max",
    "codigo": "M463"
  },
  {
    "nome": "maxi",
    "codigo": "M464"
  },
  {
    "nome": "maxw",
    "codigo": "M465"
  },
  {
    "nome": "may",
    "codigo": "M466"
  },
  {
    "nome": "may m",
    "codigo": "M467"
  },
  {
    "nome": "mayer",
    "codigo": "M468"
  },
  {
    "nome": "mayh",
    "codigo": "M469"
  },
  {
    "nome": "mayn",
    "codigo": "M471"
  },
  {
    "nome": "mayne",
    "codigo": "M472"
  },
  {
    "nome": "mayo",
    "codigo": "M473"
  },
  {
    "nome": "mayr",
    "codigo": "M474"
  },
  {
    "nome": "maz",
    "codigo": "M475"
  },
  {
    "nome": "maze",
    "codigo": "M476"
  },
  {
    "nome": "mazz",
    "codigo": "M477"
  },
  {
    "nome": "mazzon",
    "codigo": "M478"
  },
  {
    "nome": "me",
    "codigo": "M479"
  },
  {
    "nome": "meade",
    "codigo": "M481"
  },
  {
    "nome": "meado",
    "codigo": "M482"
  },
  {
    "nome": "mean",
    "codigo": "M483"
  },
  {
    "nome": "meas",
    "codigo": "M484"
  },
  {
    "nome": "meb",
    "codigo": "M485"
  },
  {
    "nome": "mec",
    "codigo": "M486"
  },
  {
    "nome": "meck",
    "codigo": "M487"
  },
  {
    "nome": "med",
    "codigo": "M488"
  },
  {
    "nome": "medi",
    "codigo": "M489"
  },
  {
    "nome": "medin",
    "codigo": "M491"
  },
  {
    "nome": "medo",
    "codigo": "M492"
  },
  {
    "nome": "medu",
    "codigo": "M493"
  },
  {
    "nome": "mee",
    "codigo": "M494"
  },
  {
    "nome": "meer",
    "codigo": "M495"
  },
  {
    "nome": "meg",
    "codigo": "M496"
  },
  {
    "nome": "meger",
    "codigo": "M497"
  },
  {
    "nome": "meh",
    "codigo": "M498"
  },
  {
    "nome": "mei",
    "codigo": "M499"
  },
  {
    "nome": "meier",
    "codigo": "M511"
  },
  {
    "nome": "meig",
    "codigo": "M512"
  },
  {
    "nome": "meil",
    "codigo": "M513"
  },
  {
    "nome": "mein",
    "codigo": "M514"
  },
  {
    "nome": "meis",
    "codigo": "M515"
  },
  {
    "nome": "mej",
    "codigo": "M516"
  },
  {
    "nome": "mel",
    "codigo": "M517"
  },
  {
    "nome": "melc",
    "codigo": "M518"
  },
  {
    "nome": "mele",
    "codigo": "M519"
  },
  {
    "nome": "melf",
    "codigo": "M521"
  },
  {
    "nome": "meli",
    "codigo": "M522"
  },
  {
    "nome": "melis",
    "codigo": "M523"
  },
  {
    "nome": "mell",
    "codigo": "M524"
  },
  {
    "nome": "mellen",
    "codigo": "M525"
  },
  {
    "nome": "melli",
    "codigo": "M526"
  },
  {
    "nome": "mello",
    "codigo": "M527"
  },
  {
    "nome": "melo",
    "codigo": "M528"
  },
  {
    "nome": "melu",
    "codigo": "M529"
  },
  {
    "nome": "melv",
    "codigo": "M531"
  },
  {
    "nome": "melz",
    "codigo": "M532"
  },
  {
    "nome": "mem",
    "codigo": "M533"
  },
  {
    "nome": "men",
    "codigo": "M534"
  },
  {
    "nome": "menar",
    "codigo": "M535"
  },
  {
    "nome": "menc",
    "codigo": "M536"
  },
  {
    "nome": "mend",
    "codigo": "M537"
  },
  {
    "nome": "mendes",
    "codigo": "M538"
  },
  {
    "nome": "mendo",
    "codigo": "M539"
  },
  {
    "nome": "mene",
    "codigo": "M541"
  },
  {
    "nome": "menen",
    "codigo": "M542"
  },
  {
    "nome": "menes",
    "codigo": "M543"
  },
  {
    "nome": "meng",
    "codigo": "M544"
  },
  {
    "nome": "meni",
    "codigo": "M545"
  },
  {
    "nome": "menl",
    "codigo": "M546"
  },
  {
    "nome": "menn",
    "codigo": "M547"
  },
  {
    "nome": "mens",
    "codigo": "M548"
  },
  {
    "nome": "ment",
    "codigo": "M549"
  },
  {
    "nome": "menz",
    "codigo": "M551"
  },
  {
    "nome": "mer",
    "codigo": "M552"
  },
  {
    "nome": "merc",
    "codigo": "M553"
  },
  {
    "nome": "mercer",
    "codigo": "M554"
  },
  {
    "nome": "merci",
    "codigo": "M555"
  },
  {
    "nome": "merco",
    "codigo": "M556"
  },
  {
    "nome": "mercy",
    "codigo": "M557"
  },
  {
    "nome": "mere",
    "codigo": "M558"
  },
  {
    "nome": "meredith",
    "codigo": "M559"
  },
  {
    "nome": "meri",
    "codigo": "M561"
  },
  {
    "nome": "merin",
    "codigo": "M562"
  },
  {
    "nome": "meriv",
    "codigo": "M563"
  },
  {
    "nome": "merl",
    "codigo": "M564"
  },
  {
    "nome": "merli",
    "codigo": "M565"
  },
  {
    "nome": "merm",
    "codigo": "M566"
  },
  {
    "nome": "mero",
    "codigo": "M567"
  },
  {
    "nome": "merr",
    "codigo": "M568"
  },
  {
    "nome": "merrif",
    "codigo": "M569"
  },
  {
    "nome": "merril",
    "codigo": "M571"
  },
  {
    "nome": "merrit",
    "codigo": "M572"
  },
  {
    "nome": "merry",
    "codigo": "M573"
  },
  {
    "nome": "mers",
    "codigo": "M574"
  },
  {
    "nome": "mert",
    "codigo": "M575"
  },
  {
    "nome": "haul",
    "codigo": "H372"
  },
  {
    "nome": "haun",
    "codigo": "H373"
  },
  {
    "nome": "haup",
    "codigo": "H374"
  },
  {
    "nome": "haur",
    "codigo": "H375"
  },
  {
    "nome": "haus",
    "codigo": "H376"
  },
  {
    "nome": "hauss",
    "codigo": "H377"
  },
  {
    "nome": "hausso",
    "codigo": "H378"
  },
  {
    "nome": "haut",
    "codigo": "H379"
  },
  {
    "nome": "hautem",
    "codigo": "H381"
  },
  {
    "nome": "hautp",
    "codigo": "H382"
  },
  {
    "nome": "hav",
    "codigo": "H383"
  },
  {
    "nome": "havel",
    "codigo": "H384"
  },
  {
    "nome": "haven",
    "codigo": "H385"
  },
  {
    "nome": "haven m",
    "codigo": "H386"
  },
  {
    "nome": "haver",
    "codigo": "H387"
  },
  {
    "nome": "havi",
    "codigo": "H388"
  },
  {
    "nome": "haw",
    "codigo": "H389"
  },
  {
    "nome": "hawes",
    "codigo": "H391"
  },
  {
    "nome": "hawk",
    "codigo": "H392"
  },
  {
    "nome": "hawkins",
    "codigo": "H393"
  },
  {
    "nome": "hawkins m",
    "codigo": "H394"
  },
  {
    "nome": "hawks",
    "codigo": "H395"
  },
  {
    "nome": "hawl",
    "codigo": "H396"
  },
  {
    "nome": "hawo",
    "codigo": "H397"
  },
  {
    "nome": "haws",
    "codigo": "H398"
  },
  {
    "nome": "hawt",
    "codigo": "H399"
  },
  {
    "nome": "hax",
    "codigo": "H411"
  },
  {
    "nome": "hay",
    "codigo": "H412"
  },
  {
    "nome": "hay m",
    "codigo": "H413"
  },
  {
    "nome": "hayden",
    "codigo": "H414"
  },
  {
    "nome": "hayden m",
    "codigo": "H415"
  },
  {
    "nome": "haydon",
    "codigo": "H416"
  },
  {
    "nome": "haye",
    "codigo": "H417"
  },
  {
    "nome": "hayes m",
    "codigo": "H418"
  },
  {
    "nome": "hayg",
    "codigo": "H419"
  },
  {
    "nome": "hayl",
    "codigo": "H421"
  },
  {
    "nome": "haym",
    "codigo": "H422"
  },
  {
    "nome": "hayn",
    "codigo": "H423"
  },
  {
    "nome": "haynes",
    "codigo": "H424"
  },
  {
    "nome": "hays",
    "codigo": "H425"
  },
  {
    "nome": "hayt",
    "codigo": "H426"
  },
  {
    "nome": "hayw",
    "codigo": "H427"
  },
  {
    "nome": "haz",
    "codigo": "H428"
  },
  {
    "nome": "haze",
    "codigo": "H429"
  },
  {
    "nome": "hazl",
    "codigo": "H431"
  },
  {
    "nome": "he",
    "codigo": "H432"
  },
  {
    "nome": "headl",
    "codigo": "H433"
  },
  {
    "nome": "heal",
    "codigo": "H434"
  },
  {
    "nome": "hear",
    "codigo": "H435"
  },
  {
    "nome": "hearn",
    "codigo": "H436"
  },
  {
    "nome": "heat",
    "codigo": "H437"
  },
  {
    "nome": "heath m",
    "codigo": "H438"
  },
  {
    "nome": "heathc",
    "codigo": "H439"
  },
  {
    "nome": "heathe",
    "codigo": "H441"
  },
  {
    "nome": "heato",
    "codigo": "H442"
  },
  {
    "nome": "heb",
    "codigo": "H443"
  },
  {
    "nome": "heben",
    "codigo": "H444"
  },
  {
    "nome": "heber",
    "codigo": "H445"
  },
  {
    "nome": "hebert",
    "codigo": "H446"
  },
  {
    "nome": "hec",
    "codigo": "H447"
  },
  {
    "nome": "heck",
    "codigo": "H448"
  },
  {
    "nome": "hecker",
    "codigo": "H449"
  },
  {
    "nome": "hect",
    "codigo": "H451"
  },
  {
    "nome": "hed",
    "codigo": "H452"
  },
  {
    "nome": "hedg",
    "codigo": "H453"
  },
  {
    "nome": "hedi",
    "codigo": "H454"
  },
  {
    "nome": "hedl",
    "codigo": "H455"
  },
  {
    "nome": "hedo",
    "codigo": "H456"
  },
  {
    "nome": "hedw",
    "codigo": "H457"
  },
  {
    "nome": "hee",
    "codigo": "H458"
  },
  {
    "nome": "heer",
    "codigo": "H459"
  },
  {
    "nome": "hef",
    "codigo": "H461"
  },
  {
    "nome": "heg",
    "codigo": "H462"
  },
  {
    "nome": "heges",
    "codigo": "H463"
  },
  {
    "nome": "hegh",
    "codigo": "H464"
  },
  {
    "nome": "hei",
    "codigo": "H465"
  },
  {
    "nome": "heil",
    "codigo": "H466"
  },
  {
    "nome": "heim",
    "codigo": "H467"
  },
  {
    "nome": "hein",
    "codigo": "H468"
  },
  {
    "nome": "heinr",
    "codigo": "H469"
  },
  {
    "nome": "heins",
    "codigo": "H471"
  },
  {
    "nome": "heinz",
    "codigo": "H472"
  },
  {
    "nome": "heis",
    "codigo": "H473"
  },
  {
    "nome": "hel",
    "codigo": "H474"
  },
  {
    "nome": "heli",
    "codigo": "H475"
  },
  {
    "nome": "hell",
    "codigo": "H476"
  },
  {
    "nome": "helle",
    "codigo": "H477"
  },
  {
    "nome": "helm",
    "codigo": "H478"
  },
  {
    "nome": "helmh",
    "codigo": "H479"
  },
  {
    "nome": "helmo",
    "codigo": "H481"
  },
  {
    "nome": "helo",
    "codigo": "H482"
  },
  {
    "nome": "help",
    "codigo": "H483"
  },
  {
    "nome": "helps",
    "codigo": "H484"
  },
  {
    "nome": "helv",
    "codigo": "H485"
  },
  {
    "nome": "helw",
    "codigo": "H486"
  },
  {
    "nome": "hem",
    "codigo": "H487"
  },
  {
    "nome": "heme",
    "codigo": "H488"
  },
  {
    "nome": "hemm",
    "codigo": "H489"
  },
  {
    "nome": "hemp",
    "codigo": "H491"
  },
  {
    "nome": "hems",
    "codigo": "H492"
  },
  {
    "nome": "hen",
    "codigo": "H493"
  },
  {
    "nome": "henc",
    "codigo": "H494"
  },
  {
    "nome": "hend",
    "codigo": "H495"
  },
  {
    "nome": "henderson",
    "codigo": "H496"
  },
  {
    "nome": "henderson m",
    "codigo": "H497"
  },
  {
    "nome": "hendr",
    "codigo": "H498"
  },
  {
    "nome": "henf",
    "codigo": "H499"
  },
  {
    "nome": "heng",
    "codigo": "H511"
  },
  {
    "nome": "henk",
    "codigo": "H512"
  },
  {
    "nome": "henkel",
    "codigo": "H513"
  },
  {
    "nome": "henl",
    "codigo": "H514"
  },
  {
    "nome": "henn",
    "codigo": "H515"
  },
  {
    "nome": "henni",
    "codigo": "H516"
  },
  {
    "nome": "hennin",
    "codigo": "H517"
  },
  {
    "nome": "henr",
    "codigo": "H518"
  },
  {
    "nome": "henrio",
    "codigo": "H519"
  },
  {
    "nome": "henry",
    "codigo": "H521"
  },
  {
    "nome": "henry m",
    "codigo": "H523"
  },
  {
    "nome": "henry s",
    "codigo": "H524"
  },
  {
    "nome": "henry w",
    "codigo": "H525"
  },
  {
    "nome": "henry g",
    "codigo": "H522"
  },
  {
    "nome": "hens",
    "codigo": "H526"
  },
  {
    "nome": "hent",
    "codigo": "H527"
  },
  {
    "nome": "hentz",
    "codigo": "H528"
  },
  {
    "nome": "hep",
    "codigo": "H529"
  },
  {
    "nome": "her",
    "codigo": "H531"
  },
  {
    "nome": "herar",
    "codigo": "H532"
  },
  {
    "nome": "herau",
    "codigo": "H533"
  },
  {
    "nome": "herb",
    "codigo": "H534"
  },
  {
    "nome": "herber",
    "codigo": "H535"
  },
  {
    "nome": "herbert",
    "codigo": "H536"
  },
  {
    "nome": "herbert m",
    "codigo": "H537"
  },
  {
    "nome": "herbi",
    "codigo": "H538"
  },
  {
    "nome": "herc",
    "codigo": "H539"
  },
  {
    "nome": "herd",
    "codigo": "H541"
  },
  {
    "nome": "here",
    "codigo": "H542"
  },
  {
    "nome": "hereu",
    "codigo": "H543"
  },
  {
    "nome": "herf",
    "codigo": "H544"
  },
  {
    "nome": "herg",
    "codigo": "H545"
  },
  {
    "nome": "heri",
    "codigo": "H546"
  },
  {
    "nome": "herio",
    "codigo": "H547"
  },
  {
    "nome": "heris",
    "codigo": "H548"
  },
  {
    "nome": "herl",
    "codigo": "H549"
  },
  {
    "nome": "herm",
    "codigo": "H551"
  },
  {
    "nome": "hermann",
    "codigo": "H552"
  },
  {
    "nome": "herme",
    "codigo": "H553"
  },
  {
    "nome": "hermi",
    "codigo": "H554"
  },
  {
    "nome": "hermo",
    "codigo": "H555"
  },
  {
    "nome": "hermon",
    "codigo": "H556"
  },
  {
    "nome": "hern",
    "codigo": "H557"
  },
  {
    "nome": "hernd",
    "codigo": "H558"
  },
  {
    "nome": "hero",
    "codigo": "H559"
  },
  {
    "nome": "herol",
    "codigo": "H561"
  },
  {
    "nome": "heron",
    "codigo": "H562"
  },
  {
    "nome": "herp",
    "codigo": "H563"
  },
  {
    "nome": "herr",
    "codigo": "H564"
  },
  {
    "nome": "herrer",
    "codigo": "H565"
  },
  {
    "nome": "herri",
    "codigo": "H566"
  },
  {
    "nome": "herrin",
    "codigo": "H567"
  },
  {
    "nome": "herrm",
    "codigo": "H568"
  },
  {
    "nome": "hers",
    "codigo": "H569"
  },
  {
    "nome": "hersc",
    "codigo": "H571"
  },
  {
    "nome": "herse",
    "codigo": "H572"
  },
  {
    "nome": "hert",
    "codigo": "H573"
  },
  {
    "nome": "hertf",
    "codigo": "H574"
  },
  {
    "nome": "herts",
    "codigo": "H575"
  },
  {
    "nome": "hertz",
    "codigo": "H576"
  },
  {
    "nome": "herv",
    "codigo": "H577"
  },
  {
    "nome": "hervey",
    "codigo": "H578"
  },
  {
    "nome": "hervey m",
    "codigo": "H579"
  },
  {
    "nome": "herw",
    "codigo": "H581"
  },
  {
    "nome": "herz",
    "codigo": "H582"
  },
  {
    "nome": "hes",
    "codigo": "H583"
  },
  {
    "nome": "hese",
    "codigo": "H584"
  },
  {
    "nome": "hesm",
    "codigo": "H585"
  },
  {
    "nome": "hess",
    "codigo": "H586"
  },
  {
    "nome": "hesse",
    "codigo": "H587"
  },
  {
    "nome": "hest",
    "codigo": "H588"
  },
  {
    "nome": "het",
    "codigo": "H589"
  },
  {
    "nome": "hett",
    "codigo": "H591"
  },
  {
    "nome": "heu",
    "codigo": "H592"
  },
  {
    "nome": "heum",
    "codigo": "H593"
  },
  {
    "nome": "heur",
    "codigo": "H594"
  },
  {
    "nome": "heus",
    "codigo": "H595"
  },
  {
    "nome": "hev",
    "codigo": "H596"
  },
  {
    "nome": "hew",
    "codigo": "H597"
  },
  {
    "nome": "hewe",
    "codigo": "H598"
  },
  {
    "nome": "hewi",
    "codigo": "H599"
  },
  {
    "nome": "hewit",
    "codigo": "H611"
  },
  {
    "nome": "hewl",
    "codigo": "H612"
  },
  {
    "nome": "hews",
    "codigo": "H613"
  },
  {
    "nome": "hex",
    "codigo": "H614"
  },
  {
    "nome": "hey",
    "codigo": "H615"
  },
  {
    "nome": "heyf",
    "codigo": "H616"
  },
  {
    "nome": "heyl",
    "codigo": "H617"
  },
  {
    "nome": "heym",
    "codigo": "H618"
  },
  {
    "nome": "heyn",
    "codigo": "H619"
  },
  {
    "nome": "heys",
    "codigo": "H621"
  },
  {
    "nome": "heyw",
    "codigo": "H622"
  },
  {
    "nome": "hi",
    "codigo": "H623"
  },
  {
    "nome": "hib",
    "codigo": "H624"
  },
  {
    "nome": "hibo",
    "codigo": "H625"
  },
  {
    "nome": "hic",
    "codigo": "H626"
  },
  {
    "nome": "hick",
    "codigo": "H627"
  },
  {
    "nome": "hicke",
    "codigo": "H628"
  },
  {
    "nome": "hicko",
    "codigo": "H629"
  },
  {
    "nome": "hicks",
    "codigo": "H631"
  },
  {
    "nome": "hid",
    "codigo": "H632"
  },
  {
    "nome": "hie",
    "codigo": "H633"
  },
  {
    "nome": "hig",
    "codigo": "H634"
  },
  {
    "nome": "higg",
    "codigo": "H635"
  },
  {
    "nome": "higgins",
    "codigo": "H636"
  },
  {
    "nome": "higginson",
    "codigo": "H637"
  },
  {
    "nome": "high",
    "codigo": "H638"
  },
  {
    "nome": "hij",
    "codigo": "H639"
  },
  {
    "nome": "hil",
    "codigo": "H641"
  },
  {
    "nome": "hild",
    "codigo": "H642"
  },
  {
    "nome": "hilder",
    "codigo": "H643"
  },
  {
    "nome": "hildr",
    "codigo": "H644"
  },
  {
    "nome": "hill",
    "codigo": "H645"
  },
  {
    "nome": "hill g",
    "codigo": "H646"
  },
  {
    "nome": "hill m",
    "codigo": "H647"
  },
  {
    "nome": "hill s",
    "codigo": "H648"
  },
  {
    "nome": "hilla",
    "codigo": "H649"
  },
  {
    "nome": "hille",
    "codigo": "H651"
  },
  {
    "nome": "hiller",
    "codigo": "H652"
  },
  {
    "nome": "hillh",
    "codigo": "H653"
  },
  {
    "nome": "hilli",
    "codigo": "H654"
  },
  {
    "nome": "hills",
    "codigo": "H655"
  },
  {
    "nome": "hilt",
    "codigo": "H656"
  },
  {
    "nome": "him",
    "codigo": "H657"
  },
  {
    "nome": "himi",
    "codigo": "H658"
  },
  {
    "nome": "hin",
    "codigo": "H659"
  },
  {
    "nome": "hincks",
    "codigo": "H661"
  },
  {
    "nome": "hind",
    "codigo": "H662"
  },
  {
    "nome": "hing",
    "codigo": "H663"
  },
  {
    "nome": "hinr",
    "codigo": "H664"
  },
  {
    "nome": "hins",
    "codigo": "H665"
  },
  {
    "nome": "hint",
    "codigo": "H666"
  },
  {
    "nome": "hip",
    "codigo": "H667"
  },
  {
    "nome": "hir",
    "codigo": "H668"
  },
  {
    "nome": "hirs",
    "codigo": "H669"
  },
  {
    "nome": "hirt",
    "codigo": "H671"
  },
  {
    "nome": "hirz",
    "codigo": "H672"
  },
  {
    "nome": "his",
    "codigo": "H673"
  },
  {
    "nome": "hit",
    "codigo": "H674"
  },
  {
    "nome": "hitchi",
    "codigo": "H675"
  },
  {
    "nome": "hitt",
    "codigo": "H676"
  },
  {
    "nome": "hj",
    "codigo": "H677"
  },
  {
    "nome": "ho",
    "codigo": "H678"
  },
  {
    "nome": "hoar",
    "codigo": "H679"
  },
  {
    "nome": "hob",
    "codigo": "H681"
  },
  {
    "nome": "hobb",
    "codigo": "H682"
  },
  {
    "nome": "hobh",
    "codigo": "H683"
  },
  {
    "nome": "hobs",
    "codigo": "H684"
  },
  {
    "nome": "hoc",
    "codigo": "H685"
  },
  {
    "nome": "hocq",
    "codigo": "H686"
  },
  {
    "nome": "hod",
    "codigo": "H687"
  },
  {
    "nome": "hodg",
    "codigo": "H688"
  },
  {
    "nome": "hodges m",
    "codigo": "H689"
  },
  {
    "nome": "hodgs",
    "codigo": "H691"
  },
  {
    "nome": "hods",
    "codigo": "H692"
  },
  {
    "nome": "hoe",
    "codigo": "H693"
  },
  {
    "nome": "hoel",
    "codigo": "H694"
  },
  {
    "nome": "hoes",
    "codigo": "H695"
  },
  {
    "nome": "hoey",
    "codigo": "H696"
  },
  {
    "nome": "hof",
    "codigo": "H697"
  },
  {
    "nome": "hoff",
    "codigo": "H698"
  },
  {
    "nome": "hoffm",
    "codigo": "H699"
  },
  {
    "nome": "hoffman m",
    "codigo": "H711"
  },
  {
    "nome": "hofl",
    "codigo": "H712"
  },
  {
    "nome": "hofm",
    "codigo": "H713"
  },
  {
    "nome": "hog",
    "codigo": "H714"
  },
  {
    "nome": "hogar",
    "codigo": "H715"
  },
  {
    "nome": "hogg",
    "codigo": "H716"
  },
  {
    "nome": "hoh",
    "codigo": "H717"
  },
  {
    "nome": "hohenl",
    "codigo": "H718"
  },
  {
    "nome": "hohenz",
    "codigo": "H719"
  },
  {
    "nome": "hok",
    "codigo": "H721"
  },
  {
    "nome": "hol",
    "codigo": "H722"
  },
  {
    "nome": "holb",
    "codigo": "H723"
  },
  {
    "nome": "holbr",
    "codigo": "H724"
  },
  {
    "nome": "holc",
    "codigo": "H725"
  },
  {
    "nome": "hold",
    "codigo": "H726"
  },
  {
    "nome": "holder",
    "codigo": "H727"
  },
  {
    "nome": "holds",
    "codigo": "H728"
  },
  {
    "nome": "hole",
    "codigo": "H729"
  },
  {
    "nome": "holg",
    "codigo": "H731"
  },
  {
    "nome": "holi",
    "codigo": "H732"
  },
  {
    "nome": "holl",
    "codigo": "H733"
  },
  {
    "nome": "holland",
    "codigo": "H734"
  },
  {
    "nome": "holland g",
    "codigo": "H735"
  },
  {
    "nome": "holland m",
    "codigo": "H736"
  },
  {
    "nome": "holland s",
    "codigo": "H737"
  },
  {
    "nome": "holley",
    "codigo": "H738"
  },
  {
    "nome": "holli",
    "codigo": "H739"
  },
  {
    "nome": "hollin",
    "codigo": "H741"
  },
  {
    "nome": "hollis",
    "codigo": "H742"
  },
  {
    "nome": "hollis m",
    "codigo": "H743"
  },
  {
    "nome": "hollist",
    "codigo": "H744"
  },
  {
    "nome": "hollo",
    "codigo": "H745"
  },
  {
    "nome": "holly",
    "codigo": "H746"
  },
  {
    "nome": "holm",
    "codigo": "H747"
  },
  {
    "nome": "holme",
    "codigo": "H748"
  },
  {
    "nome": "holmes",
    "codigo": "H749"
  },
  {
    "nome": "holmes g",
    "codigo": "H751"
  },
  {
    "nome": "holmes m",
    "codigo": "H752"
  },
  {
    "nome": "holmes s",
    "codigo": "H753"
  },
  {
    "nome": "holo",
    "codigo": "H754"
  },
  {
    "nome": "holr",
    "codigo": "H755"
  },
  {
    "nome": "hols",
    "codigo": "H756"
  },
  {
    "nome": "holste",
    "codigo": "H757"
  },
  {
    "nome": "holt",
    "codigo": "H758"
  },
  {
    "nome": "holw",
    "codigo": "H759"
  },
  {
    "nome": "holy",
    "codigo": "H761"
  },
  {
    "nome": "holz",
    "codigo": "H762"
  },
  {
    "nome": "hom",
    "codigo": "H763"
  },
  {
    "nome": "homb",
    "codigo": "H764"
  },
  {
    "nome": "home",
    "codigo": "H765"
  },
  {
    "nome": "homer",
    "codigo": "H766"
  },
  {
    "nome": "homes",
    "codigo": "H767"
  },
  {
    "nome": "homm",
    "codigo": "H768"
  },
  {
    "nome": "hon",
    "codigo": "H769"
  },
  {
    "nome": "hond",
    "codigo": "H771"
  },
  {
    "nome": "hone",
    "codigo": "H772"
  },
  {
    "nome": "honi",
    "codigo": "H773"
  },
  {
    "nome": "hono",
    "codigo": "H774"
  },
  {
    "nome": "hont",
    "codigo": "H775"
  },
  {
    "nome": "hoo",
    "codigo": "H776"
  },
  {
    "nome": "hood m",
    "codigo": "H777"
  },
  {
    "nome": "hoof",
    "codigo": "H778"
  },
  {
    "nome": "hoog",
    "codigo": "H779"
  },
  {
    "nome": "hook",
    "codigo": "H781"
  },
  {
    "nome": "hooke",
    "codigo": "H782"
  },
  {
    "nome": "hooker",
    "codigo": "H783"
  },
  {
    "nome": "hooker m",
    "codigo": "H784"
  },
  {
    "nome": "hoop",
    "codigo": "H785"
  },
  {
    "nome": "hooper g",
    "codigo": "H786"
  },
  {
    "nome": "hooper m",
    "codigo": "H787"
  },
  {
    "nome": "hooper s",
    "codigo": "H788"
  },
  {
    "nome": "hoor",
    "codigo": "H789"
  },
  {
    "nome": "hop",
    "codigo": "H791"
  },
  {
    "nome": "hopf",
    "codigo": "H792"
  },
  {
    "nome": "hopk",
    "codigo": "H793"
  },
  {
    "nome": "hopkins g",
    "codigo": "H794"
  },
  {
    "nome": "hopkins m",
    "codigo": "H795"
  },
  {
    "nome": "hopkins s",
    "codigo": "H796"
  },
  {
    "nome": "hopkinson",
    "codigo": "H797"
  },
  {
    "nome": "hopp",
    "codigo": "H798"
  },
  {
    "nome": "hopt",
    "codigo": "H799"
  },
  {
    "nome": "hor",
    "codigo": "H811"
  },
  {
    "nome": "horl",
    "codigo": "H812"
  },
  {
    "nome": "horn",
    "codigo": "H813"
  },
  {
    "nome": "hornb",
    "codigo": "H814"
  },
  {
    "nome": "horne",
    "codigo": "H815"
  },
  {
    "nome": "horner",
    "codigo": "H816"
  },
  {
    "nome": "hors",
    "codigo": "H817"
  },
  {
    "nome": "horsl",
    "codigo": "H818"
  },
  {
    "nome": "horst",
    "codigo": "H819"
  },
  {
    "nome": "hort",
    "codigo": "H821"
  },
  {
    "nome": "horten",
    "codigo": "H822"
  },
  {
    "nome": "horto",
    "codigo": "H823"
  },
  {
    "nome": "horw",
    "codigo": "H824"
  },
  {
    "nome": "hos",
    "codigo": "H825"
  },
  {
    "nome": "hosk",
    "codigo": "H826"
  },
  {
    "nome": "hosm",
    "codigo": "H827"
  },
  {
    "nome": "hosp",
    "codigo": "H828"
  },
  {
    "nome": "hoss",
    "codigo": "H829"
  },
  {
    "nome": "host",
    "codigo": "H831"
  },
  {
    "nome": "hot",
    "codigo": "H832"
  },
  {
    "nome": "hotm",
    "codigo": "H833"
  },
  {
    "nome": "hott",
    "codigo": "H834"
  },
  {
    "nome": "hou",
    "codigo": "H835"
  },
  {
    "nome": "houd",
    "codigo": "H836"
  },
  {
    "nome": "houe",
    "codigo": "H837"
  },
  {
    "nome": "houg",
    "codigo": "H838"
  },
  {
    "nome": "houn",
    "codigo": "H839"
  },
  {
    "nome": "hour",
    "codigo": "H841"
  },
  {
    "nome": "hous",
    "codigo": "H842"
  },
  {
    "nome": "houst",
    "codigo": "H843"
  },
  {
    "nome": "hout",
    "codigo": "H844"
  },
  {
    "nome": "hov",
    "codigo": "H845"
  },
  {
    "nome": "hovey",
    "codigo": "H846"
  },
  {
    "nome": "how",
    "codigo": "H847"
  },
  {
    "nome": "howard",
    "codigo": "H848"
  },
  {
    "nome": "howard g",
    "codigo": "H849"
  },
  {
    "nome": "howard m",
    "codigo": "H851"
  },
  {
    "nome": "howard s",
    "codigo": "H852"
  },
  {
    "nome": "howard w",
    "codigo": "H853"
  },
  {
    "nome": "howd",
    "codigo": "H854"
  },
  {
    "nome": "howe",
    "codigo": "H855"
  },
  {
    "nome": "howe g",
    "codigo": "H856"
  },
  {
    "nome": "howe m",
    "codigo": "H857"
  },
  {
    "nome": "howe s",
    "codigo": "H858"
  },
  {
    "nome": "howel",
    "codigo": "H859"
  },
  {
    "nome": "howi",
    "codigo": "H861"
  },
  {
    "nome": "howis",
    "codigo": "H862"
  },
  {
    "nome": "howit",
    "codigo": "H863"
  },
  {
    "nome": "howl",
    "codigo": "H864"
  },
  {
    "nome": "howle",
    "codigo": "H865"
  },
  {
    "nome": "hows",
    "codigo": "H866"
  },
  {
    "nome": "hoy",
    "codigo": "H867"
  },
  {
    "nome": "hoyt",
    "codigo": "H868"
  },
  {
    "nome": "hoyt m",
    "codigo": "H869"
  },
  {
    "nome": "hox",
    "codigo": "H871"
  },
  {
    "nome": "hoz",
    "codigo": "H872"
  },
  {
    "nome": "hr",
    "codigo": "H873"
  },
  {
    "nome": "hu",
    "codigo": "H874"
  },
  {
    "nome": "hub",
    "codigo": "H875"
  },
  {
    "nome": "hubbard m",
    "codigo": "H876"
  },
  {
    "nome": "hube",
    "codigo": "H877"
  },
  {
    "nome": "hubert",
    "codigo": "H878"
  },
  {
    "nome": "hubn",
    "codigo": "H879"
  },
  {
    "nome": "hubs",
    "codigo": "H881"
  },
  {
    "nome": "huc",
    "codigo": "H882"
  },
  {
    "nome": "hud",
    "codigo": "H883"
  },
  {
    "nome": "huddl",
    "codigo": "H884"
  },
  {
    "nome": "huds",
    "codigo": "H885"
  },
  {
    "nome": "hudson m",
    "codigo": "H886"
  },
  {
    "nome": "hue",
    "codigo": "H887"
  },
  {
    "nome": "huet",
    "codigo": "H888"
  },
  {
    "nome": "huf",
    "codigo": "H889"
  },
  {
    "nome": "hug",
    "codigo": "H891"
  },
  {
    "nome": "hugh",
    "codigo": "H892"
  },
  {
    "nome": "hughes",
    "codigo": "H893"
  },
  {
    "nome": "hughes m",
    "codigo": "H894"
  },
  {
    "nome": "hugo",
    "codigo": "H895"
  },
  {
    "nome": "hugon",
    "codigo": "H896"
  },
  {
    "nome": "hugu",
    "codigo": "H897"
  },
  {
    "nome": "hugui",
    "codigo": "H898"
  },
  {
    "nome": "hui",
    "codigo": "H899"
  },
  {
    "nome": "huit",
    "codigo": "H911"
  },
  {
    "nome": "hul",
    "codigo": "H912"
  },
  {
    "nome": "hull",
    "codigo": "H913"
  },
  {
    "nome": "hulli",
    "codigo": "H914"
  },
  {
    "nome": "hulm",
    "codigo": "H915"
  },
  {
    "nome": "hulo",
    "codigo": "H916"
  },
  {
    "nome": "huls",
    "codigo": "H917"
  },
  {
    "nome": "hum",
    "codigo": "H918"
  },
  {
    "nome": "humb",
    "codigo": "H919"
  },
  {
    "nome": "hume",
    "codigo": "H921"
  },
  {
    "nome": "hume m",
    "codigo": "H922"
  },
  {
    "nome": "humf",
    "codigo": "H923"
  },
  {
    "nome": "humi",
    "codigo": "H924"
  },
  {
    "nome": "humm",
    "codigo": "H925"
  },
  {
    "nome": "hump",
    "codigo": "H926"
  },
  {
    "nome": "humphreys",
    "codigo": "H927"
  },
  {
    "nome": "humphri",
    "codigo": "H928"
  },
  {
    "nome": "humps",
    "codigo": "H929"
  },
  {
    "nome": "hun",
    "codigo": "H931"
  },
  {
    "nome": "hunc",
    "codigo": "H932"
  },
  {
    "nome": "hund",
    "codigo": "H933"
  },
  {
    "nome": "hune",
    "codigo": "H934"
  },
  {
    "nome": "hunf",
    "codigo": "H935"
  },
  {
    "nome": "hung",
    "codigo": "H936"
  },
  {
    "nome": "huni",
    "codigo": "H937"
  },
  {
    "nome": "hunn",
    "codigo": "H938"
  },
  {
    "nome": "hunt",
    "codigo": "H939"
  },
  {
    "nome": "hunt g",
    "codigo": "H941"
  },
  {
    "nome": "hunt m",
    "codigo": "H942"
  },
  {
    "nome": "hunt s",
    "codigo": "H943"
  },
  {
    "nome": "hunte",
    "codigo": "H944"
  },
  {
    "nome": "hunter",
    "codigo": "H945"
  },
  {
    "nome": "hunter m",
    "codigo": "H946"
  },
  {
    "nome": "hunter s",
    "codigo": "H947"
  },
  {
    "nome": "hunting",
    "codigo": "H948"
  },
  {
    "nome": "huntington",
    "codigo": "H949"
  },
  {
    "nome": "huntington g",
    "codigo": "H951"
  },
  {
    "nome": "huntington m",
    "codigo": "H952"
  },
  {
    "nome": "huntington s",
    "codigo": "H953"
  },
  {
    "nome": "huntl",
    "codigo": "H954"
  },
  {
    "nome": "hunto",
    "codigo": "H955"
  },
  {
    "nome": "hunts",
    "codigo": "H956"
  },
  {
    "nome": "huo",
    "codigo": "H957"
  },
  {
    "nome": "hup",
    "codigo": "H958"
  },
  {
    "nome": "hur",
    "codigo": "H959"
  },
  {
    "nome": "hurd m",
    "codigo": "H961"
  },
  {
    "nome": "hurdi",
    "codigo": "H962"
  },
  {
    "nome": "hure",
    "codigo": "H963"
  },
  {
    "nome": "huri",
    "codigo": "H964"
  },
  {
    "nome": "hurl",
    "codigo": "H965"
  },
  {
    "nome": "hurls",
    "codigo": "H966"
  },
  {
    "nome": "hurt",
    "codigo": "H967"
  },
  {
    "nome": "hus",
    "codigo": "H968"
  },
  {
    "nome": "huse",
    "codigo": "H969"
  },
  {
    "nome": "husk",
    "codigo": "H971"
  },
  {
    "nome": "huss",
    "codigo": "H972"
  },
  {
    "nome": "hut",
    "codigo": "H973"
  },
  {
    "nome": "hutchins",
    "codigo": "H974"
  },
  {
    "nome": "hutchinson",
    "codigo": "H975"
  },
  {
    "nome": "hutchinson g",
    "codigo": "H976"
  },
  {
    "nome": "hutchinson m",
    "codigo": "H977"
  },
  {
    "nome": "hutchinson s",
    "codigo": "H978"
  },
  {
    "nome": "huth",
    "codigo": "H979"
  },
  {
    "nome": "huti",
    "codigo": "H981"
  },
  {
    "nome": "hutt",
    "codigo": "H982"
  },
  {
    "nome": "hutter",
    "codigo": "H983"
  },
  {
    "nome": "hutto",
    "codigo": "H984"
  },
  {
    "nome": "hutton m",
    "codigo": "H985"
  },
  {
    "nome": "hux",
    "codigo": "H986"
  },
  {
    "nome": "huy",
    "codigo": "H987"
  },
  {
    "nome": "huys",
    "codigo": "H988"
  },
  {
    "nome": "huz",
    "codigo": "H989"
  },
  {
    "nome": "hw",
    "codigo": "H991"
  },
  {
    "nome": "hy",
    "codigo": "H992"
  },
  {
    "nome": "hyde",
    "codigo": "H993"
  },
  {
    "nome": "hyde h",
    "codigo": "H994"
  },
  {
    "nome": "hyde p",
    "codigo": "H995"
  },
  {
    "nome": "hyl",
    "codigo": "H996"
  },
  {
    "nome": "hyn",
    "codigo": "H997"
  },
  {
    "nome": "hyp",
    "codigo": "H998"
  },
  {
    "nome": "hyr",
    "codigo": "H999"
  },
  {
    "nome": "i",
    "codigo": "I11"
  },
  {
    "nome": "ia",
    "codigo": "I11"
  },
  {
    "nome": "ib",
    "codigo": "I12"
  },
  {
    "nome": "ibn",
    "codigo": "I13"
  },
  {
    "nome": "ibr",
    "codigo": "I14"
  },
  {
    "nome": "ic",
    "codigo": "I15"
  },
  {
    "nome": "ich",
    "codigo": "I16"
  },
  {
    "nome": "ick",
    "codigo": "I17"
  },
  {
    "nome": "id",
    "codigo": "I18"
  },
  {
    "nome": "ide",
    "codigo": "I19"
  },
  {
    "nome": "ido",
    "codigo": "I21"
  },
  {
    "nome": "ie",
    "codigo": "I22"
  },
  {
    "nome": "if",
    "codigo": "I23"
  },
  {
    "nome": "ig",
    "codigo": "I24"
  },
  {
    "nome": "ih",
    "codigo": "I25"
  },
  {
    "nome": "ik",
    "codigo": "I26"
  },
  {
    "nome": "il",
    "codigo": "I27"
  },
  {
    "nome": "ili",
    "codigo": "I28"
  },
  {
    "nome": "ill",
    "codigo": "I29"
  },
  {
    "nome": "im",
    "codigo": "I31"
  },
  {
    "nome": "imb",
    "codigo": "I32"
  },
  {
    "nome": "iml",
    "codigo": "I33"
  },
  {
    "nome": "imp",
    "codigo": "I34"
  },
  {
    "nome": "in",
    "codigo": "I35"
  },
  {
    "nome": "inc",
    "codigo": "I36"
  },
  {
    "nome": "inch",
    "codigo": "I37"
  },
  {
    "nome": "ind",
    "codigo": "I38"
  },
  {
    "nome": "indi",
    "codigo": "I39"
  },
  {
    "nome": "indo",
    "codigo": "I41"
  },
  {
    "nome": "indu",
    "codigo": "I42"
  },
  {
    "nome": "inf",
    "codigo": "I43"
  },
  {
    "nome": "ing",
    "codigo": "I44"
  },
  {
    "nome": "inge",
    "codigo": "I45"
  },
  {
    "nome": "ingel",
    "codigo": "I46"
  },
  {
    "nome": "inger",
    "codigo": "I47"
  },
  {
    "nome": "ingh",
    "codigo": "I48"
  },
  {
    "nome": "ingi",
    "codigo": "I49"
  },
  {
    "nome": "ingl",
    "codigo": "I51"
  },
  {
    "nome": "ingli",
    "codigo": "I52"
  },
  {
    "nome": "ingo",
    "codigo": "I53"
  },
  {
    "nome": "ingr",
    "codigo": "I54"
  },
  {
    "nome": "ingre",
    "codigo": "I55"
  },
  {
    "nome": "ini",
    "codigo": "I56"
  },
  {
    "nome": "inm",
    "codigo": "I57"
  },
  {
    "nome": "inn",
    "codigo": "I58"
  },
  {
    "nome": "ins",
    "codigo": "I59"
  },
  {
    "nome": "int",
    "codigo": "I61"
  },
  {
    "nome": "inv",
    "codigo": "I62"
  },
  {
    "nome": "inw",
    "codigo": "I63"
  },
  {
    "nome": "io",
    "codigo": "I64"
  },
  {
    "nome": "ir",
    "codigo": "I65"
  },
  {
    "nome": "iren",
    "codigo": "I66"
  },
  {
    "nome": "iret",
    "codigo": "I67"
  },
  {
    "nome": "iri",
    "codigo": "I68"
  },
  {
    "nome": "irl",
    "codigo": "I69"
  },
  {
    "nome": "iro",
    "codigo": "I71"
  },
  {
    "nome": "irv",
    "codigo": "I72"
  },
  {
    "nome": "is",
    "codigo": "I73"
  },
  {
    "nome": "isab",
    "codigo": "I74"
  },
  {
    "nome": "isam",
    "codigo": "I75"
  },
  {
    "nome": "isar",
    "codigo": "I76"
  },
  {
    "nome": "isc",
    "codigo": "I77"
  },
  {
    "nome": "ise",
    "codigo": "I78"
  },
  {
    "nome": "ish",
    "codigo": "I79"
  },
  {
    "nome": "isi",
    "codigo": "I81"
  },
  {
    "nome": "isl",
    "codigo": "I82"
  },
  {
    "nome": "ism",
    "codigo": "I83"
  },
  {
    "nome": "isn",
    "codigo": "I84"
  },
  {
    "nome": "iso",
    "codigo": "I85"
  },
  {
    "nome": "iss",
    "codigo": "I86"
  },
  {
    "nome": "ist",
    "codigo": "I87"
  },
  {
    "nome": "it",
    "codigo": "I88"
  },
  {
    "nome": "ith",
    "codigo": "I89"
  },
  {
    "nome": "itt",
    "codigo": "I91"
  },
  {
    "nome": "iu",
    "codigo": "I92"
  },
  {
    "nome": "iv",
    "codigo": "I93"
  },
  {
    "nome": "ive",
    "codigo": "I94"
  },
  {
    "nome": "ives",
    "codigo": "I95"
  },
  {
    "nome": "ivo",
    "codigo": "I96"
  },
  {
    "nome": "ix",
    "codigo": "I97"
  },
  {
    "nome": "iz",
    "codigo": "I98"
  },
  {
    "nome": "izm",
    "codigo": "I99"
  },
  {
    "nome": "j",
    "codigo": "J11"
  },
  {
    "nome": "ja",
    "codigo": "J11"
  },
  {
    "nome": "jac",
    "codigo": "J12"
  },
  {
    "nome": "jackson j",
    "codigo": "J13"
  },
  {
    "nome": "jackson s",
    "codigo": "J14"
  },
  {
    "nome": "jaco",
    "codigo": "J15"
  },
  {
    "nome": "jacobi",
    "codigo": "J16"
  },
  {
    "nome": "jacobs",
    "codigo": "J17"
  },
  {
    "nome": "jacop",
    "codigo": "J18"
  },
  {
    "nome": "jacq",
    "codigo": "J19"
  },
  {
    "nome": "jacqui",
    "codigo": "J21"
  },
  {
    "nome": "jae",
    "codigo": "J22"
  },
  {
    "nome": "jaf",
    "codigo": "J23"
  },
  {
    "nome": "jag",
    "codigo": "J24"
  },
  {
    "nome": "jah",
    "codigo": "J25"
  },
  {
    "nome": "jal",
    "codigo": "J26"
  },
  {
    "nome": "jam",
    "codigo": "J27"
  },
  {
    "nome": "james m",
    "codigo": "J28"
  },
  {
    "nome": "james s",
    "codigo": "J29"
  },
  {
    "nome": "jameso",
    "codigo": "J31"
  },
  {
    "nome": "jami",
    "codigo": "J32"
  },
  {
    "nome": "jan",
    "codigo": "J33"
  },
  {
    "nome": "jann",
    "codigo": "J34"
  },
  {
    "nome": "jans",
    "codigo": "J35"
  },
  {
    "nome": "jaq",
    "codigo": "J36"
  },
  {
    "nome": "jar",
    "codigo": "J37"
  },
  {
    "nome": "jarv",
    "codigo": "J38"
  },
  {
    "nome": "jas",
    "codigo": "J39"
  },
  {
    "nome": "jau",
    "codigo": "J41"
  },
  {
    "nome": "jay",
    "codigo": "J42"
  },
  {
    "nome": "je",
    "codigo": "J43"
  },
  {
    "nome": "jeb",
    "codigo": "J44"
  },
  {
    "nome": "jef",
    "codigo": "J45"
  },
  {
    "nome": "jeffre",
    "codigo": "J46"
  },
  {
    "nome": "jeffri",
    "codigo": "J47"
  },
  {
    "nome": "jel",
    "codigo": "J48"
  },
  {
    "nome": "jem",
    "codigo": "J49"
  },
  {
    "nome": "jen",
    "codigo": "J51"
  },
  {
    "nome": "jenk",
    "codigo": "J52"
  },
  {
    "nome": "jenks",
    "codigo": "J53"
  },
  {
    "nome": "jenn",
    "codigo": "J54"
  },
  {
    "nome": "jer",
    "codigo": "J55"
  },
  {
    "nome": "jero",
    "codigo": "J56"
  },
  {
    "nome": "jerv",
    "codigo": "J57"
  },
  {
    "nome": "jes",
    "codigo": "J58"
  },
  {
    "nome": "jew",
    "codigo": "J59"
  },
  {
    "nome": "ji",
    "codigo": "J61"
  },
  {
    "nome": "jo",
    "codigo": "J62"
  },
  {
    "nome": "joc",
    "codigo": "J63"
  },
  {
    "nome": "joe",
    "codigo": "J64"
  },
  {
    "nome": "joh",
    "codigo": "J65"
  },
  {
    "nome": "johnso",
    "codigo": "J66"
  },
  {
    "nome": "johnson g",
    "codigo": "J67"
  },
  {
    "nome": "johnson m",
    "codigo": "J68"
  },
  {
    "nome": "johnson s",
    "codigo": "J69"
  },
  {
    "nome": "johnson w",
    "codigo": "J71"
  },
  {
    "nome": "johnst",
    "codigo": "J72"
  },
  {
    "nome": "johnston m",
    "codigo": "J73"
  },
  {
    "nome": "joi",
    "codigo": "J74"
  },
  {
    "nome": "jol",
    "codigo": "J75"
  },
  {
    "nome": "jon",
    "codigo": "J76"
  },
  {
    "nome": "jones g",
    "codigo": "J77"
  },
  {
    "nome": "jones m",
    "codigo": "J78"
  },
  {
    "nome": "jones s",
    "codigo": "J79"
  },
  {
    "nome": "jons",
    "codigo": "J81"
  },
  {
    "nome": "jor",
    "codigo": "J82"
  },
  {
    "nome": "jos",
    "codigo": "J83"
  },
  {
    "nome": "joss",
    "codigo": "J84"
  },
  {
    "nome": "jot",
    "codigo": "J85"
  },
  {
    "nome": "jou",
    "codigo": "J86"
  },
  {
    "nome": "jow",
    "codigo": "J87"
  },
  {
    "nome": "joy",
    "codigo": "J88"
  },
  {
    "nome": "joyc",
    "codigo": "J89"
  },
  {
    "nome": "ju",
    "codigo": "J91"
  },
  {
    "nome": "jud",
    "codigo": "J92"
  },
  {
    "nome": "juds",
    "codigo": "J93"
  },
  {
    "nome": "jul",
    "codigo": "J94"
  },
  {
    "nome": "jun",
    "codigo": "J95"
  },
  {
    "nome": "jus",
    "codigo": "J96"
  },
  {
    "nome": "juv",
    "codigo": "J97"
  },
  {
    "nome": "jux",
    "codigo": "J98"
  },
  {
    "nome": "jy",
    "codigo": "J99"
  },
  {
    "nome": "k",
    "codigo": "K11"
  },
  {
    "nome": "ka",
    "codigo": "K11"
  },
  {
    "nome": "kah",
    "codigo": "K12"
  },
  {
    "nome": "kai",
    "codigo": "K13"
  },
  {
    "nome": "kal",
    "codigo": "K14"
  },
  {
    "nome": "kam",
    "codigo": "K15"
  },
  {
    "nome": "kan",
    "codigo": "K16"
  },
  {
    "nome": "kap",
    "codigo": "K17"
  },
  {
    "nome": "kar",
    "codigo": "K18"
  },
  {
    "nome": "kas",
    "codigo": "K19"
  },
  {
    "nome": "kau",
    "codigo": "K21"
  },
  {
    "nome": "kaw",
    "codigo": "K22"
  },
  {
    "nome": "kay",
    "codigo": "K23"
  },
  {
    "nome": "ke",
    "codigo": "K24"
  },
  {
    "nome": "keat",
    "codigo": "K25"
  },
  {
    "nome": "kee",
    "codigo": "K26"
  },
  {
    "nome": "kei",
    "codigo": "K27"
  },
  {
    "nome": "keith",
    "codigo": "K28"
  },
  {
    "nome": "kel",
    "codigo": "K29"
  },
  {
    "nome": "kem",
    "codigo": "K31"
  },
  {
    "nome": "kemp",
    "codigo": "K32"
  },
  {
    "nome": "ken",
    "codigo": "K33"
  },
  {
    "nome": "kenn",
    "codigo": "K34"
  },
  {
    "nome": "kennedy",
    "codigo": "K35"
  },
  {
    "nome": "kennedy m",
    "codigo": "K36"
  },
  {
    "nome": "kent",
    "codigo": "K37"
  },
  {
    "nome": "kep",
    "codigo": "K38"
  },
  {
    "nome": "ker",
    "codigo": "K39"
  },
  {
    "nome": "kerr",
    "codigo": "K41"
  },
  {
    "nome": "kes",
    "codigo": "K42"
  },
  {
    "nome": "ket",
    "codigo": "K43"
  },
  {
    "nome": "key",
    "codigo": "K44"
  },
  {
    "nome": "kh",
    "codigo": "K45"
  },
  {
    "nome": "ki",
    "codigo": "K46"
  },
  {
    "nome": "kie",
    "codigo": "K47"
  },
  {
    "nome": "kil",
    "codigo": "K48"
  },
  {
    "nome": "kim",
    "codigo": "K49"
  },
  {
    "nome": "kin",
    "codigo": "K51"
  },
  {
    "nome": "king",
    "codigo": "K52"
  },
  {
    "nome": "king j",
    "codigo": "K53"
  },
  {
    "nome": "king p",
    "codigo": "K54"
  },
  {
    "nome": "kings",
    "codigo": "K55"
  },
  {
    "nome": "kins",
    "codigo": "K56"
  },
  {
    "nome": "kip",
    "codigo": "K57"
  },
  {
    "nome": "kir",
    "codigo": "K58"
  },
  {
    "nome": "kirk",
    "codigo": "K59"
  },
  {
    "nome": "kirs",
    "codigo": "K61"
  },
  {
    "nome": "kit",
    "codigo": "K62"
  },
  {
    "nome": "kl",
    "codigo": "K63"
  },
  {
    "nome": "klein",
    "codigo": "K64"
  },
  {
    "nome": "kli",
    "codigo": "K65"
  },
  {
    "nome": "klo",
    "codigo": "K66"
  },
  {
    "nome": "kn",
    "codigo": "K67"
  },
  {
    "nome": "kne",
    "codigo": "K68"
  },
  {
    "nome": "kni",
    "codigo": "K69"
  },
  {
    "nome": "knight m",
    "codigo": "K71"
  },
  {
    "nome": "kno",
    "codigo": "K72"
  },
  {
    "nome": "know",
    "codigo": "K73"
  },
  {
    "nome": "knox",
    "codigo": "K74"
  },
  {
    "nome": "ko",
    "codigo": "K75"
  },
  {
    "nome": "koc",
    "codigo": "K76"
  },
  {
    "nome": "koe",
    "codigo": "K77"
  },
  {
    "nome": "koen",
    "codigo": "K78"
  },
  {
    "nome": "koh",
    "codigo": "K79"
  },
  {
    "nome": "kol",
    "codigo": "K81"
  },
  {
    "nome": "kon",
    "codigo": "K82"
  },
  {
    "nome": "kop",
    "codigo": "K83"
  },
  {
    "nome": "kor",
    "codigo": "K84"
  },
  {
    "nome": "kort",
    "codigo": "K85"
  },
  {
    "nome": "kos",
    "codigo": "K86"
  },
  {
    "nome": "kot",
    "codigo": "K87"
  },
  {
    "nome": "kou",
    "codigo": "K88"
  },
  {
    "nome": "kr",
    "codigo": "K89"
  },
  {
    "nome": "krau",
    "codigo": "K91"
  },
  {
    "nome": "kre",
    "codigo": "K92"
  },
  {
    "nome": "kro",
    "codigo": "K93"
  },
  {
    "nome": "kru",
    "codigo": "K94"
  },
  {
    "nome": "ku",
    "codigo": "K95"
  },
  {
    "nome": "kuh",
    "codigo": "K96"
  },
  {
    "nome": "kus",
    "codigo": "K97"
  },
  {
    "nome": "kw",
    "codigo": "K98"
  },
  {
    "nome": "ky",
    "codigo": "K99"
  },
  {
    "nome": "l",
    "codigo": "L111"
  },
  {
    "nome": "la",
    "codigo": "L111"
  },
  {
    "nome": "lab",
    "codigo": "L112"
  },
  {
    "nome": "labar",
    "codigo": "L113"
  },
  {
    "nome": "labat",
    "codigo": "L114"
  },
  {
    "nome": "labbe",
    "codigo": "L115"
  },
  {
    "nome": "labe",
    "codigo": "L116"
  },
  {
    "nome": "labeo",
    "codigo": "L117"
  },
  {
    "nome": "labi",
    "codigo": "L118"
  },
  {
    "nome": "labil",
    "codigo": "L119"
  },
  {
    "nome": "labl",
    "codigo": "L121"
  },
  {
    "nome": "labo",
    "codigo": "L122"
  },
  {
    "nome": "labor",
    "codigo": "L123"
  },
  {
    "nome": "labou",
    "codigo": "L124"
  },
  {
    "nome": "labour",
    "codigo": "L125"
  },
  {
    "nome": "labr",
    "codigo": "L126"
  },
  {
    "nome": "labru",
    "codigo": "L127"
  },
  {
    "nome": "lac",
    "codigo": "L128"
  },
  {
    "nome": "lacam",
    "codigo": "L129"
  },
  {
    "nome": "lace",
    "codigo": "L131"
  },
  {
    "nome": "lach",
    "codigo": "L132"
  },
  {
    "nome": "lachap",
    "codigo": "L133"
  },
  {
    "nome": "lachas",
    "codigo": "L134"
  },
  {
    "nome": "lachat",
    "codigo": "L135"
  },
  {
    "nome": "lachau",
    "codigo": "L136"
  },
  {
    "nome": "lache",
    "codigo": "L137"
  },
  {
    "nome": "lachm",
    "codigo": "L138"
  },
  {
    "nome": "laci",
    "codigo": "L139"
  },
  {
    "nome": "lack",
    "codigo": "L141"
  },
  {
    "nome": "laco",
    "codigo": "L142"
  },
  {
    "nome": "lacor",
    "codigo": "L143"
  },
  {
    "nome": "lacos",
    "codigo": "L144"
  },
  {
    "nome": "lacou",
    "codigo": "L145"
  },
  {
    "nome": "lacr",
    "codigo": "L146"
  },
  {
    "nome": "lacro",
    "codigo": "L147"
  },
  {
    "nome": "lacros",
    "codigo": "L148"
  },
  {
    "nome": "lacru",
    "codigo": "L149"
  },
  {
    "nome": "lact",
    "codigo": "L151"
  },
  {
    "nome": "lacy",
    "codigo": "L152"
  },
  {
    "nome": "lad",
    "codigo": "L153"
  },
  {
    "nome": "ladd",
    "codigo": "L154"
  },
  {
    "nome": "ladi",
    "codigo": "L155"
  },
  {
    "nome": "lado",
    "codigo": "L156"
  },
  {
    "nome": "ladr",
    "codigo": "L157"
  },
  {
    "nome": "lae",
    "codigo": "L158"
  },
  {
    "nome": "laf",
    "codigo": "L159"
  },
  {
    "nome": "lafay",
    "codigo": "L161"
  },
  {
    "nome": "lafe",
    "codigo": "L162"
  },
  {
    "nome": "laff",
    "codigo": "L163"
  },
  {
    "nome": "lafl",
    "codigo": "L164"
  },
  {
    "nome": "lafo",
    "codigo": "L165"
  },
  {
    "nome": "lafont",
    "codigo": "L166"
  },
  {
    "nome": "lafor",
    "codigo": "L167"
  },
  {
    "nome": "lafos",
    "codigo": "L168"
  },
  {
    "nome": "lafr",
    "codigo": "L169"
  },
  {
    "nome": "lafu",
    "codigo": "L171"
  },
  {
    "nome": "lag",
    "codigo": "L172"
  },
  {
    "nome": "lagar",
    "codigo": "L173"
  },
  {
    "nome": "lage",
    "codigo": "L174"
  },
  {
    "nome": "lagi",
    "codigo": "L175"
  },
  {
    "nome": "lagn",
    "codigo": "L176"
  },
  {
    "nome": "lago",
    "codigo": "L177"
  },
  {
    "nome": "lagr",
    "codigo": "L178"
  },
  {
    "nome": "lagre",
    "codigo": "L179"
  },
  {
    "nome": "lagu",
    "codigo": "L181"
  },
  {
    "nome": "lagui",
    "codigo": "L182"
  },
  {
    "nome": "lah",
    "codigo": "L183"
  },
  {
    "nome": "laho",
    "codigo": "L184"
  },
  {
    "nome": "lai",
    "codigo": "L185"
  },
  {
    "nome": "lain",
    "codigo": "L186"
  },
  {
    "nome": "laing",
    "codigo": "L187"
  },
  {
    "nome": "lair",
    "codigo": "L188"
  },
  {
    "nome": "lais",
    "codigo": "L189"
  },
  {
    "nome": "laj",
    "codigo": "L191"
  },
  {
    "nome": "lak",
    "codigo": "L192"
  },
  {
    "nome": "lal",
    "codigo": "L193"
  },
  {
    "nome": "lalann",
    "codigo": "L194"
  },
  {
    "nome": "lali",
    "codigo": "L195"
  },
  {
    "nome": "lall",
    "codigo": "L196"
  },
  {
    "nome": "lalle",
    "codigo": "L197"
  },
  {
    "nome": "lalli",
    "codigo": "L198"
  },
  {
    "nome": "lallo",
    "codigo": "L199"
  },
  {
    "nome": "lally",
    "codigo": "L211"
  },
  {
    "nome": "lalo",
    "codigo": "L212"
  },
  {
    "nome": "lam",
    "codigo": "L213"
  },
  {
    "nome": "laman",
    "codigo": "L214"
  },
  {
    "nome": "lamar",
    "codigo": "L215"
  },
  {
    "nome": "lamarm",
    "codigo": "L216"
  },
  {
    "nome": "lamart",
    "codigo": "L217"
  },
  {
    "nome": "lamb",
    "codigo": "L218"
  },
  {
    "nome": "lamba",
    "codigo": "L219"
  },
  {
    "nome": "lambe",
    "codigo": "L221"
  },
  {
    "nome": "lambert",
    "codigo": "L222"
  },
  {
    "nome": "lamberti",
    "codigo": "L223"
  },
  {
    "nome": "lambi",
    "codigo": "L224"
  },
  {
    "nome": "lambo",
    "codigo": "L225"
  },
  {
    "nome": "lambr",
    "codigo": "L226"
  },
  {
    "nome": "lambt",
    "codigo": "L227"
  },
  {
    "nome": "lame",
    "codigo": "L228"
  },
  {
    "nome": "lamet",
    "codigo": "L229"
  },
  {
    "nome": "lami",
    "codigo": "L231"
  },
  {
    "nome": "lamir",
    "codigo": "L232"
  },
  {
    "nome": "lamo",
    "codigo": "L233"
  },
  {
    "nome": "lamon",
    "codigo": "L234"
  },
  {
    "nome": "lamot",
    "codigo": "L235"
  },
  {
    "nome": "lamou",
    "codigo": "L236"
  },
  {
    "nome": "lamp",
    "codigo": "L237"
  },
  {
    "nome": "lampi",
    "codigo": "L238"
  },
  {
    "nome": "lampr",
    "codigo": "L239"
  },
  {
    "nome": "lams",
    "codigo": "L241"
  },
  {
    "nome": "lamy",
    "codigo": "L242"
  },
  {
    "nome": "lan",
    "codigo": "L243"
  },
  {
    "nome": "lanc",
    "codigo": "L244"
  },
  {
    "nome": "lancaster m",
    "codigo": "L245"
  },
  {
    "nome": "lance",
    "codigo": "L246"
  },
  {
    "nome": "lancel",
    "codigo": "L247"
  },
  {
    "nome": "lancey",
    "codigo": "L248"
  },
  {
    "nome": "lanci",
    "codigo": "L249"
  },
  {
    "nome": "lanco",
    "codigo": "L251"
  },
  {
    "nome": "lancr",
    "codigo": "L252"
  },
  {
    "nome": "land",
    "codigo": "L253"
  },
  {
    "nome": "lande",
    "codigo": "L254"
  },
  {
    "nome": "lander",
    "codigo": "L255"
  },
  {
    "nome": "landes",
    "codigo": "L256"
  },
  {
    "nome": "landi",
    "codigo": "L257"
  },
  {
    "nome": "lando",
    "codigo": "L258"
  },
  {
    "nome": "landon",
    "codigo": "L259"
  },
  {
    "nome": "landor",
    "codigo": "L261"
  },
  {
    "nome": "landr",
    "codigo": "L262"
  },
  {
    "nome": "lands",
    "codigo": "L263"
  },
  {
    "nome": "landu",
    "codigo": "L264"
  },
  {
    "nome": "lane",
    "codigo": "L265"
  },
  {
    "nome": "lane m",
    "codigo": "L266"
  },
  {
    "nome": "laneh",
    "codigo": "L267"
  },
  {
    "nome": "lanf",
    "codigo": "L268"
  },
  {
    "nome": "lang",
    "codigo": "L269"
  },
  {
    "nome": "lang m",
    "codigo": "L271"
  },
  {
    "nome": "langd",
    "codigo": "L272"
  },
  {
    "nome": "langdo",
    "codigo": "L273"
  },
  {
    "nome": "lange",
    "codigo": "L274"
  },
  {
    "nome": "langen",
    "codigo": "L275"
  },
  {
    "nome": "langer",
    "codigo": "L276"
  },
  {
    "nome": "langet",
    "codigo": "L277"
  },
  {
    "nome": "langf",
    "codigo": "L278"
  },
  {
    "nome": "langh",
    "codigo": "L279"
  },
  {
    "nome": "langi",
    "codigo": "L281"
  },
  {
    "nome": "langl",
    "codigo": "L282"
  },
  {
    "nome": "langle",
    "codigo": "L283"
  },
  {
    "nome": "langlo",
    "codigo": "L284"
  },
  {
    "nome": "langr",
    "codigo": "L285"
  },
  {
    "nome": "langt",
    "codigo": "L286"
  },
  {
    "nome": "langu",
    "codigo": "L287"
  },
  {
    "nome": "lanj",
    "codigo": "L288"
  },
  {
    "nome": "lank",
    "codigo": "L289"
  },
  {
    "nome": "lanm",
    "codigo": "L291"
  },
  {
    "nome": "lann",
    "codigo": "L292"
  },
  {
    "nome": "lano",
    "codigo": "L293"
  },
  {
    "nome": "lans",
    "codigo": "L294"
  },
  {
    "nome": "lansd",
    "codigo": "L295"
  },
  {
    "nome": "lant",
    "codigo": "L296"
  },
  {
    "nome": "lanz",
    "codigo": "L297"
  },
  {
    "nome": "lao",
    "codigo": "L298"
  },
  {
    "nome": "lap",
    "codigo": "L299"
  },
  {
    "nome": "lape",
    "codigo": "L311"
  },
  {
    "nome": "laph",
    "codigo": "L312"
  },
  {
    "nome": "lapi",
    "codigo": "L313"
  },
  {
    "nome": "lapl",
    "codigo": "L314"
  },
  {
    "nome": "lapo",
    "codigo": "L315"
  },
  {
    "nome": "lapp",
    "codigo": "L316"
  },
  {
    "nome": "lapr",
    "codigo": "L317"
  },
  {
    "nome": "lar",
    "codigo": "L318"
  },
  {
    "nome": "larc",
    "codigo": "L319"
  },
  {
    "nome": "lard",
    "codigo": "L321"
  },
  {
    "nome": "larg",
    "codigo": "L322"
  },
  {
    "nome": "lari",
    "codigo": "L323"
  },
  {
    "nome": "lark",
    "codigo": "L324"
  },
  {
    "nome": "larn",
    "codigo": "L325"
  },
  {
    "nome": "laro",
    "codigo": "L326"
  },
  {
    "nome": "larochef",
    "codigo": "L327"
  },
  {
    "nome": "larochej",
    "codigo": "L328"
  },
  {
    "nome": "larom",
    "codigo": "L329"
  },
  {
    "nome": "laron",
    "codigo": "L331"
  },
  {
    "nome": "larou",
    "codigo": "L332"
  },
  {
    "nome": "larr",
    "codigo": "L333"
  },
  {
    "nome": "larri",
    "codigo": "L334"
  },
  {
    "nome": "lart",
    "codigo": "L335"
  },
  {
    "nome": "laru",
    "codigo": "L336"
  },
  {
    "nome": "las",
    "codigo": "L337"
  },
  {
    "nome": "lasal",
    "codigo": "L338"
  },
  {
    "nome": "lasan",
    "codigo": "L339"
  },
  {
    "nome": "lasc",
    "codigo": "L341"
  },
  {
    "nome": "lasco",
    "codigo": "L342"
  },
  {
    "nome": "lase",
    "codigo": "L343"
  },
  {
    "nome": "lasi",
    "codigo": "L344"
  },
  {
    "nome": "lask",
    "codigo": "L345"
  },
  {
    "nome": "lass",
    "codigo": "L346"
  },
  {
    "nome": "lasse",
    "codigo": "L347"
  },
  {
    "nome": "lassu",
    "codigo": "L348"
  },
  {
    "nome": "last",
    "codigo": "L349"
  },
  {
    "nome": "lat",
    "codigo": "L351"
  },
  {
    "nome": "lath",
    "codigo": "L352"
  },
  {
    "nome": "lathr",
    "codigo": "L353"
  },
  {
    "nome": "lathrop g",
    "codigo": "L354"
  },
  {
    "nome": "lathrop m",
    "codigo": "L355"
  },
  {
    "nome": "lati",
    "codigo": "L356"
  },
  {
    "nome": "latim",
    "codigo": "L357"
  },
  {
    "nome": "lato",
    "codigo": "L358"
  },
  {
    "nome": "latour",
    "codigo": "L359"
  },
  {
    "nome": "latourr",
    "codigo": "L361"
  },
  {
    "nome": "latr",
    "codigo": "L362"
  },
  {
    "nome": "latri",
    "codigo": "L363"
  },
  {
    "nome": "latro",
    "codigo": "L364"
  },
  {
    "nome": "latu",
    "codigo": "L365"
  },
  {
    "nome": "lau",
    "codigo": "L366"
  },
  {
    "nome": "laud",
    "codigo": "L367"
  },
  {
    "nome": "laude",
    "codigo": "L368"
  },
  {
    "nome": "lauderd",
    "codigo": "L369"
  },
  {
    "nome": "laudi",
    "codigo": "L371"
  },
  {
    "nome": "laudo",
    "codigo": "L372"
  },
  {
    "nome": "lauf",
    "codigo": "L373"
  },
  {
    "nome": "laug",
    "codigo": "L374"
  },
  {
    "nome": "laum",
    "codigo": "L375"
  },
  {
    "nome": "laun",
    "codigo": "L376"
  },
  {
    "nome": "laur",
    "codigo": "L377"
  },
  {
    "nome": "laure",
    "codigo": "L378"
  },
  {
    "nome": "laurenc",
    "codigo": "L379"
  },
  {
    "nome": "laurens",
    "codigo": "L381"
  },
  {
    "nome": "laurent",
    "codigo": "L382"
  },
  {
    "nome": "laurenti",
    "codigo": "L383"
  },
  {
    "nome": "lauri",
    "codigo": "L384"
  },
  {
    "nome": "laurie",
    "codigo": "L385"
  },
  {
    "nome": "lauris",
    "codigo": "L386"
  },
  {
    "nome": "lauro",
    "codigo": "L387"
  },
  {
    "nome": "laus",
    "codigo": "L388"
  },
  {
    "nome": "laut",
    "codigo": "L389"
  },
  {
    "nome": "lauv",
    "codigo": "L391"
  },
  {
    "nome": "lav",
    "codigo": "L392"
  },
  {
    "nome": "lavale",
    "codigo": "L393"
  },
  {
    "nome": "lavall",
    "codigo": "L394"
  },
  {
    "nome": "lavalli",
    "codigo": "L395"
  },
  {
    "nome": "lavar",
    "codigo": "L396"
  },
  {
    "nome": "lavat",
    "codigo": "L397"
  },
  {
    "nome": "lavau",
    "codigo": "L398"
  },
  {
    "nome": "lave",
    "codigo": "L399"
  },
  {
    "nome": "lavi",
    "codigo": "L411"
  },
  {
    "nome": "lavil",
    "codigo": "L412"
  },
  {
    "nome": "lavis",
    "codigo": "L413"
  },
  {
    "nome": "lavo",
    "codigo": "L414"
  },
  {
    "nome": "law",
    "codigo": "L415"
  },
  {
    "nome": "law m",
    "codigo": "L416"
  },
  {
    "nome": "lawe",
    "codigo": "L417"
  },
  {
    "nome": "lawl",
    "codigo": "L418"
  },
  {
    "nome": "lawrence",
    "codigo": "L419"
  },
  {
    "nome": "lawrence g",
    "codigo": "L421"
  },
  {
    "nome": "lawrence m",
    "codigo": "L422"
  },
  {
    "nome": "lawrence s",
    "codigo": "L423"
  },
  {
    "nome": "lawrence w",
    "codigo": "L424"
  },
  {
    "nome": "laws",
    "codigo": "L425"
  },
  {
    "nome": "lay",
    "codigo": "L426"
  },
  {
    "nome": "layc",
    "codigo": "L427"
  },
  {
    "nome": "layn",
    "codigo": "L428"
  },
  {
    "nome": "layt",
    "codigo": "L429"
  },
  {
    "nome": "laz",
    "codigo": "L431"
  },
  {
    "nome": "lazz",
    "codigo": "L432"
  },
  {
    "nome": "le",
    "codigo": "L433"
  },
  {
    "nome": "leac",
    "codigo": "L434"
  },
  {
    "nome": "leak",
    "codigo": "L435"
  },
  {
    "nome": "leam",
    "codigo": "L436"
  },
  {
    "nome": "lean",
    "codigo": "L437"
  },
  {
    "nome": "lear",
    "codigo": "L438"
  },
  {
    "nome": "leav",
    "codigo": "L439"
  },
  {
    "nome": "leb",
    "codigo": "L441"
  },
  {
    "nome": "lebe",
    "codigo": "L442"
  },
  {
    "nome": "leber",
    "codigo": "L443"
  },
  {
    "nome": "lebi",
    "codigo": "L444"
  },
  {
    "nome": "lebl",
    "codigo": "L445"
  },
  {
    "nome": "leblo",
    "codigo": "L446"
  },
  {
    "nome": "lebo",
    "codigo": "L447"
  },
  {
    "nome": "lebor",
    "codigo": "L448"
  },
  {
    "nome": "lebou",
    "codigo": "L449"
  },
  {
    "nome": "lebr",
    "codigo": "L451"
  },
  {
    "nome": "lebret",
    "codigo": "L452"
  },
  {
    "nome": "lebri",
    "codigo": "L453"
  },
  {
    "nome": "lebru",
    "codigo": "L454"
  },
  {
    "nome": "lec",
    "codigo": "L455"
  },
  {
    "nome": "lecar",
    "codigo": "L456"
  },
  {
    "nome": "lecc",
    "codigo": "L457"
  },
  {
    "nome": "lech",
    "codigo": "L458"
  },
  {
    "nome": "leche",
    "codigo": "L459"
  },
  {
    "nome": "leck",
    "codigo": "L461"
  },
  {
    "nome": "lecl",
    "codigo": "L462"
  },
  {
    "nome": "leclu",
    "codigo": "L463"
  },
  {
    "nome": "leco",
    "codigo": "L464"
  },
  {
    "nome": "lecom",
    "codigo": "L465"
  },
  {
    "nome": "lecon",
    "codigo": "L466"
  },
  {
    "nome": "lecoq",
    "codigo": "L467"
  },
  {
    "nome": "lecou",
    "codigo": "L468"
  },
  {
    "nome": "lecr",
    "codigo": "L469"
  },
  {
    "nome": "lect",
    "codigo": "L471"
  },
  {
    "nome": "led",
    "codigo": "L472"
  },
  {
    "nome": "lede",
    "codigo": "L473"
  },
  {
    "nome": "ledo",
    "codigo": "L474"
  },
  {
    "nome": "ledr",
    "codigo": "L475"
  },
  {
    "nome": "ledy",
    "codigo": "L476"
  },
  {
    "nome": "lee",
    "codigo": "L477"
  },
  {
    "nome": "lee g",
    "codigo": "L478"
  },
  {
    "nome": "lee m",
    "codigo": "L479"
  },
  {
    "nome": "lee s",
    "codigo": "L481"
  },
  {
    "nome": "lee w",
    "codigo": "L482"
  },
  {
    "nome": "leec",
    "codigo": "L483"
  },
  {
    "nome": "leed",
    "codigo": "L484"
  },
  {
    "nome": "leek",
    "codigo": "L485"
  },
  {
    "nome": "leen",
    "codigo": "L486"
  },
  {
    "nome": "lees",
    "codigo": "L487"
  },
  {
    "nome": "lef",
    "codigo": "L488"
  },
  {
    "nome": "lefebv",
    "codigo": "L489"
  },
  {
    "nome": "lefer",
    "codigo": "L491"
  },
  {
    "nome": "lefeu",
    "codigo": "L492"
  },
  {
    "nome": "lefev",
    "codigo": "L493"
  },
  {
    "nome": "lefo",
    "codigo": "L494"
  },
  {
    "nome": "lefr",
    "codigo": "L495"
  },
  {
    "nome": "leg",
    "codigo": "L496"
  },
  {
    "nome": "legar",
    "codigo": "L497"
  },
  {
    "nome": "legat",
    "codigo": "L498"
  },
  {
    "nome": "lege",
    "codigo": "L499"
  },
  {
    "nome": "legen",
    "codigo": "L511"
  },
  {
    "nome": "leger",
    "codigo": "L512"
  },
  {
    "nome": "legg",
    "codigo": "L513"
  },
  {
    "nome": "legi",
    "codigo": "L514"
  },
  {
    "nome": "legn",
    "codigo": "L515"
  },
  {
    "nome": "lego",
    "codigo": "L516"
  },
  {
    "nome": "legr",
    "codigo": "L517"
  },
  {
    "nome": "legras",
    "codigo": "L518"
  },
  {
    "nome": "legro",
    "codigo": "L519"
  },
  {
    "nome": "legu",
    "codigo": "L521"
  },
  {
    "nome": "leh",
    "codigo": "L522"
  },
  {
    "nome": "lehm",
    "codigo": "L523"
  },
  {
    "nome": "leho",
    "codigo": "L524"
  },
  {
    "nome": "lei",
    "codigo": "L525"
  },
  {
    "nome": "leic",
    "codigo": "L526"
  },
  {
    "nome": "leid",
    "codigo": "L527"
  },
  {
    "nome": "leig",
    "codigo": "L528"
  },
  {
    "nome": "leigh m",
    "codigo": "L529"
  },
  {
    "nome": "lein",
    "codigo": "L531"
  },
  {
    "nome": "leis",
    "codigo": "L532"
  },
  {
    "nome": "leit",
    "codigo": "L533"
  },
  {
    "nome": "lej",
    "codigo": "L534"
  },
  {
    "nome": "lejo",
    "codigo": "L535"
  },
  {
    "nome": "lek",
    "codigo": "L536"
  },
  {
    "nome": "lel",
    "codigo": "L537"
  },
  {
    "nome": "leland",
    "codigo": "L538"
  },
  {
    "nome": "lele",
    "codigo": "L539"
  },
  {
    "nome": "leli",
    "codigo": "L541"
  },
  {
    "nome": "lell",
    "codigo": "L542"
  },
  {
    "nome": "lelo",
    "codigo": "L543"
  },
  {
    "nome": "lem",
    "codigo": "L544"
  },
  {
    "nome": "lemai",
    "codigo": "L545"
  },
  {
    "nome": "lemais",
    "codigo": "L546"
  },
  {
    "nome": "lemait",
    "codigo": "L547"
  },
  {
    "nome": "lemar",
    "codigo": "L548"
  },
  {
    "nome": "lemas",
    "codigo": "L549"
  },
  {
    "nome": "leme",
    "codigo": "L551"
  },
  {
    "nome": "lemere",
    "codigo": "L552"
  },
  {
    "nome": "lemet",
    "codigo": "L553"
  },
  {
    "nome": "lemi",
    "codigo": "L554"
  },
  {
    "nome": "lemo",
    "codigo": "L555"
  },
  {
    "nome": "lemon",
    "codigo": "L556"
  },
  {
    "nome": "lemonn",
    "codigo": "L557"
  },
  {
    "nome": "lemot",
    "codigo": "L558"
  },
  {
    "nome": "lemoy",
    "codigo": "L559"
  },
  {
    "nome": "lemp",
    "codigo": "L561"
  },
  {
    "nome": "lemu",
    "codigo": "L562"
  },
  {
    "nome": "len",
    "codigo": "L563"
  },
  {
    "nome": "lend",
    "codigo": "L564"
  },
  {
    "nome": "lene",
    "codigo": "L565"
  },
  {
    "nome": "leng",
    "codigo": "L566"
  },
  {
    "nome": "lenn",
    "codigo": "L567"
  },
  {
    "nome": "lennox",
    "codigo": "L568"
  },
  {
    "nome": "leno",
    "codigo": "L569"
  },
  {
    "nome": "lenoir",
    "codigo": "L571"
  },
  {
    "nome": "lenor",
    "codigo": "L572"
  },
  {
    "nome": "lens",
    "codigo": "L573"
  },
  {
    "nome": "lent",
    "codigo": "L574"
  },
  {
    "nome": "lenz",
    "codigo": "L575"
  },
  {
    "nome": "leo",
    "codigo": "L576"
  },
  {
    "nome": "leod",
    "codigo": "L577"
  },
  {
    "nome": "leof",
    "codigo": "L578"
  },
  {
    "nome": "leon",
    "codigo": "L579"
  },
  {
    "nome": "leonard",
    "codigo": "L581"
  },
  {
    "nome": "leonc",
    "codigo": "L582"
  },
  {
    "nome": "leone",
    "codigo": "L583"
  },
  {
    "nome": "leonh",
    "codigo": "L584"
  },
  {
    "nome": "leoni",
    "codigo": "L585"
  },
  {
    "nome": "leont",
    "codigo": "L586"
  },
  {
    "nome": "leop",
    "codigo": "L587"
  },
  {
    "nome": "leot",
    "codigo": "L588"
  },
  {
    "nome": "leow",
    "codigo": "L589"
  },
  {
    "nome": "lep",
    "codigo": "L591"
  },
  {
    "nome": "lepai",
    "codigo": "L592"
  },
  {
    "nome": "lepau",
    "codigo": "L593"
  },
  {
    "nome": "lepe",
    "codigo": "L594"
  },
  {
    "nome": "lepell",
    "codigo": "L595"
  },
  {
    "nome": "lepi",
    "codigo": "L596"
  },
  {
    "nome": "lepl",
    "codigo": "L597"
  },
  {
    "nome": "lepo",
    "codigo": "L598"
  },
  {
    "nome": "lepr",
    "codigo": "L599"
  },
  {
    "nome": "leps",
    "codigo": "L611"
  },
  {
    "nome": "lepu",
    "codigo": "L612"
  },
  {
    "nome": "leq",
    "codigo": "L613"
  },
  {
    "nome": "ler",
    "codigo": "L614"
  },
  {
    "nome": "lerd",
    "codigo": "L615"
  },
  {
    "nome": "lerm",
    "codigo": "L616"
  },
  {
    "nome": "lero",
    "codigo": "L617"
  },
  {
    "nome": "leroux",
    "codigo": "L618"
  },
  {
    "nome": "leroy",
    "codigo": "L619"
  },
  {
    "nome": "leroy m",
    "codigo": "L621"
  },
  {
    "nome": "les",
    "codigo": "L622"
  },
  {
    "nome": "lesb",
    "codigo": "L623"
  },
  {
    "nome": "lesc",
    "codigo": "L624"
  },
  {
    "nome": "lesch",
    "codigo": "L625"
  },
  {
    "nome": "lesco",
    "codigo": "L626"
  },
  {
    "nome": "lescu",
    "codigo": "L627"
  },
  {
    "nome": "lesd",
    "codigo": "L628"
  },
  {
    "nome": "lesg",
    "codigo": "L629"
  },
  {
    "nome": "lesl",
    "codigo": "L631"
  },
  {
    "nome": "lesley",
    "codigo": "L632"
  },
  {
    "nome": "lesley m",
    "codigo": "L633"
  },
  {
    "nome": "leslie",
    "codigo": "L634"
  },
  {
    "nome": "leslie g",
    "codigo": "L635"
  },
  {
    "nome": "leslie m",
    "codigo": "L636"
  },
  {
    "nome": "leslie s",
    "codigo": "L637"
  },
  {
    "nome": "less",
    "codigo": "L638"
  },
  {
    "nome": "lessi",
    "codigo": "L639"
  },
  {
    "nome": "lesso",
    "codigo": "L641"
  },
  {
    "nome": "lest",
    "codigo": "L642"
  },
  {
    "nome": "lestr",
    "codigo": "L643"
  },
  {
    "nome": "lesu",
    "codigo": "L644"
  },
  {
    "nome": "let",
    "codigo": "L645"
  },
  {
    "nome": "letell",
    "codigo": "L646"
  },
  {
    "nome": "leth",
    "codigo": "L647"
  },
  {
    "nome": "leti",
    "codigo": "L648"
  },
  {
    "nome": "leto",
    "codigo": "L649"
  },
  {
    "nome": "lett",
    "codigo": "L651"
  },
  {
    "nome": "leu",
    "codigo": "L652"
  },
  {
    "nome": "leul",
    "codigo": "L653"
  },
  {
    "nome": "leus",
    "codigo": "L654"
  },
  {
    "nome": "lev",
    "codigo": "L655"
  },
  {
    "nome": "levas",
    "codigo": "L656"
  },
  {
    "nome": "leve",
    "codigo": "L657"
  },
  {
    "nome": "lever",
    "codigo": "L658"
  },
  {
    "nome": "lever m",
    "codigo": "L659"
  },
  {
    "nome": "levere",
    "codigo": "L661"
  },
  {
    "nome": "leves",
    "codigo": "L662"
  },
  {
    "nome": "levet",
    "codigo": "L663"
  },
  {
    "nome": "levi",
    "codigo": "L664"
  },
  {
    "nome": "levin",
    "codigo": "L665"
  },
  {
    "nome": "levis",
    "codigo": "L666"
  },
  {
    "nome": "levr",
    "codigo": "L667"
  },
  {
    "nome": "levy",
    "codigo": "L668"
  },
  {
    "nome": "lew",
    "codigo": "L669"
  },
  {
    "nome": "lewe",
    "codigo": "L671"
  },
  {
    "nome": "lewin",
    "codigo": "L672"
  },
  {
    "nome": "lewis",
    "codigo": "L673"
  },
  {
    "nome": "lewis g",
    "codigo": "L674"
  },
  {
    "nome": "lewis m",
    "codigo": "L675"
  },
  {
    "nome": "lewis s",
    "codigo": "L676"
  },
  {
    "nome": "lewis w",
    "codigo": "L677"
  },
  {
    "nome": "lewk",
    "codigo": "L678"
  },
  {
    "nome": "lex",
    "codigo": "L679"
  },
  {
    "nome": "ley",
    "codigo": "L681"
  },
  {
    "nome": "leybu",
    "codigo": "L682"
  },
  {
    "nome": "leyd",
    "codigo": "L683"
  },
  {
    "nome": "leyl",
    "codigo": "L684"
  },
  {
    "nome": "leys",
    "codigo": "L685"
  },
  {
    "nome": "lez",
    "codigo": "L686"
  },
  {
    "nome": "lezo",
    "codigo": "L687"
  },
  {
    "nome": "lh",
    "codigo": "L688"
  },
  {
    "nome": "lheu",
    "codigo": "L689"
  },
  {
    "nome": "lho",
    "codigo": "L691"
  },
  {
    "nome": "lhu",
    "codigo": "L692"
  },
  {
    "nome": "li",
    "codigo": "L693"
  },
  {
    "nome": "lib",
    "codigo": "L694"
  },
  {
    "nome": "liber",
    "codigo": "L695"
  },
  {
    "nome": "libo",
    "codigo": "L696"
  },
  {
    "nome": "libr",
    "codigo": "L697"
  },
  {
    "nome": "lic",
    "codigo": "L698"
  },
  {
    "nome": "licht",
    "codigo": "L699"
  },
  {
    "nome": "lici",
    "codigo": "L711"
  },
  {
    "nome": "lid",
    "codigo": "L712"
  },
  {
    "nome": "liddo",
    "codigo": "L713"
  },
  {
    "nome": "lide",
    "codigo": "L714"
  },
  {
    "nome": "lido",
    "codigo": "L715"
  },
  {
    "nome": "lie",
    "codigo": "L716"
  },
  {
    "nome": "liebn",
    "codigo": "L717"
  },
  {
    "nome": "liec",
    "codigo": "L718"
  },
  {
    "nome": "lief",
    "codigo": "L719"
  },
  {
    "nome": "lieu",
    "codigo": "L721"
  },
  {
    "nome": "liev",
    "codigo": "L722"
  },
  {
    "nome": "lig",
    "codigo": "L723"
  },
  {
    "nome": "lightf",
    "codigo": "L724"
  },
  {
    "nome": "lign",
    "codigo": "L725"
  },
  {
    "nome": "ligo",
    "codigo": "L726"
  },
  {
    "nome": "ligu",
    "codigo": "L727"
  },
  {
    "nome": "lil",
    "codigo": "L728"
  },
  {
    "nome": "lill",
    "codigo": "L729"
  },
  {
    "nome": "lily",
    "codigo": "L731"
  },
  {
    "nome": "lim",
    "codigo": "L732"
  },
  {
    "nome": "limb",
    "codigo": "L733"
  },
  {
    "nome": "limi",
    "codigo": "L734"
  },
  {
    "nome": "lin",
    "codigo": "L735"
  },
  {
    "nome": "linc",
    "codigo": "L736"
  },
  {
    "nome": "lincoln g",
    "codigo": "L737"
  },
  {
    "nome": "lincoln m",
    "codigo": "L738"
  },
  {
    "nome": "lincoln s",
    "codigo": "L739"
  },
  {
    "nome": "lincoln w",
    "codigo": "L741"
  },
  {
    "nome": "lind",
    "codigo": "L742"
  },
  {
    "nome": "linde",
    "codigo": "L743"
  },
  {
    "nome": "linden",
    "codigo": "L744"
  },
  {
    "nome": "lindes",
    "codigo": "L745"
  },
  {
    "nome": "lindl",
    "codigo": "L746"
  },
  {
    "nome": "lindn",
    "codigo": "L747"
  },
  {
    "nome": "linds",
    "codigo": "L748"
  },
  {
    "nome": "lindsay m",
    "codigo": "L749"
  },
  {
    "nome": "lindsel",
    "codigo": "L751"
  },
  {
    "nome": "lindsey",
    "codigo": "L752"
  },
  {
    "nome": "lindsey m",
    "codigo": "L753"
  },
  {
    "nome": "lindw",
    "codigo": "L754"
  },
  {
    "nome": "ling",
    "codigo": "L755"
  },
  {
    "nome": "lini",
    "codigo": "L756"
  },
  {
    "nome": "linl",
    "codigo": "L757"
  },
  {
    "nome": "linn",
    "codigo": "L758"
  },
  {
    "nome": "lins",
    "codigo": "L759"
  },
  {
    "nome": "lint",
    "codigo": "L761"
  },
  {
    "nome": "linw",
    "codigo": "L762"
  },
  {
    "nome": "lio",
    "codigo": "L763"
  },
  {
    "nome": "lip",
    "codigo": "L764"
  },
  {
    "nome": "lipp",
    "codigo": "L765"
  },
  {
    "nome": "lippm",
    "codigo": "L766"
  },
  {
    "nome": "lips",
    "codigo": "L767"
  },
  {
    "nome": "lir",
    "codigo": "L768"
  },
  {
    "nome": "lis",
    "codigo": "L769"
  },
  {
    "nome": "lisl",
    "codigo": "L771"
  },
  {
    "nome": "liss",
    "codigo": "L772"
  },
  {
    "nome": "list",
    "codigo": "L773"
  },
  {
    "nome": "lisz",
    "codigo": "L774"
  },
  {
    "nome": "lit",
    "codigo": "L775"
  },
  {
    "nome": "litch",
    "codigo": "L776"
  },
  {
    "nome": "litte",
    "codigo": "L777"
  },
  {
    "nome": "littl",
    "codigo": "L778"
  },
  {
    "nome": "littleb",
    "codigo": "L779"
  },
  {
    "nome": "littlet",
    "codigo": "L781"
  },
  {
    "nome": "littr",
    "codigo": "L782"
  },
  {
    "nome": "liu",
    "codigo": "L783"
  },
  {
    "nome": "liv",
    "codigo": "L784"
  },
  {
    "nome": "livermore m",
    "codigo": "L785"
  },
  {
    "nome": "livings",
    "codigo": "L786"
  },
  {
    "nome": "livingston m",
    "codigo": "L787"
  },
  {
    "nome": "livingstone",
    "codigo": "L788"
  },
  {
    "nome": "liz",
    "codigo": "L789"
  },
  {
    "nome": "ll",
    "codigo": "L791"
  },
  {
    "nome": "llo",
    "codigo": "L792"
  },
  {
    "nome": "lloyd",
    "codigo": "L793"
  },
  {
    "nome": "lly",
    "codigo": "L794"
  },
  {
    "nome": "lo",
    "codigo": "L795"
  },
  {
    "nome": "lob",
    "codigo": "L796"
  },
  {
    "nome": "lobe",
    "codigo": "L797"
  },
  {
    "nome": "lobk",
    "codigo": "L798"
  },
  {
    "nome": "lobo",
    "codigo": "L799"
  },
  {
    "nome": "loc",
    "codigo": "L811"
  },
  {
    "nome": "loch",
    "codigo": "L812"
  },
  {
    "nome": "lock",
    "codigo": "L813"
  },
  {
    "nome": "locke",
    "codigo": "L814"
  },
  {
    "nome": "locker",
    "codigo": "L815"
  },
  {
    "nome": "lockh",
    "codigo": "L816"
  },
  {
    "nome": "lockw",
    "codigo": "L817"
  },
  {
    "nome": "locky",
    "codigo": "L818"
  },
  {
    "nome": "loco",
    "codigo": "L819"
  },
  {
    "nome": "lod",
    "codigo": "L821"
  },
  {
    "nome": "lodg",
    "codigo": "L822"
  },
  {
    "nome": "lodi",
    "codigo": "L823"
  },
  {
    "nome": "lodo",
    "codigo": "L824"
  },
  {
    "nome": "loe",
    "codigo": "L825"
  },
  {
    "nome": "loes",
    "codigo": "L826"
  },
  {
    "nome": "loew",
    "codigo": "L827"
  },
  {
    "nome": "lof",
    "codigo": "L828"
  },
  {
    "nome": "loft",
    "codigo": "L829"
  },
  {
    "nome": "log",
    "codigo": "L831"
  },
  {
    "nome": "loge",
    "codigo": "L832"
  },
  {
    "nome": "loh",
    "codigo": "L833"
  },
  {
    "nome": "loi",
    "codigo": "L834"
  },
  {
    "nome": "loisel",
    "codigo": "L835"
  },
  {
    "nome": "lok",
    "codigo": "L836"
  },
  {
    "nome": "lol",
    "codigo": "L837"
  },
  {
    "nome": "lolm",
    "codigo": "L838"
  },
  {
    "nome": "lom",
    "codigo": "L839"
  },
  {
    "nome": "lombard",
    "codigo": "L841"
  },
  {
    "nome": "lombardi",
    "codigo": "L842"
  },
  {
    "nome": "lombe",
    "codigo": "L843"
  },
  {
    "nome": "lombr",
    "codigo": "L844"
  },
  {
    "nome": "lome",
    "codigo": "L845"
  },
  {
    "nome": "lomo",
    "codigo": "L846"
  },
  {
    "nome": "lon",
    "codigo": "L847"
  },
  {
    "nome": "long",
    "codigo": "L848"
  },
  {
    "nome": "long m",
    "codigo": "L849"
  },
  {
    "nome": "longc",
    "codigo": "L851"
  },
  {
    "nome": "longe",
    "codigo": "L852"
  },
  {
    "nome": "longf",
    "codigo": "L853"
  },
  {
    "nome": "longh",
    "codigo": "L854"
  },
  {
    "nome": "longi",
    "codigo": "L855"
  },
  {
    "nome": "longl",
    "codigo": "L856"
  },
  {
    "nome": "longs",
    "codigo": "L857"
  },
  {
    "nome": "longu",
    "codigo": "L858"
  },
  {
    "nome": "longus",
    "codigo": "L859"
  },
  {
    "nome": "loni",
    "codigo": "L861"
  },
  {
    "nome": "lons",
    "codigo": "L862"
  },
  {
    "nome": "loo",
    "codigo": "L863"
  },
  {
    "nome": "lop",
    "codigo": "L864"
  },
  {
    "nome": "lor",
    "codigo": "L865"
  },
  {
    "nome": "lord",
    "codigo": "L866"
  },
  {
    "nome": "lord m",
    "codigo": "L867"
  },
  {
    "nome": "lore",
    "codigo": "L868"
  },
  {
    "nome": "lorenz",
    "codigo": "L869"
  },
  {
    "nome": "lorg",
    "codigo": "L871"
  },
  {
    "nome": "lori",
    "codigo": "L872"
  },
  {
    "nome": "loring",
    "codigo": "L873"
  },
  {
    "nome": "loring m",
    "codigo": "L874"
  },
  {
    "nome": "lorm",
    "codigo": "L875"
  },
  {
    "nome": "lorr",
    "codigo": "L876"
  },
  {
    "nome": "lorry",
    "codigo": "L877"
  },
  {
    "nome": "lort",
    "codigo": "L878"
  },
  {
    "nome": "los",
    "codigo": "L879"
  },
  {
    "nome": "loso",
    "codigo": "L881"
  },
  {
    "nome": "lot",
    "codigo": "L882"
  },
  {
    "nome": "loti",
    "codigo": "L883"
  },
  {
    "nome": "lott",
    "codigo": "L884"
  },
  {
    "nome": "lotz",
    "codigo": "L885"
  },
  {
    "nome": "lou",
    "codigo": "L886"
  },
  {
    "nome": "loug",
    "codigo": "L887"
  },
  {
    "nome": "loui",
    "codigo": "L888"
  },
  {
    "nome": "loun",
    "codigo": "L889"
  },
  {
    "nome": "loup",
    "codigo": "L891"
  },
  {
    "nome": "lour",
    "codigo": "L892"
  },
  {
    "nome": "lout",
    "codigo": "L893"
  },
  {
    "nome": "louv",
    "codigo": "L894"
  },
  {
    "nome": "louvo",
    "codigo": "L895"
  },
  {
    "nome": "lov",
    "codigo": "L896"
  },
  {
    "nome": "love",
    "codigo": "L897"
  },
  {
    "nome": "lovel",
    "codigo": "L898"
  },
  {
    "nome": "lovell",
    "codigo": "L899"
  },
  {
    "nome": "lovell m",
    "codigo": "L911"
  },
  {
    "nome": "low",
    "codigo": "L912"
  },
  {
    "nome": "lowe",
    "codigo": "L913"
  },
  {
    "nome": "lowell",
    "codigo": "L914"
  },
  {
    "nome": "lowell g",
    "codigo": "L915"
  },
  {
    "nome": "lowell m",
    "codigo": "L916"
  },
  {
    "nome": "lowell s",
    "codigo": "L917"
  },
  {
    "nome": "lowi",
    "codigo": "L918"
  },
  {
    "nome": "lown",
    "codigo": "L919"
  },
  {
    "nome": "lowr",
    "codigo": "L921"
  },
  {
    "nome": "lowt",
    "codigo": "L922"
  },
  {
    "nome": "loy",
    "codigo": "L923"
  },
  {
    "nome": "loys",
    "codigo": "L924"
  },
  {
    "nome": "loz",
    "codigo": "L925"
  },
  {
    "nome": "lu",
    "codigo": "L926"
  },
  {
    "nome": "lubbo",
    "codigo": "L927"
  },
  {
    "nome": "lube",
    "codigo": "L928"
  },
  {
    "nome": "lubi",
    "codigo": "L929"
  },
  {
    "nome": "luc",
    "codigo": "L931"
  },
  {
    "nome": "lucan",
    "codigo": "L932"
  },
  {
    "nome": "lucas",
    "codigo": "L933"
  },
  {
    "nome": "lucc",
    "codigo": "L934"
  },
  {
    "nome": "luce",
    "codigo": "L935"
  },
  {
    "nome": "luch",
    "codigo": "L936"
  },
  {
    "nome": "luci",
    "codigo": "L937"
  },
  {
    "nome": "lucin",
    "codigo": "L938"
  },
  {
    "nome": "luciu",
    "codigo": "L939"
  },
  {
    "nome": "luck",
    "codigo": "L941"
  },
  {
    "nome": "lucr",
    "codigo": "L942"
  },
  {
    "nome": "lucy",
    "codigo": "L943"
  },
  {
    "nome": "lud",
    "codigo": "L944"
  },
  {
    "nome": "ludl",
    "codigo": "L945"
  },
  {
    "nome": "ludo",
    "codigo": "L946"
  },
  {
    "nome": "ludr",
    "codigo": "L947"
  },
  {
    "nome": "ludw",
    "codigo": "L948"
  },
  {
    "nome": "luf",
    "codigo": "L949"
  },
  {
    "nome": "lug",
    "codigo": "L951"
  },
  {
    "nome": "lui",
    "codigo": "L952"
  },
  {
    "nome": "luis",
    "codigo": "L953"
  },
  {
    "nome": "luk",
    "codigo": "L954"
  },
  {
    "nome": "lul",
    "codigo": "L955"
  },
  {
    "nome": "lully",
    "codigo": "L956"
  },
  {
    "nome": "lum",
    "codigo": "L957"
  },
  {
    "nome": "luml",
    "codigo": "L958"
  },
  {
    "nome": "lums",
    "codigo": "L959"
  },
  {
    "nome": "lun",
    "codigo": "L961"
  },
  {
    "nome": "lund",
    "codigo": "L962"
  },
  {
    "nome": "lung",
    "codigo": "L963"
  },
  {
    "nome": "lunt",
    "codigo": "L964"
  },
  {
    "nome": "lup",
    "codigo": "L965"
  },
  {
    "nome": "lupt",
    "codigo": "L966"
  },
  {
    "nome": "lur",
    "codigo": "L967"
  },
  {
    "nome": "lus",
    "codigo": "L968"
  },
  {
    "nome": "lush",
    "codigo": "L969"
  },
  {
    "nome": "lusi",
    "codigo": "L971"
  },
  {
    "nome": "luss",
    "codigo": "L972"
  },
  {
    "nome": "lut",
    "codigo": "L973"
  },
  {
    "nome": "luto",
    "codigo": "L974"
  },
  {
    "nome": "lutz",
    "codigo": "L975"
  },
  {
    "nome": "luv",
    "codigo": "L976"
  },
  {
    "nome": "lux",
    "codigo": "L977"
  },
  {
    "nome": "luy",
    "codigo": "L978"
  },
  {
    "nome": "luz",
    "codigo": "L979"
  },
  {
    "nome": "ly",
    "codigo": "L981"
  },
  {
    "nome": "lycu",
    "codigo": "L982"
  },
  {
    "nome": "lyd",
    "codigo": "L983"
  },
  {
    "nome": "lye",
    "codigo": "L984"
  },
  {
    "nome": "lyl",
    "codigo": "L985"
  },
  {
    "nome": "lym",
    "codigo": "L986"
  },
  {
    "nome": "lyn",
    "codigo": "L987"
  },
  {
    "nome": "lynd",
    "codigo": "L988"
  },
  {
    "nome": "lynn",
    "codigo": "L989"
  },
  {
    "nome": "lyo",
    "codigo": "L991"
  },
  {
    "nome": "lyr",
    "codigo": "L992"
  },
  {
    "nome": "lys",
    "codigo": "L993"
  },
  {
    "nome": "lysi",
    "codigo": "L994"
  },
  {
    "nome": "lyso",
    "codigo": "L995"
  },
  {
    "nome": "lyt",
    "codigo": "L996"
  },
  {
    "nome": "lyttl",
    "codigo": "L997"
  },
  {
    "nome": "lytto",
    "codigo": "L998"
  },
  {
    "nome": "lyv",
    "codigo": "L999"
  },
  {
    "nome": "m",
    "codigo": "M111"
  },
  {
    "nome": "ma",
    "codigo": "M111"
  },
  {
    "nome": "mab",
    "codigo": "M112"
  },
  {
    "nome": "mac",
    "codigo": "M113"
  },
  {
    "nome": "macal",
    "codigo": "M114"
  },
  {
    "nome": "macar",
    "codigo": "M115"
  },
  {
    "nome": "macart",
    "codigo": "M116"
  },
  {
    "nome": "macau",
    "codigo": "M117"
  },
  {
    "nome": "macb",
    "codigo": "M118"
  },
  {
    "nome": "macbr",
    "codigo": "M119"
  },
  {
    "nome": "macc",
    "codigo": "M121"
  },
  {
    "nome": "maccal",
    "codigo": "M122"
  },
  {
    "nome": "maccar",
    "codigo": "M123"
  },
  {
    "nome": "macch",
    "codigo": "M124"
  },
  {
    "nome": "macci",
    "codigo": "M125"
  },
  {
    "nome": "maccl",
    "codigo": "M126"
  },
  {
    "nome": "maccli",
    "codigo": "M127"
  },
  {
    "nome": "macclu",
    "codigo": "M128"
  },
  {
    "nome": "macco",
    "codigo": "M129"
  },
  {
    "nome": "maccor",
    "codigo": "M131"
  },
  {
    "nome": "maccr",
    "codigo": "M132"
  },
  {
    "nome": "maccu",
    "codigo": "M133"
  },
  {
    "nome": "macd",
    "codigo": "M134"
  },
  {
    "nome": "macdon",
    "codigo": "M135"
  },
  {
    "nome": "macdonn",
    "codigo": "M136"
  },
  {
    "nome": "macdou",
    "codigo": "M137"
  },
  {
    "nome": "macdow",
    "codigo": "M138"
  },
  {
    "nome": "macdu",
    "codigo": "M139"
  },
  {
    "nome": "mace",
    "codigo": "M141"
  },
  {
    "nome": "macer",
    "codigo": "M142"
  },
  {
    "nome": "macf",
    "codigo": "M143"
  },
  {
    "nome": "macfi",
    "codigo": "M144"
  },
  {
    "nome": "macg",
    "codigo": "M145"
  },
  {
    "nome": "macgo",
    "codigo": "M146"
  },
  {
    "nome": "macgr",
    "codigo": "M147"
  },
  {
    "nome": "macgu",
    "codigo": "M148"
  },
  {
    "nome": "mach",
    "codigo": "M149"
  },
  {
    "nome": "macho",
    "codigo": "M151"
  },
  {
    "nome": "maci",
    "codigo": "M152"
  },
  {
    "nome": "mack",
    "codigo": "M153"
  },
  {
    "nome": "macke",
    "codigo": "M154"
  },
  {
    "nome": "macken",
    "codigo": "M155"
  },
  {
    "nome": "mackenz",
    "codigo": "M156"
  },
  {
    "nome": "mackenzie m",
    "codigo": "M157"
  },
  {
    "nome": "macki",
    "codigo": "M158"
  },
  {
    "nome": "mackn",
    "codigo": "M159"
  },
  {
    "nome": "macl",
    "codigo": "M161"
  },
  {
    "nome": "maclay",
    "codigo": "M162"
  },
  {
    "nome": "macle",
    "codigo": "M163"
  },
  {
    "nome": "maclel",
    "codigo": "M164"
  },
  {
    "nome": "macleo",
    "codigo": "M165"
  },
  {
    "nome": "maclu",
    "codigo": "M166"
  },
  {
    "nome": "macm",
    "codigo": "M167"
  },
  {
    "nome": "macmu",
    "codigo": "M168"
  },
  {
    "nome": "macn",
    "codigo": "M169"
  },
  {
    "nome": "maco",
    "codigo": "M171"
  },
  {
    "nome": "macp",
    "codigo": "M172"
  },
  {
    "nome": "macq",
    "codigo": "M173"
  },
  {
    "nome": "macr",
    "codigo": "M174"
  },
  {
    "nome": "macs",
    "codigo": "M175"
  },
  {
    "nome": "macv",
    "codigo": "M176"
  },
  {
    "nome": "macw",
    "codigo": "M177"
  },
  {
    "nome": "mad",
    "codigo": "M178"
  },
  {
    "nome": "madd",
    "codigo": "M179"
  },
  {
    "nome": "made",
    "codigo": "M181"
  },
  {
    "nome": "madi",
    "codigo": "M182"
  },
  {
    "nome": "mado",
    "codigo": "M183"
  },
  {
    "nome": "mae",
    "codigo": "M184"
  },
  {
    "nome": "mael",
    "codigo": "M185"
  },
  {
    "nome": "maes",
    "codigo": "M186"
  },
  {
    "nome": "maf",
    "codigo": "M187"
  },
  {
    "nome": "mag",
    "codigo": "M188"
  },
  {
    "nome": "magat",
    "codigo": "M189"
  },
  {
    "nome": "mage",
    "codigo": "M191"
  },
  {
    "nome": "magen",
    "codigo": "M192"
  },
  {
    "nome": "magg",
    "codigo": "M193"
  },
  {
    "nome": "magi",
    "codigo": "M194"
  },
  {
    "nome": "magl",
    "codigo": "M195"
  },
  {
    "nome": "magn",
    "codigo": "M196"
  },
  {
    "nome": "magni",
    "codigo": "M197"
  },
  {
    "nome": "magno",
    "codigo": "M198"
  },
  {
    "nome": "magnu",
    "codigo": "M199"
  },
  {
    "nome": "mago",
    "codigo": "M211"
  },
  {
    "nome": "magr",
    "codigo": "M212"
  },
  {
    "nome": "magu",
    "codigo": "M213"
  },
  {
    "nome": "mah",
    "codigo": "M214"
  },
  {
    "nome": "mahm",
    "codigo": "M215"
  },
  {
    "nome": "maho",
    "codigo": "M216"
  },
  {
    "nome": "mai",
    "codigo": "M217"
  },
  {
    "nome": "maig",
    "codigo": "M218"
  },
  {
    "nome": "mail",
    "codigo": "M219"
  },
  {
    "nome": "maille",
    "codigo": "M221"
  },
  {
    "nome": "mailly",
    "codigo": "M222"
  },
  {
    "nome": "maim",
    "codigo": "M223"
  },
  {
    "nome": "main",
    "codigo": "M224"
  },
  {
    "nome": "maine",
    "codigo": "M225"
  },
  {
    "nome": "maint",
    "codigo": "M226"
  },
  {
    "nome": "mainw",
    "codigo": "M227"
  },
  {
    "nome": "mair",
    "codigo": "M228"
  },
  {
    "nome": "mairo",
    "codigo": "M229"
  },
  {
    "nome": "mais",
    "codigo": "M231"
  },
  {
    "nome": "mait",
    "codigo": "M232"
  },
  {
    "nome": "maj",
    "codigo": "M233"
  },
  {
    "nome": "majo",
    "codigo": "M234"
  },
  {
    "nome": "mak",
    "codigo": "M235"
  },
  {
    "nome": "mal",
    "codigo": "M236"
  },
  {
    "nome": "malan",
    "codigo": "M237"
  },
  {
    "nome": "malas",
    "codigo": "M238"
  },
  {
    "nome": "malat",
    "codigo": "M239"
  },
  {
    "nome": "malb",
    "codigo": "M241"
  },
  {
    "nome": "malc",
    "codigo": "M242"
  },
  {
    "nome": "malco",
    "codigo": "M243"
  },
  {
    "nome": "mald",
    "codigo": "M244"
  },
  {
    "nome": "male",
    "codigo": "M245"
  },
  {
    "nome": "males",
    "codigo": "M246"
  },
  {
    "nome": "malet",
    "codigo": "M247"
  },
  {
    "nome": "malev",
    "codigo": "M248"
  },
  {
    "nome": "malh",
    "codigo": "M249"
  },
  {
    "nome": "mali",
    "codigo": "M251"
  },
  {
    "nome": "mall",
    "codigo": "M252"
  },
  {
    "nome": "mallet",
    "codigo": "M253"
  },
  {
    "nome": "malli",
    "codigo": "M254"
  },
  {
    "nome": "mallo",
    "codigo": "M255"
  },
  {
    "nome": "malm",
    "codigo": "M256"
  },
  {
    "nome": "malo",
    "codigo": "M257"
  },
  {
    "nome": "malou",
    "codigo": "M258"
  },
  {
    "nome": "malp",
    "codigo": "M259"
  },
  {
    "nome": "malt",
    "codigo": "M261"
  },
  {
    "nome": "malv",
    "codigo": "M262"
  },
  {
    "nome": "mam",
    "codigo": "M263"
  },
  {
    "nome": "mame",
    "codigo": "M264"
  },
  {
    "nome": "mami",
    "codigo": "M265"
  },
  {
    "nome": "man",
    "codigo": "M266"
  },
  {
    "nome": "manas",
    "codigo": "M267"
  },
  {
    "nome": "manc",
    "codigo": "M268"
  },
  {
    "nome": "manci",
    "codigo": "M269"
  },
  {
    "nome": "mand",
    "codigo": "M271"
  },
  {
    "nome": "mander",
    "codigo": "M272"
  },
  {
    "nome": "mandr",
    "codigo": "M273"
  },
  {
    "nome": "mane",
    "codigo": "M274"
  },
  {
    "nome": "manet",
    "codigo": "M275"
  },
  {
    "nome": "manf",
    "codigo": "M276"
  },
  {
    "nome": "mang",
    "codigo": "M277"
  },
  {
    "nome": "mani",
    "codigo": "M278"
  },
  {
    "nome": "manl",
    "codigo": "M279"
  },
  {
    "nome": "mann",
    "codigo": "M281"
  },
  {
    "nome": "mann m",
    "codigo": "M282"
  },
  {
    "nome": "manni",
    "codigo": "M283"
  },
  {
    "nome": "manning m",
    "codigo": "M284"
  },
  {
    "nome": "manno",
    "codigo": "M285"
  },
  {
    "nome": "newell g",
    "codigo": "N545"
  },
  {
    "nome": "newell m",
    "codigo": "N546"
  },
  {
    "nome": "newell s",
    "codigo": "N547"
  },
  {
    "nome": "newh",
    "codigo": "N548"
  },
  {
    "nome": "newl",
    "codigo": "N549"
  },
  {
    "nome": "newm",
    "codigo": "N551"
  },
  {
    "nome": "newman d",
    "codigo": "N552"
  },
  {
    "nome": "newman j",
    "codigo": "N553"
  },
  {
    "nome": "newman m",
    "codigo": "N554"
  },
  {
    "nome": "newman s",
    "codigo": "N555"
  },
  {
    "nome": "newman w",
    "codigo": "N556"
  },
  {
    "nome": "newn",
    "codigo": "N557"
  },
  {
    "nome": "newp",
    "codigo": "N558"
  },
  {
    "nome": "newt",
    "codigo": "N559"
  },
  {
    "nome": "newton",
    "codigo": "N561"
  },
  {
    "nome": "newton c",
    "codigo": "N562"
  },
  {
    "nome": "newton f",
    "codigo": "N563"
  },
  {
    "nome": "newton j",
    "codigo": "N564"
  },
  {
    "nome": "newton m",
    "codigo": "N565"
  },
  {
    "nome": "newton s",
    "codigo": "N566"
  },
  {
    "nome": "newton w",
    "codigo": "N567"
  },
  {
    "nome": "ney",
    "codigo": "N568"
  },
  {
    "nome": "ney j",
    "codigo": "N569"
  },
  {
    "nome": "ney p",
    "codigo": "N571"
  },
  {
    "nome": "neyl",
    "codigo": "N572"
  },
  {
    "nome": "neyn",
    "codigo": "N573"
  },
  {
    "nome": "neyr",
    "codigo": "N574"
  },
  {
    "nome": "nez",
    "codigo": "N575"
  },
  {
    "nome": "ng",
    "codigo": "N576"
  },
  {
    "nome": "ni",
    "codigo": "N577"
  },
  {
    "nome": "nib",
    "codigo": "N578"
  },
  {
    "nome": "nibe",
    "codigo": "N579"
  },
  {
    "nome": "nibo",
    "codigo": "N581"
  },
  {
    "nome": "nic",
    "codigo": "N582"
  },
  {
    "nome": "nican",
    "codigo": "N583"
  },
  {
    "nome": "nicc",
    "codigo": "N584"
  },
  {
    "nome": "niccoli",
    "codigo": "N585"
  },
  {
    "nome": "niccolini",
    "codigo": "N586"
  },
  {
    "nome": "niccolo",
    "codigo": "N587"
  },
  {
    "nome": "nice",
    "codigo": "N588"
  },
  {
    "nome": "nicep",
    "codigo": "N589"
  },
  {
    "nome": "nicer",
    "codigo": "N591"
  },
  {
    "nome": "nicet",
    "codigo": "N592"
  },
  {
    "nome": "nicetas",
    "codigo": "N593"
  },
  {
    "nome": "nich",
    "codigo": "N594"
  },
  {
    "nome": "nichol",
    "codigo": "N595"
  },
  {
    "nome": "nichol m",
    "codigo": "N596"
  },
  {
    "nome": "nicholas",
    "codigo": "N597"
  },
  {
    "nome": "nicholas j",
    "codigo": "N598"
  },
  {
    "nome": "nicholas p",
    "codigo": "N599"
  },
  {
    "nome": "nicholl",
    "codigo": "N611"
  },
  {
    "nome": "nicholl m",
    "codigo": "N612"
  },
  {
    "nome": "nicholls",
    "codigo": "N613"
  },
  {
    "nome": "nicholls g",
    "codigo": "N614"
  },
  {
    "nome": "nicholls m",
    "codigo": "N615"
  },
  {
    "nome": "nichols",
    "codigo": "N616"
  },
  {
    "nome": "nichols c",
    "codigo": "N617"
  },
  {
    "nome": "nichols f",
    "codigo": "N618"
  },
  {
    "nome": "nichols j",
    "codigo": "N619"
  },
  {
    "nome": "nichols m",
    "codigo": "N621"
  },
  {
    "nome": "nichols s",
    "codigo": "N622"
  },
  {
    "nome": "nichols w",
    "codigo": "N623"
  },
  {
    "nome": "nicholson",
    "codigo": "N624"
  },
  {
    "nome": "nicholson d",
    "codigo": "N625"
  },
  {
    "nome": "nicholson j",
    "codigo": "N626"
  },
  {
    "nome": "nicholson m",
    "codigo": "N627"
  },
  {
    "nome": "nicholson s",
    "codigo": "N628"
  },
  {
    "nome": "nicholson w",
    "codigo": "N629"
  },
  {
    "nome": "nici",
    "codigo": "N631"
  },
  {
    "nome": "nick",
    "codigo": "N632"
  },
  {
    "nome": "nico",
    "codigo": "N633"
  },
  {
    "nome": "nicol",
    "codigo": "N634"
  },
  {
    "nome": "nicolai",
    "codigo": "N635"
  },
  {
    "nome": "nicolai j",
    "codigo": "N636"
  },
  {
    "nome": "nicolai p",
    "codigo": "N637"
  },
  {
    "nome": "nicolas",
    "codigo": "N638"
  },
  {
    "nome": "nicolau",
    "codigo": "N639"
  },
  {
    "nome": "nicolay",
    "codigo": "N641"
  },
  {
    "nome": "nicole",
    "codigo": "N642"
  },
  {
    "nome": "nicolet",
    "codigo": "N643"
  },
  {
    "nome": "nicoli",
    "codigo": "N644"
  },
  {
    "nome": "nicoll",
    "codigo": "N645"
  },
  {
    "nome": "nicollet",
    "codigo": "N646"
  },
  {
    "nome": "nicolls",
    "codigo": "N647"
  },
  {
    "nome": "nicolls j",
    "codigo": "N648"
  },
  {
    "nome": "nicolls p",
    "codigo": "N649"
  },
  {
    "nome": "nicolo",
    "codigo": "N651"
  },
  {
    "nome": "nicols",
    "codigo": "N652"
  },
  {
    "nome": "nicolson",
    "codigo": "N653"
  },
  {
    "nome": "nicolson m",
    "codigo": "N654"
  },
  {
    "nome": "nicom",
    "codigo": "N655"
  },
  {
    "nome": "nicome",
    "codigo": "N656"
  },
  {
    "nome": "nicon",
    "codigo": "N657"
  },
  {
    "nome": "nicop",
    "codigo": "N658"
  },
  {
    "nome": "nicor",
    "codigo": "N659"
  },
  {
    "nome": "nicos",
    "codigo": "N661"
  },
  {
    "nome": "nicot",
    "codigo": "N662"
  },
  {
    "nome": "nicou",
    "codigo": "N663"
  },
  {
    "nome": "nid",
    "codigo": "N664"
  },
  {
    "nome": "nie",
    "codigo": "N665"
  },
  {
    "nome": "nied",
    "codigo": "N666"
  },
  {
    "nome": "niel",
    "codigo": "N667"
  },
  {
    "nome": "niell",
    "codigo": "N668"
  },
  {
    "nome": "niels",
    "codigo": "N669"
  },
  {
    "nome": "niem",
    "codigo": "N671"
  },
  {
    "nome": "nieme",
    "codigo": "N672"
  },
  {
    "nome": "niemo",
    "codigo": "N673"
  },
  {
    "nome": "niep",
    "codigo": "N674"
  },
  {
    "nome": "nier",
    "codigo": "N675"
  },
  {
    "nome": "niero",
    "codigo": "N676"
  },
  {
    "nome": "niet",
    "codigo": "N677"
  },
  {
    "nome": "nieu",
    "codigo": "N678"
  },
  {
    "nome": "nieul",
    "codigo": "N679"
  },
  {
    "nome": "nieup",
    "codigo": "N681"
  },
  {
    "nome": "nieuw",
    "codigo": "N682"
  },
  {
    "nome": "nif",
    "codigo": "N683"
  },
  {
    "nome": "nig",
    "codigo": "N684"
  },
  {
    "nome": "niger",
    "codigo": "N685"
  },
  {
    "nome": "niget",
    "codigo": "N686"
  },
  {
    "nome": "nigh",
    "codigo": "N687"
  },
  {
    "nome": "nightengale m",
    "codigo": "N688"
  },
  {
    "nome": "nigr",
    "codigo": "N689"
  },
  {
    "nome": "nih",
    "codigo": "N691"
  },
  {
    "nome": "nik",
    "codigo": "N692"
  },
  {
    "nome": "niko",
    "codigo": "N693"
  },
  {
    "nome": "nikon",
    "codigo": "N694"
  },
  {
    "nome": "nil",
    "codigo": "N695"
  },
  {
    "nome": "niles",
    "codigo": "N696"
  },
  {
    "nome": "niles d",
    "codigo": "N697"
  },
  {
    "nome": "niles j",
    "codigo": "N698"
  },
  {
    "nome": "niles m",
    "codigo": "N699"
  },
  {
    "nome": "niles s",
    "codigo": "N711"
  },
  {
    "nome": "niles w",
    "codigo": "N712"
  },
  {
    "nome": "nim",
    "codigo": "N713"
  },
  {
    "nome": "nin",
    "codigo": "N714"
  },
  {
    "nome": "nini",
    "codigo": "N715"
  },
  {
    "nome": "nino",
    "codigo": "N716"
  },
  {
    "nome": "ninu",
    "codigo": "N717"
  },
  {
    "nome": "nio",
    "codigo": "N718"
  },
  {
    "nome": "nip",
    "codigo": "N719"
  },
  {
    "nome": "niq",
    "codigo": "N721"
  },
  {
    "nome": "nis",
    "codigo": "N722"
  },
  {
    "nome": "nisb",
    "codigo": "N723"
  },
  {
    "nome": "nisbet m",
    "codigo": "N724"
  },
  {
    "nome": "nisl",
    "codigo": "N725"
  },
  {
    "nome": "niss",
    "codigo": "N726"
  },
  {
    "nome": "nisso",
    "codigo": "N727"
  },
  {
    "nome": "nit",
    "codigo": "N728"
  },
  {
    "nome": "nith",
    "codigo": "N729"
  },
  {
    "nome": "nito",
    "codigo": "N731"
  },
  {
    "nome": "nits",
    "codigo": "N732"
  },
  {
    "nome": "nitt",
    "codigo": "N733"
  },
  {
    "nome": "niv",
    "codigo": "N734"
  },
  {
    "nome": "niver",
    "codigo": "N735"
  },
  {
    "nome": "nix",
    "codigo": "N736"
  },
  {
    "nome": "niz",
    "codigo": "N737"
  },
  {
    "nome": "nj",
    "codigo": "N738"
  },
  {
    "nome": "no",
    "codigo": "N739"
  },
  {
    "nome": "noail",
    "codigo": "N741"
  },
  {
    "nome": "noailles m",
    "codigo": "N742"
  },
  {
    "nome": "noak",
    "codigo": "N743"
  },
  {
    "nome": "nob",
    "codigo": "N744"
  },
  {
    "nome": "nobi",
    "codigo": "N745"
  },
  {
    "nome": "nobl",
    "codigo": "N746"
  },
  {
    "nome": "noble",
    "codigo": "N747"
  },
  {
    "nome": "noble d",
    "codigo": "N748"
  },
  {
    "nome": "noble j",
    "codigo": "N749"
  },
  {
    "nome": "noble m",
    "codigo": "N751"
  },
  {
    "nome": "noble s",
    "codigo": "N752"
  },
  {
    "nome": "noble w",
    "codigo": "N753"
  },
  {
    "nome": "nobr",
    "codigo": "N754"
  },
  {
    "nome": "noby",
    "codigo": "N755"
  },
  {
    "nome": "noc",
    "codigo": "N756"
  },
  {
    "nome": "noch",
    "codigo": "N757"
  },
  {
    "nome": "noci",
    "codigo": "N758"
  },
  {
    "nome": "nocr",
    "codigo": "N759"
  },
  {
    "nome": "nod",
    "codigo": "N761"
  },
  {
    "nome": "nodu",
    "codigo": "N762"
  },
  {
    "nome": "noe",
    "codigo": "N763"
  },
  {
    "nome": "noed",
    "codigo": "N764"
  },
  {
    "nome": "noel",
    "codigo": "N765"
  },
  {
    "nome": "noel d",
    "codigo": "N766"
  },
  {
    "nome": "noel j",
    "codigo": "N767"
  },
  {
    "nome": "noel m",
    "codigo": "N768"
  },
  {
    "nome": "noel s",
    "codigo": "N769"
  },
  {
    "nome": "noes",
    "codigo": "N771"
  },
  {
    "nome": "noet",
    "codigo": "N772"
  },
  {
    "nome": "nof",
    "codigo": "N773"
  },
  {
    "nome": "nog",
    "codigo": "N774"
  },
  {
    "nome": "nogaro",
    "codigo": "N775"
  },
  {
    "nome": "noge",
    "codigo": "N776"
  },
  {
    "nome": "nogh",
    "codigo": "N777"
  },
  {
    "nome": "nogu",
    "codigo": "N778"
  },
  {
    "nome": "noh",
    "codigo": "N779"
  },
  {
    "nome": "nohr",
    "codigo": "N781"
  },
  {
    "nome": "noi",
    "codigo": "N782"
  },
  {
    "nome": "noiret",
    "codigo": "N783"
  },
  {
    "nome": "noirot",
    "codigo": "N784"
  },
  {
    "nome": "nok",
    "codigo": "N785"
  },
  {
    "nome": "nol",
    "codigo": "N786"
  },
  {
    "nome": "nolan",
    "codigo": "N787"
  },
  {
    "nome": "nolan j",
    "codigo": "N788"
  },
  {
    "nome": "nolan p",
    "codigo": "N789"
  },
  {
    "nome": "nold",
    "codigo": "N791"
  },
  {
    "nome": "noli",
    "codigo": "N792"
  },
  {
    "nome": "noll",
    "codigo": "N793"
  },
  {
    "nome": "nollek",
    "codigo": "N794"
  },
  {
    "nome": "nollet",
    "codigo": "N795"
  },
  {
    "nome": "nolli",
    "codigo": "N796"
  },
  {
    "nome": "nolp",
    "codigo": "N797"
  },
  {
    "nome": "nolt",
    "codigo": "N798"
  },
  {
    "nome": "nom",
    "codigo": "N799"
  },
  {
    "nome": "nomu",
    "codigo": "N811"
  },
  {
    "nome": "non",
    "codigo": "N812"
  },
  {
    "nome": "noni",
    "codigo": "N813"
  },
  {
    "nome": "nonn",
    "codigo": "N814"
  },
  {
    "nome": "nonz",
    "codigo": "N815"
  },
  {
    "nome": "noo",
    "codigo": "N816"
  },
  {
    "nome": "noom",
    "codigo": "N817"
  },
  {
    "nome": "noor",
    "codigo": "N818"
  },
  {
    "nome": "noot",
    "codigo": "N819"
  },
  {
    "nome": "nop",
    "codigo": "N821"
  },
  {
    "nome": "nor",
    "codigo": "N822"
  },
  {
    "nome": "norbert",
    "codigo": "N823"
  },
  {
    "nome": "norbert m",
    "codigo": "N824"
  },
  {
    "nome": "norbl",
    "codigo": "N825"
  },
  {
    "nome": "norby",
    "codigo": "N826"
  },
  {
    "nome": "norc",
    "codigo": "N827"
  },
  {
    "nome": "nord",
    "codigo": "N828"
  },
  {
    "nome": "norden",
    "codigo": "N829"
  },
  {
    "nome": "nordenh",
    "codigo": "N831"
  },
  {
    "nome": "nordens",
    "codigo": "N832"
  },
  {
    "nome": "nordt",
    "codigo": "N833"
  },
  {
    "nome": "nore",
    "codigo": "N834"
  },
  {
    "nome": "norf",
    "codigo": "N835"
  },
  {
    "nome": "norfolk j",
    "codigo": "N836"
  },
  {
    "nome": "norfolk p",
    "codigo": "N837"
  },
  {
    "nome": "norg",
    "codigo": "N838"
  },
  {
    "nome": "norgh",
    "codigo": "N839"
  },
  {
    "nome": "nori",
    "codigo": "N841"
  },
  {
    "nome": "norm",
    "codigo": "N842"
  },
  {
    "nome": "norman m",
    "codigo": "N843"
  },
  {
    "nome": "normanb",
    "codigo": "N844"
  },
  {
    "nome": "normand",
    "codigo": "N845"
  },
  {
    "nome": "normand j",
    "codigo": "N846"
  },
  {
    "nome": "normand p",
    "codigo": "N847"
  },
  {
    "nome": "normandy",
    "codigo": "N848"
  },
  {
    "nome": "normann",
    "codigo": "N849"
  },
  {
    "nome": "normant",
    "codigo": "N851"
  },
  {
    "nome": "noro",
    "codigo": "N852"
  },
  {
    "nome": "norr",
    "codigo": "N853"
  },
  {
    "nome": "norris c",
    "codigo": "N854"
  },
  {
    "nome": "norris f",
    "codigo": "N855"
  },
  {
    "nome": "norris j",
    "codigo": "N856"
  },
  {
    "nome": "norris m",
    "codigo": "N857"
  },
  {
    "nome": "norris r",
    "codigo": "N858"
  },
  {
    "nome": "norris s",
    "codigo": "N859"
  },
  {
    "nome": "norris w",
    "codigo": "N861"
  },
  {
    "nome": "norry",
    "codigo": "N862"
  },
  {
    "nome": "nors",
    "codigo": "N863"
  },
  {
    "nome": "north",
    "codigo": "N864"
  },
  {
    "nome": "north g",
    "codigo": "N865"
  },
  {
    "nome": "north m",
    "codigo": "N866"
  },
  {
    "nome": "north s",
    "codigo": "N867"
  },
  {
    "nome": "northa",
    "codigo": "N868"
  },
  {
    "nome": "northampton",
    "codigo": "N869"
  },
  {
    "nome": "northampton m",
    "codigo": "N871"
  },
  {
    "nome": "northb",
    "codigo": "N872"
  },
  {
    "nome": "northc",
    "codigo": "N873"
  },
  {
    "nome": "northe",
    "codigo": "N874"
  },
  {
    "nome": "northn",
    "codigo": "N875"
  },
  {
    "nome": "northo",
    "codigo": "N876"
  },
  {
    "nome": "northr",
    "codigo": "N877"
  },
  {
    "nome": "northu",
    "codigo": "N878"
  },
  {
    "nome": "northw",
    "codigo": "N879"
  },
  {
    "nome": "northwo",
    "codigo": "N881"
  },
  {
    "nome": "norto",
    "codigo": "N882"
  },
  {
    "nome": "norton c",
    "codigo": "N883"
  },
  {
    "nome": "norton f",
    "codigo": "N884"
  },
  {
    "nome": "norton j",
    "codigo": "N885"
  },
  {
    "nome": "norton m",
    "codigo": "N886"
  },
  {
    "nome": "norton r",
    "codigo": "N887"
  },
  {
    "nome": "norton s",
    "codigo": "N888"
  },
  {
    "nome": "norton w",
    "codigo": "N889"
  },
  {
    "nome": "norv",
    "codigo": "N891"
  },
  {
    "nome": "norw",
    "codigo": "N892"
  },
  {
    "nome": "norwich m",
    "codigo": "N893"
  },
  {
    "nome": "norwo",
    "codigo": "N894"
  },
  {
    "nome": "norwood m",
    "codigo": "N895"
  },
  {
    "nome": "norz",
    "codigo": "N896"
  },
  {
    "nome": "nos",
    "codigo": "N897"
  },
  {
    "nome": "nost",
    "codigo": "N898"
  },
  {
    "nome": "not",
    "codigo": "N899"
  },
  {
    "nome": "note",
    "codigo": "N911"
  },
  {
    "nome": "noth",
    "codigo": "N912"
  },
  {
    "nome": "notk",
    "codigo": "N913"
  },
  {
    "nome": "notr",
    "codigo": "N914"
  },
  {
    "nome": "nott",
    "codigo": "N915"
  },
  {
    "nome": "nott g",
    "codigo": "N916"
  },
  {
    "nome": "nott m",
    "codigo": "N917"
  },
  {
    "nome": "nott s",
    "codigo": "N918"
  },
  {
    "nome": "notti",
    "codigo": "N919"
  },
  {
    "nome": "nottingham m",
    "codigo": "N921"
  },
  {
    "nome": "nottn",
    "codigo": "N922"
  },
  {
    "nome": "notto",
    "codigo": "N923"
  },
  {
    "nome": "nou",
    "codigo": "N924"
  },
  {
    "nome": "noue",
    "codigo": "N925"
  },
  {
    "nome": "nouet",
    "codigo": "N926"
  },
  {
    "nome": "noug",
    "codigo": "N927"
  },
  {
    "nome": "nouh",
    "codigo": "N928"
  },
  {
    "nome": "noul",
    "codigo": "N929"
  },
  {
    "nome": "nour",
    "codigo": "N931"
  },
  {
    "nome": "nourr",
    "codigo": "N932"
  },
  {
    "nome": "nours",
    "codigo": "N933"
  },
  {
    "nome": "nouv",
    "codigo": "N934"
  },
  {
    "nome": "nov",
    "codigo": "N935"
  },
  {
    "nome": "novar",
    "codigo": "N936"
  },
  {
    "nome": "nove",
    "codigo": "N937"
  },
  {
    "nome": "novelli",
    "codigo": "N938"
  },
  {
    "nome": "novello",
    "codigo": "N939"
  },
  {
    "nome": "nover",
    "codigo": "N941"
  },
  {
    "nome": "noves",
    "codigo": "N942"
  },
  {
    "nome": "novi",
    "codigo": "N943"
  },
  {
    "nome": "novio",
    "codigo": "N944"
  },
  {
    "nome": "noviu",
    "codigo": "N945"
  },
  {
    "nome": "now",
    "codigo": "N946"
  },
  {
    "nome": "nowe",
    "codigo": "N947"
  },
  {
    "nome": "nowell m",
    "codigo": "N948"
  },
  {
    "nome": "noy",
    "codigo": "N949"
  },
  {
    "nome": "noyer",
    "codigo": "N951"
  },
  {
    "nome": "noyes",
    "codigo": "N952"
  },
  {
    "nome": "noyes c",
    "codigo": "N953"
  },
  {
    "nome": "noyes f",
    "codigo": "N954"
  },
  {
    "nome": "noyes j",
    "codigo": "N955"
  },
  {
    "nome": "noyes m",
    "codigo": "N956"
  },
  {
    "nome": "noyes r",
    "codigo": "N957"
  },
  {
    "nome": "noyes s",
    "codigo": "N958"
  },
  {
    "nome": "noyes w",
    "codigo": "N959"
  },
  {
    "nome": "noz",
    "codigo": "N961"
  },
  {
    "nome": "nu",
    "codigo": "N962"
  },
  {
    "nome": "nuce",
    "codigo": "N963"
  },
  {
    "nome": "nuci",
    "codigo": "N964"
  },
  {
    "nome": "nug",
    "codigo": "N965"
  },
  {
    "nome": "nugent",
    "codigo": "N966"
  },
  {
    "nome": "nugent j",
    "codigo": "N967"
  },
  {
    "nome": "nugent s",
    "codigo": "N968"
  },
  {
    "nome": "nul",
    "codigo": "N969"
  },
  {
    "nome": "num",
    "codigo": "N971"
  },
  {
    "nome": "nun",
    "codigo": "N972"
  },
  {
    "nome": "nunu",
    "codigo": "N973"
  },
  {
    "nome": "nur",
    "codigo": "N974"
  },
  {
    "nome": "nus",
    "codigo": "N975"
  },
  {
    "nome": "nut",
    "codigo": "N976"
  },
  {
    "nome": "nutt j",
    "codigo": "N977"
  },
  {
    "nome": "nutt p",
    "codigo": "N978"
  },
  {
    "nome": "nutta",
    "codigo": "N979"
  },
  {
    "nome": "nuttall m",
    "codigo": "N981"
  },
  {
    "nome": "nutter",
    "codigo": "N982"
  },
  {
    "nome": "nutter g",
    "codigo": "N983"
  },
  {
    "nome": "nutter m",
    "codigo": "N984"
  },
  {
    "nome": "nutter s",
    "codigo": "N985"
  },
  {
    "nome": "nutting",
    "codigo": "N986"
  },
  {
    "nome": "nutting g",
    "codigo": "N987"
  },
  {
    "nome": "nutting m",
    "codigo": "N988"
  },
  {
    "nome": "nuv",
    "codigo": "N989"
  },
  {
    "nome": "nuy",
    "codigo": "N991"
  },
  {
    "nome": "nuz",
    "codigo": "N992"
  },
  {
    "nome": "ny",
    "codigo": "N993"
  },
  {
    "nome": "nye",
    "codigo": "N994"
  },
  {
    "nome": "nyk",
    "codigo": "N995"
  },
  {
    "nome": "nym",
    "codigo": "N996"
  },
  {
    "nome": "nyo",
    "codigo": "N997"
  },
  {
    "nome": "nys",
    "codigo": "N998"
  },
  {
    "nome": "nyt",
    "codigo": "N999"
  },
  {
    "nome": "o",
    "codigo": "O11"
  },
  {
    "nome": "oa",
    "codigo": "O11"
  },
  {
    "nome": "ob",
    "codigo": "O12"
  },
  {
    "nome": "obr",
    "codigo": "O13"
  },
  {
    "nome": "obs",
    "codigo": "O14"
  },
  {
    "nome": "oc",
    "codigo": "O15"
  },
  {
    "nome": "och",
    "codigo": "O16"
  },
  {
    "nome": "oco",
    "codigo": "O17"
  },
  {
    "nome": "oconn",
    "codigo": "O18"
  },
  {
    "nome": "ocor",
    "codigo": "O19"
  },
  {
    "nome": "oct",
    "codigo": "O21"
  },
  {
    "nome": "od",
    "codigo": "O22"
  },
  {
    "nome": "ode",
    "codigo": "O23"
  },
  {
    "nome": "odi",
    "codigo": "O24"
  },
  {
    "nome": "odo",
    "codigo": "O25"
  },
  {
    "nome": "odon",
    "codigo": "O26"
  },
  {
    "nome": "odr",
    "codigo": "O27"
  },
  {
    "nome": "oe",
    "codigo": "O28"
  },
  {
    "nome": "oer",
    "codigo": "O29"
  },
  {
    "nome": "of",
    "codigo": "O31"
  },
  {
    "nome": "off",
    "codigo": "O32"
  },
  {
    "nome": "ofl",
    "codigo": "O33"
  },
  {
    "nome": "og",
    "codigo": "O34"
  },
  {
    "nome": "ogl",
    "codigo": "O35"
  },
  {
    "nome": "oh",
    "codigo": "O36"
  },
  {
    "nome": "ohe",
    "codigo": "O37"
  },
  {
    "nome": "ohm",
    "codigo": "O38"
  },
  {
    "nome": "oi",
    "codigo": "O39"
  },
  {
    "nome": "ok",
    "codigo": "O41"
  },
  {
    "nome": "ol",
    "codigo": "O42"
  },
  {
    "nome": "olb",
    "codigo": "O43"
  },
  {
    "nome": "old",
    "codigo": "O44"
  },
  {
    "nome": "ole",
    "codigo": "O45"
  },
  {
    "nome": "oli",
    "codigo": "O46"
  },
  {
    "nome": "olip",
    "codigo": "O47"
  },
  {
    "nome": "oliv",
    "codigo": "O48"
  },
  {
    "nome": "olivi",
    "codigo": "O49"
  },
  {
    "nome": "olm",
    "codigo": "O51"
  },
  {
    "nome": "olo",
    "codigo": "O52"
  },
  {
    "nome": "oly",
    "codigo": "O53"
  },
  {
    "nome": "om",
    "codigo": "O54"
  },
  {
    "nome": "ome",
    "codigo": "O55"
  },
  {
    "nome": "omo",
    "codigo": "O56"
  },
  {
    "nome": "omu",
    "codigo": "O57"
  },
  {
    "nome": "on",
    "codigo": "O58"
  },
  {
    "nome": "ons",
    "codigo": "O59"
  },
  {
    "nome": "op",
    "codigo": "O61"
  },
  {
    "nome": "opp",
    "codigo": "O62"
  },
  {
    "nome": "or",
    "codigo": "O63"
  },
  {
    "nome": "orb",
    "codigo": "O64"
  },
  {
    "nome": "ord",
    "codigo": "O65"
  },
  {
    "nome": "ore",
    "codigo": "O66"
  },
  {
    "nome": "orf",
    "codigo": "O67"
  },
  {
    "nome": "org",
    "codigo": "O68"
  },
  {
    "nome": "ori",
    "codigo": "O69"
  },
  {
    "nome": "orl",
    "codigo": "O71"
  },
  {
    "nome": "orlo",
    "codigo": "O72"
  },
  {
    "nome": "orm",
    "codigo": "O73"
  },
  {
    "nome": "orn",
    "codigo": "O74"
  },
  {
    "nome": "orr",
    "codigo": "O75"
  },
  {
    "nome": "ors",
    "codigo": "O76"
  },
  {
    "nome": "ort",
    "codigo": "O77"
  },
  {
    "nome": "orto",
    "codigo": "O78"
  },
  {
    "nome": "orv",
    "codigo": "O79"
  },
  {
    "nome": "os",
    "codigo": "O81"
  },
  {
    "nome": "osg",
    "codigo": "O82"
  },
  {
    "nome": "osm",
    "codigo": "O83"
  },
  {
    "nome": "oss",
    "codigo": "O84"
  },
  {
    "nome": "ost",
    "codigo": "O85"
  },
  {
    "nome": "osw",
    "codigo": "O86"
  },
  {
    "nome": "ot",
    "codigo": "O87"
  },
  {
    "nome": "oti",
    "codigo": "O88"
  },
  {
    "nome": "ott",
    "codigo": "O89"
  },
  {
    "nome": "ottl",
    "codigo": "O91"
  },
  {
    "nome": "otw",
    "codigo": "O92"
  },
  {
    "nome": "ou",
    "codigo": "O93"
  },
  {
    "nome": "ous",
    "codigo": "O94"
  },
  {
    "nome": "ouv",
    "codigo": "O95"
  },
  {
    "nome": "ov",
    "codigo": "O96"
  },
  {
    "nome": "ow",
    "codigo": "O97"
  },
  {
    "nome": "ox",
    "codigo": "O98"
  },
  {
    "nome": "oz",
    "codigo": "O99"
  },
  {
    "nome": "p",
    "codigo": "P111"
  },
  {
    "nome": "pa",
    "codigo": "P111"
  },
  {
    "nome": "paac",
    "codigo": "P112"
  },
  {
    "nome": "paacu",
    "codigo": "P113"
  },
  {
    "nome": "pacc",
    "codigo": "P114"
  },
  {
    "nome": "pace",
    "codigo": "P115"
  },
  {
    "nome": "pach",
    "codigo": "P116"
  },
  {
    "nome": "paci",
    "codigo": "P117"
  },
  {
    "nome": "pacin",
    "codigo": "P118"
  },
  {
    "nome": "pack",
    "codigo": "P119"
  },
  {
    "nome": "paco",
    "codigo": "P121"
  },
  {
    "nome": "pacu",
    "codigo": "P122"
  },
  {
    "nome": "pad",
    "codigo": "P123"
  },
  {
    "nome": "pado",
    "codigo": "P124"
  },
  {
    "nome": "padu",
    "codigo": "P125"
  },
  {
    "nome": "pae",
    "codigo": "P126"
  },
  {
    "nome": "paez",
    "codigo": "P127"
  },
  {
    "nome": "pag",
    "codigo": "P128"
  },
  {
    "nome": "pagani",
    "codigo": "P129"
  },
  {
    "nome": "pagano",
    "codigo": "P131"
  },
  {
    "nome": "page",
    "codigo": "P132"
  },
  {
    "nome": "page m",
    "codigo": "P133"
  },
  {
    "nome": "pagen",
    "codigo": "P134"
  },
  {
    "nome": "paget",
    "codigo": "P135"
  },
  {
    "nome": "pagi",
    "codigo": "P136"
  },
  {
    "nome": "pagit",
    "codigo": "P137"
  },
  {
    "nome": "pagl",
    "codigo": "P138"
  },
  {
    "nome": "pagn",
    "codigo": "P139"
  },
  {
    "nome": "pah",
    "codigo": "P141"
  },
  {
    "nome": "pai",
    "codigo": "P142"
  },
  {
    "nome": "pail",
    "codigo": "P143"
  },
  {
    "nome": "pain",
    "codigo": "P144"
  },
  {
    "nome": "paine g",
    "codigo": "P145"
  },
  {
    "nome": "paine m",
    "codigo": "P146"
  },
  {
    "nome": "paine s",
    "codigo": "P147"
  },
  {
    "nome": "paint",
    "codigo": "P148"
  },
  {
    "nome": "pais",
    "codigo": "P149"
  },
  {
    "nome": "paj",
    "codigo": "P151"
  },
  {
    "nome": "pak",
    "codigo": "P152"
  },
  {
    "nome": "pal",
    "codigo": "P153"
  },
  {
    "nome": "palai",
    "codigo": "P154"
  },
  {
    "nome": "palaz",
    "codigo": "P155"
  },
  {
    "nome": "pale",
    "codigo": "P156"
  },
  {
    "nome": "pales",
    "codigo": "P157"
  },
  {
    "nome": "paley",
    "codigo": "P158"
  },
  {
    "nome": "palf",
    "codigo": "P159"
  },
  {
    "nome": "palg",
    "codigo": "P161"
  },
  {
    "nome": "pali",
    "codigo": "P162"
  },
  {
    "nome": "palis",
    "codigo": "P163"
  },
  {
    "nome": "pall",
    "codigo": "P164"
  },
  {
    "nome": "pallav",
    "codigo": "P165"
  },
  {
    "nome": "palle",
    "codigo": "P166"
  },
  {
    "nome": "palli",
    "codigo": "P167"
  },
  {
    "nome": "pallis",
    "codigo": "P168"
  },
  {
    "nome": "pallu",
    "codigo": "P169"
  },
  {
    "nome": "palm",
    "codigo": "P171"
  },
  {
    "nome": "palme",
    "codigo": "P172"
  },
  {
    "nome": "palmer",
    "codigo": "P173"
  },
  {
    "nome": "palmer g",
    "codigo": "P174"
  },
  {
    "nome": "palmer m",
    "codigo": "P175"
  },
  {
    "nome": "palmer s",
    "codigo": "P176"
  },
  {
    "nome": "palmer w",
    "codigo": "P177"
  },
  {
    "nome": "palmers",
    "codigo": "P178"
  },
  {
    "nome": "palmi",
    "codigo": "P179"
  },
  {
    "nome": "palo",
    "codigo": "P181"
  },
  {
    "nome": "pals",
    "codigo": "P182"
  },
  {
    "nome": "palt",
    "codigo": "P183"
  },
  {
    "nome": "palu",
    "codigo": "P184"
  },
  {
    "nome": "pam",
    "codigo": "P185"
  },
  {
    "nome": "pamph",
    "codigo": "P186"
  },
  {
    "nome": "pan",
    "codigo": "P187"
  },
  {
    "nome": "panc",
    "codigo": "P188"
  },
  {
    "nome": "pand",
    "codigo": "P189"
  },
  {
    "nome": "pane",
    "codigo": "P191"
  },
  {
    "nome": "pani",
    "codigo": "P192"
  },
  {
    "nome": "paniz",
    "codigo": "P193"
  },
  {
    "nome": "pann",
    "codigo": "P194"
  },
  {
    "nome": "pano",
    "codigo": "P195"
  },
  {
    "nome": "pans",
    "codigo": "P196"
  },
  {
    "nome": "pant",
    "codigo": "P197"
  },
  {
    "nome": "panto",
    "codigo": "P198"
  },
  {
    "nome": "panz",
    "codigo": "P199"
  },
  {
    "nome": "pao",
    "codigo": "P211"
  },
  {
    "nome": "paolo",
    "codigo": "P212"
  },
  {
    "nome": "pap",
    "codigo": "P213"
  },
  {
    "nome": "pape",
    "codigo": "P214"
  },
  {
    "nome": "papi",
    "codigo": "P215"
  },
  {
    "nome": "papil",
    "codigo": "P216"
  },
  {
    "nome": "papin",
    "codigo": "P217"
  },
  {
    "nome": "papo",
    "codigo": "P218"
  },
  {
    "nome": "paq",
    "codigo": "P219"
  },
  {
    "nome": "par",
    "codigo": "P221"
  },
  {
    "nome": "parad",
    "codigo": "P222"
  },
  {
    "nome": "paran",
    "codigo": "P223"
  },
  {
    "nome": "parav",
    "codigo": "P224"
  },
  {
    "nome": "parc",
    "codigo": "P225"
  },
  {
    "nome": "pard",
    "codigo": "P226"
  },
  {
    "nome": "pare",
    "codigo": "P227"
  },
  {
    "nome": "paren",
    "codigo": "P228"
  },
  {
    "nome": "parf",
    "codigo": "P229"
  },
  {
    "nome": "pari",
    "codigo": "P231"
  },
  {
    "nome": "paris",
    "codigo": "P232"
  },
  {
    "nome": "parish",
    "codigo": "P233"
  },
  {
    "nome": "parisi",
    "codigo": "P234"
  },
  {
    "nome": "park",
    "codigo": "P235"
  },
  {
    "nome": "park m",
    "codigo": "P236"
  },
  {
    "nome": "parke",
    "codigo": "P237"
  },
  {
    "nome": "parker",
    "codigo": "P238"
  },
  {
    "nome": "parker f",
    "codigo": "P239"
  },
  {
    "nome": "parker j",
    "codigo": "P241"
  },
  {
    "nome": "parker m",
    "codigo": "P242"
  },
  {
    "nome": "parker s",
    "codigo": "P243"
  },
  {
    "nome": "parker w",
    "codigo": "P244"
  },
  {
    "nome": "parkes",
    "codigo": "P245"
  },
  {
    "nome": "parkh",
    "codigo": "P246"
  },
  {
    "nome": "parki",
    "codigo": "P247"
  },
  {
    "nome": "parkinson m",
    "codigo": "P248"
  },
  {
    "nome": "parkman",
    "codigo": "P249"
  },
  {
    "nome": "parkman m",
    "codigo": "P251"
  },
  {
    "nome": "parks",
    "codigo": "P252"
  },
  {
    "nome": "parm",
    "codigo": "P253"
  },
  {
    "nome": "parment",
    "codigo": "P254"
  },
  {
    "nome": "parmi",
    "codigo": "P255"
  },
  {
    "nome": "parn",
    "codigo": "P256"
  },
  {
    "nome": "paro",
    "codigo": "P257"
  },
  {
    "nome": "parr",
    "codigo": "P258"
  },
  {
    "nome": "parr m",
    "codigo": "P259"
  },
  {
    "nome": "parri",
    "codigo": "P261"
  },
  {
    "nome": "parro",
    "codigo": "P262"
  },
  {
    "nome": "parrot",
    "codigo": "P263"
  },
  {
    "nome": "parry",
    "codigo": "P264"
  },
  {
    "nome": "parry m",
    "codigo": "P265"
  },
  {
    "nome": "pars",
    "codigo": "P266"
  },
  {
    "nome": "parsons",
    "codigo": "P267"
  },
  {
    "nome": "parsons g",
    "codigo": "P268"
  },
  {
    "nome": "parsons m",
    "codigo": "P269"
  },
  {
    "nome": "parsons s",
    "codigo": "P271"
  },
  {
    "nome": "parsons w",
    "codigo": "P272"
  },
  {
    "nome": "part",
    "codigo": "P273"
  },
  {
    "nome": "parto",
    "codigo": "P274"
  },
  {
    "nome": "partr",
    "codigo": "P275"
  },
  {
    "nome": "parv",
    "codigo": "P276"
  },
  {
    "nome": "pas",
    "codigo": "P277"
  },
  {
    "nome": "pasc",
    "codigo": "P278"
  },
  {
    "nome": "pasch",
    "codigo": "P279"
  },
  {
    "nome": "pasco",
    "codigo": "P281"
  },
  {
    "nome": "pasi",
    "codigo": "P282"
  },
  {
    "nome": "paso",
    "codigo": "P283"
  },
  {
    "nome": "pasq",
    "codigo": "P284"
  },
  {
    "nome": "pass",
    "codigo": "P285"
  },
  {
    "nome": "passar",
    "codigo": "P286"
  },
  {
    "nome": "passe",
    "codigo": "P287"
  },
  {
    "nome": "passi",
    "codigo": "P288"
  },
  {
    "nome": "passo",
    "codigo": "P289"
  },
  {
    "nome": "past",
    "codigo": "P291"
  },
  {
    "nome": "pasto",
    "codigo": "P292"
  },
  {
    "nome": "pastor",
    "codigo": "P293"
  },
  {
    "nome": "pat",
    "codigo": "P294"
  },
  {
    "nome": "pate",
    "codigo": "P295"
  },
  {
    "nome": "paters",
    "codigo": "P296"
  },
  {
    "nome": "paterson m",
    "codigo": "P297"
  },
  {
    "nome": "pati",
    "codigo": "P298"
  },
  {
    "nome": "patis",
    "codigo": "P299"
  },
  {
    "nome": "patm",
    "codigo": "P311"
  },
  {
    "nome": "pato",
    "codigo": "P312"
  },
  {
    "nome": "patou",
    "codigo": "P313"
  },
  {
    "nome": "patr",
    "codigo": "P314"
  },
  {
    "nome": "patt",
    "codigo": "P315"
  },
  {
    "nome": "patten",
    "codigo": "P316"
  },
  {
    "nome": "patterson",
    "codigo": "P317"
  },
  {
    "nome": "patterson m",
    "codigo": "P318"
  },
  {
    "nome": "pattes",
    "codigo": "P319"
  },
  {
    "nome": "patti",
    "codigo": "P321"
  },
  {
    "nome": "patto",
    "codigo": "P322"
  },
  {
    "nome": "pau",
    "codigo": "P323"
  },
  {
    "nome": "paul",
    "codigo": "P324"
  },
  {
    "nome": "pauld",
    "codigo": "P325"
  },
  {
    "nome": "paule",
    "codigo": "P326"
  },
  {
    "nome": "pauli",
    "codigo": "P327"
  },
  {
    "nome": "paulin",
    "codigo": "P328"
  },
  {
    "nome": "paull",
    "codigo": "P329"
  },
  {
    "nome": "paulm",
    "codigo": "P331"
  },
  {
    "nome": "pauls",
    "codigo": "P332"
  },
  {
    "nome": "paulu",
    "codigo": "P333"
  },
  {
    "nome": "paus",
    "codigo": "P334"
  },
  {
    "nome": "paut",
    "codigo": "P335"
  },
  {
    "nome": "pauw",
    "codigo": "P336"
  },
  {
    "nome": "pav",
    "codigo": "P337"
  },
  {
    "nome": "pavi",
    "codigo": "P338"
  },
  {
    "nome": "pavo",
    "codigo": "P339"
  },
  {
    "nome": "pax",
    "codigo": "P341"
  },
  {
    "nome": "paxt",
    "codigo": "P342"
  },
  {
    "nome": "pay",
    "codigo": "P343"
  },
  {
    "nome": "payer",
    "codigo": "P344"
  },
  {
    "nome": "payn",
    "codigo": "P345"
  },
  {
    "nome": "payne",
    "codigo": "P346"
  },
  {
    "nome": "pays",
    "codigo": "P347"
  },
  {
    "nome": "paz",
    "codigo": "P348"
  },
  {
    "nome": "pe",
    "codigo": "P349"
  },
  {
    "nome": "peabody",
    "codigo": "P351"
  },
  {
    "nome": "peabody g",
    "codigo": "P352"
  },
  {
    "nome": "peabody m",
    "codigo": "P353"
  },
  {
    "nome": "peabody s",
    "codigo": "P354"
  },
  {
    "nome": "peac",
    "codigo": "P355"
  },
  {
    "nome": "peaco",
    "codigo": "P356"
  },
  {
    "nome": "peak",
    "codigo": "P357"
  },
  {
    "nome": "peal",
    "codigo": "P358"
  },
  {
    "nome": "pear",
    "codigo": "P359"
  },
  {
    "nome": "pears",
    "codigo": "P361"
  },
  {
    "nome": "pearson m",
    "codigo": "P362"
  },
  {
    "nome": "peas",
    "codigo": "P363"
  },
  {
    "nome": "pec",
    "codigo": "P364"
  },
  {
    "nome": "pecc",
    "codigo": "P365"
  },
  {
    "nome": "peck",
    "codigo": "P366"
  },
  {
    "nome": "peck m",
    "codigo": "P367"
  },
  {
    "nome": "peckh",
    "codigo": "P368"
  },
  {
    "nome": "peco",
    "codigo": "P369"
  },
  {
    "nome": "ped",
    "codigo": "P371"
  },
  {
    "nome": "pedro",
    "codigo": "P372"
  },
  {
    "nome": "pee",
    "codigo": "P373"
  },
  {
    "nome": "peel",
    "codigo": "P374"
  },
  {
    "nome": "peer",
    "codigo": "P375"
  },
  {
    "nome": "peg",
    "codigo": "P376"
  },
  {
    "nome": "pei",
    "codigo": "P377"
  },
  {
    "nome": "peirc",
    "codigo": "P378"
  },
  {
    "nome": "peirs",
    "codigo": "P379"
  },
  {
    "nome": "pel",
    "codigo": "P381"
  },
  {
    "nome": "pelet",
    "codigo": "P382"
  },
  {
    "nome": "pelh",
    "codigo": "P383"
  },
  {
    "nome": "peli",
    "codigo": "P384"
  },
  {
    "nome": "pell",
    "codigo": "P385"
  },
  {
    "nome": "pelle",
    "codigo": "P386"
  },
  {
    "nome": "peller",
    "codigo": "P387"
  },
  {
    "nome": "pellet",
    "codigo": "P388"
  },
  {
    "nome": "pellew",
    "codigo": "P389"
  },
  {
    "nome": "pelli",
    "codigo": "P391"
  },
  {
    "nome": "pello",
    "codigo": "P392"
  },
  {
    "nome": "pelt",
    "codigo": "P393"
  },
  {
    "nome": "pemb",
    "codigo": "P394"
  },
  {
    "nome": "pemberton m",
    "codigo": "P395"
  },
  {
    "nome": "pembr",
    "codigo": "P396"
  },
  {
    "nome": "pen",
    "codigo": "P397"
  },
  {
    "nome": "pendl",
    "codigo": "P398"
  },
  {
    "nome": "penh",
    "codigo": "P399"
  },
  {
    "nome": "peni",
    "codigo": "P411"
  },
  {
    "nome": "penn",
    "codigo": "P412"
  },
  {
    "nome": "pennel",
    "codigo": "P413"
  },
  {
    "nome": "penni",
    "codigo": "P414"
  },
  {
    "nome": "penno",
    "codigo": "P415"
  },
  {
    "nome": "penny",
    "codigo": "P416"
  },
  {
    "nome": "penr",
    "codigo": "P417"
  },
  {
    "nome": "pens",
    "codigo": "P418"
  },
  {
    "nome": "pent",
    "codigo": "P419"
  },
  {
    "nome": "pep",
    "codigo": "P421"
  },
  {
    "nome": "pepi",
    "codigo": "P422"
  },
  {
    "nome": "pepo",
    "codigo": "P423"
  },
  {
    "nome": "pepp",
    "codigo": "P424"
  },
  {
    "nome": "pepy",
    "codigo": "P425"
  },
  {
    "nome": "per",
    "codigo": "P426"
  },
  {
    "nome": "perau",
    "codigo": "P427"
  },
  {
    "nome": "perc",
    "codigo": "P428"
  },
  {
    "nome": "perci",
    "codigo": "P429"
  },
  {
    "nome": "percy",
    "codigo": "P431"
  },
  {
    "nome": "percy m",
    "codigo": "P432"
  },
  {
    "nome": "perd",
    "codigo": "P433"
  },
  {
    "nome": "pere",
    "codigo": "P434"
  },
  {
    "nome": "pereg",
    "codigo": "P435"
  },
  {
    "nome": "perei",
    "codigo": "P436"
  },
  {
    "nome": "perel",
    "codigo": "P437"
  },
  {
    "nome": "perez",
    "codigo": "P438"
  },
  {
    "nome": "perg",
    "codigo": "P439"
  },
  {
    "nome": "peri",
    "codigo": "P441"
  },
  {
    "nome": "perier",
    "codigo": "P442"
  },
  {
    "nome": "perig",
    "codigo": "P443"
  },
  {
    "nome": "perigo",
    "codigo": "P444"
  },
  {
    "nome": "perin",
    "codigo": "P445"
  },
  {
    "nome": "peris",
    "codigo": "P446"
  },
  {
    "nome": "perk",
    "codigo": "P447"
  },
  {
    "nome": "perkins",
    "codigo": "P448"
  },
  {
    "nome": "perkins j",
    "codigo": "P449"
  },
  {
    "nome": "perkins p",
    "codigo": "P451"
  },
  {
    "nome": "pern",
    "codigo": "P452"
  },
  {
    "nome": "pero",
    "codigo": "P453"
  },
  {
    "nome": "perr",
    "codigo": "P454"
  },
  {
    "nome": "perre",
    "codigo": "P455"
  },
  {
    "nome": "perri",
    "codigo": "P456"
  },
  {
    "nome": "perrier",
    "codigo": "P457"
  },
  {
    "nome": "perrin",
    "codigo": "P458"
  },
  {
    "nome": "perro",
    "codigo": "P459"
  },
  {
    "nome": "perrot",
    "codigo": "P461"
  },
  {
    "nome": "perry",
    "codigo": "P462"
  },
  {
    "nome": "perry g",
    "codigo": "P463"
  },
  {
    "nome": "perry m",
    "codigo": "P464"
  },
  {
    "nome": "perry s",
    "codigo": "P465"
  },
  {
    "nome": "pers",
    "codigo": "P466"
  },
  {
    "nome": "perso",
    "codigo": "P467"
  },
  {
    "nome": "pert",
    "codigo": "P468"
  },
  {
    "nome": "perti",
    "codigo": "P469"
  },
  {
    "nome": "peru",
    "codigo": "P471"
  },
  {
    "nome": "pes",
    "codigo": "P472"
  },
  {
    "nome": "pesc",
    "codigo": "P473"
  },
  {
    "nome": "pese",
    "codigo": "P474"
  },
  {
    "nome": "pess",
    "codigo": "P475"
  },
  {
    "nome": "pest",
    "codigo": "P476"
  },
  {
    "nome": "pet",
    "codigo": "P477"
  },
  {
    "nome": "peter",
    "codigo": "P478"
  },
  {
    "nome": "peterb",
    "codigo": "P479"
  },
  {
    "nome": "peters",
    "codigo": "P481"
  },
  {
    "nome": "peters j",
    "codigo": "P482"
  },
  {
    "nome": "peters p",
    "codigo": "P483"
  },
  {
    "nome": "petersen",
    "codigo": "P484"
  },
  {
    "nome": "peterson",
    "codigo": "P485"
  },
  {
    "nome": "peth",
    "codigo": "P486"
  },
  {
    "nome": "peti",
    "codigo": "P487"
  },
  {
    "nome": "petis",
    "codigo": "P488"
  },
  {
    "nome": "petit",
    "codigo": "P489"
  },
  {
    "nome": "petito",
    "codigo": "P491"
  },
  {
    "nome": "peto",
    "codigo": "P492"
  },
  {
    "nome": "petr",
    "codigo": "P493"
  },
  {
    "nome": "petrei",
    "codigo": "P494"
  },
  {
    "nome": "petri",
    "codigo": "P495"
  },
  {
    "nome": "petrin",
    "codigo": "P496"
  },
  {
    "nome": "petro",
    "codigo": "P497"
  },
  {
    "nome": "petru",
    "codigo": "P498"
  },
  {
    "nome": "pett",
    "codigo": "P499"
  },
  {
    "nome": "petti",
    "codigo": "P511"
  },
  {
    "nome": "petty",
    "codigo": "P512"
  },
  {
    "nome": "petz",
    "codigo": "P513"
  },
  {
    "nome": "peu",
    "codigo": "P514"
  },
  {
    "nome": "pey",
    "codigo": "P515"
  },
  {
    "nome": "peyro",
    "codigo": "P516"
  },
  {
    "nome": "peys",
    "codigo": "P517"
  },
  {
    "nome": "peyst",
    "codigo": "P518"
  },
  {
    "nome": "peyt",
    "codigo": "P519"
  },
  {
    "nome": "pez",
    "codigo": "P521"
  },
  {
    "nome": "pezr",
    "codigo": "P522"
  },
  {
    "nome": "pf",
    "codigo": "P523"
  },
  {
    "nome": "pfe",
    "codigo": "P524"
  },
  {
    "nome": "pfei",
    "codigo": "P525"
  },
  {
    "nome": "pfeiffer",
    "codigo": "P526"
  },
  {
    "nome": "pfeiffer m",
    "codigo": "P527"
  },
  {
    "nome": "pfen",
    "codigo": "P528"
  },
  {
    "nome": "pfi",
    "codigo": "P529"
  },
  {
    "nome": "pfl",
    "codigo": "P531"
  },
  {
    "nome": "ph",
    "codigo": "P532"
  },
  {
    "nome": "phal",
    "codigo": "P533"
  },
  {
    "nome": "phale",
    "codigo": "P534"
  },
  {
    "nome": "phan",
    "codigo": "P535"
  },
  {
    "nome": "phar",
    "codigo": "P536"
  },
  {
    "nome": "phe",
    "codigo": "P537"
  },
  {
    "nome": "phel",
    "codigo": "P538"
  },
  {
    "nome": "phelps j",
    "codigo": "P539"
  },
  {
    "nome": "phelps p",
    "codigo": "P541"
  },
  {
    "nome": "pher",
    "codigo": "P542"
  },
  {
    "nome": "phi",
    "codigo": "P543"
  },
  {
    "nome": "phil",
    "codigo": "P544"
  },
  {
    "nome": "philb",
    "codigo": "P545"
  },
  {
    "nome": "phile",
    "codigo": "P546"
  },
  {
    "nome": "phili",
    "codigo": "P547"
  },
  {
    "nome": "philid",
    "codigo": "P548"
  },
  {
    "nome": "philip",
    "codigo": "P549"
  },
  {
    "nome": "philipp",
    "codigo": "P551"
  },
  {
    "nome": "philippi",
    "codigo": "P552"
  },
  {
    "nome": "philippu",
    "codigo": "P553"
  },
  {
    "nome": "philips",
    "codigo": "P554"
  },
  {
    "nome": "philips m",
    "codigo": "P555"
  },
  {
    "nome": "phill",
    "codigo": "P556"
  },
  {
    "nome": "phillip",
    "codigo": "P557"
  },
  {
    "nome": "phillips",
    "codigo": "P558"
  },
  {
    "nome": "phillips f",
    "codigo": "P559"
  },
  {
    "nome": "phillips j",
    "codigo": "P561"
  },
  {
    "nome": "phillips m",
    "codigo": "P562"
  },
  {
    "nome": "phillips s",
    "codigo": "P563"
  },
  {
    "nome": "phillips w",
    "codigo": "P564"
  },
  {
    "nome": "philo",
    "codigo": "P565"
  },
  {
    "nome": "philoc",
    "codigo": "P566"
  },
  {
    "nome": "philom",
    "codigo": "P567"
  },
  {
    "nome": "philos",
    "codigo": "P568"
  },
  {
    "nome": "philox",
    "codigo": "P569"
  },
  {
    "nome": "philp",
    "codigo": "P571"
  },
  {
    "nome": "phin",
    "codigo": "P572"
  },
  {
    "nome": "phip",
    "codigo": "P573"
  },
  {
    "nome": "pho",
    "codigo": "P574"
  },
  {
    "nome": "phor",
    "codigo": "P575"
  },
  {
    "nome": "phr",
    "codigo": "P576"
  },
  {
    "nome": "phry",
    "codigo": "P577"
  },
  {
    "nome": "phy",
    "codigo": "P578"
  },
  {
    "nome": "pi",
    "codigo": "P579"
  },
  {
    "nome": "pian",
    "codigo": "P581"
  },
  {
    "nome": "piat",
    "codigo": "P582"
  },
  {
    "nome": "piatt",
    "codigo": "P583"
  },
  {
    "nome": "piaz",
    "codigo": "P584"
  },
  {
    "nome": "pic",
    "codigo": "P585"
  },
  {
    "nome": "picar",
    "codigo": "P586"
  },
  {
    "nome": "picc",
    "codigo": "P587"
  },
  {
    "nome": "piccin",
    "codigo": "P588"
  },
  {
    "nome": "piccio",
    "codigo": "P589"
  },
  {
    "nome": "picco",
    "codigo": "P591"
  },
  {
    "nome": "pich",
    "codigo": "P592"
  },
  {
    "nome": "picho",
    "codigo": "P593"
  },
  {
    "nome": "pick",
    "codigo": "P594"
  },
  {
    "nome": "picker",
    "codigo": "P595"
  },
  {
    "nome": "pickering m",
    "codigo": "P596"
  },
  {
    "nome": "picket",
    "codigo": "P597"
  },
  {
    "nome": "pico",
    "codigo": "P598"
  },
  {
    "nome": "picou",
    "codigo": "P599"
  },
  {
    "nome": "pict",
    "codigo": "P611"
  },
  {
    "nome": "pid",
    "codigo": "P612"
  },
  {
    "nome": "pie",
    "codigo": "P613"
  },
  {
    "nome": "pien",
    "codigo": "P614"
  },
  {
    "nome": "pier",
    "codigo": "P615"
  },
  {
    "nome": "pierce g",
    "codigo": "P616"
  },
  {
    "nome": "pierce m",
    "codigo": "P617"
  },
  {
    "nome": "pierce s",
    "codigo": "P618"
  },
  {
    "nome": "pierl",
    "codigo": "P619"
  },
  {
    "nome": "pierp",
    "codigo": "P621"
  },
  {
    "nome": "pierr",
    "codigo": "P622"
  },
  {
    "nome": "pierres",
    "codigo": "P623"
  },
  {
    "nome": "piers",
    "codigo": "P624"
  },
  {
    "nome": "piet",
    "codigo": "P625"
  },
  {
    "nome": "pietro",
    "codigo": "P626"
  },
  {
    "nome": "pif",
    "codigo": "P627"
  },
  {
    "nome": "pig",
    "codigo": "P628"
  },
  {
    "nome": "pige",
    "codigo": "P629"
  },
  {
    "nome": "pigg",
    "codigo": "P631"
  },
  {
    "nome": "pign",
    "codigo": "P632"
  },
  {
    "nome": "pigo",
    "codigo": "P633"
  },
  {
    "nome": "pih",
    "codigo": "P634"
  },
  {
    "nome": "pik",
    "codigo": "P635"
  },
  {
    "nome": "pike m",
    "codigo": "P636"
  },
  {
    "nome": "pil",
    "codigo": "P637"
  },
  {
    "nome": "piles",
    "codigo": "P638"
  },
  {
    "nome": "pilk",
    "codigo": "P639"
  },
  {
    "nome": "pill",
    "codigo": "P641"
  },
  {
    "nome": "pillo",
    "codigo": "P642"
  },
  {
    "nome": "pilo",
    "codigo": "P643"
  },
  {
    "nome": "pim",
    "codigo": "P644"
  },
  {
    "nome": "pin",
    "codigo": "P645"
  },
  {
    "nome": "pinar",
    "codigo": "P646"
  },
  {
    "nome": "pinc",
    "codigo": "P647"
  },
  {
    "nome": "pind",
    "codigo": "P648"
  },
  {
    "nome": "pine",
    "codigo": "P649"
  },
  {
    "nome": "pinel",
    "codigo": "P651"
  },
  {
    "nome": "pinet",
    "codigo": "P652"
  },
  {
    "nome": "ping",
    "codigo": "P653"
  },
  {
    "nome": "pinh",
    "codigo": "P654"
  },
  {
    "nome": "pink",
    "codigo": "P655"
  },
  {
    "nome": "pinn",
    "codigo": "P656"
  },
  {
    "nome": "pino",
    "codigo": "P657"
  },
  {
    "nome": "pins",
    "codigo": "P658"
  },
  {
    "nome": "pint",
    "codigo": "P659"
  },
  {
    "nome": "pinz",
    "codigo": "P661"
  },
  {
    "nome": "pio",
    "codigo": "P662"
  },
  {
    "nome": "pioz",
    "codigo": "P663"
  },
  {
    "nome": "pip",
    "codigo": "P664"
  },
  {
    "nome": "piper",
    "codigo": "P665"
  },
  {
    "nome": "piq",
    "codigo": "P666"
  },
  {
    "nome": "pir",
    "codigo": "P667"
  },
  {
    "nome": "piri",
    "codigo": "P668"
  },
  {
    "nome": "pirk",
    "codigo": "P669"
  },
  {
    "nome": "piro",
    "codigo": "P671"
  },
  {
    "nome": "piron",
    "codigo": "P672"
  },
  {
    "nome": "pis",
    "codigo": "P673"
  },
  {
    "nome": "pisani",
    "codigo": "P674"
  },
  {
    "nome": "pisano",
    "codigo": "P675"
  },
  {
    "nome": "pisc",
    "codigo": "P676"
  },
  {
    "nome": "pise",
    "codigo": "P677"
  },
  {
    "nome": "piso",
    "codigo": "P678"
  },
  {
    "nome": "pist",
    "codigo": "P679"
  },
  {
    "nome": "pit",
    "codigo": "P681"
  },
  {
    "nome": "pitc",
    "codigo": "P682"
  },
  {
    "nome": "pith",
    "codigo": "P683"
  },
  {
    "nome": "piti",
    "codigo": "P684"
  },
  {
    "nome": "pitm",
    "codigo": "P685"
  },
  {
    "nome": "pitr",
    "codigo": "P686"
  },
  {
    "nome": "pits",
    "codigo": "P687"
  },
  {
    "nome": "pitt",
    "codigo": "P688"
  },
  {
    "nome": "pitti",
    "codigo": "P689"
  },
  {
    "nome": "pitto",
    "codigo": "P691"
  },
  {
    "nome": "pitts",
    "codigo": "P692"
  },
  {
    "nome": "merv",
    "codigo": "M576"
  },
  {
    "nome": "merz",
    "codigo": "M577"
  },
  {
    "nome": "mes",
    "codigo": "M578"
  },
  {
    "nome": "mesm",
    "codigo": "M579"
  },
  {
    "nome": "mesn",
    "codigo": "M581"
  },
  {
    "nome": "mesni",
    "codigo": "M582"
  },
  {
    "nome": "mess",
    "codigo": "M583"
  },
  {
    "nome": "messe",
    "codigo": "M584"
  },
  {
    "nome": "messi",
    "codigo": "M585"
  },
  {
    "nome": "mest",
    "codigo": "M586"
  },
  {
    "nome": "met",
    "codigo": "M587"
  },
  {
    "nome": "metc",
    "codigo": "M588"
  },
  {
    "nome": "mete",
    "codigo": "M589"
  },
  {
    "nome": "metey",
    "codigo": "M591"
  },
  {
    "nome": "meth",
    "codigo": "M592"
  },
  {
    "nome": "meto",
    "codigo": "M593"
  },
  {
    "nome": "metr",
    "codigo": "M594"
  },
  {
    "nome": "mett",
    "codigo": "M595"
  },
  {
    "nome": "metz",
    "codigo": "M596"
  },
  {
    "nome": "meu",
    "codigo": "M597"
  },
  {
    "nome": "meur",
    "codigo": "M598"
  },
  {
    "nome": "meus",
    "codigo": "M599"
  },
  {
    "nome": "mew",
    "codigo": "M611"
  },
  {
    "nome": "mey",
    "codigo": "M612"
  },
  {
    "nome": "meyer m",
    "codigo": "M613"
  },
  {
    "nome": "meyn",
    "codigo": "M614"
  },
  {
    "nome": "meyr",
    "codigo": "M615"
  },
  {
    "nome": "meys",
    "codigo": "M616"
  },
  {
    "nome": "mez",
    "codigo": "M617"
  },
  {
    "nome": "mi",
    "codigo": "M618"
  },
  {
    "nome": "mic",
    "codigo": "M619"
  },
  {
    "nome": "mich",
    "codigo": "M621"
  },
  {
    "nome": "michau",
    "codigo": "M622"
  },
  {
    "nome": "miche",
    "codigo": "M623"
  },
  {
    "nome": "michi",
    "codigo": "M624"
  },
  {
    "nome": "micho",
    "codigo": "M625"
  },
  {
    "nome": "mico",
    "codigo": "M626"
  },
  {
    "nome": "mid",
    "codigo": "M627"
  },
  {
    "nome": "middleton",
    "codigo": "M628"
  },
  {
    "nome": "middleton m",
    "codigo": "M629"
  },
  {
    "nome": "mie",
    "codigo": "M631"
  },
  {
    "nome": "mier",
    "codigo": "M632"
  },
  {
    "nome": "mif",
    "codigo": "M633"
  },
  {
    "nome": "mig",
    "codigo": "M634"
  },
  {
    "nome": "mign",
    "codigo": "M635"
  },
  {
    "nome": "migno",
    "codigo": "M636"
  },
  {
    "nome": "mil",
    "codigo": "M637"
  },
  {
    "nome": "milb",
    "codigo": "M638"
  },
  {
    "nome": "milc",
    "codigo": "M639"
  },
  {
    "nome": "mild",
    "codigo": "M641"
  },
  {
    "nome": "mile",
    "codigo": "M642"
  },
  {
    "nome": "miles",
    "codigo": "M643"
  },
  {
    "nome": "milf",
    "codigo": "M644"
  },
  {
    "nome": "mill",
    "codigo": "M645"
  },
  {
    "nome": "mille",
    "codigo": "M646"
  },
  {
    "nome": "miller",
    "codigo": "M647"
  },
  {
    "nome": "miller g",
    "codigo": "M648"
  },
  {
    "nome": "miller m",
    "codigo": "M649"
  },
  {
    "nome": "miller s",
    "codigo": "M651"
  },
  {
    "nome": "miller w",
    "codigo": "M652"
  },
  {
    "nome": "millet",
    "codigo": "M653"
  },
  {
    "nome": "milli",
    "codigo": "M654"
  },
  {
    "nome": "millin",
    "codigo": "M655"
  },
  {
    "nome": "millo",
    "codigo": "M656"
  },
  {
    "nome": "mills",
    "codigo": "M657"
  },
  {
    "nome": "milm",
    "codigo": "M658"
  },
  {
    "nome": "miln",
    "codigo": "M659"
  },
  {
    "nome": "milo",
    "codigo": "M661"
  },
  {
    "nome": "milt",
    "codigo": "M662"
  },
  {
    "nome": "min",
    "codigo": "M663"
  },
  {
    "nome": "mine",
    "codigo": "M664"
  },
  {
    "nome": "mini",
    "codigo": "M665"
  },
  {
    "nome": "mino",
    "codigo": "M666"
  },
  {
    "nome": "mint",
    "codigo": "M667"
  },
  {
    "nome": "minu",
    "codigo": "M668"
  },
  {
    "nome": "mio",
    "codigo": "M669"
  },
  {
    "nome": "mir",
    "codigo": "M671"
  },
  {
    "nome": "miran",
    "codigo": "M672"
  },
  {
    "nome": "mirb",
    "codigo": "M673"
  },
  {
    "nome": "mire",
    "codigo": "M674"
  },
  {
    "nome": "miri",
    "codigo": "M675"
  },
  {
    "nome": "miro",
    "codigo": "M676"
  },
  {
    "nome": "mirz",
    "codigo": "M677"
  },
  {
    "nome": "mis",
    "codigo": "M678"
  },
  {
    "nome": "mit",
    "codigo": "M679"
  },
  {
    "nome": "mitchell",
    "codigo": "M681"
  },
  {
    "nome": "mitchell m",
    "codigo": "M682"
  },
  {
    "nome": "mitf",
    "codigo": "M683"
  },
  {
    "nome": "mith",
    "codigo": "M684"
  },
  {
    "nome": "mitt",
    "codigo": "M685"
  },
  {
    "nome": "mn",
    "codigo": "M686"
  },
  {
    "nome": "mo",
    "codigo": "M687"
  },
  {
    "nome": "moce",
    "codigo": "M688"
  },
  {
    "nome": "mod",
    "codigo": "M689"
  },
  {
    "nome": "modes",
    "codigo": "M691"
  },
  {
    "nome": "modi",
    "codigo": "M692"
  },
  {
    "nome": "moe",
    "codigo": "M693"
  },
  {
    "nome": "moer",
    "codigo": "M694"
  },
  {
    "nome": "mof",
    "codigo": "M695"
  },
  {
    "nome": "mog",
    "codigo": "M696"
  },
  {
    "nome": "moh",
    "codigo": "M697"
  },
  {
    "nome": "mohl",
    "codigo": "M698"
  },
  {
    "nome": "mohr",
    "codigo": "M699"
  },
  {
    "nome": "mohu",
    "codigo": "M711"
  },
  {
    "nome": "moi",
    "codigo": "M712"
  },
  {
    "nome": "moir",
    "codigo": "M713"
  },
  {
    "nome": "mois",
    "codigo": "M714"
  },
  {
    "nome": "moit",
    "codigo": "M715"
  },
  {
    "nome": "mok",
    "codigo": "M716"
  },
  {
    "nome": "mol",
    "codigo": "M717"
  },
  {
    "nome": "mole",
    "codigo": "M718"
  },
  {
    "nome": "moles",
    "codigo": "M719"
  },
  {
    "nome": "moli",
    "codigo": "M721"
  },
  {
    "nome": "molin",
    "codigo": "M722"
  },
  {
    "nome": "molini",
    "codigo": "M723"
  },
  {
    "nome": "molis",
    "codigo": "M724"
  },
  {
    "nome": "molit",
    "codigo": "M725"
  },
  {
    "nome": "moll",
    "codigo": "M726"
  },
  {
    "nome": "mollo",
    "codigo": "M727"
  },
  {
    "nome": "molo",
    "codigo": "M728"
  },
  {
    "nome": "molt",
    "codigo": "M729"
  },
  {
    "nome": "moly",
    "codigo": "M731"
  },
  {
    "nome": "mom",
    "codigo": "M732"
  },
  {
    "nome": "momm",
    "codigo": "M733"
  },
  {
    "nome": "mon",
    "codigo": "M734"
  },
  {
    "nome": "monal",
    "codigo": "M735"
  },
  {
    "nome": "monas",
    "codigo": "M736"
  },
  {
    "nome": "monc",
    "codigo": "M737"
  },
  {
    "nome": "moncl",
    "codigo": "M738"
  },
  {
    "nome": "moncr",
    "codigo": "M739"
  },
  {
    "nome": "mond",
    "codigo": "M741"
  },
  {
    "nome": "mone",
    "codigo": "M742"
  },
  {
    "nome": "mong",
    "codigo": "M743"
  },
  {
    "nome": "moni",
    "codigo": "M744"
  },
  {
    "nome": "monk",
    "codigo": "M745"
  },
  {
    "nome": "monl",
    "codigo": "M746"
  },
  {
    "nome": "monm",
    "codigo": "M747"
  },
  {
    "nome": "monn",
    "codigo": "M748"
  },
  {
    "nome": "monni",
    "codigo": "M749"
  },
  {
    "nome": "mono",
    "codigo": "M751"
  },
  {
    "nome": "monr",
    "codigo": "M752"
  },
  {
    "nome": "monroe",
    "codigo": "M753"
  },
  {
    "nome": "mons",
    "codigo": "M754"
  },
  {
    "nome": "monso",
    "codigo": "M755"
  },
  {
    "nome": "monst",
    "codigo": "M756"
  },
  {
    "nome": "mont",
    "codigo": "M757"
  },
  {
    "nome": "montag",
    "codigo": "M758"
  },
  {
    "nome": "montague",
    "codigo": "M759"
  },
  {
    "nome": "montai",
    "codigo": "M761"
  },
  {
    "nome": "montal",
    "codigo": "M762"
  },
  {
    "nome": "montale",
    "codigo": "M763"
  },
  {
    "nome": "montan",
    "codigo": "M764"
  },
  {
    "nome": "montano",
    "codigo": "M765"
  },
  {
    "nome": "montar",
    "codigo": "M766"
  },
  {
    "nome": "montau",
    "codigo": "M767"
  },
  {
    "nome": "montb",
    "codigo": "M768"
  },
  {
    "nome": "montbr",
    "codigo": "M769"
  },
  {
    "nome": "montc",
    "codigo": "M771"
  },
  {
    "nome": "monte",
    "codigo": "M772"
  },
  {
    "nome": "monteb",
    "codigo": "M773"
  },
  {
    "nome": "montef",
    "codigo": "M774"
  },
  {
    "nome": "monteg",
    "codigo": "M775"
  },
  {
    "nome": "montel",
    "codigo": "M776"
  },
  {
    "nome": "montem",
    "codigo": "M777"
  },
  {
    "nome": "monter",
    "codigo": "M778"
  },
  {
    "nome": "montes",
    "codigo": "M779"
  },
  {
    "nome": "montess",
    "codigo": "M781"
  },
  {
    "nome": "montf",
    "codigo": "M782"
  },
  {
    "nome": "montfl",
    "codigo": "M783"
  },
  {
    "nome": "montfo",
    "codigo": "M784"
  },
  {
    "nome": "montg",
    "codigo": "M785"
  },
  {
    "nome": "montgo",
    "codigo": "M786"
  },
  {
    "nome": "montgom",
    "codigo": "M787"
  },
  {
    "nome": "montgomery m",
    "codigo": "M788"
  },
  {
    "nome": "month",
    "codigo": "M789"
  },
  {
    "nome": "monti",
    "codigo": "M791"
  },
  {
    "nome": "montig",
    "codigo": "M792"
  },
  {
    "nome": "montl",
    "codigo": "M793"
  },
  {
    "nome": "montlu",
    "codigo": "M794"
  },
  {
    "nome": "montm",
    "codigo": "M795"
  },
  {
    "nome": "montmi",
    "codigo": "M796"
  },
  {
    "nome": "montmo",
    "codigo": "M797"
  },
  {
    "nome": "monto",
    "codigo": "M798"
  },
  {
    "nome": "montp",
    "codigo": "M799"
  },
  {
    "nome": "montr",
    "codigo": "M811"
  },
  {
    "nome": "montri",
    "codigo": "M812"
  },
  {
    "nome": "montro",
    "codigo": "M813"
  },
  {
    "nome": "montv",
    "codigo": "M814"
  },
  {
    "nome": "monu",
    "codigo": "M815"
  },
  {
    "nome": "monz",
    "codigo": "M816"
  },
  {
    "nome": "moo",
    "codigo": "M817"
  },
  {
    "nome": "moon",
    "codigo": "M818"
  },
  {
    "nome": "moor",
    "codigo": "M819"
  },
  {
    "nome": "moore",
    "codigo": "M821"
  },
  {
    "nome": "moore g",
    "codigo": "M822"
  },
  {
    "nome": "moore m",
    "codigo": "M823"
  },
  {
    "nome": "moore s",
    "codigo": "M824"
  },
  {
    "nome": "moore w",
    "codigo": "M825"
  },
  {
    "nome": "moq",
    "codigo": "M826"
  },
  {
    "nome": "mor",
    "codigo": "M827"
  },
  {
    "nome": "moral",
    "codigo": "M828"
  },
  {
    "nome": "moran",
    "codigo": "M829"
  },
  {
    "nome": "morat",
    "codigo": "M831"
  },
  {
    "nome": "moraz",
    "codigo": "M832"
  },
  {
    "nome": "morc",
    "codigo": "M833"
  },
  {
    "nome": "mord",
    "codigo": "M834"
  },
  {
    "nome": "more",
    "codigo": "M835"
  },
  {
    "nome": "more m",
    "codigo": "M836"
  },
  {
    "nome": "moreau",
    "codigo": "M837"
  },
  {
    "nome": "moreh",
    "codigo": "M838"
  },
  {
    "nome": "morel",
    "codigo": "M839"
  },
  {
    "nome": "morell",
    "codigo": "M841"
  },
  {
    "nome": "morelli",
    "codigo": "M842"
  },
  {
    "nome": "moren",
    "codigo": "M843"
  },
  {
    "nome": "moret",
    "codigo": "M844"
  },
  {
    "nome": "moreti",
    "codigo": "M845"
  },
  {
    "nome": "morf",
    "codigo": "M846"
  },
  {
    "nome": "morg",
    "codigo": "M847"
  },
  {
    "nome": "morgan g",
    "codigo": "M848"
  },
  {
    "nome": "morgan m",
    "codigo": "M849"
  },
  {
    "nome": "morge",
    "codigo": "M851"
  },
  {
    "nome": "morgeus",
    "codigo": "M852"
  },
  {
    "nome": "morh",
    "codigo": "M853"
  },
  {
    "nome": "mori",
    "codigo": "M854"
  },
  {
    "nome": "morie",
    "codigo": "M855"
  },
  {
    "nome": "morig",
    "codigo": "M856"
  },
  {
    "nome": "moril",
    "codigo": "M857"
  },
  {
    "nome": "morin",
    "codigo": "M858"
  },
  {
    "nome": "morini",
    "codigo": "M859"
  },
  {
    "nome": "moris",
    "codigo": "M861"
  },
  {
    "nome": "morit",
    "codigo": "M862"
  },
  {
    "nome": "morl",
    "codigo": "M863"
  },
  {
    "nome": "morle",
    "codigo": "M864"
  },
  {
    "nome": "morlo",
    "codigo": "M865"
  },
  {
    "nome": "morn",
    "codigo": "M866"
  },
  {
    "nome": "moro",
    "codigo": "M867"
  },
  {
    "nome": "moron",
    "codigo": "M868"
  },
  {
    "nome": "moros",
    "codigo": "M869"
  },
  {
    "nome": "moroz",
    "codigo": "M871"
  },
  {
    "nome": "morr",
    "codigo": "M872"
  },
  {
    "nome": "morrell",
    "codigo": "M873"
  },
  {
    "nome": "morri",
    "codigo": "M874"
  },
  {
    "nome": "morris",
    "codigo": "M875"
  },
  {
    "nome": "morris g",
    "codigo": "M876"
  },
  {
    "nome": "morris m",
    "codigo": "M877"
  },
  {
    "nome": "morrison",
    "codigo": "M878"
  },
  {
    "nome": "morrison g",
    "codigo": "M879"
  },
  {
    "nome": "morrison m",
    "codigo": "M881"
  },
  {
    "nome": "morrison s",
    "codigo": "M882"
  },
  {
    "nome": "morrison w",
    "codigo": "M883"
  },
  {
    "nome": "mors",
    "codigo": "M884"
  },
  {
    "nome": "morse g",
    "codigo": "M885"
  },
  {
    "nome": "morse m",
    "codigo": "M886"
  },
  {
    "nome": "mort",
    "codigo": "M887"
  },
  {
    "nome": "morti",
    "codigo": "M888"
  },
  {
    "nome": "morto",
    "codigo": "M889"
  },
  {
    "nome": "morton m",
    "codigo": "M891"
  },
  {
    "nome": "morv",
    "codigo": "M892"
  },
  {
    "nome": "mory",
    "codigo": "M893"
  },
  {
    "nome": "mos",
    "codigo": "M894"
  },
  {
    "nome": "mosch",
    "codigo": "M895"
  },
  {
    "nome": "moscho",
    "codigo": "M896"
  },
  {
    "nome": "mose",
    "codigo": "M897"
  },
  {
    "nome": "mosel",
    "codigo": "M898"
  },
  {
    "nome": "moser",
    "codigo": "M899"
  },
  {
    "nome": "moses",
    "codigo": "M911"
  },
  {
    "nome": "mosl",
    "codigo": "M912"
  },
  {
    "nome": "moss",
    "codigo": "M913"
  },
  {
    "nome": "mosso",
    "codigo": "M914"
  },
  {
    "nome": "most",
    "codigo": "M915"
  },
  {
    "nome": "mosto",
    "codigo": "M916"
  },
  {
    "nome": "mot",
    "codigo": "M917"
  },
  {
    "nome": "moth",
    "codigo": "M918"
  },
  {
    "nome": "motl",
    "codigo": "M919"
  },
  {
    "nome": "mott",
    "codigo": "M921"
  },
  {
    "nome": "motte",
    "codigo": "M922"
  },
  {
    "nome": "motz",
    "codigo": "M923"
  },
  {
    "nome": "mou",
    "codigo": "M924"
  },
  {
    "nome": "mouf",
    "codigo": "M925"
  },
  {
    "nome": "moul",
    "codigo": "M926"
  },
  {
    "nome": "moult",
    "codigo": "M927"
  },
  {
    "nome": "moun",
    "codigo": "M928"
  },
  {
    "nome": "mour",
    "codigo": "M929"
  },
  {
    "nome": "moure",
    "codigo": "M931"
  },
  {
    "nome": "mous",
    "codigo": "M932"
  },
  {
    "nome": "mouss",
    "codigo": "M933"
  },
  {
    "nome": "mout",
    "codigo": "M934"
  },
  {
    "nome": "mov",
    "codigo": "M935"
  },
  {
    "nome": "mow",
    "codigo": "M936"
  },
  {
    "nome": "mox",
    "codigo": "M937"
  },
  {
    "nome": "moy",
    "codigo": "M938"
  },
  {
    "nome": "moz",
    "codigo": "M939"
  },
  {
    "nome": "mu",
    "codigo": "M941"
  },
  {
    "nome": "muc",
    "codigo": "M942"
  },
  {
    "nome": "mud",
    "codigo": "M943"
  },
  {
    "nome": "mudg",
    "codigo": "M944"
  },
  {
    "nome": "mudi",
    "codigo": "M945"
  },
  {
    "nome": "muel",
    "codigo": "M946"
  },
  {
    "nome": "mueller m",
    "codigo": "M947"
  },
  {
    "nome": "muen",
    "codigo": "M948"
  },
  {
    "nome": "muf",
    "codigo": "M949"
  },
  {
    "nome": "mug",
    "codigo": "M951"
  },
  {
    "nome": "muh",
    "codigo": "M952"
  },
  {
    "nome": "mui",
    "codigo": "M953"
  },
  {
    "nome": "mul",
    "codigo": "M954"
  },
  {
    "nome": "mulf",
    "codigo": "M955"
  },
  {
    "nome": "mulg",
    "codigo": "M956"
  },
  {
    "nome": "muli",
    "codigo": "M957"
  },
  {
    "nome": "mull",
    "codigo": "M958"
  },
  {
    "nome": "mulli",
    "codigo": "M959"
  },
  {
    "nome": "mulr",
    "codigo": "M961"
  },
  {
    "nome": "mum",
    "codigo": "M962"
  },
  {
    "nome": "mun",
    "codigo": "M963"
  },
  {
    "nome": "munck",
    "codigo": "M964"
  },
  {
    "nome": "mund",
    "codigo": "M965"
  },
  {
    "nome": "munf",
    "codigo": "M966"
  },
  {
    "nome": "muno",
    "codigo": "M967"
  },
  {
    "nome": "munr",
    "codigo": "M968"
  },
  {
    "nome": "muns",
    "codigo": "M969"
  },
  {
    "nome": "munt",
    "codigo": "M971"
  },
  {
    "nome": "mur",
    "codigo": "M972"
  },
  {
    "nome": "murc",
    "codigo": "M973"
  },
  {
    "nome": "murd",
    "codigo": "M974"
  },
  {
    "nome": "mure",
    "codigo": "M975"
  },
  {
    "nome": "murg",
    "codigo": "M976"
  },
  {
    "nome": "muri",
    "codigo": "M977"
  },
  {
    "nome": "murp",
    "codigo": "M978"
  },
  {
    "nome": "murr",
    "codigo": "M979"
  },
  {
    "nome": "murray",
    "codigo": "M981"
  },
  {
    "nome": "murray g",
    "codigo": "M982"
  },
  {
    "nome": "murray m",
    "codigo": "M983"
  },
  {
    "nome": "murray s",
    "codigo": "M984"
  },
  {
    "nome": "mus",
    "codigo": "M985"
  },
  {
    "nome": "muse",
    "codigo": "M986"
  },
  {
    "nome": "musg",
    "codigo": "M987"
  },
  {
    "nome": "musp",
    "codigo": "M988"
  },
  {
    "nome": "muss",
    "codigo": "M989"
  },
  {
    "nome": "must",
    "codigo": "M991"
  },
  {
    "nome": "mut",
    "codigo": "M992"
  },
  {
    "nome": "mutr",
    "codigo": "M993"
  },
  {
    "nome": "muz",
    "codigo": "M994"
  },
  {
    "nome": "my",
    "codigo": "M995"
  },
  {
    "nome": "mye",
    "codigo": "M996"
  },
  {
    "nome": "myl",
    "codigo": "M997"
  },
  {
    "nome": "myr",
    "codigo": "M998"
  },
  {
    "nome": "myt",
    "codigo": "M999"
  },
  {
    "nome": "n",
    "codigo": "N111"
  },
  {
    "nome": "na",
    "codigo": "N111"
  },
  {
    "nome": "naas",
    "codigo": "N112"
  },
  {
    "nome": "nab",
    "codigo": "N113"
  },
  {
    "nome": "nabb",
    "codigo": "N114"
  },
  {
    "nome": "nabe",
    "codigo": "N115"
  },
  {
    "nome": "nabi",
    "codigo": "N116"
  },
  {
    "nome": "nabo",
    "codigo": "N117"
  },
  {
    "nome": "nac",
    "codigo": "N118"
  },
  {
    "nome": "nach",
    "codigo": "N119"
  },
  {
    "nome": "nachi",
    "codigo": "N121"
  },
  {
    "nome": "nachm",
    "codigo": "N122"
  },
  {
    "nome": "nacho",
    "codigo": "N123"
  },
  {
    "nome": "nacht",
    "codigo": "N124"
  },
  {
    "nome": "nack",
    "codigo": "N125"
  },
  {
    "nome": "nad",
    "codigo": "N126"
  },
  {
    "nome": "nadal",
    "codigo": "N127"
  },
  {
    "nome": "nadar",
    "codigo": "N128"
  },
  {
    "nome": "nadas",
    "codigo": "N129"
  },
  {
    "nome": "nadast",
    "codigo": "N131"
  },
  {
    "nome": "nadau",
    "codigo": "N132"
  },
  {
    "nome": "nadaul",
    "codigo": "N133"
  },
  {
    "nome": "nade",
    "codigo": "N134"
  },
  {
    "nome": "nader",
    "codigo": "N135"
  },
  {
    "nome": "nadi",
    "codigo": "N136"
  },
  {
    "nome": "nadj",
    "codigo": "N137"
  },
  {
    "nome": "nado",
    "codigo": "N138"
  },
  {
    "nome": "nae",
    "codigo": "N139"
  },
  {
    "nome": "naeg",
    "codigo": "N141"
  },
  {
    "nome": "naek",
    "codigo": "N142"
  },
  {
    "nome": "nael",
    "codigo": "N143"
  },
  {
    "nome": "naer",
    "codigo": "N144"
  },
  {
    "nome": "naev",
    "codigo": "N145"
  },
  {
    "nome": "naf",
    "codigo": "N146"
  },
  {
    "nome": "nag",
    "codigo": "N147"
  },
  {
    "nome": "nagi",
    "codigo": "N148"
  },
  {
    "nome": "nagl",
    "codigo": "N149"
  },
  {
    "nome": "nagli",
    "codigo": "N151"
  },
  {
    "nome": "nago",
    "codigo": "N152"
  },
  {
    "nome": "nah",
    "codigo": "N153"
  },
  {
    "nome": "nahl",
    "codigo": "N154"
  },
  {
    "nome": "nai",
    "codigo": "N155"
  },
  {
    "nome": "nail",
    "codigo": "N156"
  },
  {
    "nome": "naim",
    "codigo": "N157"
  },
  {
    "nome": "nair",
    "codigo": "N158"
  },
  {
    "nome": "nait",
    "codigo": "N159"
  },
  {
    "nome": "naiv",
    "codigo": "N161"
  },
  {
    "nome": "naj",
    "codigo": "N162"
  },
  {
    "nome": "nak",
    "codigo": "N163"
  },
  {
    "nome": "nakw",
    "codigo": "N164"
  },
  {
    "nome": "nal",
    "codigo": "N165"
  },
  {
    "nome": "naldi",
    "codigo": "N166"
  },
  {
    "nome": "naldin",
    "codigo": "N167"
  },
  {
    "nome": "naldo",
    "codigo": "N168"
  },
  {
    "nome": "nale",
    "codigo": "N169"
  },
  {
    "nome": "nali",
    "codigo": "N171"
  },
  {
    "nome": "nall",
    "codigo": "N172"
  },
  {
    "nome": "nals",
    "codigo": "N173"
  },
  {
    "nome": "nam",
    "codigo": "N174"
  },
  {
    "nome": "nan",
    "codigo": "N175"
  },
  {
    "nome": "nanc",
    "codigo": "N176"
  },
  {
    "nome": "nane",
    "codigo": "N177"
  },
  {
    "nome": "nang",
    "codigo": "N178"
  },
  {
    "nome": "nani",
    "codigo": "N179"
  },
  {
    "nome": "nanin",
    "codigo": "N181"
  },
  {
    "nome": "nanini",
    "codigo": "N182"
  },
  {
    "nome": "nann",
    "codigo": "N183"
  },
  {
    "nome": "nanni",
    "codigo": "N184"
  },
  {
    "nome": "nanno",
    "codigo": "N185"
  },
  {
    "nome": "nannu",
    "codigo": "N186"
  },
  {
    "nome": "nanq",
    "codigo": "N187"
  },
  {
    "nome": "nans",
    "codigo": "N188"
  },
  {
    "nome": "nanso",
    "codigo": "N189"
  },
  {
    "nome": "nant",
    "codigo": "N191"
  },
  {
    "nome": "nanteu",
    "codigo": "N192"
  },
  {
    "nome": "nanti",
    "codigo": "N193"
  },
  {
    "nome": "nao",
    "codigo": "N194"
  },
  {
    "nome": "nap",
    "codigo": "N195"
  },
  {
    "nome": "napier",
    "codigo": "N196"
  },
  {
    "nome": "napier c",
    "codigo": "N197"
  },
  {
    "nome": "napier f",
    "codigo": "N198"
  },
  {
    "nome": "napier j",
    "codigo": "N199"
  },
  {
    "nome": "napier m",
    "codigo": "N211"
  },
  {
    "nome": "napier s",
    "codigo": "N212"
  },
  {
    "nome": "napier w",
    "codigo": "N213"
  },
  {
    "nome": "napio",
    "codigo": "N214"
  },
  {
    "nome": "napl",
    "codigo": "N215"
  },
  {
    "nome": "napo",
    "codigo": "N216"
  },
  {
    "nome": "napp",
    "codigo": "N217"
  },
  {
    "nome": "nar",
    "codigo": "N218"
  },
  {
    "nome": "narbo",
    "codigo": "N219"
  },
  {
    "nome": "narbor",
    "codigo": "N221"
  },
  {
    "nome": "narc",
    "codigo": "N222"
  },
  {
    "nome": "nard",
    "codigo": "N223"
  },
  {
    "nome": "nardin",
    "codigo": "N224"
  },
  {
    "nome": "nare",
    "codigo": "N225"
  },
  {
    "nome": "nares",
    "codigo": "N226"
  },
  {
    "nome": "nares m",
    "codigo": "N227"
  },
  {
    "nome": "narg",
    "codigo": "N228"
  },
  {
    "nome": "nari",
    "codigo": "N229"
  },
  {
    "nome": "narin",
    "codigo": "N231"
  },
  {
    "nome": "narn",
    "codigo": "N232"
  },
  {
    "nome": "narp",
    "codigo": "N233"
  },
  {
    "nome": "narr",
    "codigo": "N234"
  },
  {
    "nome": "nars",
    "codigo": "N235"
  },
  {
    "nome": "narst",
    "codigo": "N236"
  },
  {
    "nome": "naru",
    "codigo": "N237"
  },
  {
    "nome": "narv",
    "codigo": "N238"
  },
  {
    "nome": "narvy",
    "codigo": "N239"
  },
  {
    "nome": "nas",
    "codigo": "N241"
  },
  {
    "nome": "nasaf",
    "codigo": "N242"
  },
  {
    "nome": "nasal",
    "codigo": "N243"
  },
  {
    "nome": "nasc",
    "codigo": "N244"
  },
  {
    "nome": "nasco",
    "codigo": "N245"
  },
  {
    "nome": "nase",
    "codigo": "N246"
  },
  {
    "nome": "naser",
    "codigo": "N247"
  },
  {
    "nome": "nash",
    "codigo": "N248"
  },
  {
    "nome": "nash f",
    "codigo": "N249"
  },
  {
    "nome": "nash j",
    "codigo": "N251"
  },
  {
    "nome": "nash m",
    "codigo": "N252"
  },
  {
    "nome": "nash s",
    "codigo": "N253"
  },
  {
    "nome": "nasi",
    "codigo": "N254"
  },
  {
    "nome": "nasm",
    "codigo": "N255"
  },
  {
    "nome": "nasmith",
    "codigo": "N256"
  },
  {
    "nome": "nasmith m",
    "codigo": "N257"
  },
  {
    "nome": "nasmyth",
    "codigo": "N258"
  },
  {
    "nome": "nasmyth m",
    "codigo": "N259"
  },
  {
    "nome": "naso",
    "codigo": "N261"
  },
  {
    "nome": "nasol",
    "codigo": "N262"
  },
  {
    "nome": "nason",
    "codigo": "N263"
  },
  {
    "nome": "nasr",
    "codigo": "N264"
  },
  {
    "nome": "nass",
    "codigo": "N265"
  },
  {
    "nome": "nassau",
    "codigo": "N266"
  },
  {
    "nome": "nasse",
    "codigo": "N267"
  },
  {
    "nome": "nassi",
    "codigo": "N268"
  },
  {
    "nome": "nast",
    "codigo": "N269"
  },
  {
    "nome": "nat",
    "codigo": "N271"
  },
  {
    "nome": "natali",
    "codigo": "N272"
  },
  {
    "nome": "natar",
    "codigo": "N273"
  },
  {
    "nome": "nath",
    "codigo": "N274"
  },
  {
    "nome": "nathans",
    "codigo": "N275"
  },
  {
    "nome": "nathu",
    "codigo": "N276"
  },
  {
    "nome": "nati",
    "codigo": "N277"
  },
  {
    "nome": "nativ",
    "codigo": "N278"
  },
  {
    "nome": "nato",
    "codigo": "N279"
  },
  {
    "nome": "natt",
    "codigo": "N281"
  },
  {
    "nome": "natte",
    "codigo": "N282"
  },
  {
    "nome": "natti",
    "codigo": "N283"
  },
  {
    "nome": "natto",
    "codigo": "N284"
  },
  {
    "nome": "natu",
    "codigo": "N285"
  },
  {
    "nome": "natz",
    "codigo": "N286"
  },
  {
    "nome": "nau",
    "codigo": "N287"
  },
  {
    "nome": "naub",
    "codigo": "N288"
  },
  {
    "nome": "nauc",
    "codigo": "N289"
  },
  {
    "nome": "naud",
    "codigo": "N291"
  },
  {
    "nome": "naudet",
    "codigo": "N292"
  },
  {
    "nome": "naudi",
    "codigo": "N293"
  },
  {
    "nome": "naudo",
    "codigo": "N294"
  },
  {
    "nome": "naue",
    "codigo": "N295"
  },
  {
    "nome": "nauer",
    "codigo": "N296"
  },
  {
    "nome": "naug",
    "codigo": "N297"
  },
  {
    "nome": "naul",
    "codigo": "N298"
  },
  {
    "nome": "naum",
    "codigo": "N299"
  },
  {
    "nome": "naumann m",
    "codigo": "N311"
  },
  {
    "nome": "naun",
    "codigo": "N312"
  },
  {
    "nome": "naus",
    "codigo": "N313"
  },
  {
    "nome": "nauss",
    "codigo": "N314"
  },
  {
    "nome": "nauz",
    "codigo": "N315"
  },
  {
    "nome": "nav",
    "codigo": "N316"
  },
  {
    "nome": "navag",
    "codigo": "N317"
  },
  {
    "nome": "navai",
    "codigo": "N318"
  },
  {
    "nome": "navar",
    "codigo": "N319"
  },
  {
    "nome": "navarr",
    "codigo": "N321"
  },
  {
    "nome": "navarro",
    "codigo": "N322"
  },
  {
    "nome": "nave",
    "codigo": "N323"
  },
  {
    "nome": "navez",
    "codigo": "N324"
  },
  {
    "nome": "navi",
    "codigo": "N325"
  },
  {
    "nome": "navil",
    "codigo": "N326"
  },
  {
    "nome": "navo",
    "codigo": "N327"
  },
  {
    "nome": "naw",
    "codigo": "N328"
  },
  {
    "nome": "nawr",
    "codigo": "N329"
  },
  {
    "nome": "nay",
    "codigo": "N331"
  },
  {
    "nome": "nayli",
    "codigo": "N332"
  },
  {
    "nome": "naylo",
    "codigo": "N333"
  },
  {
    "nome": "naz",
    "codigo": "N334"
  },
  {
    "nome": "nazar",
    "codigo": "N335"
  },
  {
    "nome": "nazo",
    "codigo": "N336"
  },
  {
    "nome": "nazz",
    "codigo": "N337"
  },
  {
    "nome": "ne",
    "codigo": "N338"
  },
  {
    "nome": "neal f",
    "codigo": "N339"
  },
  {
    "nome": "neal j",
    "codigo": "N341"
  },
  {
    "nome": "neal m",
    "codigo": "N342"
  },
  {
    "nome": "neal s",
    "codigo": "N343"
  },
  {
    "nome": "neal w",
    "codigo": "N344"
  },
  {
    "nome": "neale",
    "codigo": "N345"
  },
  {
    "nome": "neale g",
    "codigo": "N346"
  },
  {
    "nome": "neale m",
    "codigo": "N347"
  },
  {
    "nome": "neale s",
    "codigo": "N348"
  },
  {
    "nome": "neander",
    "codigo": "N349"
  },
  {
    "nome": "neander j",
    "codigo": "N351"
  },
  {
    "nome": "neander p",
    "codigo": "N352"
  },
  {
    "nome": "neap",
    "codigo": "N353"
  },
  {
    "nome": "near",
    "codigo": "N354"
  },
  {
    "nome": "neat",
    "codigo": "N355"
  },
  {
    "nome": "neate",
    "codigo": "N356"
  },
  {
    "nome": "neav",
    "codigo": "N357"
  },
  {
    "nome": "neb",
    "codigo": "N358"
  },
  {
    "nome": "nebe",
    "codigo": "N359"
  },
  {
    "nome": "neben",
    "codigo": "N361"
  },
  {
    "nome": "nebr",
    "codigo": "N362"
  },
  {
    "nome": "nebu",
    "codigo": "N363"
  },
  {
    "nome": "nec",
    "codigo": "N364"
  },
  {
    "nome": "neck",
    "codigo": "N365"
  },
  {
    "nome": "necker",
    "codigo": "N366"
  },
  {
    "nome": "necker m",
    "codigo": "N367"
  },
  {
    "nome": "neco",
    "codigo": "N368"
  },
  {
    "nome": "nect",
    "codigo": "N369"
  },
  {
    "nome": "ned",
    "codigo": "N371"
  },
  {
    "nome": "nee",
    "codigo": "N372"
  },
  {
    "nome": "neeb",
    "codigo": "N373"
  },
  {
    "nome": "need",
    "codigo": "N374"
  },
  {
    "nome": "needham m",
    "codigo": "N375"
  },
  {
    "nome": "neef",
    "codigo": "N376"
  },
  {
    "nome": "neefe",
    "codigo": "N377"
  },
  {
    "nome": "neel",
    "codigo": "N378"
  },
  {
    "nome": "neele",
    "codigo": "N379"
  },
  {
    "nome": "neer",
    "codigo": "N381"
  },
  {
    "nome": "nees",
    "codigo": "N382"
  },
  {
    "nome": "nef",
    "codigo": "N383"
  },
  {
    "nome": "neg",
    "codigo": "N384"
  },
  {
    "nome": "negr",
    "codigo": "N385"
  },
  {
    "nome": "negri",
    "codigo": "N386"
  },
  {
    "nome": "negri g",
    "codigo": "N387"
  },
  {
    "nome": "negri m",
    "codigo": "N388"
  },
  {
    "nome": "negri s",
    "codigo": "N389"
  },
  {
    "nome": "negri w",
    "codigo": "N391"
  },
  {
    "nome": "negrier",
    "codigo": "N392"
  },
  {
    "nome": "negro",
    "codigo": "N393"
  },
  {
    "nome": "negron",
    "codigo": "N394"
  },
  {
    "nome": "neh",
    "codigo": "N395"
  },
  {
    "nome": "nehr",
    "codigo": "N396"
  },
  {
    "nome": "nei",
    "codigo": "N397"
  },
  {
    "nome": "neil",
    "codigo": "N398"
  },
  {
    "nome": "neile",
    "codigo": "N399"
  },
  {
    "nome": "neill",
    "codigo": "N411"
  },
  {
    "nome": "neill j",
    "codigo": "N412"
  },
  {
    "nome": "neill p",
    "codigo": "N413"
  },
  {
    "nome": "neils",
    "codigo": "N414"
  },
  {
    "nome": "neip",
    "codigo": "N415"
  },
  {
    "nome": "neis",
    "codigo": "N416"
  },
  {
    "nome": "neit",
    "codigo": "N417"
  },
  {
    "nome": "nek",
    "codigo": "N418"
  },
  {
    "nome": "nel",
    "codigo": "N419"
  },
  {
    "nome": "nell",
    "codigo": "N421"
  },
  {
    "nome": "nelli",
    "codigo": "N422"
  },
  {
    "nome": "nello",
    "codigo": "N423"
  },
  {
    "nome": "nels",
    "codigo": "N424"
  },
  {
    "nome": "nelson c",
    "codigo": "N425"
  },
  {
    "nome": "nelson f",
    "codigo": "N426"
  },
  {
    "nome": "nelson j",
    "codigo": "N427"
  },
  {
    "nome": "nelson m",
    "codigo": "N428"
  },
  {
    "nome": "nelson r",
    "codigo": "N429"
  },
  {
    "nome": "nelson s",
    "codigo": "N431"
  },
  {
    "nome": "nelson w",
    "codigo": "N432"
  },
  {
    "nome": "nem",
    "codigo": "N433"
  },
  {
    "nome": "nemi",
    "codigo": "N434"
  },
  {
    "nome": "nemn",
    "codigo": "N435"
  },
  {
    "nome": "nemo",
    "codigo": "N436"
  },
  {
    "nome": "nen",
    "codigo": "N437"
  },
  {
    "nome": "neo",
    "codigo": "N438"
  },
  {
    "nome": "nep",
    "codigo": "N439"
  },
  {
    "nome": "nepo",
    "codigo": "N441"
  },
  {
    "nome": "nepos",
    "codigo": "N442"
  },
  {
    "nome": "ner",
    "codigo": "N443"
  },
  {
    "nome": "nere",
    "codigo": "N444"
  },
  {
    "nome": "neri",
    "codigo": "N445"
  },
  {
    "nome": "nerin",
    "codigo": "N446"
  },
  {
    "nome": "nerit",
    "codigo": "N447"
  },
  {
    "nome": "nerl",
    "codigo": "N448"
  },
  {
    "nome": "nero",
    "codigo": "N449"
  },
  {
    "nome": "neroc",
    "codigo": "N451"
  },
  {
    "nome": "neron",
    "codigo": "N452"
  },
  {
    "nome": "ners",
    "codigo": "N453"
  },
  {
    "nome": "neru",
    "codigo": "N454"
  },
  {
    "nome": "nerv",
    "codigo": "N455"
  },
  {
    "nome": "nervet",
    "codigo": "N456"
  },
  {
    "nome": "nes",
    "codigo": "N457"
  },
  {
    "nome": "nesb",
    "codigo": "N458"
  },
  {
    "nome": "nese",
    "codigo": "N459"
  },
  {
    "nome": "nesl",
    "codigo": "N461"
  },
  {
    "nome": "nesm",
    "codigo": "N462"
  },
  {
    "nome": "ness",
    "codigo": "N463"
  },
  {
    "nome": "nessel",
    "codigo": "N464"
  },
  {
    "nome": "nessi",
    "codigo": "N465"
  },
  {
    "nome": "nessm",
    "codigo": "N466"
  },
  {
    "nome": "nesso",
    "codigo": "N467"
  },
  {
    "nome": "nest",
    "codigo": "N468"
  },
  {
    "nome": "net",
    "codigo": "N469"
  },
  {
    "nome": "nets",
    "codigo": "N471"
  },
  {
    "nome": "nett",
    "codigo": "N472"
  },
  {
    "nome": "nette",
    "codigo": "N473"
  },
  {
    "nome": "netter",
    "codigo": "N474"
  },
  {
    "nome": "nettl",
    "codigo": "N475"
  },
  {
    "nome": "nettleton m",
    "codigo": "N476"
  },
  {
    "nome": "neu",
    "codigo": "N477"
  },
  {
    "nome": "neube",
    "codigo": "N478"
  },
  {
    "nome": "neud",
    "codigo": "N479"
  },
  {
    "nome": "neue",
    "codigo": "N481"
  },
  {
    "nome": "neuf",
    "codigo": "N482"
  },
  {
    "nome": "neufv",
    "codigo": "N483"
  },
  {
    "nome": "neug",
    "codigo": "N484"
  },
  {
    "nome": "neuh",
    "codigo": "N485"
  },
  {
    "nome": "neuk",
    "codigo": "N486"
  },
  {
    "nome": "neul",
    "codigo": "N487"
  },
  {
    "nome": "neum",
    "codigo": "N488"
  },
  {
    "nome": "neuman",
    "codigo": "N489"
  },
  {
    "nome": "neuman g",
    "codigo": "N491"
  },
  {
    "nome": "neuman m",
    "codigo": "N492"
  },
  {
    "nome": "neumar",
    "codigo": "N493"
  },
  {
    "nome": "neun",
    "codigo": "N494"
  },
  {
    "nome": "neus",
    "codigo": "N495"
  },
  {
    "nome": "neusi",
    "codigo": "N496"
  },
  {
    "nome": "neut",
    "codigo": "N497"
  },
  {
    "nome": "neuv",
    "codigo": "N498"
  },
  {
    "nome": "nev",
    "codigo": "N499"
  },
  {
    "nome": "neve",
    "codigo": "N511"
  },
  {
    "nome": "nevel",
    "codigo": "N512"
  },
  {
    "nome": "never",
    "codigo": "N513"
  },
  {
    "nome": "nevers",
    "codigo": "N514"
  },
  {
    "nome": "nevers g",
    "codigo": "N515"
  },
  {
    "nome": "nevers m",
    "codigo": "N516"
  },
  {
    "nome": "nevers s",
    "codigo": "N517"
  },
  {
    "nome": "nevers w",
    "codigo": "N518"
  },
  {
    "nome": "neveu",
    "codigo": "N519"
  },
  {
    "nome": "nevi",
    "codigo": "N521"
  },
  {
    "nome": "nevill",
    "codigo": "N522"
  },
  {
    "nome": "neville",
    "codigo": "N523"
  },
  {
    "nome": "neville j",
    "codigo": "N524"
  },
  {
    "nome": "neville p",
    "codigo": "N525"
  },
  {
    "nome": "nevin",
    "codigo": "N526"
  },
  {
    "nome": "nevins",
    "codigo": "N527"
  },
  {
    "nome": "nevins m",
    "codigo": "N528"
  },
  {
    "nome": "nevit",
    "codigo": "N529"
  },
  {
    "nome": "nevy",
    "codigo": "N531"
  },
  {
    "nome": "new",
    "codigo": "N532"
  },
  {
    "nome": "newb",
    "codigo": "N533"
  },
  {
    "nome": "newbe",
    "codigo": "N534"
  },
  {
    "nome": "newbu",
    "codigo": "N535"
  },
  {
    "nome": "newc",
    "codigo": "N536"
  },
  {
    "nome": "newco",
    "codigo": "N537"
  },
  {
    "nome": "newcomb m",
    "codigo": "N538"
  },
  {
    "nome": "newcombe",
    "codigo": "N539"
  },
  {
    "nome": "newcome",
    "codigo": "N541"
  },
  {
    "nome": "newd",
    "codigo": "N542"
  },
  {
    "nome": "newe",
    "codigo": "N543"
  },
  {
    "nome": "newell",
    "codigo": "N544"
  },
  {
    "nome": "strat",
    "codigo": "S898"
  },
  {
    "nome": "strath",
    "codigo": "S899"
  },
  {
    "nome": "stratt",
    "codigo": "S911"
  },
  {
    "nome": "strau",
    "codigo": "S912"
  },
  {
    "nome": "straw",
    "codigo": "S913"
  },
  {
    "nome": "stre",
    "codigo": "S914"
  },
  {
    "nome": "street",
    "codigo": "S915"
  },
  {
    "nome": "stri",
    "codigo": "S916"
  },
  {
    "nome": "strickl",
    "codigo": "S917"
  },
  {
    "nome": "strin",
    "codigo": "S918"
  },
  {
    "nome": "stro",
    "codigo": "S919"
  },
  {
    "nome": "strog",
    "codigo": "S921"
  },
  {
    "nome": "stron",
    "codigo": "S922"
  },
  {
    "nome": "strong",
    "codigo": "S923"
  },
  {
    "nome": "strong p",
    "codigo": "S924"
  },
  {
    "nome": "strot",
    "codigo": "S925"
  },
  {
    "nome": "stroz",
    "codigo": "S926"
  },
  {
    "nome": "stru",
    "codigo": "S927"
  },
  {
    "nome": "stry",
    "codigo": "S928"
  },
  {
    "nome": "stu",
    "codigo": "S929"
  },
  {
    "nome": "stuart j",
    "codigo": "S931"
  },
  {
    "nome": "stuart m",
    "codigo": "S932"
  },
  {
    "nome": "stud",
    "codigo": "S933"
  },
  {
    "nome": "stuk",
    "codigo": "S934"
  },
  {
    "nome": "stur",
    "codigo": "S935"
  },
  {
    "nome": "sturm",
    "codigo": "S936"
  },
  {
    "nome": "stut",
    "codigo": "S937"
  },
  {
    "nome": "stuy",
    "codigo": "S938"
  },
  {
    "nome": "sua",
    "codigo": "S939"
  },
  {
    "nome": "sub",
    "codigo": "S941"
  },
  {
    "nome": "suc",
    "codigo": "S942"
  },
  {
    "nome": "sud",
    "codigo": "S943"
  },
  {
    "nome": "sue",
    "codigo": "S944"
  },
  {
    "nome": "suev",
    "codigo": "S945"
  },
  {
    "nome": "suf",
    "codigo": "S946"
  },
  {
    "nome": "sug",
    "codigo": "S947"
  },
  {
    "nome": "sui",
    "codigo": "S948"
  },
  {
    "nome": "sul",
    "codigo": "S949"
  },
  {
    "nome": "sullivan m",
    "codigo": "S951"
  },
  {
    "nome": "sullivan s",
    "codigo": "S952"
  },
  {
    "nome": "sully",
    "codigo": "S953"
  },
  {
    "nome": "sulp",
    "codigo": "S954"
  },
  {
    "nome": "sum",
    "codigo": "S955"
  },
  {
    "nome": "sumn",
    "codigo": "S956"
  },
  {
    "nome": "sun",
    "codigo": "S957"
  },
  {
    "nome": "sunderl",
    "codigo": "S958"
  },
  {
    "nome": "sup",
    "codigo": "S959"
  },
  {
    "nome": "sur",
    "codigo": "S961"
  },
  {
    "nome": "surr",
    "codigo": "S962"
  },
  {
    "nome": "surv",
    "codigo": "S963"
  },
  {
    "nome": "sus",
    "codigo": "S964"
  },
  {
    "nome": "sut",
    "codigo": "S965"
  },
  {
    "nome": "suth",
    "codigo": "S966"
  },
  {
    "nome": "sutt",
    "codigo": "S967"
  },
  {
    "nome": "suz",
    "codigo": "S968"
  },
  {
    "nome": "svi",
    "codigo": "S969"
  },
  {
    "nome": "swa",
    "codigo": "S971"
  },
  {
    "nome": "swan",
    "codigo": "S972"
  },
  {
    "nome": "swar",
    "codigo": "S973"
  },
  {
    "nome": "swe",
    "codigo": "S974"
  },
  {
    "nome": "swet",
    "codigo": "S975"
  },
  {
    "nome": "swi",
    "codigo": "S976"
  },
  {
    "nome": "swift",
    "codigo": "S977"
  },
  {
    "nome": "swin",
    "codigo": "S978"
  },
  {
    "nome": "swint",
    "codigo": "S979"
  },
  {
    "nome": "sya",
    "codigo": "S981"
  },
  {
    "nome": "syd",
    "codigo": "S982"
  },
  {
    "nome": "syk",
    "codigo": "S983"
  },
  {
    "nome": "syl",
    "codigo": "S984"
  },
  {
    "nome": "sylv",
    "codigo": "S985"
  },
  {
    "nome": "sym",
    "codigo": "S986"
  },
  {
    "nome": "symm",
    "codigo": "S987"
  },
  {
    "nome": "symo",
    "codigo": "S988"
  },
  {
    "nome": "symp",
    "codigo": "S989"
  },
  {
    "nome": "syms",
    "codigo": "S991"
  },
  {
    "nome": "syn",
    "codigo": "S992"
  },
  {
    "nome": "syng",
    "codigo": "S993"
  },
  {
    "nome": "syp",
    "codigo": "S994"
  },
  {
    "nome": "syr",
    "codigo": "S995"
  },
  {
    "nome": "sza",
    "codigo": "S996"
  },
  {
    "nome": "sze",
    "codigo": "S997"
  },
  {
    "nome": "szi",
    "codigo": "S998"
  },
  {
    "nome": "szy",
    "codigo": "S999"
  },
  {
    "nome": "t",
    "codigo": "T111"
  },
  {
    "nome": "ta",
    "codigo": "T111"
  },
  {
    "nome": "tab",
    "codigo": "T112"
  },
  {
    "nome": "tabe",
    "codigo": "T113"
  },
  {
    "nome": "tabo",
    "codigo": "T114"
  },
  {
    "nome": "tac",
    "codigo": "T115"
  },
  {
    "nome": "tacf",
    "codigo": "T116"
  },
  {
    "nome": "tach",
    "codigo": "T117"
  },
  {
    "nome": "taci",
    "codigo": "T118"
  },
  {
    "nome": "taco",
    "codigo": "T119"
  },
  {
    "nome": "tad",
    "codigo": "T121"
  },
  {
    "nome": "tado",
    "codigo": "T122"
  },
  {
    "nome": "tae",
    "codigo": "T123"
  },
  {
    "nome": "taf",
    "codigo": "T124"
  },
  {
    "nome": "tag",
    "codigo": "T125"
  },
  {
    "nome": "tagl",
    "codigo": "T126"
  },
  {
    "nome": "taglias",
    "codigo": "T127"
  },
  {
    "nome": "taglio",
    "codigo": "T128"
  },
  {
    "nome": "tai",
    "codigo": "T129"
  },
  {
    "nome": "tail",
    "codigo": "T131"
  },
  {
    "nome": "taille",
    "codigo": "T132"
  },
  {
    "nome": "tailli",
    "codigo": "T133"
  },
  {
    "nome": "tain",
    "codigo": "T134"
  },
  {
    "nome": "tais",
    "codigo": "T135"
  },
  {
    "nome": "tak",
    "codigo": "T136"
  },
  {
    "nome": "tal",
    "codigo": "T137"
  },
  {
    "nome": "talbot",
    "codigo": "T138"
  },
  {
    "nome": "talbot g",
    "codigo": "T139"
  },
  {
    "nome": "talbot m",
    "codigo": "T141"
  },
  {
    "nome": "talbot s",
    "codigo": "T142"
  },
  {
    "nome": "tale",
    "codigo": "T143"
  },
  {
    "nome": "talf",
    "codigo": "T144"
  },
  {
    "nome": "talh",
    "codigo": "T145"
  },
  {
    "nome": "tali",
    "codigo": "T146"
  },
  {
    "nome": "tall",
    "codigo": "T147"
  },
  {
    "nome": "talley",
    "codigo": "T148"
  },
  {
    "nome": "talli",
    "codigo": "T149"
  },
  {
    "nome": "talm",
    "codigo": "T151"
  },
  {
    "nome": "talo",
    "codigo": "T152"
  },
  {
    "nome": "tam",
    "codigo": "T153"
  },
  {
    "nome": "tamb",
    "codigo": "T154"
  },
  {
    "nome": "tambe",
    "codigo": "T155"
  },
  {
    "nome": "tambou",
    "codigo": "T156"
  },
  {
    "nome": "tame",
    "codigo": "T157"
  },
  {
    "nome": "tami",
    "codigo": "T158"
  },
  {
    "nome": "tamp",
    "codigo": "T159"
  },
  {
    "nome": "tan",
    "codigo": "T161"
  },
  {
    "nome": "tanc",
    "codigo": "T162"
  },
  {
    "nome": "tand",
    "codigo": "T163"
  },
  {
    "nome": "tane",
    "codigo": "T164"
  },
  {
    "nome": "tank",
    "codigo": "T165"
  },
  {
    "nome": "tann",
    "codigo": "T166"
  },
  {
    "nome": "tanner m",
    "codigo": "T167"
  },
  {
    "nome": "tans",
    "codigo": "T168"
  },
  {
    "nome": "tant",
    "codigo": "T169"
  },
  {
    "nome": "tanz",
    "codigo": "T171"
  },
  {
    "nome": "tap",
    "codigo": "T172"
  },
  {
    "nome": "tapl",
    "codigo": "T173"
  },
  {
    "nome": "tapp",
    "codigo": "T174"
  },
  {
    "nome": "tappan m",
    "codigo": "T175"
  },
  {
    "nome": "tar",
    "codigo": "T176"
  },
  {
    "nome": "taras",
    "codigo": "T177"
  },
  {
    "nome": "tarau",
    "codigo": "T178"
  },
  {
    "nome": "tarb",
    "codigo": "T179"
  },
  {
    "nome": "tard",
    "codigo": "T181"
  },
  {
    "nome": "tardieu",
    "codigo": "T182"
  },
  {
    "nome": "tardif",
    "codigo": "T183"
  },
  {
    "nome": "tare",
    "codigo": "T184"
  },
  {
    "nome": "targ",
    "codigo": "T185"
  },
  {
    "nome": "tari",
    "codigo": "T186"
  },
  {
    "nome": "tarin",
    "codigo": "T187"
  },
  {
    "nome": "tarl",
    "codigo": "T188"
  },
  {
    "nome": "tarn",
    "codigo": "T189"
  },
  {
    "nome": "taro",
    "codigo": "T191"
  },
  {
    "nome": "tarr",
    "codigo": "T192"
  },
  {
    "nome": "tars",
    "codigo": "T193"
  },
  {
    "nome": "tartar",
    "codigo": "T194"
  },
  {
    "nome": "tarti",
    "codigo": "T195"
  },
  {
    "nome": "taru",
    "codigo": "T196"
  },
  {
    "nome": "tas",
    "codigo": "T197"
  },
  {
    "nome": "task",
    "codigo": "T198"
  },
  {
    "nome": "tasm",
    "codigo": "T199"
  },
  {
    "nome": "tass",
    "codigo": "T211"
  },
  {
    "nome": "tasse",
    "codigo": "T212"
  },
  {
    "nome": "tassi",
    "codigo": "T213"
  },
  {
    "nome": "tasso",
    "codigo": "T214"
  },
  {
    "nome": "tasson",
    "codigo": "T215"
  },
  {
    "nome": "tat",
    "codigo": "T216"
  },
  {
    "nome": "tate m",
    "codigo": "T217"
  },
  {
    "nome": "tath",
    "codigo": "T218"
  },
  {
    "nome": "tati",
    "codigo": "T219"
  },
  {
    "nome": "tatt",
    "codigo": "T221"
  },
  {
    "nome": "tau",
    "codigo": "T222"
  },
  {
    "nome": "taubn",
    "codigo": "T223"
  },
  {
    "nome": "tauc",
    "codigo": "T224"
  },
  {
    "nome": "taul",
    "codigo": "T225"
  },
  {
    "nome": "taun",
    "codigo": "T226"
  },
  {
    "nome": "taup",
    "codigo": "T227"
  },
  {
    "nome": "taus",
    "codigo": "T228"
  },
  {
    "nome": "taut",
    "codigo": "T229"
  },
  {
    "nome": "tav",
    "codigo": "T231"
  },
  {
    "nome": "tave",
    "codigo": "T232"
  },
  {
    "nome": "taver",
    "codigo": "T233"
  },
  {
    "nome": "taverni",
    "codigo": "T234"
  },
  {
    "nome": "tax",
    "codigo": "T235"
  },
  {
    "nome": "tay",
    "codigo": "T236"
  },
  {
    "nome": "tayler",
    "codigo": "T237"
  },
  {
    "nome": "taylor",
    "codigo": "T238"
  },
  {
    "nome": "taylor c",
    "codigo": "T239"
  },
  {
    "nome": "taylor f",
    "codigo": "T241"
  },
  {
    "nome": "taylor h",
    "codigo": "T242"
  },
  {
    "nome": "taylor j",
    "codigo": "T243"
  },
  {
    "nome": "taylor m",
    "codigo": "T244"
  },
  {
    "nome": "taylor p",
    "codigo": "T245"
  },
  {
    "nome": "taylor s",
    "codigo": "T246"
  },
  {
    "nome": "taylor w",
    "codigo": "T247"
  },
  {
    "nome": "taz",
    "codigo": "T248"
  },
  {
    "nome": "tc",
    "codigo": "T249"
  },
  {
    "nome": "tche",
    "codigo": "T251"
  },
  {
    "nome": "tcho",
    "codigo": "T252"
  },
  {
    "nome": "te",
    "codigo": "T253"
  },
  {
    "nome": "teb",
    "codigo": "T254"
  },
  {
    "nome": "tec",
    "codigo": "T255"
  },
  {
    "nome": "ted",
    "codigo": "T256"
  },
  {
    "nome": "tedm",
    "codigo": "T257"
  },
  {
    "nome": "tee",
    "codigo": "T258"
  },
  {
    "nome": "tef",
    "codigo": "T259"
  },
  {
    "nome": "teg",
    "codigo": "T261"
  },
  {
    "nome": "tei",
    "codigo": "T262"
  },
  {
    "nome": "teif",
    "codigo": "T263"
  },
  {
    "nome": "teil",
    "codigo": "T264"
  },
  {
    "nome": "teis",
    "codigo": "T265"
  },
  {
    "nome": "teix",
    "codigo": "T266"
  },
  {
    "nome": "tel",
    "codigo": "T267"
  },
  {
    "nome": "telem",
    "codigo": "T268"
  },
  {
    "nome": "teles",
    "codigo": "T269"
  },
  {
    "nome": "telf",
    "codigo": "T271"
  },
  {
    "nome": "teli",
    "codigo": "T272"
  },
  {
    "nome": "tell",
    "codigo": "T273"
  },
  {
    "nome": "teller",
    "codigo": "T274"
  },
  {
    "nome": "tellez",
    "codigo": "T275"
  },
  {
    "nome": "telli",
    "codigo": "T276"
  },
  {
    "nome": "tello",
    "codigo": "T277"
  },
  {
    "nome": "tem",
    "codigo": "T278"
  },
  {
    "nome": "teme",
    "codigo": "T279"
  },
  {
    "nome": "temm",
    "codigo": "T281"
  },
  {
    "nome": "temp",
    "codigo": "T282"
  },
  {
    "nome": "tempest m",
    "codigo": "T283"
  },
  {
    "nome": "templ",
    "codigo": "T284"
  },
  {
    "nome": "temple g",
    "codigo": "T285"
  },
  {
    "nome": "temple m",
    "codigo": "T286"
  },
  {
    "nome": "piu",
    "codigo": "P693"
  },
  {
    "nome": "pix",
    "codigo": "P694"
  },
  {
    "nome": "piz",
    "codigo": "P695"
  },
  {
    "nome": "pl",
    "codigo": "P696"
  },
  {
    "nome": "plac",
    "codigo": "P697"
  },
  {
    "nome": "placi",
    "codigo": "P698"
  },
  {
    "nome": "plan",
    "codigo": "P699"
  },
  {
    "nome": "planchet",
    "codigo": "P711"
  },
  {
    "nome": "plane",
    "codigo": "P712"
  },
  {
    "nome": "plant",
    "codigo": "P713"
  },
  {
    "nome": "planti",
    "codigo": "P714"
  },
  {
    "nome": "plas",
    "codigo": "P715"
  },
  {
    "nome": "plat",
    "codigo": "P716"
  },
  {
    "nome": "platn",
    "codigo": "P717"
  },
  {
    "nome": "plato",
    "codigo": "P718"
  },
  {
    "nome": "platt",
    "codigo": "P719"
  },
  {
    "nome": "plau",
    "codigo": "P721"
  },
  {
    "nome": "play",
    "codigo": "P722"
  },
  {
    "nome": "playfo",
    "codigo": "P723"
  },
  {
    "nome": "ple",
    "codigo": "P724"
  },
  {
    "nome": "plen",
    "codigo": "P725"
  },
  {
    "nome": "ples",
    "codigo": "P726"
  },
  {
    "nome": "pley",
    "codigo": "P727"
  },
  {
    "nome": "pli",
    "codigo": "P728"
  },
  {
    "nome": "plo",
    "codigo": "P729"
  },
  {
    "nome": "plou",
    "codigo": "P731"
  },
  {
    "nome": "plow",
    "codigo": "P732"
  },
  {
    "nome": "plu",
    "codigo": "P733"
  },
  {
    "nome": "plum",
    "codigo": "P734"
  },
  {
    "nome": "plumm",
    "codigo": "P735"
  },
  {
    "nome": "plump",
    "codigo": "P736"
  },
  {
    "nome": "plun",
    "codigo": "P737"
  },
  {
    "nome": "pluy",
    "codigo": "P738"
  },
  {
    "nome": "po",
    "codigo": "P739"
  },
  {
    "nome": "poco",
    "codigo": "P741"
  },
  {
    "nome": "pod",
    "codigo": "P742"
  },
  {
    "nome": "poe",
    "codigo": "P743"
  },
  {
    "nome": "poel",
    "codigo": "P744"
  },
  {
    "nome": "poer",
    "codigo": "P745"
  },
  {
    "nome": "pog",
    "codigo": "P746"
  },
  {
    "nome": "poh",
    "codigo": "P747"
  },
  {
    "nome": "pohl",
    "codigo": "P748"
  },
  {
    "nome": "poi",
    "codigo": "P749"
  },
  {
    "nome": "poin",
    "codigo": "P751"
  },
  {
    "nome": "poins",
    "codigo": "P752"
  },
  {
    "nome": "poir",
    "codigo": "P753"
  },
  {
    "nome": "pois",
    "codigo": "P754"
  },
  {
    "nome": "poisso",
    "codigo": "P755"
  },
  {
    "nome": "poit",
    "codigo": "P756"
  },
  {
    "nome": "poiti",
    "codigo": "P757"
  },
  {
    "nome": "poix",
    "codigo": "P758"
  },
  {
    "nome": "poj",
    "codigo": "P759"
  },
  {
    "nome": "pok",
    "codigo": "P761"
  },
  {
    "nome": "pol",
    "codigo": "P762"
  },
  {
    "nome": "pole",
    "codigo": "P763"
  },
  {
    "nome": "polem",
    "codigo": "P764"
  },
  {
    "nome": "polen",
    "codigo": "P765"
  },
  {
    "nome": "poli",
    "codigo": "P766"
  },
  {
    "nome": "polier",
    "codigo": "P767"
  },
  {
    "nome": "polig",
    "codigo": "P768"
  },
  {
    "nome": "polit",
    "codigo": "P769"
  },
  {
    "nome": "poll",
    "codigo": "P771"
  },
  {
    "nome": "pollard m",
    "codigo": "P772"
  },
  {
    "nome": "polle",
    "codigo": "P773"
  },
  {
    "nome": "polli",
    "codigo": "P774"
  },
  {
    "nome": "pollio",
    "codigo": "P775"
  },
  {
    "nome": "pollo",
    "codigo": "P776"
  },
  {
    "nome": "pollock m",
    "codigo": "P777"
  },
  {
    "nome": "polo",
    "codigo": "P778"
  },
  {
    "nome": "polt",
    "codigo": "P779"
  },
  {
    "nome": "poly",
    "codigo": "P781"
  },
  {
    "nome": "polyc",
    "codigo": "P782"
  },
  {
    "nome": "polym",
    "codigo": "P783"
  },
  {
    "nome": "pom",
    "codigo": "P784"
  },
  {
    "nome": "pome",
    "codigo": "P785"
  },
  {
    "nome": "pomf",
    "codigo": "P786"
  },
  {
    "nome": "pomm",
    "codigo": "P787"
  },
  {
    "nome": "pomp",
    "codigo": "P788"
  },
  {
    "nome": "pompi",
    "codigo": "P789"
  },
  {
    "nome": "pompo",
    "codigo": "P791"
  },
  {
    "nome": "pon",
    "codigo": "P792"
  },
  {
    "nome": "poncel",
    "codigo": "P793"
  },
  {
    "nome": "poncet",
    "codigo": "P794"
  },
  {
    "nome": "ponch",
    "codigo": "P795"
  },
  {
    "nome": "pond",
    "codigo": "P796"
  },
  {
    "nome": "poni",
    "codigo": "P797"
  },
  {
    "nome": "pons",
    "codigo": "P798"
  },
  {
    "nome": "ponso",
    "codigo": "P799"
  },
  {
    "nome": "pont",
    "codigo": "P811"
  },
  {
    "nome": "pontb",
    "codigo": "P812"
  },
  {
    "nome": "ponte",
    "codigo": "P813"
  },
  {
    "nome": "pontec",
    "codigo": "P814"
  },
  {
    "nome": "pontev",
    "codigo": "P815"
  },
  {
    "nome": "ponti",
    "codigo": "P816"
  },
  {
    "nome": "pontm",
    "codigo": "P817"
  },
  {
    "nome": "ponto",
    "codigo": "P818"
  },
  {
    "nome": "ponz",
    "codigo": "P819"
  },
  {
    "nome": "poo",
    "codigo": "P821"
  },
  {
    "nome": "poole",
    "codigo": "P822"
  },
  {
    "nome": "poor",
    "codigo": "P823"
  },
  {
    "nome": "poort",
    "codigo": "P824"
  },
  {
    "nome": "pop",
    "codigo": "P825"
  },
  {
    "nome": "pope m",
    "codigo": "P826"
  },
  {
    "nome": "poph",
    "codigo": "P827"
  },
  {
    "nome": "popi",
    "codigo": "P828"
  },
  {
    "nome": "popo",
    "codigo": "P829"
  },
  {
    "nome": "popp",
    "codigo": "P831"
  },
  {
    "nome": "por",
    "codigo": "P832"
  },
  {
    "nome": "porc",
    "codigo": "P833"
  },
  {
    "nome": "porci",
    "codigo": "P834"
  },
  {
    "nome": "pord",
    "codigo": "P835"
  },
  {
    "nome": "pori",
    "codigo": "P836"
  },
  {
    "nome": "porp",
    "codigo": "P837"
  },
  {
    "nome": "porr",
    "codigo": "P838"
  },
  {
    "nome": "port",
    "codigo": "P839"
  },
  {
    "nome": "portaf",
    "codigo": "P841"
  },
  {
    "nome": "portal",
    "codigo": "P842"
  },
  {
    "nome": "porte",
    "codigo": "P843"
  },
  {
    "nome": "porter",
    "codigo": "P844"
  },
  {
    "nome": "porter f",
    "codigo": "P845"
  },
  {
    "nome": "porter j",
    "codigo": "P846"
  },
  {
    "nome": "porter m",
    "codigo": "P847"
  },
  {
    "nome": "porter s",
    "codigo": "P848"
  },
  {
    "nome": "porter w",
    "codigo": "P849"
  },
  {
    "nome": "porth",
    "codigo": "P851"
  },
  {
    "nome": "porti",
    "codigo": "P852"
  },
  {
    "nome": "portm",
    "codigo": "P853"
  },
  {
    "nome": "porz",
    "codigo": "P854"
  },
  {
    "nome": "pos",
    "codigo": "P855"
  },
  {
    "nome": "poss",
    "codigo": "P856"
  },
  {
    "nome": "post",
    "codigo": "P857"
  },
  {
    "nome": "postl",
    "codigo": "P858"
  },
  {
    "nome": "pot",
    "codigo": "P859"
  },
  {
    "nome": "pote",
    "codigo": "P861"
  },
  {
    "nome": "poth",
    "codigo": "P862"
  },
  {
    "nome": "poti",
    "codigo": "P863"
  },
  {
    "nome": "poto",
    "codigo": "P864"
  },
  {
    "nome": "pott",
    "codigo": "P865"
  },
  {
    "nome": "potter",
    "codigo": "P866"
  },
  {
    "nome": "potter g",
    "codigo": "P867"
  },
  {
    "nome": "potter m",
    "codigo": "P868"
  },
  {
    "nome": "potter s",
    "codigo": "P869"
  },
  {
    "nome": "potti",
    "codigo": "P871"
  },
  {
    "nome": "pou",
    "codigo": "P872"
  },
  {
    "nome": "poui",
    "codigo": "P873"
  },
  {
    "nome": "poul",
    "codigo": "P874"
  },
  {
    "nome": "poull",
    "codigo": "P875"
  },
  {
    "nome": "poult",
    "codigo": "P876"
  },
  {
    "nome": "pour",
    "codigo": "P877"
  },
  {
    "nome": "pous",
    "codigo": "P878"
  },
  {
    "nome": "pout",
    "codigo": "P879"
  },
  {
    "nome": "pow",
    "codigo": "P881"
  },
  {
    "nome": "powell",
    "codigo": "P882"
  },
  {
    "nome": "powell f",
    "codigo": "P883"
  },
  {
    "nome": "powell j",
    "codigo": "P884"
  },
  {
    "nome": "powell m",
    "codigo": "P885"
  },
  {
    "nome": "powell s",
    "codigo": "P886"
  },
  {
    "nome": "power",
    "codigo": "P887"
  },
  {
    "nome": "powers",
    "codigo": "P888"
  },
  {
    "nome": "pown",
    "codigo": "P889"
  },
  {
    "nome": "poy",
    "codigo": "P891"
  },
  {
    "nome": "poyn",
    "codigo": "P892"
  },
  {
    "nome": "poz",
    "codigo": "P893"
  },
  {
    "nome": "pozzo",
    "codigo": "P894"
  },
  {
    "nome": "pr",
    "codigo": "P895"
  },
  {
    "nome": "prad",
    "codigo": "P896"
  },
  {
    "nome": "prae",
    "codigo": "P897"
  },
  {
    "nome": "praet",
    "codigo": "P898"
  },
  {
    "nome": "pran",
    "codigo": "P899"
  },
  {
    "nome": "pras",
    "codigo": "P911"
  },
  {
    "nome": "prat",
    "codigo": "P912"
  },
  {
    "nome": "pratt",
    "codigo": "P913"
  },
  {
    "nome": "pratt f",
    "codigo": "P914"
  },
  {
    "nome": "pratt j",
    "codigo": "P915"
  },
  {
    "nome": "pratt m",
    "codigo": "P916"
  },
  {
    "nome": "pratt s",
    "codigo": "P917"
  },
  {
    "nome": "prau",
    "codigo": "P918"
  },
  {
    "nome": "prax",
    "codigo": "P919"
  },
  {
    "nome": "pray",
    "codigo": "P921"
  },
  {
    "nome": "pre",
    "codigo": "P922"
  },
  {
    "nome": "prec",
    "codigo": "P923"
  },
  {
    "nome": "prei",
    "codigo": "P924"
  },
  {
    "nome": "prem",
    "codigo": "P925"
  },
  {
    "nome": "pren",
    "codigo": "P926"
  },
  {
    "nome": "prent",
    "codigo": "P927"
  },
  {
    "nome": "pres",
    "codigo": "P928"
  },
  {
    "nome": "prescott",
    "codigo": "P929"
  },
  {
    "nome": "prescott g",
    "codigo": "P931"
  },
  {
    "nome": "prescott m",
    "codigo": "P932"
  },
  {
    "nome": "prescott s",
    "codigo": "P933"
  },
  {
    "nome": "presl",
    "codigo": "P934"
  },
  {
    "nome": "press",
    "codigo": "P935"
  },
  {
    "nome": "prest",
    "codigo": "P936"
  },
  {
    "nome": "preston",
    "codigo": "P937"
  },
  {
    "nome": "preston g",
    "codigo": "P938"
  },
  {
    "nome": "preston m",
    "codigo": "P939"
  },
  {
    "nome": "preston s",
    "codigo": "P941"
  },
  {
    "nome": "preston w",
    "codigo": "P942"
  },
  {
    "nome": "preu",
    "codigo": "P943"
  },
  {
    "nome": "prev",
    "codigo": "P944"
  },
  {
    "nome": "pri",
    "codigo": "P945"
  },
  {
    "nome": "price m",
    "codigo": "P946"
  },
  {
    "nome": "prich",
    "codigo": "P947"
  },
  {
    "nome": "prie",
    "codigo": "P948"
  },
  {
    "nome": "pries",
    "codigo": "P949"
  },
  {
    "nome": "prieu",
    "codigo": "P951"
  },
  {
    "nome": "prim",
    "codigo": "P952"
  },
  {
    "nome": "prime",
    "codigo": "P953"
  },
  {
    "nome": "prin",
    "codigo": "P954"
  },
  {
    "nome": "prince g",
    "codigo": "P955"
  },
  {
    "nome": "prince m",
    "codigo": "P956"
  },
  {
    "nome": "prince s",
    "codigo": "P957"
  },
  {
    "nome": "prio",
    "codigo": "P958"
  },
  {
    "nome": "pris",
    "codigo": "P959"
  },
  {
    "nome": "prit",
    "codigo": "P961"
  },
  {
    "nome": "pro",
    "codigo": "P962"
  },
  {
    "nome": "proc",
    "codigo": "P963"
  },
  {
    "nome": "proct",
    "codigo": "P964"
  },
  {
    "nome": "prom",
    "codigo": "P965"
  },
  {
    "nome": "pros",
    "codigo": "P966"
  },
  {
    "nome": "prot",
    "codigo": "P967"
  },
  {
    "nome": "prou",
    "codigo": "P968"
  },
  {
    "nome": "prov",
    "codigo": "P969"
  },
  {
    "nome": "pru",
    "codigo": "P971"
  },
  {
    "nome": "prun",
    "codigo": "P972"
  },
  {
    "nome": "pry",
    "codigo": "P973"
  },
  {
    "nome": "ps",
    "codigo": "P974"
  },
  {
    "nome": "pt",
    "codigo": "P975"
  },
  {
    "nome": "pu",
    "codigo": "P976"
  },
  {
    "nome": "puc",
    "codigo": "P977"
  },
  {
    "nome": "pug",
    "codigo": "P978"
  },
  {
    "nome": "pui",
    "codigo": "P979"
  },
  {
    "nome": "pul",
    "codigo": "P981"
  },
  {
    "nome": "pull",
    "codigo": "P982"
  },
  {
    "nome": "pult",
    "codigo": "P983"
  },
  {
    "nome": "pun",
    "codigo": "P984"
  },
  {
    "nome": "pur",
    "codigo": "P985"
  },
  {
    "nome": "purs",
    "codigo": "P986"
  },
  {
    "nome": "pus",
    "codigo": "P987"
  },
  {
    "nome": "put",
    "codigo": "P988"
  },
  {
    "nome": "putnam",
    "codigo": "P989"
  },
  {
    "nome": "putnam g",
    "codigo": "P991"
  },
  {
    "nome": "putnam m",
    "codigo": "P992"
  },
  {
    "nome": "putnam s",
    "codigo": "P993"
  },
  {
    "nome": "puy",
    "codigo": "P994"
  },
  {
    "nome": "py",
    "codigo": "P995"
  },
  {
    "nome": "pyl",
    "codigo": "P996"
  },
  {
    "nome": "pyn",
    "codigo": "P997"
  },
  {
    "nome": "pyr",
    "codigo": "P998"
  },
  {
    "nome": "pyt",
    "codigo": "P999"
  },
  {
    "nome": "q",
    "codigo": "Q1"
  },
  {
    "nome": "qu",
    "codigo": "Q1"
  },
  {
    "nome": "qua",
    "codigo": "Q1"
  },
  {
    "nome": "quat",
    "codigo": "Q2"
  },
  {
    "nome": "que",
    "codigo": "Q3"
  },
  {
    "nome": "quer",
    "codigo": "Q4"
  },
  {
    "nome": "ques",
    "codigo": "Q5"
  },
  {
    "nome": "qui",
    "codigo": "Q6"
  },
  {
    "nome": "quin",
    "codigo": "Q7"
  },
  {
    "nome": "quir",
    "codigo": "Q8"
  },
  {
    "nome": "quo",
    "codigo": "Q9"
  },
  {
    "nome": "r",
    "codigo": "R111"
  },
  {
    "nome": "ra",
    "codigo": "R111"
  },
  {
    "nome": "rab",
    "codigo": "R112"
  },
  {
    "nome": "rabau",
    "codigo": "R113"
  },
  {
    "nome": "rabe",
    "codigo": "R114"
  },
  {
    "nome": "raben",
    "codigo": "R115"
  },
  {
    "nome": "rabi",
    "codigo": "R116"
  },
  {
    "nome": "rabu",
    "codigo": "R117"
  },
  {
    "nome": "rac",
    "codigo": "R118"
  },
  {
    "nome": "rach",
    "codigo": "R119"
  },
  {
    "nome": "raci",
    "codigo": "R121"
  },
  {
    "nome": "rack",
    "codigo": "R122"
  },
  {
    "nome": "raco",
    "codigo": "R123"
  },
  {
    "nome": "rad",
    "codigo": "R124"
  },
  {
    "nome": "radc",
    "codigo": "R125"
  },
  {
    "nome": "rade",
    "codigo": "R126"
  },
  {
    "nome": "radem",
    "codigo": "R127"
  },
  {
    "nome": "radet",
    "codigo": "R128"
  },
  {
    "nome": "radi",
    "codigo": "R129"
  },
  {
    "nome": "rado",
    "codigo": "R131"
  },
  {
    "nome": "radu",
    "codigo": "R132"
  },
  {
    "nome": "radz",
    "codigo": "R133"
  },
  {
    "nome": "rae",
    "codigo": "R134"
  },
  {
    "nome": "raen",
    "codigo": "R135"
  },
  {
    "nome": "raf",
    "codigo": "R136"
  },
  {
    "nome": "raffen",
    "codigo": "R137"
  },
  {
    "nome": "raffl",
    "codigo": "R138"
  },
  {
    "nome": "rafn",
    "codigo": "R139"
  },
  {
    "nome": "rag",
    "codigo": "R141"
  },
  {
    "nome": "ragg",
    "codigo": "R142"
  },
  {
    "nome": "ragl",
    "codigo": "R143"
  },
  {
    "nome": "rago",
    "codigo": "R144"
  },
  {
    "nome": "ragu",
    "codigo": "R145"
  },
  {
    "nome": "ragus",
    "codigo": "R146"
  },
  {
    "nome": "rah",
    "codigo": "R147"
  },
  {
    "nome": "rahn",
    "codigo": "R148"
  },
  {
    "nome": "rai",
    "codigo": "R149"
  },
  {
    "nome": "raik",
    "codigo": "R151"
  },
  {
    "nome": "rail",
    "codigo": "R152"
  },
  {
    "nome": "raim",
    "codigo": "R153"
  },
  {
    "nome": "rain",
    "codigo": "R154"
  },
  {
    "nome": "raine",
    "codigo": "R155"
  },
  {
    "nome": "rainey",
    "codigo": "R156"
  },
  {
    "nome": "raini",
    "codigo": "R157"
  },
  {
    "nome": "raino",
    "codigo": "R158"
  },
  {
    "nome": "rainv",
    "codigo": "R159"
  },
  {
    "nome": "rait",
    "codigo": "R161"
  },
  {
    "nome": "rak",
    "codigo": "R162"
  },
  {
    "nome": "ral",
    "codigo": "R163"
  },
  {
    "nome": "rals",
    "codigo": "R164"
  },
  {
    "nome": "ram",
    "codigo": "R165"
  },
  {
    "nome": "ramaz",
    "codigo": "R166"
  },
  {
    "nome": "ramb",
    "codigo": "R167"
  },
  {
    "nome": "rambu",
    "codigo": "R168"
  },
  {
    "nome": "ramd",
    "codigo": "R169"
  },
  {
    "nome": "rame",
    "codigo": "R171"
  },
  {
    "nome": "ramel",
    "codigo": "R172"
  },
  {
    "nome": "rami",
    "codigo": "R173"
  },
  {
    "nome": "ramm",
    "codigo": "R174"
  },
  {
    "nome": "ramo",
    "codigo": "R175"
  },
  {
    "nome": "ramou",
    "codigo": "R176"
  },
  {
    "nome": "ramp",
    "codigo": "R177"
  },
  {
    "nome": "rams",
    "codigo": "R178"
  },
  {
    "nome": "ramsay j",
    "codigo": "R179"
  },
  {
    "nome": "ramsay p",
    "codigo": "R181"
  },
  {
    "nome": "ramsd",
    "codigo": "R182"
  },
  {
    "nome": "ramse",
    "codigo": "R183"
  },
  {
    "nome": "ramu",
    "codigo": "R184"
  },
  {
    "nome": "ran",
    "codigo": "R185"
  },
  {
    "nome": "rand",
    "codigo": "R186"
  },
  {
    "nome": "rand m",
    "codigo": "R187"
  },
  {
    "nome": "randall",
    "codigo": "R188"
  },
  {
    "nome": "randall m",
    "codigo": "R189"
  },
  {
    "nome": "rande",
    "codigo": "R191"
  },
  {
    "nome": "rando",
    "codigo": "R192"
  },
  {
    "nome": "randolph g",
    "codigo": "R193"
  },
  {
    "nome": "randolph m",
    "codigo": "R194"
  },
  {
    "nome": "randon",
    "codigo": "R195"
  },
  {
    "nome": "rang",
    "codigo": "R196"
  },
  {
    "nome": "rani",
    "codigo": "R197"
  },
  {
    "nome": "rank",
    "codigo": "R198"
  },
  {
    "nome": "ranken",
    "codigo": "R199"
  },
  {
    "nome": "ranki",
    "codigo": "R211"
  },
  {
    "nome": "rans",
    "codigo": "R212"
  },
  {
    "nome": "rant",
    "codigo": "R213"
  },
  {
    "nome": "ranz",
    "codigo": "R214"
  },
  {
    "nome": "rao",
    "codigo": "R215"
  },
  {
    "nome": "rap",
    "codigo": "R216"
  },
  {
    "nome": "raph",
    "codigo": "R217"
  },
  {
    "nome": "rapi",
    "codigo": "R218"
  },
  {
    "nome": "rapo",
    "codigo": "R219"
  },
  {
    "nome": "rapp",
    "codigo": "R221"
  },
  {
    "nome": "ras",
    "codigo": "R222"
  },
  {
    "nome": "rasch",
    "codigo": "R223"
  },
  {
    "nome": "rase",
    "codigo": "R224"
  },
  {
    "nome": "rask",
    "codigo": "R225"
  },
  {
    "nome": "rasp",
    "codigo": "R226"
  },
  {
    "nome": "raspo",
    "codigo": "R227"
  },
  {
    "nome": "rass",
    "codigo": "R228"
  },
  {
    "nome": "rast",
    "codigo": "R229"
  },
  {
    "nome": "rasto",
    "codigo": "R231"
  },
  {
    "nome": "rat",
    "codigo": "R232"
  },
  {
    "nome": "ratc",
    "codigo": "R233"
  },
  {
    "nome": "rath",
    "codigo": "R234"
  },
  {
    "nome": "raths",
    "codigo": "R235"
  },
  {
    "nome": "rati",
    "codigo": "R236"
  },
  {
    "nome": "ratt",
    "codigo": "R237"
  },
  {
    "nome": "ratz",
    "codigo": "R238"
  },
  {
    "nome": "rau",
    "codigo": "R239"
  },
  {
    "nome": "rauch",
    "codigo": "R241"
  },
  {
    "nome": "rauco",
    "codigo": "R242"
  },
  {
    "nome": "raud",
    "codigo": "R243"
  },
  {
    "nome": "rauf",
    "codigo": "R244"
  },
  {
    "nome": "raul",
    "codigo": "R245"
  },
  {
    "nome": "raum",
    "codigo": "R246"
  },
  {
    "nome": "raup",
    "codigo": "R247"
  },
  {
    "nome": "raus",
    "codigo": "R248"
  },
  {
    "nome": "raut",
    "codigo": "R249"
  },
  {
    "nome": "rauz",
    "codigo": "R251"
  },
  {
    "nome": "rav",
    "codigo": "R252"
  },
  {
    "nome": "raven",
    "codigo": "R253"
  },
  {
    "nome": "ravens",
    "codigo": "R254"
  },
  {
    "nome": "raves",
    "codigo": "R255"
  },
  {
    "nome": "ravi",
    "codigo": "R256"
  },
  {
    "nome": "raw",
    "codigo": "R257"
  },
  {
    "nome": "rawl",
    "codigo": "R258"
  },
  {
    "nome": "rawlin",
    "codigo": "R259"
  },
  {
    "nome": "rawlinson",
    "codigo": "R261"
  },
  {
    "nome": "raws",
    "codigo": "R262"
  },
  {
    "nome": "ray",
    "codigo": "R263"
  },
  {
    "nome": "ray m",
    "codigo": "R264"
  },
  {
    "nome": "rayb",
    "codigo": "R265"
  },
  {
    "nome": "raye",
    "codigo": "R266"
  },
  {
    "nome": "raym",
    "codigo": "R267"
  },
  {
    "nome": "raymond",
    "codigo": "R268"
  },
  {
    "nome": "raymond g",
    "codigo": "R269"
  },
  {
    "nome": "raymond m",
    "codigo": "R271"
  },
  {
    "nome": "raymond s",
    "codigo": "R272"
  },
  {
    "nome": "raymond w",
    "codigo": "R273"
  },
  {
    "nome": "rayn",
    "codigo": "R274"
  },
  {
    "nome": "rayne",
    "codigo": "R275"
  },
  {
    "nome": "rayno",
    "codigo": "R276"
  },
  {
    "nome": "rayo",
    "codigo": "R277"
  },
  {
    "nome": "raz",
    "codigo": "R278"
  },
  {
    "nome": "razou",
    "codigo": "R279"
  },
  {
    "nome": "re",
    "codigo": "R281"
  },
  {
    "nome": "read",
    "codigo": "R282"
  },
  {
    "nome": "read h",
    "codigo": "R283"
  },
  {
    "nome": "read m",
    "codigo": "R284"
  },
  {
    "nome": "reade",
    "codigo": "R285"
  },
  {
    "nome": "reade m",
    "codigo": "R286"
  },
  {
    "nome": "reading",
    "codigo": "R287"
  },
  {
    "nome": "real",
    "codigo": "R288"
  },
  {
    "nome": "reb",
    "codigo": "R289"
  },
  {
    "nome": "rebell",
    "codigo": "R291"
  },
  {
    "nome": "rebo",
    "codigo": "R292"
  },
  {
    "nome": "rebs",
    "codigo": "R293"
  },
  {
    "nome": "rec",
    "codigo": "R294"
  },
  {
    "nome": "recco",
    "codigo": "R295"
  },
  {
    "nome": "rech",
    "codigo": "R296"
  },
  {
    "nome": "rechen",
    "codigo": "R297"
  },
  {
    "nome": "reck",
    "codigo": "R298"
  },
  {
    "nome": "recl",
    "codigo": "R299"
  },
  {
    "nome": "reco",
    "codigo": "R311"
  },
  {
    "nome": "red",
    "codigo": "R312"
  },
  {
    "nome": "redd",
    "codigo": "R313"
  },
  {
    "nome": "rede",
    "codigo": "R314"
  },
  {
    "nome": "redf",
    "codigo": "R315"
  },
  {
    "nome": "redg",
    "codigo": "R316"
  },
  {
    "nome": "redi",
    "codigo": "R317"
  },
  {
    "nome": "redm",
    "codigo": "R318"
  },
  {
    "nome": "redo",
    "codigo": "R319"
  },
  {
    "nome": "redp",
    "codigo": "R321"
  },
  {
    "nome": "ree",
    "codigo": "R322"
  },
  {
    "nome": "reed",
    "codigo": "R323"
  },
  {
    "nome": "reed g",
    "codigo": "R324"
  },
  {
    "nome": "reed m",
    "codigo": "R325"
  },
  {
    "nome": "reed s",
    "codigo": "R326"
  },
  {
    "nome": "reed w",
    "codigo": "R327"
  },
  {
    "nome": "rees",
    "codigo": "R328"
  },
  {
    "nome": "reese",
    "codigo": "R329"
  },
  {
    "nome": "reev",
    "codigo": "R331"
  },
  {
    "nome": "reeves",
    "codigo": "R332"
  },
  {
    "nome": "reg",
    "codigo": "R333"
  },
  {
    "nome": "regg",
    "codigo": "R334"
  },
  {
    "nome": "regi",
    "codigo": "R335"
  },
  {
    "nome": "regio",
    "codigo": "R336"
  },
  {
    "nome": "regis",
    "codigo": "R337"
  },
  {
    "nome": "regn",
    "codigo": "R338"
  },
  {
    "nome": "regnau",
    "codigo": "R339"
  },
  {
    "nome": "regne",
    "codigo": "R341"
  },
  {
    "nome": "regni",
    "codigo": "R342"
  },
  {
    "nome": "rego",
    "codigo": "R343"
  },
  {
    "nome": "regu",
    "codigo": "R344"
  },
  {
    "nome": "reh",
    "codigo": "R345"
  },
  {
    "nome": "reht",
    "codigo": "R346"
  },
  {
    "nome": "rei",
    "codigo": "R347"
  },
  {
    "nome": "reicha",
    "codigo": "R348"
  },
  {
    "nome": "reiche",
    "codigo": "R349"
  },
  {
    "nome": "reichen",
    "codigo": "R351"
  },
  {
    "nome": "reichm",
    "codigo": "R352"
  },
  {
    "nome": "reid",
    "codigo": "R353"
  },
  {
    "nome": "reid d",
    "codigo": "R354"
  },
  {
    "nome": "reid f",
    "codigo": "R355"
  },
  {
    "nome": "reid j",
    "codigo": "R356"
  },
  {
    "nome": "reid m",
    "codigo": "R357"
  },
  {
    "nome": "reid s",
    "codigo": "R358"
  },
  {
    "nome": "reid w",
    "codigo": "R359"
  },
  {
    "nome": "reif",
    "codigo": "R361"
  },
  {
    "nome": "reil",
    "codigo": "R362"
  },
  {
    "nome": "reim",
    "codigo": "R363"
  },
  {
    "nome": "rein",
    "codigo": "R364"
  },
  {
    "nome": "reine",
    "codigo": "R365"
  },
  {
    "nome": "reinec",
    "codigo": "R366"
  },
  {
    "nome": "reiner",
    "codigo": "R367"
  },
  {
    "nome": "reinh",
    "codigo": "R368"
  },
  {
    "nome": "reinhard",
    "codigo": "R369"
  },
  {
    "nome": "reinhart",
    "codigo": "R371"
  },
  {
    "nome": "reinho",
    "codigo": "R372"
  },
  {
    "nome": "reinm",
    "codigo": "R373"
  },
  {
    "nome": "reins",
    "codigo": "R374"
  },
  {
    "nome": "reis",
    "codigo": "R375"
  },
  {
    "nome": "reiset",
    "codigo": "R376"
  },
  {
    "nome": "reisi",
    "codigo": "R377"
  },
  {
    "nome": "reiss",
    "codigo": "R378"
  },
  {
    "nome": "reit",
    "codigo": "R379"
  },
  {
    "nome": "rej",
    "codigo": "R381"
  },
  {
    "nome": "rel",
    "codigo": "R382"
  },
  {
    "nome": "rell",
    "codigo": "R383"
  },
  {
    "nome": "rem",
    "codigo": "R384"
  },
  {
    "nome": "remb",
    "codigo": "R385"
  },
  {
    "nome": "reme",
    "codigo": "R386"
  },
  {
    "nome": "remi",
    "codigo": "R387"
  },
  {
    "nome": "remin",
    "codigo": "R388"
  },
  {
    "nome": "remo",
    "codigo": "R389"
  },
  {
    "nome": "remu",
    "codigo": "R391"
  },
  {
    "nome": "remy",
    "codigo": "R392"
  },
  {
    "nome": "ren",
    "codigo": "R393"
  },
  {
    "nome": "renar",
    "codigo": "R394"
  },
  {
    "nome": "renau",
    "codigo": "R395"
  },
  {
    "nome": "renaul",
    "codigo": "R396"
  },
  {
    "nome": "rend",
    "codigo": "R397"
  },
  {
    "nome": "rendu",
    "codigo": "R398"
  },
  {
    "nome": "rene",
    "codigo": "R399"
  },
  {
    "nome": "renes",
    "codigo": "R411"
  },
  {
    "nome": "reng",
    "codigo": "R412"
  },
  {
    "nome": "reni",
    "codigo": "R413"
  },
  {
    "nome": "renn",
    "codigo": "R414"
  },
  {
    "nome": "rennev",
    "codigo": "R415"
  },
  {
    "nome": "renni",
    "codigo": "R416"
  },
  {
    "nome": "renny",
    "codigo": "R417"
  },
  {
    "nome": "reno",
    "codigo": "R418"
  },
  {
    "nome": "renou",
    "codigo": "R419"
  },
  {
    "nome": "rens",
    "codigo": "R421"
  },
  {
    "nome": "rent",
    "codigo": "R422"
  },
  {
    "nome": "renu",
    "codigo": "R423"
  },
  {
    "nome": "renv",
    "codigo": "R424"
  },
  {
    "nome": "rep",
    "codigo": "R425"
  },
  {
    "nome": "rept",
    "codigo": "R426"
  },
  {
    "nome": "req",
    "codigo": "R427"
  },
  {
    "nome": "rer",
    "codigo": "R428"
  },
  {
    "nome": "res",
    "codigo": "R429"
  },
  {
    "nome": "resch",
    "codigo": "R431"
  },
  {
    "nome": "rese",
    "codigo": "R432"
  },
  {
    "nome": "resen",
    "codigo": "R433"
  },
  {
    "nome": "resn",
    "codigo": "R434"
  },
  {
    "nome": "ress",
    "codigo": "R435"
  },
  {
    "nome": "rest",
    "codigo": "R436"
  },
  {
    "nome": "ret",
    "codigo": "R437"
  },
  {
    "nome": "reth",
    "codigo": "R438"
  },
  {
    "nome": "rett",
    "codigo": "R439"
  },
  {
    "nome": "retz",
    "codigo": "R441"
  },
  {
    "nome": "reu",
    "codigo": "R442"
  },
  {
    "nome": "reul",
    "codigo": "R443"
  },
  {
    "nome": "reum",
    "codigo": "R444"
  },
  {
    "nome": "reus",
    "codigo": "R445"
  },
  {
    "nome": "reuss",
    "codigo": "R446"
  },
  {
    "nome": "reut",
    "codigo": "R447"
  },
  {
    "nome": "reuv",
    "codigo": "R448"
  },
  {
    "nome": "rev",
    "codigo": "R449"
  },
  {
    "nome": "revell",
    "codigo": "R451"
  },
  {
    "nome": "rever",
    "codigo": "R452"
  },
  {
    "nome": "reves",
    "codigo": "R453"
  },
  {
    "nome": "revi",
    "codigo": "R454"
  },
  {
    "nome": "rex",
    "codigo": "R455"
  },
  {
    "nome": "rey",
    "codigo": "R456"
  },
  {
    "nome": "reyb",
    "codigo": "R457"
  },
  {
    "nome": "reym",
    "codigo": "R458"
  },
  {
    "nome": "reyn",
    "codigo": "R459"
  },
  {
    "nome": "reyni",
    "codigo": "R461"
  },
  {
    "nome": "reyno",
    "codigo": "R462"
  },
  {
    "nome": "reynolds g",
    "codigo": "R463"
  },
  {
    "nome": "reynolds m",
    "codigo": "R464"
  },
  {
    "nome": "reynolds s",
    "codigo": "R465"
  },
  {
    "nome": "reynolds w",
    "codigo": "R466"
  },
  {
    "nome": "rez",
    "codigo": "R467"
  },
  {
    "nome": "rh",
    "codigo": "R468"
  },
  {
    "nome": "rhe",
    "codigo": "R469"
  },
  {
    "nome": "rhen",
    "codigo": "R471"
  },
  {
    "nome": "rhet",
    "codigo": "R472"
  },
  {
    "nome": "rhi",
    "codigo": "R473"
  },
  {
    "nome": "rho",
    "codigo": "R474"
  },
  {
    "nome": "rhod",
    "codigo": "R475"
  },
  {
    "nome": "rhodes",
    "codigo": "R476"
  },
  {
    "nome": "rhodes m",
    "codigo": "R477"
  },
  {
    "nome": "rhodo",
    "codigo": "R478"
  },
  {
    "nome": "rhou",
    "codigo": "R479"
  },
  {
    "nome": "ri",
    "codigo": "R481"
  },
  {
    "nome": "rib",
    "codigo": "R482"
  },
  {
    "nome": "ribb",
    "codigo": "R483"
  },
  {
    "nome": "ribe",
    "codigo": "R484"
  },
  {
    "nome": "ribes",
    "codigo": "R485"
  },
  {
    "nome": "ribo",
    "codigo": "R486"
  },
  {
    "nome": "ric",
    "codigo": "R487"
  },
  {
    "nome": "ricardo",
    "codigo": "R488"
  },
  {
    "nome": "ricc",
    "codigo": "R489"
  },
  {
    "nome": "ricci",
    "codigo": "R491"
  },
  {
    "nome": "ricciar",
    "codigo": "R492"
  },
  {
    "nome": "riccio",
    "codigo": "R493"
  },
  {
    "nome": "ricco",
    "codigo": "R494"
  },
  {
    "nome": "rice",
    "codigo": "R495"
  },
  {
    "nome": "rice g",
    "codigo": "R496"
  },
  {
    "nome": "rice m",
    "codigo": "R497"
  },
  {
    "nome": "rich",
    "codigo": "R498"
  },
  {
    "nome": "rich m",
    "codigo": "R499"
  },
  {
    "nome": "richard",
    "codigo": "R511"
  },
  {
    "nome": "richard g",
    "codigo": "R512"
  },
  {
    "nome": "richard m",
    "codigo": "R513"
  },
  {
    "nome": "richards",
    "codigo": "R514"
  },
  {
    "nome": "richards f",
    "codigo": "R515"
  },
  {
    "nome": "richards j",
    "codigo": "R516"
  },
  {
    "nome": "richards m",
    "codigo": "R517"
  },
  {
    "nome": "richards s",
    "codigo": "R518"
  },
  {
    "nome": "richards w",
    "codigo": "R519"
  },
  {
    "nome": "richardson",
    "codigo": "R521"
  },
  {
    "nome": "richardson d",
    "codigo": "R522"
  },
  {
    "nome": "richardson j",
    "codigo": "R523"
  },
  {
    "nome": "richardson m",
    "codigo": "R524"
  },
  {
    "nome": "richardson s",
    "codigo": "R525"
  },
  {
    "nome": "richardson w",
    "codigo": "R526"
  },
  {
    "nome": "riche",
    "codigo": "R527"
  },
  {
    "nome": "richel",
    "codigo": "R528"
  },
  {
    "nome": "richer",
    "codigo": "R529"
  },
  {
    "nome": "richi",
    "codigo": "R531"
  },
  {
    "nome": "richm",
    "codigo": "R532"
  },
  {
    "nome": "richmond m",
    "codigo": "R533"
  },
  {
    "nome": "richt",
    "codigo": "R534"
  },
  {
    "nome": "richter",
    "codigo": "R535"
  },
  {
    "nome": "richter m",
    "codigo": "R536"
  },
  {
    "nome": "richter s",
    "codigo": "R537"
  },
  {
    "nome": "rici",
    "codigo": "R538"
  },
  {
    "nome": "rick",
    "codigo": "R539"
  },
  {
    "nome": "rico",
    "codigo": "R541"
  },
  {
    "nome": "rid",
    "codigo": "R542"
  },
  {
    "nome": "riddel",
    "codigo": "R543"
  },
  {
    "nome": "ride",
    "codigo": "R544"
  },
  {
    "nome": "ridl",
    "codigo": "R545"
  },
  {
    "nome": "ridley m",
    "codigo": "R546"
  },
  {
    "nome": "rido",
    "codigo": "R547"
  },
  {
    "nome": "rie",
    "codigo": "R548"
  },
  {
    "nome": "ried",
    "codigo": "R549"
  },
  {
    "nome": "riedes",
    "codigo": "R551"
  },
  {
    "nome": "riedi",
    "codigo": "R552"
  },
  {
    "nome": "rief",
    "codigo": "R553"
  },
  {
    "nome": "rieg",
    "codigo": "R554"
  },
  {
    "nome": "rieh",
    "codigo": "R555"
  },
  {
    "nome": "riem",
    "codigo": "R556"
  },
  {
    "nome": "rien",
    "codigo": "R557"
  },
  {
    "nome": "riep",
    "codigo": "R558"
  },
  {
    "nome": "ries",
    "codigo": "R559"
  },
  {
    "nome": "riese",
    "codigo": "R561"
  },
  {
    "nome": "riesn",
    "codigo": "R562"
  },
  {
    "nome": "riet",
    "codigo": "R563"
  },
  {
    "nome": "rieu",
    "codigo": "R564"
  },
  {
    "nome": "rig",
    "codigo": "R565"
  },
  {
    "nome": "rigaul",
    "codigo": "R566"
  },
  {
    "nome": "rigb",
    "codigo": "R567"
  },
  {
    "nome": "rige",
    "codigo": "R568"
  },
  {
    "nome": "rigg",
    "codigo": "R569"
  },
  {
    "nome": "righ",
    "codigo": "R571"
  },
  {
    "nome": "rign",
    "codigo": "R572"
  },
  {
    "nome": "ril",
    "codigo": "R573"
  },
  {
    "nome": "rill",
    "codigo": "R574"
  },
  {
    "nome": "rim",
    "codigo": "R575"
  },
  {
    "nome": "rimi",
    "codigo": "R576"
  },
  {
    "nome": "rimm",
    "codigo": "R577"
  },
  {
    "nome": "rin",
    "codigo": "R578"
  },
  {
    "nome": "rinc",
    "codigo": "R579"
  },
  {
    "nome": "ring",
    "codigo": "R581"
  },
  {
    "nome": "ringo",
    "codigo": "R582"
  },
  {
    "nome": "rint",
    "codigo": "R583"
  },
  {
    "nome": "rinu",
    "codigo": "R584"
  },
  {
    "nome": "rio",
    "codigo": "R585"
  },
  {
    "nome": "rios",
    "codigo": "R586"
  },
  {
    "nome": "riou",
    "codigo": "R587"
  },
  {
    "nome": "rip",
    "codigo": "R588"
  },
  {
    "nome": "ripley",
    "codigo": "R589"
  },
  {
    "nome": "ripley h",
    "codigo": "R591"
  },
  {
    "nome": "ripley r",
    "codigo": "R592"
  },
  {
    "nome": "ripp",
    "codigo": "R593"
  },
  {
    "nome": "riq",
    "codigo": "R594"
  },
  {
    "nome": "ris",
    "codigo": "R595"
  },
  {
    "nome": "riss",
    "codigo": "R596"
  },
  {
    "nome": "rist",
    "codigo": "R597"
  },
  {
    "nome": "rit",
    "codigo": "R598"
  },
  {
    "nome": "ritchie g",
    "codigo": "R599"
  },
  {
    "nome": "ritchie m",
    "codigo": "R611"
  },
  {
    "nome": "rits",
    "codigo": "R612"
  },
  {
    "nome": "ritt",
    "codigo": "R613"
  },
  {
    "nome": "ritter",
    "codigo": "R614"
  },
  {
    "nome": "ritter m",
    "codigo": "R615"
  },
  {
    "nome": "riv",
    "codigo": "R616"
  },
  {
    "nome": "rivan",
    "codigo": "R617"
  },
  {
    "nome": "rivar",
    "codigo": "R618"
  },
  {
    "nome": "rivau",
    "codigo": "R619"
  },
  {
    "nome": "rive",
    "codigo": "R621"
  },
  {
    "nome": "rivers",
    "codigo": "R622"
  },
  {
    "nome": "rives",
    "codigo": "R623"
  },
  {
    "nome": "rivet",
    "codigo": "R624"
  },
  {
    "nome": "rivi",
    "codigo": "R625"
  },
  {
    "nome": "rivo",
    "codigo": "R626"
  },
  {
    "nome": "riz",
    "codigo": "R627"
  },
  {
    "nome": "ro",
    "codigo": "R628"
  },
  {
    "nome": "robar",
    "codigo": "R629"
  },
  {
    "nome": "robb",
    "codigo": "R631"
  },
  {
    "nome": "robbins",
    "codigo": "R632"
  },
  {
    "nome": "robbins f",
    "codigo": "R633"
  },
  {
    "nome": "robbins j",
    "codigo": "R634"
  },
  {
    "nome": "robbins m",
    "codigo": "R635"
  },
  {
    "nome": "robbins s",
    "codigo": "R636"
  },
  {
    "nome": "robbins w",
    "codigo": "R637"
  },
  {
    "nome": "robe",
    "codigo": "R638"
  },
  {
    "nome": "robert",
    "codigo": "R639"
  },
  {
    "nome": "robert g",
    "codigo": "R641"
  },
  {
    "nome": "robert m",
    "codigo": "R642"
  },
  {
    "nome": "roberts",
    "codigo": "R643"
  },
  {
    "nome": "roberts f",
    "codigo": "R644"
  },
  {
    "nome": "roberts j",
    "codigo": "R645"
  },
  {
    "nome": "roberts m",
    "codigo": "R646"
  },
  {
    "nome": "roberts s",
    "codigo": "R647"
  },
  {
    "nome": "roberts w",
    "codigo": "R648"
  },
  {
    "nome": "robertson",
    "codigo": "R649"
  },
  {
    "nome": "robertson j",
    "codigo": "R651"
  },
  {
    "nome": "robertson s",
    "codigo": "R652"
  },
  {
    "nome": "robes",
    "codigo": "R653"
  },
  {
    "nome": "robi",
    "codigo": "R654"
  },
  {
    "nome": "robin",
    "codigo": "R655"
  },
  {
    "nome": "robine",
    "codigo": "R656"
  },
  {
    "nome": "robins",
    "codigo": "R657"
  },
  {
    "nome": "robinson",
    "codigo": "R658"
  },
  {
    "nome": "robinson d",
    "codigo": "R659"
  },
  {
    "nome": "robinson g",
    "codigo": "R661"
  },
  {
    "nome": "robinson j",
    "codigo": "R662"
  },
  {
    "nome": "robinson m",
    "codigo": "R663"
  },
  {
    "nome": "robinson s",
    "codigo": "R664"
  },
  {
    "nome": "robinson t",
    "codigo": "R665"
  },
  {
    "nome": "robinson w",
    "codigo": "R666"
  },
  {
    "nome": "robs",
    "codigo": "R667"
  },
  {
    "nome": "roby",
    "codigo": "R668"
  },
  {
    "nome": "roc",
    "codigo": "R669"
  },
  {
    "nome": "rocc",
    "codigo": "R671"
  },
  {
    "nome": "roch",
    "codigo": "R672"
  },
  {
    "nome": "roche",
    "codigo": "R673"
  },
  {
    "nome": "rochef",
    "codigo": "R674"
  },
  {
    "nome": "rochem",
    "codigo": "R675"
  },
  {
    "nome": "roches",
    "codigo": "R676"
  },
  {
    "nome": "rochet",
    "codigo": "R677"
  },
  {
    "nome": "rochf",
    "codigo": "R678"
  },
  {
    "nome": "rochm",
    "codigo": "R679"
  },
  {
    "nome": "rocho",
    "codigo": "R681"
  },
  {
    "nome": "rock",
    "codigo": "R682"
  },
  {
    "nome": "rocki",
    "codigo": "R683"
  },
  {
    "nome": "rockw",
    "codigo": "R684"
  },
  {
    "nome": "rod",
    "codigo": "R685"
  },
  {
    "nome": "rodd",
    "codigo": "R686"
  },
  {
    "nome": "rode",
    "codigo": "R687"
  },
  {
    "nome": "roder",
    "codigo": "R688"
  },
  {
    "nome": "rodew",
    "codigo": "R689"
  },
  {
    "nome": "rodg",
    "codigo": "R691"
  },
  {
    "nome": "rodi",
    "codigo": "R692"
  },
  {
    "nome": "rodm",
    "codigo": "R693"
  },
  {
    "nome": "rodn",
    "codigo": "R694"
  },
  {
    "nome": "rodo",
    "codigo": "R695"
  },
  {
    "nome": "rodr",
    "codigo": "R696"
  },
  {
    "nome": "rodw",
    "codigo": "R697"
  },
  {
    "nome": "roe",
    "codigo": "R698"
  },
  {
    "nome": "roe m",
    "codigo": "R699"
  },
  {
    "nome": "roeb",
    "codigo": "R711"
  },
  {
    "nome": "roed",
    "codigo": "R712"
  },
  {
    "nome": "roeh",
    "codigo": "R713"
  },
  {
    "nome": "roel",
    "codigo": "R714"
  },
  {
    "nome": "roem",
    "codigo": "R715"
  },
  {
    "nome": "roep",
    "codigo": "R716"
  },
  {
    "nome": "roer",
    "codigo": "R717"
  },
  {
    "nome": "roes",
    "codigo": "R718"
  },
  {
    "nome": "roet",
    "codigo": "R719"
  },
  {
    "nome": "rog",
    "codigo": "R721"
  },
  {
    "nome": "roger",
    "codigo": "R722"
  },
  {
    "nome": "roger m",
    "codigo": "R723"
  },
  {
    "nome": "rogers",
    "codigo": "R724"
  },
  {
    "nome": "rogers d",
    "codigo": "R725"
  },
  {
    "nome": "rogers g",
    "codigo": "R726"
  },
  {
    "nome": "rogers j",
    "codigo": "R727"
  },
  {
    "nome": "rogers m",
    "codigo": "R728"
  },
  {
    "nome": "rogers s",
    "codigo": "R729"
  },
  {
    "nome": "rogers w",
    "codigo": "R731"
  },
  {
    "nome": "roget",
    "codigo": "R732"
  },
  {
    "nome": "rogg",
    "codigo": "R733"
  },
  {
    "nome": "rogi",
    "codigo": "R734"
  },
  {
    "nome": "rogn",
    "codigo": "R735"
  },
  {
    "nome": "rogu",
    "codigo": "R736"
  },
  {
    "nome": "roh",
    "codigo": "R737"
  },
  {
    "nome": "rohl",
    "codigo": "R738"
  },
  {
    "nome": "rohr",
    "codigo": "R739"
  },
  {
    "nome": "roi",
    "codigo": "R741"
  },
  {
    "nome": "rok",
    "codigo": "R742"
  },
  {
    "nome": "roko",
    "codigo": "R743"
  },
  {
    "nome": "rol",
    "codigo": "R744"
  },
  {
    "nome": "role",
    "codigo": "R745"
  },
  {
    "nome": "rolf",
    "codigo": "R746"
  },
  {
    "nome": "rolfe m",
    "codigo": "R747"
  },
  {
    "nome": "roli",
    "codigo": "R748"
  },
  {
    "nome": "roll",
    "codigo": "R749"
  },
  {
    "nome": "rolles",
    "codigo": "R751"
  },
  {
    "nome": "rollett",
    "codigo": "R752"
  },
  {
    "nome": "rolli",
    "codigo": "R753"
  },
  {
    "nome": "rollin",
    "codigo": "R754"
  },
  {
    "nome": "rollo",
    "codigo": "R755"
  },
  {
    "nome": "rom",
    "codigo": "R756"
  },
  {
    "nome": "romai",
    "codigo": "R757"
  },
  {
    "nome": "roman",
    "codigo": "R758"
  },
  {
    "nome": "romano",
    "codigo": "R759"
  },
  {
    "nome": "romanu",
    "codigo": "R761"
  },
  {
    "nome": "romb",
    "codigo": "R762"
  },
  {
    "nome": "rome",
    "codigo": "R763"
  },
  {
    "nome": "romey",
    "codigo": "R764"
  },
  {
    "nome": "romi",
    "codigo": "R765"
  },
  {
    "nome": "romm",
    "codigo": "R766"
  },
  {
    "nome": "romu",
    "codigo": "R767"
  },
  {
    "nome": "ron",
    "codigo": "R768"
  },
  {
    "nome": "ronc",
    "codigo": "R769"
  },
  {
    "nome": "rond",
    "codigo": "R771"
  },
  {
    "nome": "rone",
    "codigo": "R772"
  },
  {
    "nome": "rong",
    "codigo": "R773"
  },
  {
    "nome": "rons",
    "codigo": "R774"
  },
  {
    "nome": "ronz",
    "codigo": "R775"
  },
  {
    "nome": "roo",
    "codigo": "R776"
  },
  {
    "nome": "rook",
    "codigo": "R777"
  },
  {
    "nome": "roop",
    "codigo": "R778"
  },
  {
    "nome": "roor",
    "codigo": "R779"
  },
  {
    "nome": "roos",
    "codigo": "R781"
  },
  {
    "nome": "root",
    "codigo": "R782"
  },
  {
    "nome": "root m",
    "codigo": "R783"
  },
  {
    "nome": "rop",
    "codigo": "R784"
  },
  {
    "nome": "ropes",
    "codigo": "R785"
  },
  {
    "nome": "roq",
    "codigo": "R786"
  },
  {
    "nome": "ror",
    "codigo": "R787"
  },
  {
    "nome": "ros",
    "codigo": "R788"
  },
  {
    "nome": "rosar",
    "codigo": "R789"
  },
  {
    "nome": "rosc",
    "codigo": "R791"
  },
  {
    "nome": "rosco",
    "codigo": "R792"
  },
  {
    "nome": "roscoe g",
    "codigo": "R793"
  },
  {
    "nome": "roscoe m",
    "codigo": "R794"
  },
  {
    "nome": "rose",
    "codigo": "R795"
  },
  {
    "nome": "rose g",
    "codigo": "R796"
  },
  {
    "nome": "rose m",
    "codigo": "R797"
  },
  {
    "nome": "roseb",
    "codigo": "R798"
  },
  {
    "nome": "rosec",
    "codigo": "R799"
  },
  {
    "nome": "rosel",
    "codigo": "R811"
  },
  {
    "nome": "rosem",
    "codigo": "R812"
  },
  {
    "nome": "rosen",
    "codigo": "R813"
  },
  {
    "nome": "rosenk",
    "codigo": "R814"
  },
  {
    "nome": "rosenn",
    "codigo": "R815"
  },
  {
    "nome": "rosenw",
    "codigo": "R816"
  },
  {
    "nome": "roset",
    "codigo": "R817"
  },
  {
    "nome": "rosew",
    "codigo": "R818"
  },
  {
    "nome": "rosi",
    "codigo": "R819"
  },
  {
    "nome": "rosin",
    "codigo": "R821"
  },
  {
    "nome": "rosn",
    "codigo": "R822"
  },
  {
    "nome": "ross",
    "codigo": "R823"
  },
  {
    "nome": "ross g",
    "codigo": "R824"
  },
  {
    "nome": "ross m",
    "codigo": "R825"
  },
  {
    "nome": "ross s",
    "codigo": "R826"
  },
  {
    "nome": "ross w",
    "codigo": "R827"
  },
  {
    "nome": "rossel",
    "codigo": "R828"
  },
  {
    "nome": "rosset",
    "codigo": "R829"
  },
  {
    "nome": "rossi",
    "codigo": "R831"
  },
  {
    "nome": "rossi g",
    "codigo": "R832"
  },
  {
    "nome": "rossi m",
    "codigo": "R833"
  },
  {
    "nome": "rossig",
    "codigo": "R834"
  },
  {
    "nome": "rossin",
    "codigo": "R835"
  },
  {
    "nome": "rossl",
    "codigo": "R836"
  },
  {
    "nome": "rossm",
    "codigo": "R837"
  },
  {
    "nome": "rosso",
    "codigo": "R838"
  },
  {
    "nome": "rost",
    "codigo": "R839"
  },
  {
    "nome": "rosw",
    "codigo": "R841"
  },
  {
    "nome": "rot",
    "codigo": "R842"
  },
  {
    "nome": "rote",
    "codigo": "R843"
  },
  {
    "nome": "rotg",
    "codigo": "R844"
  },
  {
    "nome": "roth",
    "codigo": "R845"
  },
  {
    "nome": "rothen",
    "codigo": "R846"
  },
  {
    "nome": "roths",
    "codigo": "R847"
  },
  {
    "nome": "rothw",
    "codigo": "R848"
  },
  {
    "nome": "rotr",
    "codigo": "R849"
  },
  {
    "nome": "rott",
    "codigo": "R851"
  },
  {
    "nome": "rou",
    "codigo": "R852"
  },
  {
    "nome": "roub",
    "codigo": "R853"
  },
  {
    "nome": "rouc",
    "codigo": "R854"
  },
  {
    "nome": "roug",
    "codigo": "R855"
  },
  {
    "nome": "rouget",
    "codigo": "R856"
  },
  {
    "nome": "roui",
    "codigo": "R857"
  },
  {
    "nome": "rouj",
    "codigo": "R858"
  },
  {
    "nome": "roul",
    "codigo": "R859"
  },
  {
    "nome": "roup",
    "codigo": "R861"
  },
  {
    "nome": "rouq",
    "codigo": "R862"
  },
  {
    "nome": "rous",
    "codigo": "R863"
  },
  {
    "nome": "rouss",
    "codigo": "R864"
  },
  {
    "nome": "roussel",
    "codigo": "R865"
  },
  {
    "nome": "roussele",
    "codigo": "R866"
  },
  {
    "nome": "rousset",
    "codigo": "R867"
  },
  {
    "nome": "roust",
    "codigo": "R868"
  },
  {
    "nome": "rout",
    "codigo": "R869"
  },
  {
    "nome": "roux",
    "codigo": "R871"
  },
  {
    "nome": "rouy",
    "codigo": "R872"
  },
  {
    "nome": "rov",
    "codigo": "R873"
  },
  {
    "nome": "rovet",
    "codigo": "R874"
  },
  {
    "nome": "rovi",
    "codigo": "R875"
  },
  {
    "nome": "row",
    "codigo": "R876"
  },
  {
    "nome": "rowan",
    "codigo": "R877"
  },
  {
    "nome": "rowe",
    "codigo": "R878"
  },
  {
    "nome": "rowe m",
    "codigo": "R879"
  },
  {
    "nome": "rowel",
    "codigo": "R881"
  },
  {
    "nome": "rowi",
    "codigo": "R882"
  },
  {
    "nome": "rowl",
    "codigo": "R883"
  },
  {
    "nome": "rowle",
    "codigo": "R884"
  },
  {
    "nome": "rows",
    "codigo": "R885"
  },
  {
    "nome": "rox",
    "codigo": "R886"
  },
  {
    "nome": "roxb",
    "codigo": "R887"
  },
  {
    "nome": "roy",
    "codigo": "R888"
  },
  {
    "nome": "roye",
    "codigo": "R889"
  },
  {
    "nome": "royer",
    "codigo": "R891"
  },
  {
    "nome": "royo",
    "codigo": "R892"
  },
  {
    "nome": "roz",
    "codigo": "R893"
  },
  {
    "nome": "ru",
    "codigo": "R894"
  },
  {
    "nome": "ruben",
    "codigo": "R895"
  },
  {
    "nome": "rubi",
    "codigo": "R896"
  },
  {
    "nome": "rubr",
    "codigo": "R897"
  },
  {
    "nome": "ruc",
    "codigo": "R898"
  },
  {
    "nome": "ruch",
    "codigo": "R899"
  },
  {
    "nome": "ruck",
    "codigo": "R911"
  },
  {
    "nome": "ruckers",
    "codigo": "R912"
  },
  {
    "nome": "rud",
    "codigo": "R913"
  },
  {
    "nome": "rudd",
    "codigo": "R914"
  },
  {
    "nome": "rude",
    "codigo": "R915"
  },
  {
    "nome": "rudi",
    "codigo": "R916"
  },
  {
    "nome": "rudo",
    "codigo": "R917"
  },
  {
    "nome": "rue",
    "codigo": "R918"
  },
  {
    "nome": "ruef",
    "codigo": "R919"
  },
  {
    "nome": "ruel",
    "codigo": "R921"
  },
  {
    "nome": "ruf",
    "codigo": "R922"
  },
  {
    "nome": "ruffi",
    "codigo": "R923"
  },
  {
    "nome": "ruffn",
    "codigo": "R924"
  },
  {
    "nome": "ruffo",
    "codigo": "R925"
  },
  {
    "nome": "rufi",
    "codigo": "R926"
  },
  {
    "nome": "rufu",
    "codigo": "R927"
  },
  {
    "nome": "rug",
    "codigo": "R928"
  },
  {
    "nome": "rugg",
    "codigo": "R929"
  },
  {
    "nome": "ruggi",
    "codigo": "R931"
  },
  {
    "nome": "ruggl",
    "codigo": "R932"
  },
  {
    "nome": "ruh",
    "codigo": "R933"
  },
  {
    "nome": "rui",
    "codigo": "R934"
  },
  {
    "nome": "rul",
    "codigo": "R935"
  },
  {
    "nome": "rum",
    "codigo": "R936"
  },
  {
    "nome": "rumm",
    "codigo": "R937"
  },
  {
    "nome": "rums",
    "codigo": "R938"
  },
  {
    "nome": "run",
    "codigo": "R939"
  },
  {
    "nome": "rund",
    "codigo": "R941"
  },
  {
    "nome": "rung",
    "codigo": "R942"
  },
  {
    "nome": "runn",
    "codigo": "R943"
  },
  {
    "nome": "ruo",
    "codigo": "R944"
  },
  {
    "nome": "rup",
    "codigo": "R945"
  },
  {
    "nome": "rupp",
    "codigo": "R946"
  },
  {
    "nome": "rupr",
    "codigo": "R947"
  },
  {
    "nome": "rur",
    "codigo": "R948"
  },
  {
    "nome": "rus",
    "codigo": "R949"
  },
  {
    "nome": "rusch",
    "codigo": "R951"
  },
  {
    "nome": "rush",
    "codigo": "R952"
  },
  {
    "nome": "rush m",
    "codigo": "R953"
  },
  {
    "nome": "rusht",
    "codigo": "R954"
  },
  {
    "nome": "rushw",
    "codigo": "R955"
  },
  {
    "nome": "rusk",
    "codigo": "R956"
  },
  {
    "nome": "rusp",
    "codigo": "R957"
  },
  {
    "nome": "russ",
    "codigo": "R958"
  },
  {
    "nome": "russel",
    "codigo": "R959"
  },
  {
    "nome": "russell",
    "codigo": "R961"
  },
  {
    "nome": "russell d",
    "codigo": "R962"
  },
  {
    "nome": "russell f",
    "codigo": "R963"
  },
  {
    "nome": "russell j",
    "codigo": "R964"
  },
  {
    "nome": "russell m",
    "codigo": "R965"
  },
  {
    "nome": "russell p",
    "codigo": "R966"
  },
  {
    "nome": "russell s",
    "codigo": "R967"
  },
  {
    "nome": "russell w",
    "codigo": "R968"
  },
  {
    "nome": "russi",
    "codigo": "R969"
  },
  {
    "nome": "rust",
    "codigo": "R971"
  },
  {
    "nome": "rut",
    "codigo": "R972"
  },
  {
    "nome": "rutg",
    "codigo": "R973"
  },
  {
    "nome": "ruth",
    "codigo": "R974"
  },
  {
    "nome": "rutherf",
    "codigo": "R975"
  },
  {
    "nome": "ruthv",
    "codigo": "R976"
  },
  {
    "nome": "ruti",
    "codigo": "R977"
  },
  {
    "nome": "rutl",
    "codigo": "R978"
  },
  {
    "nome": "rutland m",
    "codigo": "R979"
  },
  {
    "nome": "rutledge",
    "codigo": "R981"
  },
  {
    "nome": "rutt",
    "codigo": "R982"
  },
  {
    "nome": "ruv",
    "codigo": "R983"
  },
  {
    "nome": "rux",
    "codigo": "R984"
  },
  {
    "nome": "ruy",
    "codigo": "R985"
  },
  {
    "nome": "ruyt",
    "codigo": "R986"
  },
  {
    "nome": "ruz",
    "codigo": "R987"
  },
  {
    "nome": "ry",
    "codigo": "R988"
  },
  {
    "nome": "ryan m",
    "codigo": "R989"
  },
  {
    "nome": "ryc",
    "codigo": "R991"
  },
  {
    "nome": "ryd",
    "codigo": "R992"
  },
  {
    "nome": "rye",
    "codigo": "R993"
  },
  {
    "nome": "ryl",
    "codigo": "R994"
  },
  {
    "nome": "rym",
    "codigo": "R995"
  },
  {
    "nome": "rys",
    "codigo": "R996"
  },
  {
    "nome": "ryt",
    "codigo": "R997"
  },
  {
    "nome": "ryv",
    "codigo": "R998"
  },
  {
    "nome": "rz",
    "codigo": "R999"
  },
  {
    "nome": "s",
    "codigo": "S111"
  },
  {
    "nome": "sa",
    "codigo": "S111"
  },
  {
    "nome": "saar",
    "codigo": "S112"
  },
  {
    "nome": "sab",
    "codigo": "S113"
  },
  {
    "nome": "sabb",
    "codigo": "S114"
  },
  {
    "nome": "sabe",
    "codigo": "S115"
  },
  {
    "nome": "sabi",
    "codigo": "S116"
  },
  {
    "nome": "sabl",
    "codigo": "S117"
  },
  {
    "nome": "sabr",
    "codigo": "S118"
  },
  {
    "nome": "sac",
    "codigo": "S119"
  },
  {
    "nome": "sach",
    "codigo": "S121"
  },
  {
    "nome": "saco",
    "codigo": "S122"
  },
  {
    "nome": "sacr",
    "codigo": "S123"
  },
  {
    "nome": "sad",
    "codigo": "S124"
  },
  {
    "nome": "sade",
    "codigo": "S125"
  },
  {
    "nome": "sadl",
    "codigo": "S126"
  },
  {
    "nome": "sae",
    "codigo": "S127"
  },
  {
    "nome": "saf",
    "codigo": "S128"
  },
  {
    "nome": "sag",
    "codigo": "S129"
  },
  {
    "nome": "sah",
    "codigo": "S131"
  },
  {
    "nome": "sai",
    "codigo": "S132"
  },
  {
    "nome": "saint a",
    "codigo": "S133"
  },
  {
    "nome": "saint an",
    "codigo": "S134"
  },
  {
    "nome": "saint b",
    "codigo": "S135"
  },
  {
    "nome": "saint c",
    "codigo": "S136"
  },
  {
    "nome": "saint e",
    "codigo": "S137"
  },
  {
    "nome": "saint f",
    "codigo": "S138"
  },
  {
    "nome": "saint g",
    "codigo": "S139"
  },
  {
    "nome": "saint h",
    "codigo": "S141"
  },
  {
    "nome": "saint i",
    "codigo": "S142"
  },
  {
    "nome": "saint j",
    "codigo": "S143"
  },
  {
    "nome": "saint ju",
    "codigo": "S144"
  },
  {
    "nome": "saint l",
    "codigo": "S145"
  },
  {
    "nome": "saint m",
    "codigo": "S146"
  },
  {
    "nome": "saint n",
    "codigo": "S147"
  },
  {
    "nome": "saint o",
    "codigo": "S148"
  },
  {
    "nome": "saint p",
    "codigo": "S149"
  },
  {
    "nome": "saint r",
    "codigo": "S151"
  },
  {
    "nome": "saint s",
    "codigo": "S152"
  },
  {
    "nome": "saint simon",
    "codigo": "S153"
  },
  {
    "nome": "saint u",
    "codigo": "S154"
  },
  {
    "nome": "saint v",
    "codigo": "S155"
  },
  {
    "nome": "sainte",
    "codigo": "S156"
  },
  {
    "nome": "sainte m",
    "codigo": "S157"
  },
  {
    "nome": "sais",
    "codigo": "S158"
  },
  {
    "nome": "sal",
    "codigo": "S159"
  },
  {
    "nome": "salan",
    "codigo": "S161"
  },
  {
    "nome": "sald",
    "codigo": "S162"
  },
  {
    "nome": "sale",
    "codigo": "S163"
  },
  {
    "nome": "salg",
    "codigo": "S164"
  },
  {
    "nome": "sali",
    "codigo": "S165"
  },
  {
    "nome": "salis",
    "codigo": "S166"
  },
  {
    "nome": "salisbury",
    "codigo": "S167"
  },
  {
    "nome": "sall",
    "codigo": "S168"
  },
  {
    "nome": "sallo",
    "codigo": "S169"
  },
  {
    "nome": "salm",
    "codigo": "S171"
  },
  {
    "nome": "salmon",
    "codigo": "S172"
  },
  {
    "nome": "salo",
    "codigo": "S173"
  },
  {
    "nome": "salomon",
    "codigo": "S174"
  },
  {
    "nome": "salon",
    "codigo": "S175"
  },
  {
    "nome": "salt",
    "codigo": "S176"
  },
  {
    "nome": "salter",
    "codigo": "S177"
  },
  {
    "nome": "saltm",
    "codigo": "S178"
  },
  {
    "nome": "salto",
    "codigo": "S179"
  },
  {
    "nome": "salu",
    "codigo": "S181"
  },
  {
    "nome": "salv",
    "codigo": "S182"
  },
  {
    "nome": "salve",
    "codigo": "S183"
  },
  {
    "nome": "salvi",
    "codigo": "S184"
  },
  {
    "nome": "salvin",
    "codigo": "S185"
  },
  {
    "nome": "salvo",
    "codigo": "S186"
  },
  {
    "nome": "sam",
    "codigo": "S187"
  },
  {
    "nome": "samh",
    "codigo": "S188"
  },
  {
    "nome": "samm",
    "codigo": "S189"
  },
  {
    "nome": "samo",
    "codigo": "S191"
  },
  {
    "nome": "samp",
    "codigo": "S192"
  },
  {
    "nome": "sams",
    "codigo": "S193"
  },
  {
    "nome": "san",
    "codigo": "S194"
  },
  {
    "nome": "san f",
    "codigo": "S195"
  },
  {
    "nome": "san l",
    "codigo": "S196"
  },
  {
    "nome": "san s",
    "codigo": "S197"
  },
  {
    "nome": "sanb",
    "codigo": "S198"
  },
  {
    "nome": "sanc",
    "codigo": "S199"
  },
  {
    "nome": "sanch",
    "codigo": "S211"
  },
  {
    "nome": "sancr",
    "codigo": "S212"
  },
  {
    "nome": "sand",
    "codigo": "S213"
  },
  {
    "nome": "sande",
    "codigo": "S214"
  },
  {
    "nome": "sanders",
    "codigo": "S215"
  },
  {
    "nome": "sanderson",
    "codigo": "S216"
  },
  {
    "nome": "sandf",
    "codigo": "S217"
  },
  {
    "nome": "sando",
    "codigo": "S218"
  },
  {
    "nome": "sandr",
    "codigo": "S219"
  },
  {
    "nome": "sands",
    "codigo": "S221"
  },
  {
    "nome": "sandy",
    "codigo": "S222"
  },
  {
    "nome": "sane",
    "codigo": "S223"
  },
  {
    "nome": "sanf",
    "codigo": "S224"
  },
  {
    "nome": "sang",
    "codigo": "S225"
  },
  {
    "nome": "sangr",
    "codigo": "S226"
  },
  {
    "nome": "sani",
    "codigo": "S227"
  },
  {
    "nome": "sann",
    "codigo": "S228"
  },
  {
    "nome": "sans",
    "codigo": "S229"
  },
  {
    "nome": "sant",
    "codigo": "S231"
  },
  {
    "nome": "santag",
    "codigo": "S232"
  },
  {
    "nome": "santar",
    "codigo": "S233"
  },
  {
    "nome": "sante",
    "codigo": "S234"
  },
  {
    "nome": "santi",
    "codigo": "S235"
  },
  {
    "nome": "santis",
    "codigo": "S236"
  },
  {
    "nome": "santo",
    "codigo": "S237"
  },
  {
    "nome": "sanu",
    "codigo": "S238"
  },
  {
    "nome": "sao",
    "codigo": "S239"
  },
  {
    "nome": "sap",
    "codigo": "S241"
  },
  {
    "nome": "saq",
    "codigo": "S242"
  },
  {
    "nome": "sar",
    "codigo": "S243"
  },
  {
    "nome": "sard",
    "codigo": "S244"
  },
  {
    "nome": "sarg",
    "codigo": "S245"
  },
  {
    "nome": "sarm",
    "codigo": "S246"
  },
  {
    "nome": "sarr",
    "codigo": "S247"
  },
  {
    "nome": "sars",
    "codigo": "S248"
  },
  {
    "nome": "sart",
    "codigo": "S249"
  },
  {
    "nome": "sarto",
    "codigo": "S251"
  },
  {
    "nome": "sas",
    "codigo": "S252"
  },
  {
    "nome": "sat",
    "codigo": "S253"
  },
  {
    "nome": "satu",
    "codigo": "S254"
  },
  {
    "nome": "sau",
    "codigo": "S255"
  },
  {
    "nome": "saul",
    "codigo": "S256"
  },
  {
    "nome": "saun",
    "codigo": "S257"
  },
  {
    "nome": "saup",
    "codigo": "S258"
  },
  {
    "nome": "saur",
    "codigo": "S259"
  },
  {
    "nome": "saut",
    "codigo": "S261"
  },
  {
    "nome": "sauv",
    "codigo": "S262"
  },
  {
    "nome": "sav",
    "codigo": "S263"
  },
  {
    "nome": "savage j",
    "codigo": "S264"
  },
  {
    "nome": "savar",
    "codigo": "S265"
  },
  {
    "nome": "savas",
    "codigo": "S266"
  },
  {
    "nome": "savi",
    "codigo": "S267"
  },
  {
    "nome": "savo",
    "codigo": "S268"
  },
  {
    "nome": "savot",
    "codigo": "S269"
  },
  {
    "nome": "saw",
    "codigo": "S271"
  },
  {
    "nome": "sax",
    "codigo": "S272"
  },
  {
    "nome": "saxo",
    "codigo": "S273"
  },
  {
    "nome": "say",
    "codigo": "S274"
  },
  {
    "nome": "sayl",
    "codigo": "S275"
  },
  {
    "nome": "sba",
    "codigo": "S276"
  },
  {
    "nome": "sca",
    "codigo": "S277"
  },
  {
    "nome": "scae",
    "codigo": "S278"
  },
  {
    "nome": "scal",
    "codigo": "S279"
  },
  {
    "nome": "scalab",
    "codigo": "S281"
  },
  {
    "nome": "scali",
    "codigo": "S282"
  },
  {
    "nome": "scam",
    "codigo": "S283"
  },
  {
    "nome": "scap",
    "codigo": "S284"
  },
  {
    "nome": "scar",
    "codigo": "S285"
  },
  {
    "nome": "scarl",
    "codigo": "S286"
  },
  {
    "nome": "scars",
    "codigo": "S287"
  },
  {
    "nome": "scav",
    "codigo": "S288"
  },
  {
    "nome": "sce",
    "codigo": "S289"
  },
  {
    "nome": "sch",
    "codigo": "S291"
  },
  {
    "nome": "schad",
    "codigo": "S292"
  },
  {
    "nome": "schae",
    "codigo": "S293"
  },
  {
    "nome": "schaef",
    "codigo": "S294"
  },
  {
    "nome": "schaer",
    "codigo": "S295"
  },
  {
    "nome": "schaf",
    "codigo": "S296"
  },
  {
    "nome": "schal",
    "codigo": "S297"
  },
  {
    "nome": "schall",
    "codigo": "S298"
  },
  {
    "nome": "scham",
    "codigo": "S299"
  },
  {
    "nome": "schar",
    "codigo": "S311"
  },
  {
    "nome": "schat",
    "codigo": "S312"
  },
  {
    "nome": "schau",
    "codigo": "S313"
  },
  {
    "nome": "sche",
    "codigo": "S314"
  },
  {
    "nome": "sched",
    "codigo": "S315"
  },
  {
    "nome": "schef",
    "codigo": "S316"
  },
  {
    "nome": "scheffer j",
    "codigo": "S317"
  },
  {
    "nome": "schei",
    "codigo": "S318"
  },
  {
    "nome": "scheif",
    "codigo": "S319"
  },
  {
    "nome": "scheit",
    "codigo": "S321"
  },
  {
    "nome": "schel",
    "codigo": "S322"
  },
  {
    "nome": "schem",
    "codigo": "S323"
  },
  {
    "nome": "schen",
    "codigo": "S324"
  },
  {
    "nome": "schep",
    "codigo": "S325"
  },
  {
    "nome": "scher",
    "codigo": "S326"
  },
  {
    "nome": "schet",
    "codigo": "S327"
  },
  {
    "nome": "scheu",
    "codigo": "S328"
  },
  {
    "nome": "schi",
    "codigo": "S329"
  },
  {
    "nome": "schick",
    "codigo": "S331"
  },
  {
    "nome": "schie",
    "codigo": "S332"
  },
  {
    "nome": "schif",
    "codigo": "S333"
  },
  {
    "nome": "schil",
    "codigo": "S334"
  },
  {
    "nome": "schim",
    "codigo": "S335"
  },
  {
    "nome": "schin",
    "codigo": "S336"
  },
  {
    "nome": "schir",
    "codigo": "S337"
  },
  {
    "nome": "schl",
    "codigo": "S338"
  },
  {
    "nome": "schle",
    "codigo": "S339"
  },
  {
    "nome": "schlei",
    "codigo": "S341"
  },
  {
    "nome": "schles",
    "codigo": "S342"
  },
  {
    "nome": "schleu",
    "codigo": "S343"
  },
  {
    "nome": "schli",
    "codigo": "S344"
  },
  {
    "nome": "schlo",
    "codigo": "S345"
  },
  {
    "nome": "schlu",
    "codigo": "S346"
  },
  {
    "nome": "schm",
    "codigo": "S347"
  },
  {
    "nome": "schmi",
    "codigo": "S348"
  },
  {
    "nome": "schmidt",
    "codigo": "S349"
  },
  {
    "nome": "schmidt f",
    "codigo": "S351"
  },
  {
    "nome": "schmidt j",
    "codigo": "S352"
  },
  {
    "nome": "schmidt l",
    "codigo": "S353"
  },
  {
    "nome": "schmidt s",
    "codigo": "S354"
  },
  {
    "nome": "schmit",
    "codigo": "S355"
  },
  {
    "nome": "schmo",
    "codigo": "S356"
  },
  {
    "nome": "schn",
    "codigo": "S357"
  },
  {
    "nome": "schne",
    "codigo": "S358"
  },
  {
    "nome": "schneider j",
    "codigo": "S359"
  },
  {
    "nome": "schni",
    "codigo": "S361"
  },
  {
    "nome": "schno",
    "codigo": "S362"
  },
  {
    "nome": "scho",
    "codigo": "S363"
  },
  {
    "nome": "schoe",
    "codigo": "S364"
  },
  {
    "nome": "schoeln",
    "codigo": "S366"
  },
  {
    "nome": "schoen",
    "codigo": "S365"
  },
  {
    "nome": "schoep",
    "codigo": "S367"
  },
  {
    "nome": "schol",
    "codigo": "S368"
  },
  {
    "nome": "schom",
    "codigo": "S369"
  },
  {
    "nome": "schon",
    "codigo": "S371"
  },
  {
    "nome": "schoo",
    "codigo": "S372"
  },
  {
    "nome": "schop",
    "codigo": "S373"
  },
  {
    "nome": "schor",
    "codigo": "S374"
  },
  {
    "nome": "schot",
    "codigo": "S375"
  },
  {
    "nome": "schou",
    "codigo": "S376"
  },
  {
    "nome": "schra",
    "codigo": "S377"
  },
  {
    "nome": "schrei",
    "codigo": "S378"
  },
  {
    "nome": "schrey",
    "codigo": "S379"
  },
  {
    "nome": "schro",
    "codigo": "S381"
  },
  {
    "nome": "schroet",
    "codigo": "S382"
  },
  {
    "nome": "schu",
    "codigo": "S383"
  },
  {
    "nome": "schube",
    "codigo": "S384"
  },
  {
    "nome": "schue",
    "codigo": "S385"
  },
  {
    "nome": "schul",
    "codigo": "S386"
  },
  {
    "nome": "schultz",
    "codigo": "S387"
  },
  {
    "nome": "schulz",
    "codigo": "S388"
  },
  {
    "nome": "schulz j",
    "codigo": "S389"
  },
  {
    "nome": "schulze",
    "codigo": "S391"
  },
  {
    "nome": "schum",
    "codigo": "S392"
  },
  {
    "nome": "schun",
    "codigo": "S393"
  },
  {
    "nome": "schur",
    "codigo": "S394"
  },
  {
    "nome": "schus",
    "codigo": "S395"
  },
  {
    "nome": "schut",
    "codigo": "S396"
  },
  {
    "nome": "schuy",
    "codigo": "S397"
  },
  {
    "nome": "schw",
    "codigo": "S398"
  },
  {
    "nome": "schwar",
    "codigo": "S399"
  },
  {
    "nome": "schwarz",
    "codigo": "S411"
  },
  {
    "nome": "schwe",
    "codigo": "S412"
  },
  {
    "nome": "schwei",
    "codigo": "S413"
  },
  {
    "nome": "schwem",
    "codigo": "S414"
  },
  {
    "nome": "schwer",
    "codigo": "S415"
  },
  {
    "nome": "sci",
    "codigo": "S416"
  },
  {
    "nome": "scin",
    "codigo": "S417"
  },
  {
    "nome": "scip",
    "codigo": "S418"
  },
  {
    "nome": "scir",
    "codigo": "S419"
  },
  {
    "nome": "sco",
    "codigo": "S421"
  },
  {
    "nome": "scog",
    "codigo": "S422"
  },
  {
    "nome": "scor",
    "codigo": "S423"
  },
  {
    "nome": "scot",
    "codigo": "S424"
  },
  {
    "nome": "scott",
    "codigo": "S425"
  },
  {
    "nome": "scott g",
    "codigo": "S426"
  },
  {
    "nome": "scott j",
    "codigo": "S427"
  },
  {
    "nome": "scott m",
    "codigo": "S428"
  },
  {
    "nome": "scott s",
    "codigo": "S429"
  },
  {
    "nome": "scott w",
    "codigo": "S431"
  },
  {
    "nome": "scou",
    "codigo": "S432"
  },
  {
    "nome": "scr",
    "codigo": "S433"
  },
  {
    "nome": "scri",
    "codigo": "S434"
  },
  {
    "nome": "scro",
    "codigo": "S435"
  },
  {
    "nome": "scu",
    "codigo": "S436"
  },
  {
    "nome": "scul",
    "codigo": "S437"
  },
  {
    "nome": "sea",
    "codigo": "S438"
  },
  {
    "nome": "sear",
    "codigo": "S439"
  },
  {
    "nome": "seat",
    "codigo": "S441"
  },
  {
    "nome": "seav",
    "codigo": "S442"
  },
  {
    "nome": "seb",
    "codigo": "S443"
  },
  {
    "nome": "sec",
    "codigo": "S444"
  },
  {
    "nome": "seco",
    "codigo": "S445"
  },
  {
    "nome": "secr",
    "codigo": "S446"
  },
  {
    "nome": "sed",
    "codigo": "S447"
  },
  {
    "nome": "sedg",
    "codigo": "S448"
  },
  {
    "nome": "sedl",
    "codigo": "S449"
  },
  {
    "nome": "see",
    "codigo": "S451"
  },
  {
    "nome": "seel",
    "codigo": "S452"
  },
  {
    "nome": "seem",
    "codigo": "S453"
  },
  {
    "nome": "seg",
    "codigo": "S454"
  },
  {
    "nome": "segr",
    "codigo": "S455"
  },
  {
    "nome": "segu",
    "codigo": "S456"
  },
  {
    "nome": "sei",
    "codigo": "S457"
  },
  {
    "nome": "seid",
    "codigo": "S458"
  },
  {
    "nome": "seif",
    "codigo": "S459"
  },
  {
    "nome": "seil",
    "codigo": "S461"
  },
  {
    "nome": "seis",
    "codigo": "S462"
  },
  {
    "nome": "sej",
    "codigo": "S463"
  },
  {
    "nome": "sel",
    "codigo": "S464"
  },
  {
    "nome": "self",
    "codigo": "S465"
  },
  {
    "nome": "selk",
    "codigo": "S466"
  },
  {
    "nome": "sell",
    "codigo": "S467"
  },
  {
    "nome": "sello",
    "codigo": "S468"
  },
  {
    "nome": "selv",
    "codigo": "S469"
  },
  {
    "nome": "sem",
    "codigo": "S471"
  },
  {
    "nome": "seml",
    "codigo": "S472"
  },
  {
    "nome": "semp",
    "codigo": "S473"
  },
  {
    "nome": "sen",
    "codigo": "S474"
  },
  {
    "nome": "sene",
    "codigo": "S475"
  },
  {
    "nome": "senf",
    "codigo": "S476"
  },
  {
    "nome": "seni",
    "codigo": "S477"
  },
  {
    "nome": "senn",
    "codigo": "S478"
  },
  {
    "nome": "sep",
    "codigo": "S479"
  },
  {
    "nome": "ser",
    "codigo": "S481"
  },
  {
    "nome": "seras",
    "codigo": "S482"
  },
  {
    "nome": "sere",
    "codigo": "S483"
  },
  {
    "nome": "serg",
    "codigo": "S484"
  },
  {
    "nome": "seri",
    "codigo": "S485"
  },
  {
    "nome": "serm",
    "codigo": "S486"
  },
  {
    "nome": "serr",
    "codigo": "S487"
  },
  {
    "nome": "serre",
    "codigo": "S488"
  },
  {
    "nome": "serro",
    "codigo": "S489"
  },
  {
    "nome": "serv",
    "codigo": "S491"
  },
  {
    "nome": "servin",
    "codigo": "S492"
  },
  {
    "nome": "ses",
    "codigo": "S493"
  },
  {
    "nome": "sest",
    "codigo": "S494"
  },
  {
    "nome": "set",
    "codigo": "S495"
  },
  {
    "nome": "seu",
    "codigo": "S496"
  },
  {
    "nome": "sev",
    "codigo": "S497"
  },
  {
    "nome": "sever",
    "codigo": "S498"
  },
  {
    "nome": "severus",
    "codigo": "S499"
  },
  {
    "nome": "sevi",
    "codigo": "S511"
  },
  {
    "nome": "sew",
    "codigo": "S512"
  },
  {
    "nome": "sewall s",
    "codigo": "S513"
  },
  {
    "nome": "seward",
    "codigo": "S514"
  },
  {
    "nome": "sewel",
    "codigo": "S515"
  },
  {
    "nome": "sewell",
    "codigo": "S516"
  },
  {
    "nome": "sewell s",
    "codigo": "S517"
  },
  {
    "nome": "sex",
    "codigo": "S518"
  },
  {
    "nome": "sey",
    "codigo": "S519"
  },
  {
    "nome": "seym",
    "codigo": "S521"
  },
  {
    "nome": "seyt",
    "codigo": "S522"
  },
  {
    "nome": "sfo",
    "codigo": "S523"
  },
  {
    "nome": "sha",
    "codigo": "S524"
  },
  {
    "nome": "shaf",
    "codigo": "S525"
  },
  {
    "nome": "shai",
    "codigo": "S526"
  },
  {
    "nome": "shak",
    "codigo": "S527"
  },
  {
    "nome": "shal",
    "codigo": "S528"
  },
  {
    "nome": "shap",
    "codigo": "S529"
  },
  {
    "nome": "shar",
    "codigo": "S531"
  },
  {
    "nome": "sharpe",
    "codigo": "S532"
  },
  {
    "nome": "shat",
    "codigo": "S533"
  },
  {
    "nome": "shaw",
    "codigo": "S534"
  },
  {
    "nome": "shaw l",
    "codigo": "S535"
  },
  {
    "nome": "shaw s",
    "codigo": "S536"
  },
  {
    "nome": "shaw w",
    "codigo": "S537"
  },
  {
    "nome": "shay",
    "codigo": "S538"
  },
  {
    "nome": "she",
    "codigo": "S539"
  },
  {
    "nome": "shed",
    "codigo": "S541"
  },
  {
    "nome": "shef",
    "codigo": "S542"
  },
  {
    "nome": "shei",
    "codigo": "S543"
  },
  {
    "nome": "shel",
    "codigo": "S544"
  },
  {
    "nome": "shelley",
    "codigo": "S545"
  },
  {
    "nome": "shen",
    "codigo": "S546"
  },
  {
    "nome": "shep",
    "codigo": "S547"
  },
  {
    "nome": "sheph",
    "codigo": "S548"
  },
  {
    "nome": "shepp",
    "codigo": "S549"
  },
  {
    "nome": "sher",
    "codigo": "S551"
  },
  {
    "nome": "sheri",
    "codigo": "S552"
  },
  {
    "nome": "sherm",
    "codigo": "S553"
  },
  {
    "nome": "sherw",
    "codigo": "S554"
  },
  {
    "nome": "shi",
    "codigo": "S555"
  },
  {
    "nome": "shil",
    "codigo": "S556"
  },
  {
    "nome": "ship",
    "codigo": "S557"
  },
  {
    "nome": "shir",
    "codigo": "S558"
  },
  {
    "nome": "sho",
    "codigo": "S559"
  },
  {
    "nome": "shr",
    "codigo": "S561"
  },
  {
    "nome": "shu",
    "codigo": "S562"
  },
  {
    "nome": "sib",
    "codigo": "S563"
  },
  {
    "nome": "sibl",
    "codigo": "S564"
  },
  {
    "nome": "sic",
    "codigo": "S565"
  },
  {
    "nome": "sici",
    "codigo": "S566"
  },
  {
    "nome": "sico",
    "codigo": "S567"
  },
  {
    "nome": "sid",
    "codigo": "S568"
  },
  {
    "nome": "sidn",
    "codigo": "S569"
  },
  {
    "nome": "sie",
    "codigo": "S571"
  },
  {
    "nome": "sien",
    "codigo": "S572"
  },
  {
    "nome": "sies",
    "codigo": "S573"
  },
  {
    "nome": "sig",
    "codigo": "S574"
  },
  {
    "nome": "sigf",
    "codigo": "S575"
  },
  {
    "nome": "sigi",
    "codigo": "S576"
  },
  {
    "nome": "sigis",
    "codigo": "S577"
  },
  {
    "nome": "sign",
    "codigo": "S578"
  },
  {
    "nome": "sigu",
    "codigo": "S579"
  },
  {
    "nome": "sil",
    "codigo": "S581"
  },
  {
    "nome": "silb",
    "codigo": "S582"
  },
  {
    "nome": "sili",
    "codigo": "S583"
  },
  {
    "nome": "sill",
    "codigo": "S584"
  },
  {
    "nome": "silo",
    "codigo": "S585"
  },
  {
    "nome": "silv",
    "codigo": "S586"
  },
  {
    "nome": "silve",
    "codigo": "S587"
  },
  {
    "nome": "sim",
    "codigo": "S588"
  },
  {
    "nome": "sime",
    "codigo": "S589"
  },
  {
    "nome": "siml",
    "codigo": "S591"
  },
  {
    "nome": "simm",
    "codigo": "S592"
  },
  {
    "nome": "simo",
    "codigo": "S593"
  },
  {
    "nome": "simon",
    "codigo": "S594"
  },
  {
    "nome": "simon j",
    "codigo": "S595"
  },
  {
    "nome": "simon p",
    "codigo": "S596"
  },
  {
    "nome": "simond",
    "codigo": "S597"
  },
  {
    "nome": "simone",
    "codigo": "S598"
  },
  {
    "nome": "simoni",
    "codigo": "S599"
  },
  {
    "nome": "simons",
    "codigo": "S611"
  },
  {
    "nome": "simp",
    "codigo": "S612"
  },
  {
    "nome": "simps",
    "codigo": "S613"
  },
  {
    "nome": "sims",
    "codigo": "S614"
  },
  {
    "nome": "sin",
    "codigo": "S615"
  },
  {
    "nome": "sincl",
    "codigo": "S616"
  },
  {
    "nome": "sing",
    "codigo": "S617"
  },
  {
    "nome": "sins",
    "codigo": "S618"
  },
  {
    "nome": "sir",
    "codigo": "S619"
  },
  {
    "nome": "sirm",
    "codigo": "S621"
  },
  {
    "nome": "sis",
    "codigo": "S622"
  },
  {
    "nome": "sism",
    "codigo": "S623"
  },
  {
    "nome": "siv",
    "codigo": "S624"
  },
  {
    "nome": "six",
    "codigo": "S625"
  },
  {
    "nome": "ska",
    "codigo": "S626"
  },
  {
    "nome": "ske",
    "codigo": "S627"
  },
  {
    "nome": "ski",
    "codigo": "S628"
  },
  {
    "nome": "skr",
    "codigo": "S629"
  },
  {
    "nome": "sla",
    "codigo": "S631"
  },
  {
    "nome": "sle",
    "codigo": "S632"
  },
  {
    "nome": "sli",
    "codigo": "S633"
  },
  {
    "nome": "slo",
    "codigo": "S634"
  },
  {
    "nome": "sma",
    "codigo": "S635"
  },
  {
    "nome": "smar",
    "codigo": "S636"
  },
  {
    "nome": "sme",
    "codigo": "S637"
  },
  {
    "nome": "smel",
    "codigo": "S638"
  },
  {
    "nome": "smi",
    "codigo": "S639"
  },
  {
    "nome": "smil",
    "codigo": "S641"
  },
  {
    "nome": "smit",
    "codigo": "S642"
  },
  {
    "nome": "smith b",
    "codigo": "S643"
  },
  {
    "nome": "smith c",
    "codigo": "S644"
  },
  {
    "nome": "smith d",
    "codigo": "S645"
  },
  {
    "nome": "smith e",
    "codigo": "S646"
  },
  {
    "nome": "smith f",
    "codigo": "S647"
  },
  {
    "nome": "smith g",
    "codigo": "S648"
  },
  {
    "nome": "smith h",
    "codigo": "S649"
  },
  {
    "nome": "smith j",
    "codigo": "S651"
  },
  {
    "nome": "smith john",
    "codigo": "S652"
  },
  {
    "nome": "smith jos",
    "codigo": "S653"
  },
  {
    "nome": "smith l",
    "codigo": "S654"
  },
  {
    "nome": "smith m",
    "codigo": "S655"
  },
  {
    "nome": "smith o",
    "codigo": "S656"
  },
  {
    "nome": "smith r",
    "codigo": "S657"
  },
  {
    "nome": "smith robert",
    "codigo": "S658"
  },
  {
    "nome": "smith s",
    "codigo": "S659"
  },
  {
    "nome": "smith sol",
    "codigo": "S661"
  },
  {
    "nome": "smith t",
    "codigo": "S662"
  },
  {
    "nome": "smith w",
    "codigo": "S663"
  },
  {
    "nome": "smith wm",
    "codigo": "S664"
  },
  {
    "nome": "smits",
    "codigo": "S665"
  },
  {
    "nome": "smo",
    "codigo": "S666"
  },
  {
    "nome": "smy",
    "codigo": "S667"
  },
  {
    "nome": "smythe",
    "codigo": "S668"
  },
  {
    "nome": "sna",
    "codigo": "S669"
  },
  {
    "nome": "sne",
    "codigo": "S671"
  },
  {
    "nome": "sni",
    "codigo": "S672"
  },
  {
    "nome": "sno",
    "codigo": "S673"
  },
  {
    "nome": "snow",
    "codigo": "S674"
  },
  {
    "nome": "sny",
    "codigo": "S675"
  },
  {
    "nome": "soa",
    "codigo": "S676"
  },
  {
    "nome": "sob",
    "codigo": "S677"
  },
  {
    "nome": "soc",
    "codigo": "S678"
  },
  {
    "nome": "sod",
    "codigo": "S679"
  },
  {
    "nome": "soe",
    "codigo": "S681"
  },
  {
    "nome": "sog",
    "codigo": "S682"
  },
  {
    "nome": "soi",
    "codigo": "S683"
  },
  {
    "nome": "sol",
    "codigo": "S684"
  },
  {
    "nome": "sole",
    "codigo": "S685"
  },
  {
    "nome": "soli",
    "codigo": "S686"
  },
  {
    "nome": "solis",
    "codigo": "S687"
  },
  {
    "nome": "soll",
    "codigo": "S688"
  },
  {
    "nome": "solo",
    "codigo": "S689"
  },
  {
    "nome": "solt",
    "codigo": "S691"
  },
  {
    "nome": "soly",
    "codigo": "S692"
  },
  {
    "nome": "som",
    "codigo": "S693"
  },
  {
    "nome": "somer",
    "codigo": "S694"
  },
  {
    "nome": "somers",
    "codigo": "S695"
  },
  {
    "nome": "somerv",
    "codigo": "S696"
  },
  {
    "nome": "somm",
    "codigo": "S697"
  },
  {
    "nome": "son",
    "codigo": "S698"
  },
  {
    "nome": "sonn",
    "codigo": "S699"
  },
  {
    "nome": "soo",
    "codigo": "S711"
  },
  {
    "nome": "sop",
    "codigo": "S712"
  },
  {
    "nome": "sor",
    "codigo": "S713"
  },
  {
    "nome": "sori",
    "codigo": "S714"
  },
  {
    "nome": "sos",
    "codigo": "S715"
  },
  {
    "nome": "sost",
    "codigo": "S716"
  },
  {
    "nome": "sot",
    "codigo": "S717"
  },
  {
    "nome": "soto",
    "codigo": "S718"
  },
  {
    "nome": "sou",
    "codigo": "S719"
  },
  {
    "nome": "souf",
    "codigo": "S721"
  },
  {
    "nome": "soul",
    "codigo": "S722"
  },
  {
    "nome": "souli",
    "codigo": "S723"
  },
  {
    "nome": "soum",
    "codigo": "S724"
  },
  {
    "nome": "sous",
    "codigo": "S725"
  },
  {
    "nome": "sout",
    "codigo": "S726"
  },
  {
    "nome": "southe",
    "codigo": "S727"
  },
  {
    "nome": "southw",
    "codigo": "S728"
  },
  {
    "nome": "souv",
    "codigo": "S729"
  },
  {
    "nome": "sow",
    "codigo": "S731"
  },
  {
    "nome": "spa",
    "codigo": "S732"
  },
  {
    "nome": "spaf",
    "codigo": "S733"
  },
  {
    "nome": "spal",
    "codigo": "S734"
  },
  {
    "nome": "span",
    "codigo": "S735"
  },
  {
    "nome": "spar",
    "codigo": "S736"
  },
  {
    "nome": "sparr",
    "codigo": "S737"
  },
  {
    "nome": "spat",
    "codigo": "S738"
  },
  {
    "nome": "spau",
    "codigo": "S739"
  },
  {
    "nome": "spe",
    "codigo": "S741"
  },
  {
    "nome": "spee",
    "codigo": "S742"
  },
  {
    "nome": "spel",
    "codigo": "S743"
  },
  {
    "nome": "spen",
    "codigo": "S744"
  },
  {
    "nome": "spencer",
    "codigo": "S745"
  },
  {
    "nome": "spencer s",
    "codigo": "S746"
  },
  {
    "nome": "spene",
    "codigo": "S747"
  },
  {
    "nome": "spens",
    "codigo": "S748"
  },
  {
    "nome": "sper",
    "codigo": "S749"
  },
  {
    "nome": "sperr",
    "codigo": "S751"
  },
  {
    "nome": "spet",
    "codigo": "S752"
  },
  {
    "nome": "sph",
    "codigo": "S753"
  },
  {
    "nome": "spi",
    "codigo": "S754"
  },
  {
    "nome": "spie",
    "codigo": "S755"
  },
  {
    "nome": "spil",
    "codigo": "S756"
  },
  {
    "nome": "spin",
    "codigo": "S757"
  },
  {
    "nome": "spino",
    "codigo": "S758"
  },
  {
    "nome": "spir",
    "codigo": "S759"
  },
  {
    "nome": "spit",
    "codigo": "S761"
  },
  {
    "nome": "spo",
    "codigo": "S762"
  },
  {
    "nome": "spon",
    "codigo": "S763"
  },
  {
    "nome": "spoo",
    "codigo": "S764"
  },
  {
    "nome": "spot",
    "codigo": "S765"
  },
  {
    "nome": "spr",
    "codigo": "S766"
  },
  {
    "nome": "spran",
    "codigo": "S767"
  },
  {
    "nome": "spre",
    "codigo": "S768"
  },
  {
    "nome": "spri",
    "codigo": "S769"
  },
  {
    "nome": "spro",
    "codigo": "S771"
  },
  {
    "nome": "spu",
    "codigo": "S772"
  },
  {
    "nome": "squ",
    "codigo": "S773"
  },
  {
    "nome": "squir",
    "codigo": "S774"
  },
  {
    "nome": "sta",
    "codigo": "S775"
  },
  {
    "nome": "stad",
    "codigo": "S776"
  },
  {
    "nome": "stadl",
    "codigo": "S777"
  },
  {
    "nome": "stae",
    "codigo": "S778"
  },
  {
    "nome": "staf",
    "codigo": "S779"
  },
  {
    "nome": "stah",
    "codigo": "S781"
  },
  {
    "nome": "stai",
    "codigo": "S782"
  },
  {
    "nome": "stam",
    "codigo": "S783"
  },
  {
    "nome": "stan",
    "codigo": "S784"
  },
  {
    "nome": "stand",
    "codigo": "S785"
  },
  {
    "nome": "stanh",
    "codigo": "S786"
  },
  {
    "nome": "stanl",
    "codigo": "S787"
  },
  {
    "nome": "stanley j",
    "codigo": "S788"
  },
  {
    "nome": "stanley s",
    "codigo": "S789"
  },
  {
    "nome": "stans",
    "codigo": "S791"
  },
  {
    "nome": "stant",
    "codigo": "S792"
  },
  {
    "nome": "stap",
    "codigo": "S793"
  },
  {
    "nome": "stapl",
    "codigo": "S794"
  },
  {
    "nome": "star",
    "codigo": "S795"
  },
  {
    "nome": "starr",
    "codigo": "S796"
  },
  {
    "nome": "stat",
    "codigo": "S797"
  },
  {
    "nome": "stau",
    "codigo": "S798"
  },
  {
    "nome": "ste",
    "codigo": "S799"
  },
  {
    "nome": "steb",
    "codigo": "S811"
  },
  {
    "nome": "sted",
    "codigo": "S812"
  },
  {
    "nome": "stee",
    "codigo": "S813"
  },
  {
    "nome": "steele",
    "codigo": "S814"
  },
  {
    "nome": "steev",
    "codigo": "S815"
  },
  {
    "nome": "stef",
    "codigo": "S816"
  },
  {
    "nome": "steffe",
    "codigo": "S817"
  },
  {
    "nome": "stei",
    "codigo": "S818"
  },
  {
    "nome": "stein",
    "codigo": "S819"
  },
  {
    "nome": "steind",
    "codigo": "S821"
  },
  {
    "nome": "steine",
    "codigo": "S822"
  },
  {
    "nome": "steinm",
    "codigo": "S823"
  },
  {
    "nome": "stel",
    "codigo": "S824"
  },
  {
    "nome": "sten",
    "codigo": "S825"
  },
  {
    "nome": "steno",
    "codigo": "S826"
  },
  {
    "nome": "step",
    "codigo": "S827"
  },
  {
    "nome": "stephen",
    "codigo": "S828"
  },
  {
    "nome": "stephen m",
    "codigo": "S829"
  },
  {
    "nome": "stephen s",
    "codigo": "S831"
  },
  {
    "nome": "stephens",
    "codigo": "S832"
  },
  {
    "nome": "stephens g",
    "codigo": "S833"
  },
  {
    "nome": "stephens l",
    "codigo": "S834"
  },
  {
    "nome": "stephens r",
    "codigo": "S835"
  },
  {
    "nome": "stephenson",
    "codigo": "S836"
  },
  {
    "nome": "stephenson r",
    "codigo": "S837"
  },
  {
    "nome": "ster",
    "codigo": "S838"
  },
  {
    "nome": "stern",
    "codigo": "S839"
  },
  {
    "nome": "stet",
    "codigo": "S841"
  },
  {
    "nome": "steu",
    "codigo": "S842"
  },
  {
    "nome": "stev",
    "codigo": "S843"
  },
  {
    "nome": "stevens",
    "codigo": "S844"
  },
  {
    "nome": "stevens m",
    "codigo": "S845"
  },
  {
    "nome": "stevens s",
    "codigo": "S846"
  },
  {
    "nome": "stevenson",
    "codigo": "S847"
  },
  {
    "nome": "stevenson m",
    "codigo": "S848"
  },
  {
    "nome": "stew",
    "codigo": "S849"
  },
  {
    "nome": "stewart m",
    "codigo": "S851"
  },
  {
    "nome": "stewart t",
    "codigo": "S852"
  },
  {
    "nome": "stey",
    "codigo": "S853"
  },
  {
    "nome": "sti",
    "codigo": "S854"
  },
  {
    "nome": "stie",
    "codigo": "S855"
  },
  {
    "nome": "stil",
    "codigo": "S856"
  },
  {
    "nome": "still",
    "codigo": "S857"
  },
  {
    "nome": "stim",
    "codigo": "S858"
  },
  {
    "nome": "stimp",
    "codigo": "S859"
  },
  {
    "nome": "stir",
    "codigo": "S861"
  },
  {
    "nome": "stit",
    "codigo": "S862"
  },
  {
    "nome": "sto",
    "codigo": "S863"
  },
  {
    "nome": "stoc",
    "codigo": "S864"
  },
  {
    "nome": "stockl",
    "codigo": "S865"
  },
  {
    "nome": "stockt",
    "codigo": "S866"
  },
  {
    "nome": "stod",
    "codigo": "S867"
  },
  {
    "nome": "stoddard m",
    "codigo": "S868"
  },
  {
    "nome": "stoddard s",
    "codigo": "S869"
  },
  {
    "nome": "stoe",
    "codigo": "S871"
  },
  {
    "nome": "stoel",
    "codigo": "S872"
  },
  {
    "nome": "stof",
    "codigo": "S873"
  },
  {
    "nome": "stok",
    "codigo": "S874"
  },
  {
    "nome": "stol",
    "codigo": "S875"
  },
  {
    "nome": "stolt",
    "codigo": "S876"
  },
  {
    "nome": "ston",
    "codigo": "S877"
  },
  {
    "nome": "stone j",
    "codigo": "S878"
  },
  {
    "nome": "stone m",
    "codigo": "S879"
  },
  {
    "nome": "stone t",
    "codigo": "S881"
  },
  {
    "nome": "stoo",
    "codigo": "S882"
  },
  {
    "nome": "stop",
    "codigo": "S883"
  },
  {
    "nome": "stor",
    "codigo": "S884"
  },
  {
    "nome": "stork",
    "codigo": "S885"
  },
  {
    "nome": "storr",
    "codigo": "S886"
  },
  {
    "nome": "story",
    "codigo": "S887"
  },
  {
    "nome": "story s",
    "codigo": "S888"
  },
  {
    "nome": "stou",
    "codigo": "S889"
  },
  {
    "nome": "stow",
    "codigo": "S891"
  },
  {
    "nome": "stowe",
    "codigo": "S892"
  },
  {
    "nome": "stowell",
    "codigo": "S893"
  },
  {
    "nome": "stra",
    "codigo": "S894"
  },
  {
    "nome": "strad",
    "codigo": "S895"
  },
  {
    "nome": "straf",
    "codigo": "S896"
  },
  {
    "nome": "stran",
    "codigo": "S897"
  },
  {
    "nome": "valenti",
    "codigo": "V155"
  },
  {
    "nome": "valentin",
    "codigo": "V156"
  },
  {
    "nome": "valentine",
    "codigo": "V157"
  },
  {
    "nome": "valentine j",
    "codigo": "V158"
  },
  {
    "nome": "valentine p",
    "codigo": "V159"
  },
  {
    "nome": "valentini",
    "codigo": "V161"
  },
  {
    "nome": "valer",
    "codigo": "V162"
  },
  {
    "nome": "valeri",
    "codigo": "V163"
  },
  {
    "nome": "valerio",
    "codigo": "V164"
  },
  {
    "nome": "valeriu",
    "codigo": "V165"
  },
  {
    "nome": "valery",
    "codigo": "V166"
  },
  {
    "nome": "vales",
    "codigo": "V167"
  },
  {
    "nome": "valet",
    "codigo": "V168"
  },
  {
    "nome": "valg",
    "codigo": "V169"
  },
  {
    "nome": "valh",
    "codigo": "V171"
  },
  {
    "nome": "vali",
    "codigo": "V172"
  },
  {
    "nome": "valin",
    "codigo": "V173"
  },
  {
    "nome": "valk",
    "codigo": "V174"
  },
  {
    "nome": "vall",
    "codigo": "V175"
  },
  {
    "nome": "vallad",
    "codigo": "V176"
  },
  {
    "nome": "vallan",
    "codigo": "V177"
  },
  {
    "nome": "vallar",
    "codigo": "V178"
  },
  {
    "nome": "vallau",
    "codigo": "V179"
  },
  {
    "nome": "valle",
    "codigo": "V181"
  },
  {
    "nome": "vallee",
    "codigo": "V182"
  },
  {
    "nome": "vallem",
    "codigo": "V183"
  },
  {
    "nome": "valler",
    "codigo": "V184"
  },
  {
    "nome": "valles",
    "codigo": "V185"
  },
  {
    "nome": "vallet",
    "codigo": "V186"
  },
  {
    "nome": "vallett",
    "codigo": "V187"
  },
  {
    "nome": "valli",
    "codigo": "V188"
  },
  {
    "nome": "vallis",
    "codigo": "V189"
  },
  {
    "nome": "vallo",
    "codigo": "V191"
  },
  {
    "nome": "vallon",
    "codigo": "V192"
  },
  {
    "nome": "vallot",
    "codigo": "V193"
  },
  {
    "nome": "vallou",
    "codigo": "V194"
  },
  {
    "nome": "valls",
    "codigo": "V195"
  },
  {
    "nome": "valm",
    "codigo": "V196"
  },
  {
    "nome": "valmy",
    "codigo": "V197"
  },
  {
    "nome": "valo",
    "codigo": "V198"
  },
  {
    "nome": "valor",
    "codigo": "V199"
  },
  {
    "nome": "valp",
    "codigo": "V211"
  },
  {
    "nome": "valpy",
    "codigo": "V212"
  },
  {
    "nome": "valr",
    "codigo": "V213"
  },
  {
    "nome": "vals",
    "codigo": "V214"
  },
  {
    "nome": "valt",
    "codigo": "V215"
  },
  {
    "nome": "vam",
    "codigo": "V216"
  },
  {
    "nome": "van",
    "codigo": "V217"
  },
  {
    "nome": "vanb",
    "codigo": "V218"
  },
  {
    "nome": "vanbr",
    "codigo": "V219"
  },
  {
    "nome": "vanbu",
    "codigo": "V221"
  },
  {
    "nome": "vanc",
    "codigo": "V222"
  },
  {
    "nome": "vanco",
    "codigo": "V223"
  },
  {
    "nome": "vand",
    "codigo": "V224"
  },
  {
    "nome": "vande",
    "codigo": "V225"
  },
  {
    "nome": "vandel",
    "codigo": "V226"
  },
  {
    "nome": "vanden",
    "codigo": "V227"
  },
  {
    "nome": "vander",
    "codigo": "V228"
  },
  {
    "nome": "vanderbu",
    "codigo": "V229"
  },
  {
    "nome": "vanderc",
    "codigo": "V231"
  },
  {
    "nome": "vanderd",
    "codigo": "V232"
  },
  {
    "nome": "vanderh",
    "codigo": "V233"
  },
  {
    "nome": "vanderho",
    "codigo": "V234"
  },
  {
    "nome": "vanderl",
    "codigo": "V235"
  },
  {
    "nome": "vanderm",
    "codigo": "V236"
  },
  {
    "nome": "vanderme",
    "codigo": "V237"
  },
  {
    "nome": "vandermo",
    "codigo": "V238"
  },
  {
    "nome": "vanderp",
    "codigo": "V239"
  },
  {
    "nome": "vanders",
    "codigo": "V241"
  },
  {
    "nome": "vanderw",
    "codigo": "V242"
  },
  {
    "nome": "vandeu",
    "codigo": "V243"
  },
  {
    "nome": "vandev",
    "codigo": "V244"
  },
  {
    "nome": "vandi",
    "codigo": "V245"
  },
  {
    "nome": "vando",
    "codigo": "V246"
  },
  {
    "nome": "vandy",
    "codigo": "V247"
  },
  {
    "nome": "vandyk",
    "codigo": "V248"
  },
  {
    "nome": "vane",
    "codigo": "V249"
  },
  {
    "nome": "vane m",
    "codigo": "V251"
  },
  {
    "nome": "vanee",
    "codigo": "V252"
  },
  {
    "nome": "vang",
    "codigo": "V253"
  },
  {
    "nome": "vanh",
    "codigo": "V254"
  },
  {
    "nome": "vanhe",
    "codigo": "V255"
  },
  {
    "nome": "vanho",
    "codigo": "V256"
  },
  {
    "nome": "vanhu",
    "codigo": "V257"
  },
  {
    "nome": "vani",
    "codigo": "V258"
  },
  {
    "nome": "vanl",
    "codigo": "V259"
  },
  {
    "nome": "vanloo",
    "codigo": "V261"
  },
  {
    "nome": "vanm",
    "codigo": "V262"
  },
  {
    "nome": "vanmo",
    "codigo": "V263"
  },
  {
    "nome": "vann",
    "codigo": "V264"
  },
  {
    "nome": "vanne",
    "codigo": "V265"
  },
  {
    "nome": "vannes",
    "codigo": "V266"
  },
  {
    "nome": "vannet",
    "codigo": "V267"
  },
  {
    "nome": "vanni",
    "codigo": "V268"
  },
  {
    "nome": "vannin",
    "codigo": "V269"
  },
  {
    "nome": "vannu",
    "codigo": "V271"
  },
  {
    "nome": "vano",
    "codigo": "V272"
  },
  {
    "nome": "vanp",
    "codigo": "V273"
  },
  {
    "nome": "vanr",
    "codigo": "V274"
  },
  {
    "nome": "vanro",
    "codigo": "V275"
  },
  {
    "nome": "vans",
    "codigo": "V276"
  },
  {
    "nome": "vansa",
    "codigo": "V277"
  },
  {
    "nome": "vansc",
    "codigo": "V278"
  },
  {
    "nome": "vansi",
    "codigo": "V279"
  },
  {
    "nome": "vansp",
    "codigo": "V281"
  },
  {
    "nome": "vant",
    "codigo": "V282"
  },
  {
    "nome": "vanu",
    "codigo": "V283"
  },
  {
    "nome": "vanv",
    "codigo": "V284"
  },
  {
    "nome": "vanw",
    "codigo": "V285"
  },
  {
    "nome": "vap",
    "codigo": "V286"
  },
  {
    "nome": "var",
    "codigo": "V287"
  },
  {
    "nome": "varan",
    "codigo": "V288"
  },
  {
    "nome": "varc",
    "codigo": "V289"
  },
  {
    "nome": "vard",
    "codigo": "V291"
  },
  {
    "nome": "vare",
    "codigo": "V292"
  },
  {
    "nome": "varel",
    "codigo": "V293"
  },
  {
    "nome": "varen",
    "codigo": "V294"
  },
  {
    "nome": "varenn",
    "codigo": "V295"
  },
  {
    "nome": "vares",
    "codigo": "V296"
  },
  {
    "nome": "varg",
    "codigo": "V297"
  },
  {
    "nome": "vargu",
    "codigo": "V298"
  },
  {
    "nome": "vari",
    "codigo": "V299"
  },
  {
    "nome": "varil",
    "codigo": "V311"
  },
  {
    "nome": "varin",
    "codigo": "V312"
  },
  {
    "nome": "variu",
    "codigo": "V313"
  },
  {
    "nome": "varl",
    "codigo": "V314"
  },
  {
    "nome": "varley",
    "codigo": "V315"
  },
  {
    "nome": "varlo",
    "codigo": "V316"
  },
  {
    "nome": "varn",
    "codigo": "V317"
  },
  {
    "nome": "varney",
    "codigo": "V318"
  },
  {
    "nome": "varnh",
    "codigo": "V319"
  },
  {
    "nome": "varni",
    "codigo": "V321"
  },
  {
    "nome": "varnu",
    "codigo": "V322"
  },
  {
    "nome": "varo",
    "codigo": "V323"
  },
  {
    "nome": "varot",
    "codigo": "V324"
  },
  {
    "nome": "varr",
    "codigo": "V325"
  },
  {
    "nome": "vart",
    "codigo": "V326"
  },
  {
    "nome": "varu",
    "codigo": "V327"
  },
  {
    "nome": "vas",
    "codigo": "V328"
  },
  {
    "nome": "vasc",
    "codigo": "V329"
  },
  {
    "nome": "vasco",
    "codigo": "V331"
  },
  {
    "nome": "vase",
    "codigo": "V332"
  },
  {
    "nome": "vash",
    "codigo": "V333"
  },
  {
    "nome": "vasi",
    "codigo": "V334"
  },
  {
    "nome": "vasq",
    "codigo": "V335"
  },
  {
    "nome": "vass",
    "codigo": "V336"
  },
  {
    "nome": "vassall",
    "codigo": "V337"
  },
  {
    "nome": "vasse",
    "codigo": "V338"
  },
  {
    "nome": "vassi",
    "codigo": "V339"
  },
  {
    "nome": "vast",
    "codigo": "V341"
  },
  {
    "nome": "vat",
    "codigo": "V342"
  },
  {
    "nome": "vater",
    "codigo": "V343"
  },
  {
    "nome": "vath",
    "codigo": "V344"
  },
  {
    "nome": "vati",
    "codigo": "V345"
  },
  {
    "nome": "vatin",
    "codigo": "V346"
  },
  {
    "nome": "vatk",
    "codigo": "V347"
  },
  {
    "nome": "vato",
    "codigo": "V348"
  },
  {
    "nome": "vatr",
    "codigo": "V349"
  },
  {
    "nome": "vatt",
    "codigo": "V351"
  },
  {
    "nome": "vatti",
    "codigo": "V352"
  },
  {
    "nome": "vau",
    "codigo": "V353"
  },
  {
    "nome": "vauban",
    "codigo": "V354"
  },
  {
    "nome": "vaubl",
    "codigo": "V355"
  },
  {
    "nome": "vauc",
    "codigo": "V356"
  },
  {
    "nome": "vauch",
    "codigo": "V357"
  },
  {
    "nome": "vaud",
    "codigo": "V358"
  },
  {
    "nome": "vaudoy",
    "codigo": "V359"
  },
  {
    "nome": "vaudr",
    "codigo": "V361"
  },
  {
    "nome": "vaudrey",
    "codigo": "V362"
  },
  {
    "nome": "vaug",
    "codigo": "V363"
  },
  {
    "nome": "vaughan",
    "codigo": "V364"
  },
  {
    "nome": "vaughan c",
    "codigo": "V365"
  },
  {
    "nome": "vaughan g",
    "codigo": "V366"
  },
  {
    "nome": "vaughan j",
    "codigo": "V367"
  },
  {
    "nome": "vaughan m",
    "codigo": "V368"
  },
  {
    "nome": "vaughan s",
    "codigo": "V369"
  },
  {
    "nome": "vaughan w",
    "codigo": "V371"
  },
  {
    "nome": "vaugi",
    "codigo": "V372"
  },
  {
    "nome": "vaugo",
    "codigo": "V373"
  },
  {
    "nome": "vaul",
    "codigo": "V374"
  },
  {
    "nome": "vaulo",
    "codigo": "V375"
  },
  {
    "nome": "vault",
    "codigo": "V376"
  },
  {
    "nome": "vaum",
    "codigo": "V377"
  },
  {
    "nome": "vauq",
    "codigo": "V378"
  },
  {
    "nome": "vaus",
    "codigo": "V379"
  },
  {
    "nome": "vaut",
    "codigo": "V381"
  },
  {
    "nome": "vauv",
    "codigo": "V382"
  },
  {
    "nome": "vauvi",
    "codigo": "V383"
  },
  {
    "nome": "vaux",
    "codigo": "V384"
  },
  {
    "nome": "vaux g",
    "codigo": "V385"
  },
  {
    "nome": "vaux m",
    "codigo": "V386"
  },
  {
    "nome": "vauxc",
    "codigo": "V387"
  },
  {
    "nome": "vauz",
    "codigo": "V388"
  },
  {
    "nome": "vav",
    "codigo": "V389"
  },
  {
    "nome": "vavi",
    "codigo": "V391"
  },
  {
    "nome": "vay",
    "codigo": "V392"
  },
  {
    "nome": "vaz",
    "codigo": "V393"
  },
  {
    "nome": "ve",
    "codigo": "V394"
  },
  {
    "nome": "veau",
    "codigo": "V395"
  },
  {
    "nome": "vec",
    "codigo": "V396"
  },
  {
    "nome": "vecchi",
    "codigo": "V397"
  },
  {
    "nome": "vecchio",
    "codigo": "V398"
  },
  {
    "nome": "vece",
    "codigo": "V399"
  },
  {
    "nome": "vecellio",
    "codigo": "V411"
  },
  {
    "nome": "vecn",
    "codigo": "V412"
  },
  {
    "nome": "veco",
    "codigo": "V413"
  },
  {
    "nome": "ved",
    "codigo": "V414"
  },
  {
    "nome": "vedd",
    "codigo": "V415"
  },
  {
    "nome": "vedo",
    "codigo": "V416"
  },
  {
    "nome": "vee",
    "codigo": "V417"
  },
  {
    "nome": "veen",
    "codigo": "V418"
  },
  {
    "nome": "veer",
    "codigo": "V419"
  },
  {
    "nome": "vees",
    "codigo": "V421"
  },
  {
    "nome": "veg",
    "codigo": "V422"
  },
  {
    "nome": "vegi",
    "codigo": "V423"
  },
  {
    "nome": "vegl",
    "codigo": "V424"
  },
  {
    "nome": "veh",
    "codigo": "V425"
  },
  {
    "nome": "vei",
    "codigo": "V426"
  },
  {
    "nome": "veil",
    "codigo": "V427"
  },
  {
    "nome": "veit",
    "codigo": "V428"
  },
  {
    "nome": "veitch",
    "codigo": "V429"
  },
  {
    "nome": "veith",
    "codigo": "V431"
  },
  {
    "nome": "vel",
    "codigo": "V432"
  },
  {
    "nome": "velas",
    "codigo": "V433"
  },
  {
    "nome": "velasq",
    "codigo": "V434"
  },
  {
    "nome": "veld",
    "codigo": "V435"
  },
  {
    "nome": "vele",
    "codigo": "V436"
  },
  {
    "nome": "veli",
    "codigo": "V437"
  },
  {
    "nome": "vell",
    "codigo": "V438"
  },
  {
    "nome": "velle",
    "codigo": "V439"
  },
  {
    "nome": "vello",
    "codigo": "V441"
  },
  {
    "nome": "vellu",
    "codigo": "V442"
  },
  {
    "nome": "velly",
    "codigo": "V443"
  },
  {
    "nome": "velp",
    "codigo": "V444"
  },
  {
    "nome": "velt",
    "codigo": "V445"
  },
  {
    "nome": "veltr",
    "codigo": "V446"
  },
  {
    "nome": "ven",
    "codigo": "V447"
  },
  {
    "nome": "venan",
    "codigo": "V448"
  },
  {
    "nome": "venc",
    "codigo": "V449"
  },
  {
    "nome": "vences",
    "codigo": "V451"
  },
  {
    "nome": "vend",
    "codigo": "V452"
  },
  {
    "nome": "vendr",
    "codigo": "V453"
  },
  {
    "nome": "vene",
    "codigo": "V454"
  },
  {
    "nome": "veneg",
    "codigo": "V455"
  },
  {
    "nome": "venel",
    "codigo": "V456"
  },
  {
    "nome": "venet",
    "codigo": "V457"
  },
  {
    "nome": "venez",
    "codigo": "V458"
  },
  {
    "nome": "veni",
    "codigo": "V459"
  },
  {
    "nome": "venin",
    "codigo": "V461"
  },
  {
    "nome": "venn",
    "codigo": "V462"
  },
  {
    "nome": "venner",
    "codigo": "V463"
  },
  {
    "nome": "venni",
    "codigo": "V464"
  },
  {
    "nome": "vent",
    "codigo": "V465"
  },
  {
    "nome": "vento",
    "codigo": "V466"
  },
  {
    "nome": "ventr",
    "codigo": "V467"
  },
  {
    "nome": "ventu",
    "codigo": "V468"
  },
  {
    "nome": "venturi",
    "codigo": "V469"
  },
  {
    "nome": "venu",
    "codigo": "V471"
  },
  {
    "nome": "venut",
    "codigo": "V472"
  },
  {
    "nome": "ver",
    "codigo": "V473"
  },
  {
    "nome": "verac",
    "codigo": "V474"
  },
  {
    "nome": "veral",
    "codigo": "V475"
  },
  {
    "nome": "verar",
    "codigo": "V476"
  },
  {
    "nome": "verb",
    "codigo": "V477"
  },
  {
    "nome": "verbi",
    "codigo": "V478"
  },
  {
    "nome": "verbo",
    "codigo": "V479"
  },
  {
    "nome": "verc",
    "codigo": "V481"
  },
  {
    "nome": "verci",
    "codigo": "V482"
  },
  {
    "nome": "verd",
    "codigo": "V483"
  },
  {
    "nome": "verdi",
    "codigo": "V484"
  },
  {
    "nome": "verdig",
    "codigo": "V485"
  },
  {
    "nome": "verdo",
    "codigo": "V486"
  },
  {
    "nome": "verdu",
    "codigo": "V487"
  },
  {
    "nome": "verdy",
    "codigo": "V488"
  },
  {
    "nome": "vere",
    "codigo": "V489"
  },
  {
    "nome": "verel",
    "codigo": "V491"
  },
  {
    "nome": "verels",
    "codigo": "V492"
  },
  {
    "nome": "verg",
    "codigo": "V493"
  },
  {
    "nome": "vergar",
    "codigo": "V494"
  },
  {
    "nome": "verge",
    "codigo": "V495"
  },
  {
    "nome": "verger",
    "codigo": "V496"
  },
  {
    "nome": "vergi",
    "codigo": "V497"
  },
  {
    "nome": "vergn",
    "codigo": "V498"
  },
  {
    "nome": "vergy",
    "codigo": "V499"
  },
  {
    "nome": "verh",
    "codigo": "V511"
  },
  {
    "nome": "verhag",
    "codigo": "V512"
  },
  {
    "nome": "verhe",
    "codigo": "V513"
  },
  {
    "nome": "verho",
    "codigo": "V514"
  },
  {
    "nome": "verhu",
    "codigo": "V515"
  },
  {
    "nome": "veri",
    "codigo": "V516"
  },
  {
    "nome": "verin",
    "codigo": "V517"
  },
  {
    "nome": "verj",
    "codigo": "V518"
  },
  {
    "nome": "verk",
    "codigo": "V519"
  },
  {
    "nome": "verl",
    "codigo": "V521"
  },
  {
    "nome": "verm",
    "codigo": "V522"
  },
  {
    "nome": "verme",
    "codigo": "V523"
  },
  {
    "nome": "vermeu",
    "codigo": "V524"
  },
  {
    "nome": "vermi",
    "codigo": "V525"
  },
  {
    "nome": "vermil",
    "codigo": "V526"
  },
  {
    "nome": "vermo",
    "codigo": "V527"
  },
  {
    "nome": "vermoo",
    "codigo": "V528"
  },
  {
    "nome": "vern",
    "codigo": "V529"
  },
  {
    "nome": "verne",
    "codigo": "V531"
  },
  {
    "nome": "vernet",
    "codigo": "V532"
  },
  {
    "nome": "verneu",
    "codigo": "V533"
  },
  {
    "nome": "verney",
    "codigo": "V534"
  },
  {
    "nome": "verney m",
    "codigo": "V535"
  },
  {
    "nome": "verni",
    "codigo": "V536"
  },
  {
    "nome": "vernin",
    "codigo": "V537"
  },
  {
    "nome": "verniz",
    "codigo": "V538"
  },
  {
    "nome": "verno",
    "codigo": "V539"
  },
  {
    "nome": "vernon g",
    "codigo": "V541"
  },
  {
    "nome": "vernon m",
    "codigo": "V542"
  },
  {
    "nome": "vernon s",
    "codigo": "V543"
  },
  {
    "nome": "vernu",
    "codigo": "V544"
  },
  {
    "nome": "verny",
    "codigo": "V545"
  },
  {
    "nome": "vero",
    "codigo": "V546"
  },
  {
    "nome": "veron",
    "codigo": "V547"
  },
  {
    "nome": "verona",
    "codigo": "V548"
  },
  {
    "nome": "verone",
    "codigo": "V549"
  },
  {
    "nome": "verp",
    "codigo": "V551"
  },
  {
    "nome": "verpo",
    "codigo": "V552"
  },
  {
    "nome": "verr",
    "codigo": "V553"
  },
  {
    "nome": "verri",
    "codigo": "V554"
  },
  {
    "nome": "verril",
    "codigo": "V555"
  },
  {
    "nome": "verrim",
    "codigo": "V556"
  },
  {
    "nome": "verrio",
    "codigo": "V557"
  },
  {
    "nome": "verro",
    "codigo": "V558"
  },
  {
    "nome": "verru",
    "codigo": "V559"
  },
  {
    "nome": "vers",
    "codigo": "V561"
  },
  {
    "nome": "verschu",
    "codigo": "V562"
  },
  {
    "nome": "verse",
    "codigo": "V563"
  },
  {
    "nome": "verso",
    "codigo": "V564"
  },
  {
    "nome": "verst",
    "codigo": "V565"
  },
  {
    "nome": "versto",
    "codigo": "V566"
  },
  {
    "nome": "vert",
    "codigo": "V567"
  },
  {
    "nome": "verto",
    "codigo": "V568"
  },
  {
    "nome": "veru",
    "codigo": "V569"
  },
  {
    "nome": "verv",
    "codigo": "V571"
  },
  {
    "nome": "verw",
    "codigo": "V572"
  },
  {
    "nome": "very",
    "codigo": "V573"
  },
  {
    "nome": "verz",
    "codigo": "V574"
  },
  {
    "nome": "ves",
    "codigo": "V575"
  },
  {
    "nome": "vesey",
    "codigo": "V576"
  },
  {
    "nome": "vesi",
    "codigo": "V577"
  },
  {
    "nome": "vesl",
    "codigo": "V578"
  },
  {
    "nome": "vesp",
    "codigo": "V579"
  },
  {
    "nome": "vespu",
    "codigo": "V581"
  },
  {
    "nome": "vesq",
    "codigo": "V582"
  },
  {
    "nome": "vest",
    "codigo": "V583"
  },
  {
    "nome": "vestr",
    "codigo": "V584"
  },
  {
    "nome": "vet",
    "codigo": "V585"
  },
  {
    "nome": "vetch",
    "codigo": "V586"
  },
  {
    "nome": "veth",
    "codigo": "V587"
  },
  {
    "nome": "veti",
    "codigo": "V588"
  },
  {
    "nome": "vetr",
    "codigo": "V589"
  },
  {
    "nome": "vett",
    "codigo": "V591"
  },
  {
    "nome": "vetto",
    "codigo": "V592"
  },
  {
    "nome": "vetu",
    "codigo": "V593"
  },
  {
    "nome": "veu",
    "codigo": "V594"
  },
  {
    "nome": "vey",
    "codigo": "V595"
  },
  {
    "nome": "veys",
    "codigo": "V596"
  },
  {
    "nome": "vez",
    "codigo": "V597"
  },
  {
    "nome": "vi",
    "codigo": "V598"
  },
  {
    "nome": "vial",
    "codigo": "V599"
  },
  {
    "nome": "viale",
    "codigo": "V611"
  },
  {
    "nome": "viall",
    "codigo": "V612"
  },
  {
    "nome": "vialo",
    "codigo": "V613"
  },
  {
    "nome": "vian",
    "codigo": "V614"
  },
  {
    "nome": "vianen",
    "codigo": "V615"
  },
  {
    "nome": "viani",
    "codigo": "V616"
  },
  {
    "nome": "viann",
    "codigo": "V617"
  },
  {
    "nome": "viar",
    "codigo": "V618"
  },
  {
    "nome": "viardo",
    "codigo": "V619"
  },
  {
    "nome": "viart",
    "codigo": "V621"
  },
  {
    "nome": "vias",
    "codigo": "V622"
  },
  {
    "nome": "viau",
    "codigo": "V623"
  },
  {
    "nome": "vib",
    "codigo": "V624"
  },
  {
    "nome": "vibi",
    "codigo": "V625"
  },
  {
    "nome": "vibn",
    "codigo": "V626"
  },
  {
    "nome": "vic",
    "codigo": "V627"
  },
  {
    "nome": "vicar",
    "codigo": "V628"
  },
  {
    "nome": "vicars",
    "codigo": "V629"
  },
  {
    "nome": "vicat",
    "codigo": "V631"
  },
  {
    "nome": "vice",
    "codigo": "V632"
  },
  {
    "nome": "vicenti",
    "codigo": "V633"
  },
  {
    "nome": "vich",
    "codigo": "V634"
  },
  {
    "nome": "vici",
    "codigo": "V635"
  },
  {
    "nome": "vick",
    "codigo": "V636"
  },
  {
    "nome": "vickers",
    "codigo": "V637"
  },
  {
    "nome": "vico",
    "codigo": "V638"
  },
  {
    "nome": "vicom",
    "codigo": "V639"
  },
  {
    "nome": "vicq",
    "codigo": "V641"
  },
  {
    "nome": "vict",
    "codigo": "V642"
  },
  {
    "nome": "victor g",
    "codigo": "V643"
  },
  {
    "nome": "victor m",
    "codigo": "V644"
  },
  {
    "nome": "victor s",
    "codigo": "V645"
  },
  {
    "nome": "victorin",
    "codigo": "V646"
  },
  {
    "nome": "vicu",
    "codigo": "V647"
  },
  {
    "nome": "vid",
    "codigo": "V648"
  },
  {
    "nome": "vidal m",
    "codigo": "V649"
  },
  {
    "nome": "vidau",
    "codigo": "V651"
  },
  {
    "nome": "vide",
    "codigo": "V652"
  },
  {
    "nome": "vidi",
    "codigo": "V653"
  },
  {
    "nome": "vido",
    "codigo": "V654"
  },
  {
    "nome": "vidu",
    "codigo": "V655"
  },
  {
    "nome": "vie",
    "codigo": "V656"
  },
  {
    "nome": "viei",
    "codigo": "V657"
  },
  {
    "nome": "vieillo",
    "codigo": "V658"
  },
  {
    "nome": "viel",
    "codigo": "V659"
  },
  {
    "nome": "viell",
    "codigo": "V661"
  },
  {
    "nome": "vien",
    "codigo": "V662"
  },
  {
    "nome": "vienne",
    "codigo": "V663"
  },
  {
    "nome": "vienno",
    "codigo": "V664"
  },
  {
    "nome": "vier",
    "codigo": "V665"
  },
  {
    "nome": "viet",
    "codigo": "V666"
  },
  {
    "nome": "vieu",
    "codigo": "V667"
  },
  {
    "nome": "vieus",
    "codigo": "V668"
  },
  {
    "nome": "vieuv",
    "codigo": "V669"
  },
  {
    "nome": "vieux",
    "codigo": "V671"
  },
  {
    "nome": "vig",
    "codigo": "V672"
  },
  {
    "nome": "vige",
    "codigo": "V673"
  },
  {
    "nome": "viger",
    "codigo": "V674"
  },
  {
    "nome": "vigh",
    "codigo": "V675"
  },
  {
    "nome": "vigi",
    "codigo": "V676"
  },
  {
    "nome": "vigil",
    "codigo": "V677"
  },
  {
    "nome": "vign",
    "codigo": "V678"
  },
  {
    "nome": "vignal",
    "codigo": "V679"
  },
  {
    "nome": "vignau",
    "codigo": "V681"
  },
  {
    "nome": "vigne",
    "codigo": "V682"
  },
  {
    "nome": "vigner",
    "codigo": "V683"
  },
  {
    "nome": "vignes",
    "codigo": "V684"
  },
  {
    "nome": "vigni",
    "codigo": "V685"
  },
  {
    "nome": "vigno",
    "codigo": "V686"
  },
  {
    "nome": "vignon",
    "codigo": "V687"
  },
  {
    "nome": "vigny",
    "codigo": "V688"
  },
  {
    "nome": "vigo",
    "codigo": "V689"
  },
  {
    "nome": "vigor",
    "codigo": "V691"
  },
  {
    "nome": "vigr",
    "codigo": "V692"
  },
  {
    "nome": "vigu",
    "codigo": "V693"
  },
  {
    "nome": "vigui",
    "codigo": "V694"
  },
  {
    "nome": "vil",
    "codigo": "V695"
  },
  {
    "nome": "vilain",
    "codigo": "V696"
  },
  {
    "nome": "vilar",
    "codigo": "V697"
  },
  {
    "nome": "vilat",
    "codigo": "V698"
  },
  {
    "nome": "vilb",
    "codigo": "V699"
  },
  {
    "nome": "vilh",
    "codigo": "V711"
  },
  {
    "nome": "vill",
    "codigo": "V712"
  },
  {
    "nome": "villaf",
    "codigo": "V713"
  },
  {
    "nome": "villal",
    "codigo": "V714"
  },
  {
    "nome": "villam",
    "codigo": "V715"
  },
  {
    "nome": "villan",
    "codigo": "V716"
  },
  {
    "nome": "villano",
    "codigo": "V717"
  },
  {
    "nome": "villanu",
    "codigo": "V718"
  },
  {
    "nome": "villar",
    "codigo": "V719"
  },
  {
    "nome": "villaret",
    "codigo": "V721"
  },
  {
    "nome": "villari",
    "codigo": "V722"
  },
  {
    "nome": "villars",
    "codigo": "V723"
  },
  {
    "nome": "villars g",
    "codigo": "V724"
  },
  {
    "nome": "villars m",
    "codigo": "V725"
  },
  {
    "nome": "villars s",
    "codigo": "V726"
  },
  {
    "nome": "villav",
    "codigo": "V727"
  },
  {
    "nome": "ville",
    "codigo": "V728"
  },
  {
    "nome": "villec",
    "codigo": "V729"
  },
  {
    "nome": "villef",
    "codigo": "V731"
  },
  {
    "nome": "villeg",
    "codigo": "V732"
  },
  {
    "nome": "villego",
    "codigo": "V733"
  },
  {
    "nome": "villeh",
    "codigo": "V734"
  },
  {
    "nome": "villel",
    "codigo": "V735"
  },
  {
    "nome": "villem",
    "codigo": "V736"
  },
  {
    "nome": "villen",
    "codigo": "V737"
  },
  {
    "nome": "villene",
    "codigo": "V738"
  },
  {
    "nome": "villep",
    "codigo": "V739"
  },
  {
    "nome": "villeq",
    "codigo": "V741"
  },
  {
    "nome": "viller",
    "codigo": "V742"
  },
  {
    "nome": "villerm",
    "codigo": "V743"
  },
  {
    "nome": "villero",
    "codigo": "V744"
  },
  {
    "nome": "villers",
    "codigo": "V745"
  },
  {
    "nome": "villers m",
    "codigo": "V746"
  },
  {
    "nome": "villes",
    "codigo": "V747"
  },
  {
    "nome": "villet",
    "codigo": "V748"
  },
  {
    "nome": "villeu",
    "codigo": "V749"
  },
  {
    "nome": "villi",
    "codigo": "V751"
  },
  {
    "nome": "villiers",
    "codigo": "V752"
  },
  {
    "nome": "villiers f",
    "codigo": "V753"
  },
  {
    "nome": "villiers j",
    "codigo": "V754"
  },
  {
    "nome": "villiers m",
    "codigo": "V755"
  },
  {
    "nome": "villiers s",
    "codigo": "V756"
  },
  {
    "nome": "villiers w",
    "codigo": "V757"
  },
  {
    "nome": "villo",
    "codigo": "V758"
  },
  {
    "nome": "villon",
    "codigo": "V759"
  },
  {
    "nome": "villot",
    "codigo": "V761"
  },
  {
    "nome": "vilm",
    "codigo": "V762"
  },
  {
    "nome": "vils",
    "codigo": "V763"
  },
  {
    "nome": "vim",
    "codigo": "V764"
  },
  {
    "nome": "vimo",
    "codigo": "V765"
  },
  {
    "nome": "vin",
    "codigo": "V766"
  },
  {
    "nome": "vinc",
    "codigo": "V767"
  },
  {
    "nome": "vincent",
    "codigo": "V768"
  },
  {
    "nome": "vincent c",
    "codigo": "V769"
  },
  {
    "nome": "vincent f",
    "codigo": "V771"
  },
  {
    "nome": "vincent j",
    "codigo": "V772"
  },
  {
    "nome": "vincent m",
    "codigo": "V773"
  },
  {
    "nome": "vincent s",
    "codigo": "V774"
  },
  {
    "nome": "vincent w",
    "codigo": "V775"
  },
  {
    "nome": "vinch",
    "codigo": "V776"
  },
  {
    "nome": "vinci",
    "codigo": "V777"
  },
  {
    "nome": "vinck",
    "codigo": "V778"
  },
  {
    "nome": "vind",
    "codigo": "V779"
  },
  {
    "nome": "vindi",
    "codigo": "V781"
  },
  {
    "nome": "vine",
    "codigo": "V782"
  },
  {
    "nome": "vinet",
    "codigo": "V783"
  },
  {
    "nome": "ving",
    "codigo": "V784"
  },
  {
    "nome": "vini",
    "codigo": "V785"
  },
  {
    "nome": "vink",
    "codigo": "V786"
  },
  {
    "nome": "vinn",
    "codigo": "V787"
  },
  {
    "nome": "vino",
    "codigo": "V788"
  },
  {
    "nome": "vint",
    "codigo": "V789"
  },
  {
    "nome": "vinton",
    "codigo": "V791"
  },
  {
    "nome": "vinton g",
    "codigo": "V792"
  },
  {
    "nome": "vinton m",
    "codigo": "V793"
  },
  {
    "nome": "vinton s",
    "codigo": "V794"
  },
  {
    "nome": "vio",
    "codigo": "V795"
  },
  {
    "nome": "violl",
    "codigo": "V796"
  },
  {
    "nome": "viom",
    "codigo": "V797"
  },
  {
    "nome": "vion",
    "codigo": "V798"
  },
  {
    "nome": "viot",
    "codigo": "V799"
  },
  {
    "nome": "vip",
    "codigo": "V811"
  },
  {
    "nome": "vipo",
    "codigo": "V812"
  },
  {
    "nome": "vir",
    "codigo": "V813"
  },
  {
    "nome": "vire",
    "codigo": "V814"
  },
  {
    "nome": "virey",
    "codigo": "V815"
  },
  {
    "nome": "virg",
    "codigo": "V816"
  },
  {
    "nome": "virgin",
    "codigo": "V817"
  },
  {
    "nome": "viri",
    "codigo": "V818"
  },
  {
    "nome": "virl",
    "codigo": "V819"
  },
  {
    "nome": "viru",
    "codigo": "V821"
  },
  {
    "nome": "vis",
    "codigo": "V822"
  },
  {
    "nome": "visch",
    "codigo": "V823"
  },
  {
    "nome": "visco",
    "codigo": "V824"
  },
  {
    "nome": "visconti g",
    "codigo": "V825"
  },
  {
    "nome": "visconti m",
    "codigo": "V826"
  },
  {
    "nome": "visconti s",
    "codigo": "V827"
  },
  {
    "nome": "visd",
    "codigo": "V828"
  },
  {
    "nome": "vise",
    "codigo": "V829"
  },
  {
    "nome": "visi",
    "codigo": "V831"
  },
  {
    "nome": "vism",
    "codigo": "V832"
  },
  {
    "nome": "viss",
    "codigo": "V833"
  },
  {
    "nome": "visse",
    "codigo": "V834"
  },
  {
    "nome": "vit",
    "codigo": "V835"
  },
  {
    "nome": "vital",
    "codigo": "V836"
  },
  {
    "nome": "vitalis",
    "codigo": "V837"
  },
  {
    "nome": "vite",
    "codigo": "V838"
  },
  {
    "nome": "vitel",
    "codigo": "V839"
  },
  {
    "nome": "vitelli",
    "codigo": "V841"
  },
  {
    "nome": "viten",
    "codigo": "V842"
  },
  {
    "nome": "viter",
    "codigo": "V843"
  },
  {
    "nome": "vitet",
    "codigo": "V844"
  },
  {
    "nome": "vito",
    "codigo": "V845"
  },
  {
    "nome": "vitr",
    "codigo": "V846"
  },
  {
    "nome": "vitro",
    "codigo": "V847"
  },
  {
    "nome": "vitru",
    "codigo": "V848"
  },
  {
    "nome": "vitry",
    "codigo": "V849"
  },
  {
    "nome": "vitt",
    "codigo": "V851"
  },
  {
    "nome": "vitti",
    "codigo": "V852"
  },
  {
    "nome": "vitto",
    "codigo": "V853"
  },
  {
    "nome": "vitu",
    "codigo": "V854"
  },
  {
    "nome": "viv",
    "codigo": "V855"
  },
  {
    "nome": "vivari",
    "codigo": "V856"
  },
  {
    "nome": "vive",
    "codigo": "V857"
  },
  {
    "nome": "vivi",
    "codigo": "V858"
  },
  {
    "nome": "viviani",
    "codigo": "V859"
  },
  {
    "nome": "vivien",
    "codigo": "V861"
  },
  {
    "nome": "vivier",
    "codigo": "V862"
  },
  {
    "nome": "vivo",
    "codigo": "V863"
  },
  {
    "nome": "viz",
    "codigo": "V864"
  },
  {
    "nome": "vl",
    "codigo": "V865"
  },
  {
    "nome": "vlam",
    "codigo": "V866"
  },
  {
    "nome": "vlas",
    "codigo": "V867"
  },
  {
    "nome": "vle",
    "codigo": "V868"
  },
  {
    "nome": "vli",
    "codigo": "V869"
  },
  {
    "nome": "vliet",
    "codigo": "V871"
  },
  {
    "nome": "vo",
    "codigo": "V872"
  },
  {
    "nome": "voelc",
    "codigo": "V873"
  },
  {
    "nome": "voell",
    "codigo": "V874"
  },
  {
    "nome": "voer",
    "codigo": "V875"
  },
  {
    "nome": "voet",
    "codigo": "V876"
  },
  {
    "nome": "vog",
    "codigo": "V877"
  },
  {
    "nome": "vogel",
    "codigo": "V878"
  },
  {
    "nome": "vogel m",
    "codigo": "V879"
  },
  {
    "nome": "vogh",
    "codigo": "V881"
  },
  {
    "nome": "vogi",
    "codigo": "V882"
  },
  {
    "nome": "vogl",
    "codigo": "V883"
  },
  {
    "nome": "vogler m",
    "codigo": "V884"
  },
  {
    "nome": "vogo",
    "codigo": "V885"
  },
  {
    "nome": "vogt",
    "codigo": "V886"
  },
  {
    "nome": "vogt m",
    "codigo": "V887"
  },
  {
    "nome": "vogu",
    "codigo": "V888"
  },
  {
    "nome": "voi",
    "codigo": "V889"
  },
  {
    "nome": "voigt",
    "codigo": "V891"
  },
  {
    "nome": "voigt g",
    "codigo": "V892"
  },
  {
    "nome": "voigt m",
    "codigo": "V893"
  },
  {
    "nome": "voigt s",
    "codigo": "V894"
  },
  {
    "nome": "voil",
    "codigo": "V895"
  },
  {
    "nome": "voir",
    "codigo": "V896"
  },
  {
    "nome": "vois",
    "codigo": "V897"
  },
  {
    "nome": "voit",
    "codigo": "V898"
  },
  {
    "nome": "vol",
    "codigo": "V899"
  },
  {
    "nome": "volc",
    "codigo": "V911"
  },
  {
    "nome": "volck",
    "codigo": "V912"
  },
  {
    "nome": "volckm",
    "codigo": "V913"
  },
  {
    "nome": "vold",
    "codigo": "V914"
  },
  {
    "nome": "volg",
    "codigo": "V915"
  },
  {
    "nome": "volk",
    "codigo": "V916"
  },
  {
    "nome": "volke",
    "codigo": "V917"
  },
  {
    "nome": "volkh",
    "codigo": "V918"
  },
  {
    "nome": "volkm",
    "codigo": "V919"
  },
  {
    "nome": "volko",
    "codigo": "V921"
  },
  {
    "nome": "volky",
    "codigo": "V922"
  },
  {
    "nome": "voll",
    "codigo": "V923"
  },
  {
    "nome": "vollm",
    "codigo": "V924"
  },
  {
    "nome": "vollw",
    "codigo": "V925"
  },
  {
    "nome": "volm",
    "codigo": "V926"
  },
  {
    "nome": "voln",
    "codigo": "V927"
  },
  {
    "nome": "volney",
    "codigo": "V928"
  },
  {
    "nome": "volo",
    "codigo": "V929"
  },
  {
    "nome": "volp",
    "codigo": "V931"
  },
  {
    "nome": "volpi",
    "codigo": "V932"
  },
  {
    "nome": "volpin",
    "codigo": "V933"
  },
  {
    "nome": "vols",
    "codigo": "V934"
  },
  {
    "nome": "volt",
    "codigo": "V935"
  },
  {
    "nome": "voltch",
    "codigo": "V936"
  },
  {
    "nome": "volte",
    "codigo": "V937"
  },
  {
    "nome": "volto",
    "codigo": "V938"
  },
  {
    "nome": "voltr",
    "codigo": "V939"
  },
  {
    "nome": "voltu",
    "codigo": "V941"
  },
  {
    "nome": "voltz",
    "codigo": "V942"
  },
  {
    "nome": "volu",
    "codigo": "V943"
  },
  {
    "nome": "volv",
    "codigo": "V944"
  },
  {
    "nome": "von",
    "codigo": "V945"
  },
  {
    "nome": "vond",
    "codigo": "V946"
  },
  {
    "nome": "vonk",
    "codigo": "V947"
  },
  {
    "nome": "vono",
    "codigo": "V948"
  },
  {
    "nome": "voo",
    "codigo": "V949"
  },
  {
    "nome": "voor",
    "codigo": "V951"
  },
  {
    "nome": "vop",
    "codigo": "V952"
  },
  {
    "nome": "vor",
    "codigo": "V953"
  },
  {
    "nome": "voro",
    "codigo": "V954"
  },
  {
    "nome": "vors",
    "codigo": "V955"
  },
  {
    "nome": "vorster",
    "codigo": "V956"
  },
  {
    "nome": "vort",
    "codigo": "V957"
  },
  {
    "nome": "vory",
    "codigo": "V958"
  },
  {
    "nome": "vos",
    "codigo": "V959"
  },
  {
    "nome": "vose",
    "codigo": "V961"
  },
  {
    "nome": "vose d",
    "codigo": "V962"
  },
  {
    "nome": "vose h",
    "codigo": "V963"
  },
  {
    "nome": "vose j",
    "codigo": "V964"
  },
  {
    "nome": "vose m",
    "codigo": "V965"
  },
  {
    "nome": "vose s",
    "codigo": "V966"
  },
  {
    "nome": "vose w",
    "codigo": "V967"
  },
  {
    "nome": "vosm",
    "codigo": "V968"
  },
  {
    "nome": "voss",
    "codigo": "V969"
  },
  {
    "nome": "vossi",
    "codigo": "V971"
  },
  {
    "nome": "vou",
    "codigo": "V972"
  },
  {
    "nome": "voul",
    "codigo": "V973"
  },
  {
    "nome": "vow",
    "codigo": "V974"
  },
  {
    "nome": "voy",
    "codigo": "V975"
  },
  {
    "nome": "voys",
    "codigo": "V976"
  },
  {
    "nome": "voz",
    "codigo": "V977"
  },
  {
    "nome": "vr",
    "codigo": "V978"
  },
  {
    "nome": "vre",
    "codigo": "V979"
  },
  {
    "nome": "vri",
    "codigo": "V981"
  },
  {
    "nome": "vries",
    "codigo": "V982"
  },
  {
    "nome": "vril",
    "codigo": "V983"
  },
  {
    "nome": "vro",
    "codigo": "V984"
  },
  {
    "nome": "vs",
    "codigo": "V985"
  },
  {
    "nome": "vu",
    "codigo": "V986"
  },
  {
    "nome": "vui",
    "codigo": "V987"
  },
  {
    "nome": "vuil",
    "codigo": "V988"
  },
  {
    "nome": "vuit",
    "codigo": "V989"
  },
  {
    "nome": "vul",
    "codigo": "V991"
  },
  {
    "nome": "vulp",
    "codigo": "V992"
  },
  {
    "nome": "vuls",
    "codigo": "V993"
  },
  {
    "nome": "vuo",
    "codigo": "V994"
  },
  {
    "nome": "vuy",
    "codigo": "V995"
  },
  {
    "nome": "vy",
    "codigo": "V996"
  },
  {
    "nome": "vyr",
    "codigo": "V997"
  },
  {
    "nome": "vys",
    "codigo": "V998"
  },
  {
    "nome": "vz",
    "codigo": "V999"
  },
  {
    "nome": "w",
    "codigo": "W111"
  },
  {
    "nome": "wa",
    "codigo": "W111"
  },
  {
    "nome": "waas",
    "codigo": "W112"
  },
  {
    "nome": "wac",
    "codigo": "W113"
  },
  {
    "nome": "wachs",
    "codigo": "W114"
  },
  {
    "nome": "wack",
    "codigo": "W115"
  },
  {
    "nome": "wad",
    "codigo": "W116"
  },
  {
    "nome": "waddi",
    "codigo": "W117"
  },
  {
    "nome": "waddington",
    "codigo": "W118"
  },
  {
    "nome": "wade",
    "codigo": "W119"
  },
  {
    "nome": "wade m",
    "codigo": "W121"
  },
  {
    "nome": "wadh",
    "codigo": "W122"
  },
  {
    "nome": "wadl",
    "codigo": "W123"
  },
  {
    "nome": "wads",
    "codigo": "W124"
  },
  {
    "nome": "wadsworth m",
    "codigo": "W125"
  },
  {
    "nome": "wae",
    "codigo": "W126"
  },
  {
    "nome": "wael",
    "codigo": "W127"
  },
  {
    "nome": "waf",
    "codigo": "W128"
  },
  {
    "nome": "wag",
    "codigo": "W129"
  },
  {
    "nome": "wagen",
    "codigo": "W131"
  },
  {
    "nome": "wagn",
    "codigo": "W132"
  },
  {
    "nome": "wagner g",
    "codigo": "W133"
  },
  {
    "nome": "wagner m",
    "codigo": "W134"
  },
  {
    "nome": "wagner s",
    "codigo": "W135"
  },
  {
    "nome": "wah",
    "codigo": "W136"
  },
  {
    "nome": "wahlen",
    "codigo": "W137"
  },
  {
    "nome": "wai",
    "codigo": "W138"
  },
  {
    "nome": "waill",
    "codigo": "W139"
  },
  {
    "nome": "wain",
    "codigo": "W141"
  },
  {
    "nome": "wainwright m",
    "codigo": "W142"
  },
  {
    "nome": "wais",
    "codigo": "W143"
  },
  {
    "nome": "wait",
    "codigo": "W144"
  },
  {
    "nome": "waite",
    "codigo": "W145"
  },
  {
    "nome": "wak",
    "codigo": "W146"
  },
  {
    "nome": "wakef",
    "codigo": "W147"
  },
  {
    "nome": "wakeh",
    "codigo": "W148"
  },
  {
    "nome": "wakel",
    "codigo": "W149"
  },
  {
    "nome": "wal",
    "codigo": "W151"
  },
  {
    "nome": "walch",
    "codigo": "W152"
  },
  {
    "nome": "walch j",
    "codigo": "W153"
  },
  {
    "nome": "walch p",
    "codigo": "W154"
  },
  {
    "nome": "walck",
    "codigo": "W155"
  },
  {
    "nome": "walco",
    "codigo": "W156"
  },
  {
    "nome": "wald",
    "codigo": "W157"
  },
  {
    "nome": "walde",
    "codigo": "W158"
  },
  {
    "nome": "waldeg",
    "codigo": "W159"
  },
  {
    "nome": "waldem",
    "codigo": "W161"
  },
  {
    "nome": "walden",
    "codigo": "W162"
  },
  {
    "nome": "walder",
    "codigo": "W163"
  },
  {
    "nome": "waldm",
    "codigo": "W164"
  },
  {
    "nome": "waldo",
    "codigo": "W165"
  },
  {
    "nome": "waldor",
    "codigo": "W166"
  },
  {
    "nome": "waldr",
    "codigo": "W167"
  },
  {
    "nome": "walds",
    "codigo": "W168"
  },
  {
    "nome": "wale",
    "codigo": "W169"
  },
  {
    "nome": "walei",
    "codigo": "W171"
  },
  {
    "nome": "wales",
    "codigo": "W172"
  },
  {
    "nome": "wales m",
    "codigo": "W173"
  },
  {
    "nome": "walf",
    "codigo": "W174"
  },
  {
    "nome": "walg",
    "codigo": "W175"
  },
  {
    "nome": "wali",
    "codigo": "W176"
  },
  {
    "nome": "walk",
    "codigo": "W177"
  },
  {
    "nome": "walker d",
    "codigo": "W178"
  },
  {
    "nome": "walker f",
    "codigo": "W179"
  },
  {
    "nome": "walker j",
    "codigo": "W181"
  },
  {
    "nome": "walker m",
    "codigo": "W182"
  },
  {
    "nome": "walker p",
    "codigo": "W183"
  },
  {
    "nome": "walker s",
    "codigo": "W184"
  },
  {
    "nome": "walker t",
    "codigo": "W185"
  },
  {
    "nome": "walker w",
    "codigo": "W186"
  },
  {
    "nome": "wall",
    "codigo": "W187"
  },
  {
    "nome": "wallace d",
    "codigo": "W188"
  },
  {
    "nome": "wallace f",
    "codigo": "W189"
  },
  {
    "nome": "wallace j",
    "codigo": "W191"
  },
  {
    "nome": "wallace m",
    "codigo": "W192"
  },
  {
    "nome": "wallace p",
    "codigo": "W193"
  },
  {
    "nome": "wallace s",
    "codigo": "W194"
  },
  {
    "nome": "wallace w",
    "codigo": "W195"
  },
  {
    "nome": "wallc",
    "codigo": "W196"
  },
  {
    "nome": "wallen",
    "codigo": "W197"
  },
  {
    "nome": "waller",
    "codigo": "W198"
  },
  {
    "nome": "walley",
    "codigo": "W199"
  },
  {
    "nome": "walli",
    "codigo": "W211"
  },
  {
    "nome": "wallingf",
    "codigo": "W212"
  },
  {
    "nome": "wallingt",
    "codigo": "W213"
  },
  {
    "nome": "wallis",
    "codigo": "W214"
  },
  {
    "nome": "wallo",
    "codigo": "W215"
  },
  {
    "nome": "walm",
    "codigo": "W216"
  },
  {
    "nome": "waln",
    "codigo": "W217"
  },
  {
    "nome": "walp",
    "codigo": "W218"
  },
  {
    "nome": "walpole m",
    "codigo": "W219"
  },
  {
    "nome": "walr",
    "codigo": "W221"
  },
  {
    "nome": "wals",
    "codigo": "W222"
  },
  {
    "nome": "walsh",
    "codigo": "W223"
  },
  {
    "nome": "walsh d",
    "codigo": "W224"
  },
  {
    "nome": "walsh j",
    "codigo": "W225"
  },
  {
    "nome": "walsh m",
    "codigo": "W226"
  },
  {
    "nome": "walsh s",
    "codigo": "W227"
  },
  {
    "nome": "walsh w",
    "codigo": "W228"
  },
  {
    "nome": "walsi",
    "codigo": "W229"
  },
  {
    "nome": "walt",
    "codigo": "W231"
  },
  {
    "nome": "walter g",
    "codigo": "W232"
  },
  {
    "nome": "walter m",
    "codigo": "W233"
  },
  {
    "nome": "walter s",
    "codigo": "W234"
  },
  {
    "nome": "walters",
    "codigo": "W235"
  },
  {
    "nome": "walth",
    "codigo": "W236"
  },
  {
    "nome": "walther",
    "codigo": "W237"
  },
  {
    "nome": "walto",
    "codigo": "W238"
  },
  {
    "nome": "walton g",
    "codigo": "W239"
  },
  {
    "nome": "walton m",
    "codigo": "W241"
  },
  {
    "nome": "walw",
    "codigo": "W242"
  },
  {
    "nome": "wam",
    "codigo": "W243"
  },
  {
    "nome": "wan",
    "codigo": "W244"
  },
  {
    "nome": "wand",
    "codigo": "W245"
  },
  {
    "nome": "wang",
    "codigo": "W246"
  },
  {
    "nome": "wanh",
    "codigo": "W247"
  },
  {
    "nome": "wanl",
    "codigo": "W248"
  },
  {
    "nome": "wann",
    "codigo": "W249"
  },
  {
    "nome": "wans",
    "codigo": "W251"
  },
  {
    "nome": "wap",
    "codigo": "W252"
  },
  {
    "nome": "war",
    "codigo": "W253"
  },
  {
    "nome": "warburton",
    "codigo": "W254"
  },
  {
    "nome": "warburton m",
    "codigo": "W255"
  },
  {
    "nome": "ward",
    "codigo": "W256"
  },
  {
    "nome": "ward c",
    "codigo": "W257"
  },
  {
    "nome": "ward f",
    "codigo": "W258"
  },
  {
    "nome": "ward j",
    "codigo": "W259"
  },
  {
    "nome": "ward m",
    "codigo": "W261"
  },
  {
    "nome": "ward p",
    "codigo": "W262"
  },
  {
    "nome": "ward s",
    "codigo": "W263"
  },
  {
    "nome": "ward w",
    "codigo": "W264"
  },
  {
    "nome": "warde",
    "codigo": "W265"
  },
  {
    "nome": "wardl",
    "codigo": "W266"
  },
  {
    "nome": "ware",
    "codigo": "W267"
  },
  {
    "nome": "ware d",
    "codigo": "W268"
  },
  {
    "nome": "ware j",
    "codigo": "W269"
  },
  {
    "nome": "ware m",
    "codigo": "W271"
  },
  {
    "nome": "ware s",
    "codigo": "W272"
  },
  {
    "nome": "ware w",
    "codigo": "W273"
  },
  {
    "nome": "waren",
    "codigo": "W274"
  },
  {
    "nome": "warh",
    "codigo": "W275"
  },
  {
    "nome": "wari",
    "codigo": "W276"
  },
  {
    "nome": "waring m",
    "codigo": "W277"
  },
  {
    "nome": "warn",
    "codigo": "W278"
  },
  {
    "nome": "warner",
    "codigo": "W279"
  },
  {
    "nome": "warner d",
    "codigo": "W281"
  },
  {
    "nome": "warner j",
    "codigo": "W282"
  },
  {
    "nome": "warner m",
    "codigo": "W283"
  },
  {
    "nome": "warner s",
    "codigo": "W284"
  },
  {
    "nome": "warner w",
    "codigo": "W285"
  },
  {
    "nome": "warr",
    "codigo": "W286"
  },
  {
    "nome": "warren c",
    "codigo": "W287"
  },
  {
    "nome": "warren f",
    "codigo": "W288"
  },
  {
    "nome": "warren j",
    "codigo": "W289"
  },
  {
    "nome": "warren m",
    "codigo": "W291"
  },
  {
    "nome": "warren p",
    "codigo": "W292"
  },
  {
    "nome": "warren s",
    "codigo": "W293"
  },
  {
    "nome": "warren w",
    "codigo": "W294"
  },
  {
    "nome": "warri",
    "codigo": "W295"
  },
  {
    "nome": "wart",
    "codigo": "W296"
  },
  {
    "nome": "wartens",
    "codigo": "W297"
  },
  {
    "nome": "warto",
    "codigo": "W298"
  },
  {
    "nome": "warw",
    "codigo": "W299"
  },
  {
    "nome": "warwick m",
    "codigo": "W311"
  },
  {
    "nome": "was",
    "codigo": "W312"
  },
  {
    "nome": "waser",
    "codigo": "W313"
  },
  {
    "nome": "wash",
    "codigo": "W314"
  },
  {
    "nome": "washburn m",
    "codigo": "W315"
  },
  {
    "nome": "washi",
    "codigo": "W316"
  },
  {
    "nome": "washington",
    "codigo": "W317"
  },
  {
    "nome": "washington g",
    "codigo": "W318"
  },
  {
    "nome": "washington m",
    "codigo": "W319"
  },
  {
    "nome": "wass",
    "codigo": "W321"
  },
  {
    "nome": "wasser",
    "codigo": "W322"
  },
  {
    "nome": "wassi",
    "codigo": "W323"
  },
  {
    "nome": "wat",
    "codigo": "W324"
  },
  {
    "nome": "waterf",
    "codigo": "W325"
  },
  {
    "nome": "waterh",
    "codigo": "W326"
  },
  {
    "nome": "waterl",
    "codigo": "W327"
  },
  {
    "nome": "waterm",
    "codigo": "W328"
  },
  {
    "nome": "waters",
    "codigo": "W329"
  },
  {
    "nome": "waters m",
    "codigo": "W331"
  },
  {
    "nome": "waterst",
    "codigo": "W332"
  },
  {
    "nome": "waterw",
    "codigo": "W333"
  },
  {
    "nome": "watk",
    "codigo": "W334"
  },
  {
    "nome": "watke",
    "codigo": "W335"
  },
  {
    "nome": "watkinson",
    "codigo": "W336"
  },
  {
    "nome": "wats",
    "codigo": "W337"
  },
  {
    "nome": "watson d",
    "codigo": "W338"
  },
  {
    "nome": "watson j",
    "codigo": "W339"
  },
  {
    "nome": "watson m",
    "codigo": "W341"
  },
  {
    "nome": "watson s",
    "codigo": "W342"
  },
  {
    "nome": "watson w",
    "codigo": "W343"
  },
  {
    "nome": "watt",
    "codigo": "W344"
  },
  {
    "nome": "watt j",
    "codigo": "W345"
  },
  {
    "nome": "watt p",
    "codigo": "W346"
  },
  {
    "nome": "watti",
    "codigo": "W347"
  },
  {
    "nome": "watts",
    "codigo": "W348"
  },
  {
    "nome": "watts d",
    "codigo": "W349"
  },
  {
    "nome": "watts j",
    "codigo": "W351"
  },
  {
    "nome": "watts m",
    "codigo": "W352"
  },
  {
    "nome": "watts s",
    "codigo": "W353"
  },
  {
    "nome": "wau",
    "codigo": "W354"
  },
  {
    "nome": "waut",
    "codigo": "W355"
  },
  {
    "nome": "waw",
    "codigo": "W356"
  },
  {
    "nome": "way",
    "codigo": "W357"
  },
  {
    "nome": "wayl",
    "codigo": "W358"
  },
  {
    "nome": "wayn",
    "codigo": "W359"
  },
  {
    "nome": "we",
    "codigo": "W361"
  },
  {
    "nome": "weal",
    "codigo": "W362"
  },
  {
    "nome": "weav",
    "codigo": "W363"
  },
  {
    "nome": "web",
    "codigo": "W364"
  },
  {
    "nome": "webb",
    "codigo": "W365"
  },
  {
    "nome": "webb g",
    "codigo": "W366"
  },
  {
    "nome": "webb m",
    "codigo": "W367"
  },
  {
    "nome": "webb s",
    "codigo": "W368"
  },
  {
    "nome": "webbe",
    "codigo": "W369"
  },
  {
    "nome": "webber",
    "codigo": "W371"
  },
  {
    "nome": "webber m",
    "codigo": "W372"
  },
  {
    "nome": "weber",
    "codigo": "W373"
  },
  {
    "nome": "weber g",
    "codigo": "W374"
  },
  {
    "nome": "weber m",
    "codigo": "W375"
  },
  {
    "nome": "weber s",
    "codigo": "W376"
  },
  {
    "nome": "webs",
    "codigo": "W377"
  },
  {
    "nome": "webster c",
    "codigo": "W378"
  },
  {
    "nome": "webster f",
    "codigo": "W379"
  },
  {
    "nome": "webster j",
    "codigo": "W381"
  },
  {
    "nome": "webster m",
    "codigo": "W382"
  },
  {
    "nome": "webster p",
    "codigo": "W383"
  },
  {
    "nome": "webster s",
    "codigo": "W384"
  },
  {
    "nome": "webster w",
    "codigo": "W385"
  },
  {
    "nome": "wech",
    "codigo": "W386"
  },
  {
    "nome": "weck",
    "codigo": "W387"
  },
  {
    "nome": "wed",
    "codigo": "W388"
  },
  {
    "nome": "wede",
    "codigo": "W389"
  },
  {
    "nome": "wedel",
    "codigo": "W391"
  },
  {
    "nome": "wedg",
    "codigo": "W392"
  },
  {
    "nome": "wedgw",
    "codigo": "W393"
  },
  {
    "nome": "wee",
    "codigo": "W394"
  },
  {
    "nome": "weeks",
    "codigo": "W395"
  },
  {
    "nome": "weeks m",
    "codigo": "W396"
  },
  {
    "nome": "weem",
    "codigo": "W397"
  },
  {
    "nome": "weer",
    "codigo": "W398"
  },
  {
    "nome": "weev",
    "codigo": "W399"
  },
  {
    "nome": "weg",
    "codigo": "W411"
  },
  {
    "nome": "wegn",
    "codigo": "W412"
  },
  {
    "nome": "weh",
    "codigo": "W413"
  },
  {
    "nome": "temple s",
    "codigo": "T287"
  },
  {
    "nome": "templet",
    "codigo": "T288"
  },
  {
    "nome": "ten",
    "codigo": "T289"
  },
  {
    "nome": "tend",
    "codigo": "T291"
  },
  {
    "nome": "tene",
    "codigo": "T292"
  },
  {
    "nome": "teni",
    "codigo": "T293"
  },
  {
    "nome": "tenis",
    "codigo": "T294"
  },
  {
    "nome": "tenn",
    "codigo": "T295"
  },
  {
    "nome": "tennant m",
    "codigo": "T296"
  },
  {
    "nome": "tenne",
    "codigo": "T297"
  },
  {
    "nome": "tenney",
    "codigo": "T298"
  },
  {
    "nome": "tenney m",
    "codigo": "T299"
  },
  {
    "nome": "tenni",
    "codigo": "T311"
  },
  {
    "nome": "tenny",
    "codigo": "T312"
  },
  {
    "nome": "tent",
    "codigo": "T313"
  },
  {
    "nome": "teo",
    "codigo": "T314"
  },
  {
    "nome": "ter",
    "codigo": "T315"
  },
  {
    "nome": "tere",
    "codigo": "T316"
  },
  {
    "nome": "terg",
    "codigo": "T317"
  },
  {
    "nome": "terh",
    "codigo": "T318"
  },
  {
    "nome": "term",
    "codigo": "T319"
  },
  {
    "nome": "tern",
    "codigo": "T321"
  },
  {
    "nome": "terp",
    "codigo": "T322"
  },
  {
    "nome": "terr",
    "codigo": "T323"
  },
  {
    "nome": "terras",
    "codigo": "T324"
  },
  {
    "nome": "terre",
    "codigo": "T325"
  },
  {
    "nome": "terri",
    "codigo": "T326"
  },
  {
    "nome": "terrin",
    "codigo": "T327"
  },
  {
    "nome": "terro",
    "codigo": "T328"
  },
  {
    "nome": "terry",
    "codigo": "T329"
  },
  {
    "nome": "ters",
    "codigo": "T331"
  },
  {
    "nome": "tert",
    "codigo": "T332"
  },
  {
    "nome": "terw",
    "codigo": "T333"
  },
  {
    "nome": "terz",
    "codigo": "T334"
  },
  {
    "nome": "tes",
    "codigo": "T335"
  },
  {
    "nome": "tesau",
    "codigo": "T336"
  },
  {
    "nome": "tesc",
    "codigo": "T337"
  },
  {
    "nome": "tess",
    "codigo": "T338"
  },
  {
    "nome": "tessi",
    "codigo": "T339"
  },
  {
    "nome": "tessin",
    "codigo": "T341"
  },
  {
    "nome": "test",
    "codigo": "T342"
  },
  {
    "nome": "teste",
    "codigo": "T343"
  },
  {
    "nome": "testi",
    "codigo": "T344"
  },
  {
    "nome": "testo",
    "codigo": "T345"
  },
  {
    "nome": "testu",
    "codigo": "T346"
  },
  {
    "nome": "tet",
    "codigo": "T347"
  },
  {
    "nome": "tetr",
    "codigo": "T348"
  },
  {
    "nome": "tetz",
    "codigo": "T349"
  },
  {
    "nome": "teu",
    "codigo": "T351"
  },
  {
    "nome": "teut",
    "codigo": "T352"
  },
  {
    "nome": "tev",
    "codigo": "T353"
  },
  {
    "nome": "tew",
    "codigo": "T354"
  },
  {
    "nome": "tex",
    "codigo": "T355"
  },
  {
    "nome": "tey",
    "codigo": "T356"
  },
  {
    "nome": "th",
    "codigo": "T357"
  },
  {
    "nome": "thac",
    "codigo": "T358"
  },
  {
    "nome": "thacher g",
    "codigo": "T359"
  },
  {
    "nome": "thacher m",
    "codigo": "T361"
  },
  {
    "nome": "thacher s",
    "codigo": "T362"
  },
  {
    "nome": "thack",
    "codigo": "T363"
  },
  {
    "nome": "thai",
    "codigo": "T364"
  },
  {
    "nome": "thal",
    "codigo": "T365"
  },
  {
    "nome": "tham",
    "codigo": "T366"
  },
  {
    "nome": "than",
    "codigo": "T367"
  },
  {
    "nome": "thau",
    "codigo": "T368"
  },
  {
    "nome": "thay",
    "codigo": "T369"
  },
  {
    "nome": "thayer g",
    "codigo": "T371"
  },
  {
    "nome": "thayer m",
    "codigo": "T372"
  },
  {
    "nome": "thayer s",
    "codigo": "T373"
  },
  {
    "nome": "the",
    "codigo": "T374"
  },
  {
    "nome": "theb",
    "codigo": "T375"
  },
  {
    "nome": "thei",
    "codigo": "T376"
  },
  {
    "nome": "theim",
    "codigo": "T377"
  },
  {
    "nome": "thek",
    "codigo": "T378"
  },
  {
    "nome": "thel",
    "codigo": "T379"
  },
  {
    "nome": "thelo",
    "codigo": "T381"
  },
  {
    "nome": "thelw",
    "codigo": "T382"
  },
  {
    "nome": "them",
    "codigo": "T383"
  },
  {
    "nome": "then",
    "codigo": "T384"
  },
  {
    "nome": "theo",
    "codigo": "T385"
  },
  {
    "nome": "theoc",
    "codigo": "T386"
  },
  {
    "nome": "theod",
    "codigo": "T387"
  },
  {
    "nome": "theodo",
    "codigo": "T388"
  },
  {
    "nome": "theodos",
    "codigo": "T389"
  },
  {
    "nome": "theog",
    "codigo": "T391"
  },
  {
    "nome": "theon",
    "codigo": "T392"
  },
  {
    "nome": "theop",
    "codigo": "T393"
  },
  {
    "nome": "theophi",
    "codigo": "T394"
  },
  {
    "nome": "theopo",
    "codigo": "T395"
  },
  {
    "nome": "theor",
    "codigo": "T396"
  },
  {
    "nome": "theos",
    "codigo": "T397"
  },
  {
    "nome": "ther",
    "codigo": "T398"
  },
  {
    "nome": "theri",
    "codigo": "T399"
  },
  {
    "nome": "therm",
    "codigo": "T411"
  },
  {
    "nome": "thero",
    "codigo": "T412"
  },
  {
    "nome": "thes",
    "codigo": "T413"
  },
  {
    "nome": "thess",
    "codigo": "T414"
  },
  {
    "nome": "theu",
    "codigo": "T415"
  },
  {
    "nome": "thev",
    "codigo": "T416"
  },
  {
    "nome": "theveni",
    "codigo": "T417"
  },
  {
    "nome": "theveno",
    "codigo": "T418"
  },
  {
    "nome": "thew",
    "codigo": "T419"
  },
  {
    "nome": "thex",
    "codigo": "T421"
  },
  {
    "nome": "thi",
    "codigo": "T422"
  },
  {
    "nome": "thiard",
    "codigo": "T423"
  },
  {
    "nome": "thib",
    "codigo": "T424"
  },
  {
    "nome": "thibaul",
    "codigo": "T425"
  },
  {
    "nome": "thibaut",
    "codigo": "T426"
  },
  {
    "nome": "thibo",
    "codigo": "T427"
  },
  {
    "nome": "thic",
    "codigo": "T428"
  },
  {
    "nome": "thie",
    "codigo": "T429"
  },
  {
    "nome": "thiel",
    "codigo": "T431"
  },
  {
    "nome": "thielm",
    "codigo": "T432"
  },
  {
    "nome": "thiem",
    "codigo": "T433"
  },
  {
    "nome": "thien",
    "codigo": "T434"
  },
  {
    "nome": "thier",
    "codigo": "T435"
  },
  {
    "nome": "thierry",
    "codigo": "T436"
  },
  {
    "nome": "thierry m",
    "codigo": "T437"
  },
  {
    "nome": "thiers",
    "codigo": "T438"
  },
  {
    "nome": "thies",
    "codigo": "T439"
  },
  {
    "nome": "thil",
    "codigo": "T441"
  },
  {
    "nome": "thilo",
    "codigo": "T442"
  },
  {
    "nome": "thim",
    "codigo": "T443"
  },
  {
    "nome": "thio",
    "codigo": "T444"
  },
  {
    "nome": "thir",
    "codigo": "T445"
  },
  {
    "nome": "thirl",
    "codigo": "T446"
  },
  {
    "nome": "thiro",
    "codigo": "T447"
  },
  {
    "nome": "this",
    "codigo": "T448"
  },
  {
    "nome": "tho",
    "codigo": "T449"
  },
  {
    "nome": "thol",
    "codigo": "T451"
  },
  {
    "nome": "thom",
    "codigo": "T452"
  },
  {
    "nome": "thoman",
    "codigo": "T453"
  },
  {
    "nome": "thomas",
    "codigo": "T454"
  },
  {
    "nome": "thomas c",
    "codigo": "T455"
  },
  {
    "nome": "thomas f",
    "codigo": "T456"
  },
  {
    "nome": "thomas h",
    "codigo": "T457"
  },
  {
    "nome": "thomas j",
    "codigo": "T458"
  },
  {
    "nome": "thomas m",
    "codigo": "T459"
  },
  {
    "nome": "thomas p",
    "codigo": "T461"
  },
  {
    "nome": "thomas s",
    "codigo": "T462"
  },
  {
    "nome": "thomas w",
    "codigo": "T463"
  },
  {
    "nome": "thomass",
    "codigo": "T464"
  },
  {
    "nome": "thomassy",
    "codigo": "T465"
  },
  {
    "nome": "thomo",
    "codigo": "T466"
  },
  {
    "nome": "thomp",
    "codigo": "T467"
  },
  {
    "nome": "thompson",
    "codigo": "T468"
  },
  {
    "nome": "thompson c",
    "codigo": "T469"
  },
  {
    "nome": "thompson f",
    "codigo": "T471"
  },
  {
    "nome": "thompson h",
    "codigo": "T472"
  },
  {
    "nome": "thompson j",
    "codigo": "T473"
  },
  {
    "nome": "thompson m",
    "codigo": "T474"
  },
  {
    "nome": "thompson p",
    "codigo": "T475"
  },
  {
    "nome": "thompson s",
    "codigo": "T476"
  },
  {
    "nome": "thompson t",
    "codigo": "T477"
  },
  {
    "nome": "thompson w",
    "codigo": "T478"
  },
  {
    "nome": "thoms",
    "codigo": "T479"
  },
  {
    "nome": "thomsen",
    "codigo": "T481"
  },
  {
    "nome": "thomson",
    "codigo": "T482"
  },
  {
    "nome": "thomson g",
    "codigo": "T483"
  },
  {
    "nome": "thomson m",
    "codigo": "T484"
  },
  {
    "nome": "thomson s",
    "codigo": "T485"
  },
  {
    "nome": "thomson w",
    "codigo": "T486"
  },
  {
    "nome": "thor",
    "codigo": "T487"
  },
  {
    "nome": "thore",
    "codigo": "T488"
  },
  {
    "nome": "thores",
    "codigo": "T489"
  },
  {
    "nome": "thori",
    "codigo": "T491"
  },
  {
    "nome": "thoris",
    "codigo": "T492"
  },
  {
    "nome": "thork",
    "codigo": "T493"
  },
  {
    "nome": "thorl",
    "codigo": "T494"
  },
  {
    "nome": "thorm",
    "codigo": "T495"
  },
  {
    "nome": "thorn",
    "codigo": "T496"
  },
  {
    "nome": "thornb",
    "codigo": "T497"
  },
  {
    "nome": "thornd",
    "codigo": "T498"
  },
  {
    "nome": "thorndi",
    "codigo": "T499"
  },
  {
    "nome": "thorne",
    "codigo": "T511"
  },
  {
    "nome": "thorney",
    "codigo": "T512"
  },
  {
    "nome": "thornt",
    "codigo": "T513"
  },
  {
    "nome": "thornton m",
    "codigo": "T514"
  },
  {
    "nome": "thornw",
    "codigo": "T515"
  },
  {
    "nome": "thoro",
    "codigo": "T516"
  },
  {
    "nome": "thorp",
    "codigo": "T517"
  },
  {
    "nome": "thorpe",
    "codigo": "T518"
  },
  {
    "nome": "thorpe g",
    "codigo": "T519"
  },
  {
    "nome": "thorpe m",
    "codigo": "T521"
  },
  {
    "nome": "thorpe s",
    "codigo": "T522"
  },
  {
    "nome": "thort",
    "codigo": "T523"
  },
  {
    "nome": "thou",
    "codigo": "T524"
  },
  {
    "nome": "thoui",
    "codigo": "T525"
  },
  {
    "nome": "thour",
    "codigo": "T526"
  },
  {
    "nome": "thout",
    "codigo": "T527"
  },
  {
    "nome": "thouv",
    "codigo": "T528"
  },
  {
    "nome": "thr",
    "codigo": "T529"
  },
  {
    "nome": "thre",
    "codigo": "T531"
  },
  {
    "nome": "thu",
    "codigo": "T532"
  },
  {
    "nome": "thui",
    "codigo": "T533"
  },
  {
    "nome": "thul",
    "codigo": "T534"
  },
  {
    "nome": "thun",
    "codigo": "T535"
  },
  {
    "nome": "thur",
    "codigo": "T536"
  },
  {
    "nome": "thurl",
    "codigo": "T537"
  },
  {
    "nome": "thurlo",
    "codigo": "T538"
  },
  {
    "nome": "thurm",
    "codigo": "T539"
  },
  {
    "nome": "thurn",
    "codigo": "T541"
  },
  {
    "nome": "thuro",
    "codigo": "T542"
  },
  {
    "nome": "thurs",
    "codigo": "T543"
  },
  {
    "nome": "thurston",
    "codigo": "T544"
  },
  {
    "nome": "thurston g",
    "codigo": "T545"
  },
  {
    "nome": "thurston m",
    "codigo": "T546"
  },
  {
    "nome": "thurston s",
    "codigo": "T547"
  },
  {
    "nome": "thw",
    "codigo": "T548"
  },
  {
    "nome": "thy",
    "codigo": "T549"
  },
  {
    "nome": "ti",
    "codigo": "T551"
  },
  {
    "nome": "tib",
    "codigo": "T552"
  },
  {
    "nome": "tibe",
    "codigo": "T553"
  },
  {
    "nome": "tibn",
    "codigo": "T554"
  },
  {
    "nome": "tic",
    "codigo": "T555"
  },
  {
    "nome": "tick",
    "codigo": "T556"
  },
  {
    "nome": "ticknor",
    "codigo": "T557"
  },
  {
    "nome": "tid",
    "codigo": "T558"
  },
  {
    "nome": "tie",
    "codigo": "T559"
  },
  {
    "nome": "tief",
    "codigo": "T561"
  },
  {
    "nome": "tiel",
    "codigo": "T562"
  },
  {
    "nome": "tiep",
    "codigo": "T563"
  },
  {
    "nome": "tier",
    "codigo": "T564"
  },
  {
    "nome": "tif",
    "codigo": "T565"
  },
  {
    "nome": "tig",
    "codigo": "T566"
  },
  {
    "nome": "tigl",
    "codigo": "T567"
  },
  {
    "nome": "tigr",
    "codigo": "T568"
  },
  {
    "nome": "til",
    "codigo": "T569"
  },
  {
    "nome": "tild",
    "codigo": "T571"
  },
  {
    "nome": "tile",
    "codigo": "T572"
  },
  {
    "nome": "tili",
    "codigo": "T573"
  },
  {
    "nome": "till",
    "codigo": "T574"
  },
  {
    "nome": "tille",
    "codigo": "T575"
  },
  {
    "nome": "tillet",
    "codigo": "T576"
  },
  {
    "nome": "tilli",
    "codigo": "T577"
  },
  {
    "nome": "tillo",
    "codigo": "T578"
  },
  {
    "nome": "tilly",
    "codigo": "T579"
  },
  {
    "nome": "tils",
    "codigo": "T581"
  },
  {
    "nome": "tim",
    "codigo": "T582"
  },
  {
    "nome": "timb",
    "codigo": "T583"
  },
  {
    "nome": "timm",
    "codigo": "T584"
  },
  {
    "nome": "timo",
    "codigo": "T585"
  },
  {
    "nome": "timp",
    "codigo": "T586"
  },
  {
    "nome": "tin",
    "codigo": "T587"
  },
  {
    "nome": "tind",
    "codigo": "T588"
  },
  {
    "nome": "tink",
    "codigo": "T589"
  },
  {
    "nome": "tinn",
    "codigo": "T591"
  },
  {
    "nome": "tins",
    "codigo": "T592"
  },
  {
    "nome": "tint",
    "codigo": "T593"
  },
  {
    "nome": "tio",
    "codigo": "T594"
  },
  {
    "nome": "tip",
    "codigo": "T595"
  },
  {
    "nome": "tir",
    "codigo": "T596"
  },
  {
    "nome": "tiri",
    "codigo": "T597"
  },
  {
    "nome": "tis",
    "codigo": "T598"
  },
  {
    "nome": "tisch",
    "codigo": "T599"
  },
  {
    "nome": "tische",
    "codigo": "T611"
  },
  {
    "nome": "tischl",
    "codigo": "T612"
  },
  {
    "nome": "tisd",
    "codigo": "T613"
  },
  {
    "nome": "tiss",
    "codigo": "T614"
  },
  {
    "nome": "tissi",
    "codigo": "T615"
  },
  {
    "nome": "tisso",
    "codigo": "T616"
  },
  {
    "nome": "tit",
    "codigo": "T617"
  },
  {
    "nome": "titi",
    "codigo": "T618"
  },
  {
    "nome": "titin",
    "codigo": "T619"
  },
  {
    "nome": "tito",
    "codigo": "T621"
  },
  {
    "nome": "titt",
    "codigo": "T622"
  },
  {
    "nome": "titu",
    "codigo": "T623"
  },
  {
    "nome": "tix",
    "codigo": "T624"
  },
  {
    "nome": "tiz",
    "codigo": "T625"
  },
  {
    "nome": "tk",
    "codigo": "T626"
  },
  {
    "nome": "to",
    "codigo": "T627"
  },
  {
    "nome": "tob",
    "codigo": "T628"
  },
  {
    "nome": "tobi",
    "codigo": "T629"
  },
  {
    "nome": "toc",
    "codigo": "T631"
  },
  {
    "nome": "tocq",
    "codigo": "T632"
  },
  {
    "nome": "tod",
    "codigo": "T633"
  },
  {
    "nome": "todd g",
    "codigo": "T634"
  },
  {
    "nome": "todd m",
    "codigo": "T635"
  },
  {
    "nome": "todd s",
    "codigo": "T636"
  },
  {
    "nome": "tode",
    "codigo": "T637"
  },
  {
    "nome": "todh",
    "codigo": "T638"
  },
  {
    "nome": "todl",
    "codigo": "T639"
  },
  {
    "nome": "toe",
    "codigo": "T641"
  },
  {
    "nome": "toep",
    "codigo": "T642"
  },
  {
    "nome": "toes",
    "codigo": "T643"
  },
  {
    "nome": "tof",
    "codigo": "T644"
  },
  {
    "nome": "tog",
    "codigo": "T645"
  },
  {
    "nome": "toi",
    "codigo": "T646"
  },
  {
    "nome": "tol",
    "codigo": "T647"
  },
  {
    "nome": "tolb",
    "codigo": "T648"
  },
  {
    "nome": "tole",
    "codigo": "T649"
  },
  {
    "nome": "toll",
    "codigo": "T651"
  },
  {
    "nome": "tolm",
    "codigo": "T652"
  },
  {
    "nome": "tolo",
    "codigo": "T653"
  },
  {
    "nome": "tols",
    "codigo": "T654"
  },
  {
    "nome": "tom",
    "codigo": "T655"
  },
  {
    "nome": "tomb",
    "codigo": "T656"
  },
  {
    "nome": "tomi",
    "codigo": "T657"
  },
  {
    "nome": "tomk",
    "codigo": "T658"
  },
  {
    "nome": "toml",
    "codigo": "T659"
  },
  {
    "nome": "tomm",
    "codigo": "T661"
  },
  {
    "nome": "tomp",
    "codigo": "T662"
  },
  {
    "nome": "ton",
    "codigo": "T663"
  },
  {
    "nome": "tone",
    "codigo": "T664"
  },
  {
    "nome": "tong",
    "codigo": "T665"
  },
  {
    "nome": "tonn",
    "codigo": "T666"
  },
  {
    "nome": "tont",
    "codigo": "T667"
  },
  {
    "nome": "too",
    "codigo": "T668"
  },
  {
    "nome": "tooke m",
    "codigo": "T669"
  },
  {
    "nome": "tool",
    "codigo": "T671"
  },
  {
    "nome": "toom",
    "codigo": "T672"
  },
  {
    "nome": "top",
    "codigo": "T673"
  },
  {
    "nome": "toph",
    "codigo": "T674"
  },
  {
    "nome": "topl",
    "codigo": "T675"
  },
  {
    "nome": "tor",
    "codigo": "T676"
  },
  {
    "nome": "tord",
    "codigo": "T677"
  },
  {
    "nome": "tore",
    "codigo": "T678"
  },
  {
    "nome": "toren",
    "codigo": "T679"
  },
  {
    "nome": "tores",
    "codigo": "T681"
  },
  {
    "nome": "torg",
    "codigo": "T682"
  },
  {
    "nome": "tori",
    "codigo": "T683"
  },
  {
    "nome": "torl",
    "codigo": "T684"
  },
  {
    "nome": "torn",
    "codigo": "T685"
  },
  {
    "nome": "torno",
    "codigo": "T686"
  },
  {
    "nome": "torq",
    "codigo": "T687"
  },
  {
    "nome": "torr",
    "codigo": "T688"
  },
  {
    "nome": "torre",
    "codigo": "T689"
  },
  {
    "nome": "torren",
    "codigo": "T691"
  },
  {
    "nome": "torrent",
    "codigo": "T692"
  },
  {
    "nome": "torres",
    "codigo": "T693"
  },
  {
    "nome": "torrey",
    "codigo": "T694"
  },
  {
    "nome": "torri",
    "codigo": "T695"
  },
  {
    "nome": "torrig",
    "codigo": "T696"
  },
  {
    "nome": "torrin",
    "codigo": "T697"
  },
  {
    "nome": "tors",
    "codigo": "T698"
  },
  {
    "nome": "tort",
    "codigo": "T699"
  },
  {
    "nome": "torti",
    "codigo": "T711"
  },
  {
    "nome": "torto",
    "codigo": "T712"
  },
  {
    "nome": "tos",
    "codigo": "T713"
  },
  {
    "nome": "tose",
    "codigo": "T714"
  },
  {
    "nome": "toss",
    "codigo": "T715"
  },
  {
    "nome": "tost",
    "codigo": "T716"
  },
  {
    "nome": "tot",
    "codigo": "T717"
  },
  {
    "nome": "tott",
    "codigo": "T718"
  },
  {
    "nome": "totten",
    "codigo": "T719"
  },
  {
    "nome": "tottl",
    "codigo": "T721"
  },
  {
    "nome": "tou",
    "codigo": "T722"
  },
  {
    "nome": "toul",
    "codigo": "T723"
  },
  {
    "nome": "toulm",
    "codigo": "T724"
  },
  {
    "nome": "toulo",
    "codigo": "T725"
  },
  {
    "nome": "toup",
    "codigo": "T726"
  },
  {
    "nome": "tour",
    "codigo": "T727"
  },
  {
    "nome": "tourn",
    "codigo": "T728"
  },
  {
    "nome": "tourno",
    "codigo": "T729"
  },
  {
    "nome": "touro",
    "codigo": "T731"
  },
  {
    "nome": "tourr",
    "codigo": "T732"
  },
  {
    "nome": "tourv",
    "codigo": "T733"
  },
  {
    "nome": "tous",
    "codigo": "T734"
  },
  {
    "nome": "tousse",
    "codigo": "T735"
  },
  {
    "nome": "tout",
    "codigo": "T736"
  },
  {
    "nome": "tow",
    "codigo": "T737"
  },
  {
    "nome": "tower m",
    "codigo": "T738"
  },
  {
    "nome": "towers",
    "codigo": "T739"
  },
  {
    "nome": "towg",
    "codigo": "T741"
  },
  {
    "nome": "towl",
    "codigo": "T742"
  },
  {
    "nome": "town",
    "codigo": "T743"
  },
  {
    "nome": "towne",
    "codigo": "T744"
  },
  {
    "nome": "townel",
    "codigo": "T745"
  },
  {
    "nome": "townl",
    "codigo": "T746"
  },
  {
    "nome": "towns",
    "codigo": "T747"
  },
  {
    "nome": "townsend g",
    "codigo": "T748"
  },
  {
    "nome": "townsend m",
    "codigo": "T749"
  },
  {
    "nome": "townsend s",
    "codigo": "T751"
  },
  {
    "nome": "townsend w",
    "codigo": "T752"
  },
  {
    "nome": "townsh",
    "codigo": "T753"
  },
  {
    "nome": "townshend m",
    "codigo": "T754"
  },
  {
    "nome": "townso",
    "codigo": "T755"
  },
  {
    "nome": "toy",
    "codigo": "T756"
  },
  {
    "nome": "toz",
    "codigo": "T757"
  },
  {
    "nome": "tr",
    "codigo": "T758"
  },
  {
    "nome": "trac",
    "codigo": "T759"
  },
  {
    "nome": "tracy",
    "codigo": "T761"
  },
  {
    "nome": "tracy m",
    "codigo": "T762"
  },
  {
    "nome": "trad",
    "codigo": "T763"
  },
  {
    "nome": "trae",
    "codigo": "T764"
  },
  {
    "nome": "trag",
    "codigo": "T765"
  },
  {
    "nome": "trai",
    "codigo": "T766"
  },
  {
    "nome": "traill m",
    "codigo": "T767"
  },
  {
    "nome": "train",
    "codigo": "T768"
  },
  {
    "nome": "tral",
    "codigo": "T769"
  },
  {
    "nome": "tram",
    "codigo": "T771"
  },
  {
    "nome": "tran",
    "codigo": "T772"
  },
  {
    "nome": "trap",
    "codigo": "T773"
  },
  {
    "nome": "trapp",
    "codigo": "T774"
  },
  {
    "nome": "tras",
    "codigo": "T775"
  },
  {
    "nome": "trat",
    "codigo": "T776"
  },
  {
    "nome": "trau",
    "codigo": "T777"
  },
  {
    "nome": "trauts",
    "codigo": "T778"
  },
  {
    "nome": "trav",
    "codigo": "T779"
  },
  {
    "nome": "travers m",
    "codigo": "T781"
  },
  {
    "nome": "travi",
    "codigo": "T782"
  },
  {
    "nome": "trax",
    "codigo": "T783"
  },
  {
    "nome": "tre",
    "codigo": "T784"
  },
  {
    "nome": "trebo",
    "codigo": "T785"
  },
  {
    "nome": "tred",
    "codigo": "T786"
  },
  {
    "nome": "trei",
    "codigo": "T787"
  },
  {
    "nome": "trel",
    "codigo": "T788"
  },
  {
    "nome": "trem",
    "codigo": "T789"
  },
  {
    "nome": "tremo",
    "codigo": "T791"
  },
  {
    "nome": "tren",
    "codigo": "T792"
  },
  {
    "nome": "trench m",
    "codigo": "T793"
  },
  {
    "nome": "trenck",
    "codigo": "T794"
  },
  {
    "nome": "trent",
    "codigo": "T795"
  },
  {
    "nome": "tres",
    "codigo": "T796"
  },
  {
    "nome": "tresh",
    "codigo": "T797"
  },
  {
    "nome": "tresi",
    "codigo": "T798"
  },
  {
    "nome": "tress",
    "codigo": "T799"
  },
  {
    "nome": "treu",
    "codigo": "T811"
  },
  {
    "nome": "trev",
    "codigo": "T812"
  },
  {
    "nome": "trevi",
    "codigo": "T813"
  },
  {
    "nome": "trevis",
    "codigo": "T814"
  },
  {
    "nome": "trevo",
    "codigo": "T815"
  },
  {
    "nome": "trevor m",
    "codigo": "T816"
  },
  {
    "nome": "trew",
    "codigo": "T817"
  },
  {
    "nome": "trez",
    "codigo": "T818"
  },
  {
    "nome": "tri",
    "codigo": "T819"
  },
  {
    "nome": "trian",
    "codigo": "T821"
  },
  {
    "nome": "trib",
    "codigo": "T822"
  },
  {
    "nome": "tric",
    "codigo": "T823"
  },
  {
    "nome": "trico",
    "codigo": "T824"
  },
  {
    "nome": "trie",
    "codigo": "T825"
  },
  {
    "nome": "trier",
    "codigo": "T826"
  },
  {
    "nome": "tries",
    "codigo": "T827"
  },
  {
    "nome": "trig",
    "codigo": "T828"
  },
  {
    "nome": "tril",
    "codigo": "T829"
  },
  {
    "nome": "trim",
    "codigo": "T831"
  },
  {
    "nome": "trin",
    "codigo": "T832"
  },
  {
    "nome": "trinci",
    "codigo": "T833"
  },
  {
    "nome": "trio",
    "codigo": "T834"
  },
  {
    "nome": "trip",
    "codigo": "T835"
  },
  {
    "nome": "tripp",
    "codigo": "T836"
  },
  {
    "nome": "tris",
    "codigo": "T837"
  },
  {
    "nome": "trist",
    "codigo": "T838"
  },
  {
    "nome": "trit",
    "codigo": "T839"
  },
  {
    "nome": "triv",
    "codigo": "T841"
  },
  {
    "nome": "trivu",
    "codigo": "T842"
  },
  {
    "nome": "tro",
    "codigo": "T843"
  },
  {
    "nome": "trog",
    "codigo": "T844"
  },
  {
    "nome": "troi",
    "codigo": "T845"
  },
  {
    "nome": "trol",
    "codigo": "T846"
  },
  {
    "nome": "trollo",
    "codigo": "T847"
  },
  {
    "nome": "trollope m",
    "codigo": "T848"
  },
  {
    "nome": "trom",
    "codigo": "T849"
  },
  {
    "nome": "tromp",
    "codigo": "T851"
  },
  {
    "nome": "tron",
    "codigo": "T852"
  },
  {
    "nome": "tronci",
    "codigo": "T853"
  },
  {
    "nome": "trons",
    "codigo": "T854"
  },
  {
    "nome": "troo",
    "codigo": "T855"
  },
  {
    "nome": "trop",
    "codigo": "T856"
  },
  {
    "nome": "tros",
    "codigo": "T857"
  },
  {
    "nome": "trot",
    "codigo": "T858"
  },
  {
    "nome": "trou",
    "codigo": "T859"
  },
  {
    "nome": "troui",
    "codigo": "T861"
  },
  {
    "nome": "trouv",
    "codigo": "T862"
  },
  {
    "nome": "trow",
    "codigo": "T863"
  },
  {
    "nome": "troy",
    "codigo": "T864"
  },
  {
    "nome": "tru",
    "codigo": "T865"
  },
  {
    "nome": "trud",
    "codigo": "T866"
  },
  {
    "nome": "trum",
    "codigo": "T867"
  },
  {
    "nome": "trumbull",
    "codigo": "T868"
  },
  {
    "nome": "trumbull j",
    "codigo": "T869"
  },
  {
    "nome": "trumbull s",
    "codigo": "T871"
  },
  {
    "nome": "trur",
    "codigo": "T872"
  },
  {
    "nome": "trus",
    "codigo": "T873"
  },
  {
    "nome": "trut",
    "codigo": "T874"
  },
  {
    "nome": "try",
    "codigo": "T875"
  },
  {
    "nome": "tryp",
    "codigo": "T876"
  },
  {
    "nome": "ts",
    "codigo": "T877"
  },
  {
    "nome": "tscher",
    "codigo": "T878"
  },
  {
    "nome": "tschi",
    "codigo": "T879"
  },
  {
    "nome": "tschu",
    "codigo": "T881"
  },
  {
    "nome": "tse",
    "codigo": "T882"
  },
  {
    "nome": "tu",
    "codigo": "T883"
  },
  {
    "nome": "tub",
    "codigo": "T884"
  },
  {
    "nome": "tuber",
    "codigo": "T885"
  },
  {
    "nome": "tuc",
    "codigo": "T886"
  },
  {
    "nome": "tuch",
    "codigo": "T887"
  },
  {
    "nome": "tucher",
    "codigo": "T888"
  },
  {
    "nome": "tuck",
    "codigo": "T889"
  },
  {
    "nome": "tucker",
    "codigo": "T891"
  },
  {
    "nome": "tucker g",
    "codigo": "T892"
  },
  {
    "nome": "tucker m",
    "codigo": "T893"
  },
  {
    "nome": "tucker s",
    "codigo": "T894"
  },
  {
    "nome": "tucker w",
    "codigo": "T895"
  },
  {
    "nome": "tuckerman",
    "codigo": "T896"
  },
  {
    "nome": "tuckerman m",
    "codigo": "T897"
  },
  {
    "nome": "tucket",
    "codigo": "T898"
  },
  {
    "nome": "tud",
    "codigo": "T899"
  },
  {
    "nome": "tudi",
    "codigo": "T911"
  },
  {
    "nome": "tudo",
    "codigo": "T912"
  },
  {
    "nome": "tue",
    "codigo": "T913"
  },
  {
    "nome": "tuf",
    "codigo": "T914"
  },
  {
    "nome": "tufts m",
    "codigo": "T915"
  },
  {
    "nome": "tuk",
    "codigo": "T916"
  },
  {
    "nome": "tul",
    "codigo": "T917"
  },
  {
    "nome": "tull",
    "codigo": "T918"
  },
  {
    "nome": "tulloch",
    "codigo": "T919"
  },
  {
    "nome": "tulloch m",
    "codigo": "T921"
  },
  {
    "nome": "tullus",
    "codigo": "T922"
  },
  {
    "nome": "tully",
    "codigo": "T923"
  },
  {
    "nome": "tulo",
    "codigo": "T924"
  },
  {
    "nome": "tum",
    "codigo": "T925"
  },
  {
    "nome": "tun",
    "codigo": "T926"
  },
  {
    "nome": "tuns",
    "codigo": "T927"
  },
  {
    "nome": "tup",
    "codigo": "T928"
  },
  {
    "nome": "tur",
    "codigo": "T929"
  },
  {
    "nome": "turb",
    "codigo": "T931"
  },
  {
    "nome": "turc",
    "codigo": "T932"
  },
  {
    "nome": "turco",
    "codigo": "T933"
  },
  {
    "nome": "ture",
    "codigo": "T934"
  },
  {
    "nome": "turen",
    "codigo": "T935"
  },
  {
    "nome": "turg",
    "codigo": "T936"
  },
  {
    "nome": "turgo",
    "codigo": "T937"
  },
  {
    "nome": "turi",
    "codigo": "T938"
  },
  {
    "nome": "turk",
    "codigo": "T939"
  },
  {
    "nome": "turl",
    "codigo": "T941"
  },
  {
    "nome": "turn",
    "codigo": "T942"
  },
  {
    "nome": "turnbull m",
    "codigo": "T943"
  },
  {
    "nome": "turne",
    "codigo": "T944"
  },
  {
    "nome": "turner c",
    "codigo": "T945"
  },
  {
    "nome": "turner f",
    "codigo": "T946"
  },
  {
    "nome": "turner h",
    "codigo": "T947"
  },
  {
    "nome": "turner j",
    "codigo": "T948"
  },
  {
    "nome": "turner m",
    "codigo": "T949"
  },
  {
    "nome": "turner p",
    "codigo": "T951"
  },
  {
    "nome": "turner s",
    "codigo": "T952"
  },
  {
    "nome": "turner t",
    "codigo": "T953"
  },
  {
    "nome": "turner w",
    "codigo": "T954"
  },
  {
    "nome": "turnh",
    "codigo": "T955"
  },
  {
    "nome": "turno",
    "codigo": "T956"
  },
  {
    "nome": "turp",
    "codigo": "T957"
  },
  {
    "nome": "turr",
    "codigo": "T958"
  },
  {
    "nome": "turrett",
    "codigo": "T959"
  },
  {
    "nome": "turri",
    "codigo": "T961"
  },
  {
    "nome": "turt",
    "codigo": "T962"
  },
  {
    "nome": "turv",
    "codigo": "T963"
  },
  {
    "nome": "tus",
    "codigo": "T964"
  },
  {
    "nome": "tuss",
    "codigo": "T965"
  },
  {
    "nome": "tut",
    "codigo": "T966"
  },
  {
    "nome": "tutt",
    "codigo": "T967"
  },
  {
    "nome": "tuy",
    "codigo": "T968"
  },
  {
    "nome": "tw",
    "codigo": "T969"
  },
  {
    "nome": "twee",
    "codigo": "T971"
  },
  {
    "nome": "twi",
    "codigo": "T972"
  },
  {
    "nome": "twin",
    "codigo": "T973"
  },
  {
    "nome": "twis",
    "codigo": "T974"
  },
  {
    "nome": "twy",
    "codigo": "T975"
  },
  {
    "nome": "twys",
    "codigo": "T976"
  },
  {
    "nome": "ty",
    "codigo": "T977"
  },
  {
    "nome": "tyc",
    "codigo": "T978"
  },
  {
    "nome": "tye",
    "codigo": "T979"
  },
  {
    "nome": "tyl",
    "codigo": "T981"
  },
  {
    "nome": "tyler g",
    "codigo": "T982"
  },
  {
    "nome": "tyler m",
    "codigo": "T983"
  },
  {
    "nome": "tyler s",
    "codigo": "T984"
  },
  {
    "nome": "tyler w",
    "codigo": "T985"
  },
  {
    "nome": "tym",
    "codigo": "T986"
  },
  {
    "nome": "tyn",
    "codigo": "T987"
  },
  {
    "nome": "tyndall",
    "codigo": "T988"
  },
  {
    "nome": "tyng",
    "codigo": "T989"
  },
  {
    "nome": "typ",
    "codigo": "T991"
  },
  {
    "nome": "tyr",
    "codigo": "T992"
  },
  {
    "nome": "tyrrell",
    "codigo": "T993"
  },
  {
    "nome": "tys",
    "codigo": "T994"
  },
  {
    "nome": "tyt",
    "codigo": "T995"
  },
  {
    "nome": "tytler",
    "codigo": "T996"
  },
  {
    "nome": "tytler s",
    "codigo": "T997"
  },
  {
    "nome": "tz",
    "codigo": "T998"
  },
  {
    "nome": "tzs",
    "codigo": "T999"
  },
  {
    "nome": "u",
    "codigo": "U11"
  },
  {
    "nome": "ua",
    "codigo": "U11"
  },
  {
    "nome": "ub",
    "codigo": "U12"
  },
  {
    "nome": "ube",
    "codigo": "U13"
  },
  {
    "nome": "uber",
    "codigo": "U14"
  },
  {
    "nome": "ubi",
    "codigo": "U15"
  },
  {
    "nome": "uc",
    "codigo": "U16"
  },
  {
    "nome": "uch",
    "codigo": "U17"
  },
  {
    "nome": "ud",
    "codigo": "U18"
  },
  {
    "nome": "ude",
    "codigo": "U19"
  },
  {
    "nome": "udi",
    "codigo": "U21"
  },
  {
    "nome": "ue",
    "codigo": "U22"
  },
  {
    "nome": "uf",
    "codigo": "U23"
  },
  {
    "nome": "uffi",
    "codigo": "U24"
  },
  {
    "nome": "uffo",
    "codigo": "U25"
  },
  {
    "nome": "ug",
    "codigo": "U26"
  },
  {
    "nome": "ugo",
    "codigo": "U27"
  },
  {
    "nome": "uh",
    "codigo": "U28"
  },
  {
    "nome": "uhd",
    "codigo": "U29"
  },
  {
    "nome": "uhl",
    "codigo": "U31"
  },
  {
    "nome": "uht",
    "codigo": "U32"
  },
  {
    "nome": "ui",
    "codigo": "U33"
  },
  {
    "nome": "uk",
    "codigo": "U34"
  },
  {
    "nome": "ukr",
    "codigo": "U35"
  },
  {
    "nome": "ul",
    "codigo": "U36"
  },
  {
    "nome": "ule",
    "codigo": "U37"
  },
  {
    "nome": "ulf",
    "codigo": "U38"
  },
  {
    "nome": "uli",
    "codigo": "U39"
  },
  {
    "nome": "ull",
    "codigo": "U41"
  },
  {
    "nome": "ulle",
    "codigo": "U42"
  },
  {
    "nome": "ulm",
    "codigo": "U43"
  },
  {
    "nome": "ulp",
    "codigo": "U44"
  },
  {
    "nome": "ulr",
    "codigo": "U45"
  },
  {
    "nome": "uls",
    "codigo": "U46"
  },
  {
    "nome": "ult",
    "codigo": "U47"
  },
  {
    "nome": "um",
    "codigo": "U48"
  },
  {
    "nome": "umbr",
    "codigo": "U49"
  },
  {
    "nome": "umf",
    "codigo": "U51"
  },
  {
    "nome": "uml",
    "codigo": "U52"
  },
  {
    "nome": "ums",
    "codigo": "U53"
  },
  {
    "nome": "un",
    "codigo": "U54"
  },
  {
    "nome": "unde",
    "codigo": "U55"
  },
  {
    "nome": "underw",
    "codigo": "U56"
  },
  {
    "nome": "ung",
    "codigo": "U57"
  },
  {
    "nome": "uni",
    "codigo": "U58"
  },
  {
    "nome": "uns",
    "codigo": "U59"
  },
  {
    "nome": "unt",
    "codigo": "U61"
  },
  {
    "nome": "unw",
    "codigo": "U62"
  },
  {
    "nome": "unz",
    "codigo": "U63"
  },
  {
    "nome": "uo",
    "codigo": "U64"
  },
  {
    "nome": "up",
    "codigo": "U65"
  },
  {
    "nome": "upd",
    "codigo": "U66"
  },
  {
    "nome": "uph",
    "codigo": "U67"
  },
  {
    "nome": "upm",
    "codigo": "U68"
  },
  {
    "nome": "ups",
    "codigo": "U69"
  },
  {
    "nome": "upt",
    "codigo": "U71"
  },
  {
    "nome": "ur",
    "codigo": "U72"
  },
  {
    "nome": "urbi",
    "codigo": "U73"
  },
  {
    "nome": "urc",
    "codigo": "U74"
  },
  {
    "nome": "ure",
    "codigo": "U75"
  },
  {
    "nome": "uri",
    "codigo": "U76"
  },
  {
    "nome": "url",
    "codigo": "U77"
  },
  {
    "nome": "uro",
    "codigo": "U78"
  },
  {
    "nome": "urq",
    "codigo": "U79"
  },
  {
    "nome": "urr",
    "codigo": "U81"
  },
  {
    "nome": "urs",
    "codigo": "U82"
  },
  {
    "nome": "urv",
    "codigo": "U83"
  },
  {
    "nome": "us",
    "codigo": "U84"
  },
  {
    "nome": "ush",
    "codigo": "U85"
  },
  {
    "nome": "usl",
    "codigo": "U86"
  },
  {
    "nome": "uss",
    "codigo": "U87"
  },
  {
    "nome": "ust",
    "codigo": "U88"
  },
  {
    "nome": "ut",
    "codigo": "U89"
  },
  {
    "nome": "utl",
    "codigo": "U91"
  },
  {
    "nome": "utr",
    "codigo": "U92"
  },
  {
    "nome": "utt",
    "codigo": "U93"
  },
  {
    "nome": "uv",
    "codigo": "U94"
  },
  {
    "nome": "uw",
    "codigo": "U95"
  },
  {
    "nome": "ux",
    "codigo": "U96"
  },
  {
    "nome": "uy",
    "codigo": "U97"
  },
  {
    "nome": "uyt",
    "codigo": "U98"
  },
  {
    "nome": "uz",
    "codigo": "U99"
  },
  {
    "nome": "v",
    "codigo": "V111"
  },
  {
    "nome": "va",
    "codigo": "V111"
  },
  {
    "nome": "vac",
    "codigo": "V112"
  },
  {
    "nome": "vacc",
    "codigo": "V113"
  },
  {
    "nome": "vaccar",
    "codigo": "V114"
  },
  {
    "nome": "vacch",
    "codigo": "V115"
  },
  {
    "nome": "vacchi",
    "codigo": "V116"
  },
  {
    "nome": "vacco",
    "codigo": "V117"
  },
  {
    "nome": "vach",
    "codigo": "V118"
  },
  {
    "nome": "vacho",
    "codigo": "V119"
  },
  {
    "nome": "vacq",
    "codigo": "V121"
  },
  {
    "nome": "vad",
    "codigo": "V122"
  },
  {
    "nome": "vade",
    "codigo": "V123"
  },
  {
    "nome": "vadi",
    "codigo": "V124"
  },
  {
    "nome": "vae",
    "codigo": "V125"
  },
  {
    "nome": "vag",
    "codigo": "V126"
  },
  {
    "nome": "vah",
    "codigo": "V127"
  },
  {
    "nome": "vai",
    "codigo": "V128"
  },
  {
    "nome": "vail",
    "codigo": "V129"
  },
  {
    "nome": "vaill",
    "codigo": "V131"
  },
  {
    "nome": "vais",
    "codigo": "V132"
  },
  {
    "nome": "vaj",
    "codigo": "V133"
  },
  {
    "nome": "vak",
    "codigo": "V134"
  },
  {
    "nome": "val",
    "codigo": "V135"
  },
  {
    "nome": "valad",
    "codigo": "V136"
  },
  {
    "nome": "valar",
    "codigo": "V137"
  },
  {
    "nome": "valaz",
    "codigo": "V138"
  },
  {
    "nome": "valb",
    "codigo": "V139"
  },
  {
    "nome": "valc",
    "codigo": "V141"
  },
  {
    "nome": "valck",
    "codigo": "V142"
  },
  {
    "nome": "valckenb",
    "codigo": "V143"
  },
  {
    "nome": "vald",
    "codigo": "V144"
  },
  {
    "nome": "valdes",
    "codigo": "V145"
  },
  {
    "nome": "valdi",
    "codigo": "V146"
  },
  {
    "nome": "valdo",
    "codigo": "V147"
  },
  {
    "nome": "valdr",
    "codigo": "V148"
  },
  {
    "nome": "vale",
    "codigo": "V149"
  },
  {
    "nome": "valeg",
    "codigo": "V151"
  },
  {
    "nome": "valen",
    "codigo": "V152"
  },
  {
    "nome": "valens",
    "codigo": "V153"
  },
  {
    "nome": "valent",
    "codigo": "V154"
  },
  {
    "nome": "wehr",
    "codigo": "W414"
  },
  {
    "nome": "wei",
    "codigo": "W415"
  },
  {
    "nome": "weich",
    "codigo": "W416"
  },
  {
    "nome": "weid",
    "codigo": "W417"
  },
  {
    "nome": "weidm",
    "codigo": "W418"
  },
  {
    "nome": "weig",
    "codigo": "W419"
  },
  {
    "nome": "weik",
    "codigo": "W421"
  },
  {
    "nome": "weil",
    "codigo": "W422"
  },
  {
    "nome": "wein",
    "codigo": "W423"
  },
  {
    "nome": "weinm",
    "codigo": "W424"
  },
  {
    "nome": "weir",
    "codigo": "W425"
  },
  {
    "nome": "weis",
    "codigo": "W426"
  },
  {
    "nome": "weise",
    "codigo": "W427"
  },
  {
    "nome": "weisk",
    "codigo": "W428"
  },
  {
    "nome": "weiss",
    "codigo": "W429"
  },
  {
    "nome": "weiss j",
    "codigo": "W431"
  },
  {
    "nome": "weiss p",
    "codigo": "W432"
  },
  {
    "nome": "weissen",
    "codigo": "W433"
  },
  {
    "nome": "weit",
    "codigo": "W434"
  },
  {
    "nome": "weits",
    "codigo": "W435"
  },
  {
    "nome": "weitz",
    "codigo": "W436"
  },
  {
    "nome": "wek",
    "codigo": "W437"
  },
  {
    "nome": "wel",
    "codigo": "W438"
  },
  {
    "nome": "welch",
    "codigo": "W439"
  },
  {
    "nome": "welch m",
    "codigo": "W441"
  },
  {
    "nome": "welck",
    "codigo": "W442"
  },
  {
    "nome": "weld",
    "codigo": "W443"
  },
  {
    "nome": "weld m",
    "codigo": "W444"
  },
  {
    "nome": "welde",
    "codigo": "W445"
  },
  {
    "nome": "welh",
    "codigo": "W446"
  },
  {
    "nome": "well",
    "codigo": "W447"
  },
  {
    "nome": "weller",
    "codigo": "W448"
  },
  {
    "nome": "welles",
    "codigo": "W449"
  },
  {
    "nome": "wellesl",
    "codigo": "W451"
  },
  {
    "nome": "welli",
    "codigo": "W452"
  },
  {
    "nome": "wells",
    "codigo": "W453"
  },
  {
    "nome": "wells g",
    "codigo": "W454"
  },
  {
    "nome": "wells m",
    "codigo": "W455"
  },
  {
    "nome": "wells s",
    "codigo": "W456"
  },
  {
    "nome": "wellw",
    "codigo": "W457"
  },
  {
    "nome": "wels",
    "codigo": "W458"
  },
  {
    "nome": "welse",
    "codigo": "W459"
  },
  {
    "nome": "welsh",
    "codigo": "W461"
  },
  {
    "nome": "welsh j",
    "codigo": "W462"
  },
  {
    "nome": "welsh p",
    "codigo": "W463"
  },
  {
    "nome": "welt",
    "codigo": "W464"
  },
  {
    "nome": "welw",
    "codigo": "W465"
  },
  {
    "nome": "wem",
    "codigo": "W466"
  },
  {
    "nome": "wen",
    "codigo": "W467"
  },
  {
    "nome": "wenc",
    "codigo": "W468"
  },
  {
    "nome": "wend",
    "codigo": "W469"
  },
  {
    "nome": "wendl",
    "codigo": "W471"
  },
  {
    "nome": "wendo",
    "codigo": "W472"
  },
  {
    "nome": "wendt",
    "codigo": "W473"
  },
  {
    "nome": "weng",
    "codigo": "W474"
  },
  {
    "nome": "weni",
    "codigo": "W475"
  },
  {
    "nome": "wenl",
    "codigo": "W476"
  },
  {
    "nome": "went",
    "codigo": "W477"
  },
  {
    "nome": "wentworth g",
    "codigo": "W478"
  },
  {
    "nome": "wentworth m",
    "codigo": "W479"
  },
  {
    "nome": "wentz",
    "codigo": "W481"
  },
  {
    "nome": "wenz",
    "codigo": "W482"
  },
  {
    "nome": "wep",
    "codigo": "W483"
  },
  {
    "nome": "wer",
    "codigo": "W484"
  },
  {
    "nome": "werde",
    "codigo": "W485"
  },
  {
    "nome": "were",
    "codigo": "W486"
  },
  {
    "nome": "weren",
    "codigo": "W487"
  },
  {
    "nome": "werf",
    "codigo": "W488"
  },
  {
    "nome": "werl",
    "codigo": "W489"
  },
  {
    "nome": "wern",
    "codigo": "W491"
  },
  {
    "nome": "werner",
    "codigo": "W492"
  },
  {
    "nome": "werner g",
    "codigo": "W493"
  },
  {
    "nome": "werner m",
    "codigo": "W494"
  },
  {
    "nome": "wernh",
    "codigo": "W495"
  },
  {
    "nome": "werni",
    "codigo": "W496"
  },
  {
    "nome": "werns",
    "codigo": "W497"
  },
  {
    "nome": "werp",
    "codigo": "W498"
  },
  {
    "nome": "wert",
    "codigo": "W499"
  },
  {
    "nome": "wes",
    "codigo": "W511"
  },
  {
    "nome": "wesen",
    "codigo": "W512"
  },
  {
    "nome": "wesl",
    "codigo": "W513"
  },
  {
    "nome": "wesley m",
    "codigo": "W514"
  },
  {
    "nome": "wess",
    "codigo": "W515"
  },
  {
    "nome": "west",
    "codigo": "W516"
  },
  {
    "nome": "west d",
    "codigo": "W517"
  },
  {
    "nome": "west j",
    "codigo": "W518"
  },
  {
    "nome": "west m",
    "codigo": "W519"
  },
  {
    "nome": "west s",
    "codigo": "W521"
  },
  {
    "nome": "west w",
    "codigo": "W522"
  },
  {
    "nome": "westb",
    "codigo": "W523"
  },
  {
    "nome": "westc",
    "codigo": "W524"
  },
  {
    "nome": "weste",
    "codigo": "W525"
  },
  {
    "nome": "wester",
    "codigo": "W526"
  },
  {
    "nome": "westerm",
    "codigo": "W527"
  },
  {
    "nome": "westg",
    "codigo": "W528"
  },
  {
    "nome": "westh",
    "codigo": "W529"
  },
  {
    "nome": "westm",
    "codigo": "W531"
  },
  {
    "nome": "westmi",
    "codigo": "W532"
  },
  {
    "nome": "westmo",
    "codigo": "W533"
  },
  {
    "nome": "westo",
    "codigo": "W534"
  },
  {
    "nome": "weston g",
    "codigo": "W535"
  },
  {
    "nome": "weston p",
    "codigo": "W536"
  },
  {
    "nome": "westp",
    "codigo": "W537"
  },
  {
    "nome": "westr",
    "codigo": "W538"
  },
  {
    "nome": "wet",
    "codigo": "W539"
  },
  {
    "nome": "wetm",
    "codigo": "W541"
  },
  {
    "nome": "wett",
    "codigo": "W542"
  },
  {
    "nome": "wetts",
    "codigo": "W543"
  },
  {
    "nome": "wetz",
    "codigo": "W544"
  },
  {
    "nome": "wex",
    "codigo": "W545"
  },
  {
    "nome": "wey",
    "codigo": "W546"
  },
  {
    "nome": "weye",
    "codigo": "W547"
  },
  {
    "nome": "weyl",
    "codigo": "W548"
  },
  {
    "nome": "weym",
    "codigo": "W549"
  },
  {
    "nome": "wh",
    "codigo": "W551"
  },
  {
    "nome": "whal",
    "codigo": "W552"
  },
  {
    "nome": "whart",
    "codigo": "W553"
  },
  {
    "nome": "wharton m",
    "codigo": "W554"
  },
  {
    "nome": "what",
    "codigo": "W555"
  },
  {
    "nome": "whe",
    "codigo": "W556"
  },
  {
    "nome": "wheatl",
    "codigo": "W557"
  },
  {
    "nome": "wheato",
    "codigo": "W558"
  },
  {
    "nome": "whed",
    "codigo": "W559"
  },
  {
    "nome": "whee",
    "codigo": "W561"
  },
  {
    "nome": "wheeler",
    "codigo": "W562"
  },
  {
    "nome": "wheeler g",
    "codigo": "W563"
  },
  {
    "nome": "wheeler p",
    "codigo": "W564"
  },
  {
    "nome": "wheelo",
    "codigo": "W565"
  },
  {
    "nome": "wheelw",
    "codigo": "W566"
  },
  {
    "nome": "whelp",
    "codigo": "W567"
  },
  {
    "nome": "whet",
    "codigo": "W568"
  },
  {
    "nome": "whew",
    "codigo": "W569"
  },
  {
    "nome": "whi",
    "codigo": "W571"
  },
  {
    "nome": "whid",
    "codigo": "W572"
  },
  {
    "nome": "whip",
    "codigo": "W573"
  },
  {
    "nome": "whipple j",
    "codigo": "W574"
  },
  {
    "nome": "whipple p",
    "codigo": "W575"
  },
  {
    "nome": "whis",
    "codigo": "W576"
  },
  {
    "nome": "whit",
    "codigo": "W577"
  },
  {
    "nome": "whitaker m",
    "codigo": "W578"
  },
  {
    "nome": "whitb",
    "codigo": "W579"
  },
  {
    "nome": "whitc",
    "codigo": "W581"
  },
  {
    "nome": "white",
    "codigo": "W582"
  },
  {
    "nome": "white c",
    "codigo": "W583"
  },
  {
    "nome": "white f",
    "codigo": "W584"
  },
  {
    "nome": "white j",
    "codigo": "W585"
  },
  {
    "nome": "white m",
    "codigo": "W586"
  },
  {
    "nome": "white p",
    "codigo": "W587"
  },
  {
    "nome": "white s",
    "codigo": "W588"
  },
  {
    "nome": "white w",
    "codigo": "W589"
  },
  {
    "nome": "whitef",
    "codigo": "W591"
  },
  {
    "nome": "whiteh",
    "codigo": "W592"
  },
  {
    "nome": "whiteho",
    "codigo": "W593"
  },
  {
    "nome": "whitel",
    "codigo": "W594"
  },
  {
    "nome": "whitf",
    "codigo": "W595"
  },
  {
    "nome": "whitg",
    "codigo": "W596"
  },
  {
    "nome": "whiti",
    "codigo": "W597"
  },
  {
    "nome": "whiting",
    "codigo": "W598"
  },
  {
    "nome": "whiting g",
    "codigo": "W599"
  },
  {
    "nome": "whiting m",
    "codigo": "W611"
  },
  {
    "nome": "whiting s",
    "codigo": "W612"
  },
  {
    "nome": "whiting w",
    "codigo": "W613"
  },
  {
    "nome": "whitm",
    "codigo": "W614"
  },
  {
    "nome": "whitman m",
    "codigo": "W615"
  },
  {
    "nome": "whitmore",
    "codigo": "W616"
  },
  {
    "nome": "whitney",
    "codigo": "W617"
  },
  {
    "nome": "whitney d",
    "codigo": "W618"
  },
  {
    "nome": "whitney j",
    "codigo": "W619"
  },
  {
    "nome": "whitney m",
    "codigo": "W621"
  },
  {
    "nome": "whitney s",
    "codigo": "W622"
  },
  {
    "nome": "whitney w",
    "codigo": "W623"
  },
  {
    "nome": "whitt",
    "codigo": "W624"
  },
  {
    "nome": "whitti",
    "codigo": "W625"
  },
  {
    "nome": "whitting",
    "codigo": "W626"
  },
  {
    "nome": "whittl",
    "codigo": "W627"
  },
  {
    "nome": "whitw",
    "codigo": "W628"
  },
  {
    "nome": "why",
    "codigo": "W629"
  },
  {
    "nome": "wi",
    "codigo": "W631"
  },
  {
    "nome": "wib",
    "codigo": "W632"
  },
  {
    "nome": "wic",
    "codigo": "W633"
  },
  {
    "nome": "wichi",
    "codigo": "W634"
  },
  {
    "nome": "wichm",
    "codigo": "W635"
  },
  {
    "nome": "wick",
    "codigo": "W636"
  },
  {
    "nome": "wickh",
    "codigo": "W637"
  },
  {
    "nome": "wid",
    "codigo": "W638"
  },
  {
    "nome": "wide",
    "codigo": "W639"
  },
  {
    "nome": "widm",
    "codigo": "W641"
  },
  {
    "nome": "wie",
    "codigo": "W642"
  },
  {
    "nome": "wiede",
    "codigo": "W643"
  },
  {
    "nome": "wiedem",
    "codigo": "W644"
  },
  {
    "nome": "wieg",
    "codigo": "W645"
  },
  {
    "nome": "wiel",
    "codigo": "W646"
  },
  {
    "nome": "wien",
    "codigo": "W647"
  },
  {
    "nome": "wier",
    "codigo": "W648"
  },
  {
    "nome": "wies",
    "codigo": "W649"
  },
  {
    "nome": "wiese",
    "codigo": "W651"
  },
  {
    "nome": "wiess",
    "codigo": "W652"
  },
  {
    "nome": "wif",
    "codigo": "W653"
  },
  {
    "nome": "wig",
    "codigo": "W654"
  },
  {
    "nome": "wigg",
    "codigo": "W655"
  },
  {
    "nome": "wiggl",
    "codigo": "W656"
  },
  {
    "nome": "wigh",
    "codigo": "W657"
  },
  {
    "nome": "wightm",
    "codigo": "W658"
  },
  {
    "nome": "wigm",
    "codigo": "W659"
  },
  {
    "nome": "wign",
    "codigo": "W661"
  },
  {
    "nome": "wigr",
    "codigo": "W662"
  },
  {
    "nome": "wik",
    "codigo": "W663"
  },
  {
    "nome": "wil",
    "codigo": "W664"
  },
  {
    "nome": "wilbr",
    "codigo": "W665"
  },
  {
    "nome": "wilbu",
    "codigo": "W666"
  },
  {
    "nome": "wilc",
    "codigo": "W667"
  },
  {
    "nome": "wild",
    "codigo": "W668"
  },
  {
    "nome": "wildb",
    "codigo": "W669"
  },
  {
    "nome": "wilde",
    "codigo": "W671"
  },
  {
    "nome": "wilde m",
    "codigo": "W672"
  },
  {
    "nome": "wilder",
    "codigo": "W673"
  },
  {
    "nome": "wildm",
    "codigo": "W674"
  },
  {
    "nome": "wildt",
    "codigo": "W675"
  },
  {
    "nome": "wile",
    "codigo": "W676"
  },
  {
    "nome": "wilf",
    "codigo": "W677"
  },
  {
    "nome": "wilh",
    "codigo": "W678"
  },
  {
    "nome": "wili",
    "codigo": "W679"
  },
  {
    "nome": "wilk",
    "codigo": "W681"
  },
  {
    "nome": "wilkes",
    "codigo": "W682"
  },
  {
    "nome": "wilki",
    "codigo": "W683"
  },
  {
    "nome": "wilkins",
    "codigo": "W684"
  },
  {
    "nome": "wilkins m",
    "codigo": "W685"
  },
  {
    "nome": "wilkinson",
    "codigo": "W686"
  },
  {
    "nome": "wilkinson m",
    "codigo": "W687"
  },
  {
    "nome": "wilks",
    "codigo": "W688"
  },
  {
    "nome": "will",
    "codigo": "W689"
  },
  {
    "nome": "willar",
    "codigo": "W691"
  },
  {
    "nome": "willard d",
    "codigo": "W692"
  },
  {
    "nome": "willard j",
    "codigo": "W693"
  },
  {
    "nome": "willard m",
    "codigo": "W694"
  },
  {
    "nome": "willard s",
    "codigo": "W695"
  },
  {
    "nome": "willard w",
    "codigo": "W696"
  },
  {
    "nome": "willc",
    "codigo": "W697"
  },
  {
    "nome": "wille",
    "codigo": "W698"
  },
  {
    "nome": "willem",
    "codigo": "W699"
  },
  {
    "nome": "willen",
    "codigo": "W711"
  },
  {
    "nome": "willer",
    "codigo": "W712"
  },
  {
    "nome": "willes",
    "codigo": "W713"
  },
  {
    "nome": "willey",
    "codigo": "W714"
  },
  {
    "nome": "willi",
    "codigo": "W715"
  },
  {
    "nome": "william",
    "codigo": "W716"
  },
  {
    "nome": "william g",
    "codigo": "W717"
  },
  {
    "nome": "william m",
    "codigo": "W718"
  },
  {
    "nome": "william s",
    "codigo": "W719"
  },
  {
    "nome": "williams",
    "codigo": "W721"
  },
  {
    "nome": "williams c",
    "codigo": "W722"
  },
  {
    "nome": "williams f",
    "codigo": "W723"
  },
  {
    "nome": "williams j",
    "codigo": "W724"
  },
  {
    "nome": "williams m",
    "codigo": "W725"
  },
  {
    "nome": "williams p",
    "codigo": "W726"
  },
  {
    "nome": "williams s",
    "codigo": "W727"
  },
  {
    "nome": "williams w",
    "codigo": "W728"
  },
  {
    "nome": "williamson",
    "codigo": "W729"
  },
  {
    "nome": "williamson j",
    "codigo": "W731"
  },
  {
    "nome": "williamson p",
    "codigo": "W732"
  },
  {
    "nome": "willin",
    "codigo": "W733"
  },
  {
    "nome": "willis",
    "codigo": "W734"
  },
  {
    "nome": "willis m",
    "codigo": "W735"
  },
  {
    "nome": "willist",
    "codigo": "W736"
  },
  {
    "nome": "willm",
    "codigo": "W737"
  },
  {
    "nome": "willmo",
    "codigo": "W738"
  },
  {
    "nome": "willo",
    "codigo": "W739"
  },
  {
    "nome": "wills",
    "codigo": "W741"
  },
  {
    "nome": "willso",
    "codigo": "W742"
  },
  {
    "nome": "wilm",
    "codigo": "W743"
  },
  {
    "nome": "wilmo",
    "codigo": "W744"
  },
  {
    "nome": "wilr",
    "codigo": "W745"
  },
  {
    "nome": "wils",
    "codigo": "W746"
  },
  {
    "nome": "wilson c",
    "codigo": "W747"
  },
  {
    "nome": "wilson f",
    "codigo": "W748"
  },
  {
    "nome": "wilson j",
    "codigo": "W749"
  },
  {
    "nome": "wilson m",
    "codigo": "W751"
  },
  {
    "nome": "wilson p",
    "codigo": "W752"
  },
  {
    "nome": "wilson s",
    "codigo": "W753"
  },
  {
    "nome": "wilson w",
    "codigo": "W754"
  },
  {
    "nome": "wilt",
    "codigo": "W755"
  },
  {
    "nome": "wilton m",
    "codigo": "W756"
  },
  {
    "nome": "wim",
    "codigo": "W757"
  },
  {
    "nome": "win",
    "codigo": "W758"
  },
  {
    "nome": "winche",
    "codigo": "W759"
  },
  {
    "nome": "winck",
    "codigo": "W761"
  },
  {
    "nome": "winckl",
    "codigo": "W762"
  },
  {
    "nome": "wind",
    "codigo": "W763"
  },
  {
    "nome": "windh",
    "codigo": "W764"
  },
  {
    "nome": "windi",
    "codigo": "W765"
  },
  {
    "nome": "winds",
    "codigo": "W766"
  },
  {
    "nome": "wine",
    "codigo": "W767"
  },
  {
    "nome": "wines",
    "codigo": "W768"
  },
  {
    "nome": "wing",
    "codigo": "W769"
  },
  {
    "nome": "wingf",
    "codigo": "W771"
  },
  {
    "nome": "wingr",
    "codigo": "W772"
  },
  {
    "nome": "wink",
    "codigo": "W773"
  },
  {
    "nome": "winkelm",
    "codigo": "W774"
  },
  {
    "nome": "winkl",
    "codigo": "W775"
  },
  {
    "nome": "winn",
    "codigo": "W776"
  },
  {
    "nome": "wins",
    "codigo": "W777"
  },
  {
    "nome": "winslow",
    "codigo": "W778"
  },
  {
    "nome": "winslow g",
    "codigo": "W779"
  },
  {
    "nome": "winslow m",
    "codigo": "W781"
  },
  {
    "nome": "winslow s",
    "codigo": "W782"
  },
  {
    "nome": "winst",
    "codigo": "W783"
  },
  {
    "nome": "wint",
    "codigo": "W784"
  },
  {
    "nome": "winter g",
    "codigo": "W785"
  },
  {
    "nome": "winter m",
    "codigo": "W786"
  },
  {
    "nome": "winter s",
    "codigo": "W787"
  },
  {
    "nome": "winterf",
    "codigo": "W788"
  },
  {
    "nome": "winth",
    "codigo": "W789"
  },
  {
    "nome": "winthrop",
    "codigo": "W791"
  },
  {
    "nome": "winthrop j",
    "codigo": "W792"
  },
  {
    "nome": "winthrop p",
    "codigo": "W793"
  },
  {
    "nome": "wintr",
    "codigo": "W794"
  },
  {
    "nome": "winw",
    "codigo": "W795"
  },
  {
    "nome": "wio",
    "codigo": "W796"
  },
  {
    "nome": "wip",
    "codigo": "W797"
  },
  {
    "nome": "wir",
    "codigo": "W798"
  },
  {
    "nome": "wirt",
    "codigo": "W799"
  },
  {
    "nome": "wis",
    "codigo": "W811"
  },
  {
    "nome": "wise",
    "codigo": "W812"
  },
  {
    "nome": "wise m",
    "codigo": "W813"
  },
  {
    "nome": "wisem",
    "codigo": "W814"
  },
  {
    "nome": "wisn",
    "codigo": "W815"
  },
  {
    "nome": "wiss",
    "codigo": "W816"
  },
  {
    "nome": "wist",
    "codigo": "W817"
  },
  {
    "nome": "wisw",
    "codigo": "W818"
  },
  {
    "nome": "wit",
    "codigo": "W819"
  },
  {
    "nome": "wite",
    "codigo": "W821"
  },
  {
    "nome": "with",
    "codigo": "W822"
  },
  {
    "nome": "witheri",
    "codigo": "W823"
  },
  {
    "nome": "withers",
    "codigo": "W824"
  },
  {
    "nome": "witi",
    "codigo": "W825"
  },
  {
    "nome": "wits",
    "codigo": "W826"
  },
  {
    "nome": "witt",
    "codigo": "W827"
  },
  {
    "nome": "witte",
    "codigo": "W828"
  },
  {
    "nome": "witten",
    "codigo": "W829"
  },
  {
    "nome": "wittg",
    "codigo": "W831"
  },
  {
    "nome": "witti",
    "codigo": "W832"
  },
  {
    "nome": "witz",
    "codigo": "W833"
  },
  {
    "nome": "witzl",
    "codigo": "W834"
  },
  {
    "nome": "wix",
    "codigo": "W835"
  },
  {
    "nome": "wl",
    "codigo": "W836"
  },
  {
    "nome": "wo",
    "codigo": "W837"
  },
  {
    "nome": "wod",
    "codigo": "W838"
  },
  {
    "nome": "wodes",
    "codigo": "W839"
  },
  {
    "nome": "woe",
    "codigo": "W841"
  },
  {
    "nome": "woel",
    "codigo": "W842"
  },
  {
    "nome": "woer",
    "codigo": "W843"
  },
  {
    "nome": "wof",
    "codigo": "W844"
  },
  {
    "nome": "wog",
    "codigo": "W845"
  },
  {
    "nome": "woh",
    "codigo": "W846"
  },
  {
    "nome": "woi",
    "codigo": "W847"
  },
  {
    "nome": "wol",
    "codigo": "W848"
  },
  {
    "nome": "wolcott",
    "codigo": "W849"
  },
  {
    "nome": "wolcott m",
    "codigo": "W851"
  },
  {
    "nome": "wold",
    "codigo": "W852"
  },
  {
    "nome": "wolf",
    "codigo": "W853"
  },
  {
    "nome": "wolf j",
    "codigo": "W854"
  },
  {
    "nome": "wolf p",
    "codigo": "W855"
  },
  {
    "nome": "wolffe",
    "codigo": "W856"
  },
  {
    "nome": "wolffe j",
    "codigo": "W857"
  },
  {
    "nome": "wolffe p",
    "codigo": "W858"
  },
  {
    "nome": "wolfg",
    "codigo": "W859"
  },
  {
    "nome": "wolfr",
    "codigo": "W861"
  },
  {
    "nome": "wolk",
    "codigo": "W862"
  },
  {
    "nome": "woll",
    "codigo": "W863"
  },
  {
    "nome": "wolle",
    "codigo": "W864"
  },
  {
    "nome": "wolm",
    "codigo": "W865"
  },
  {
    "nome": "wolo",
    "codigo": "W866"
  },
  {
    "nome": "wols",
    "codigo": "W867"
  },
  {
    "nome": "wolt",
    "codigo": "W868"
  },
  {
    "nome": "woltm",
    "codigo": "W869"
  },
  {
    "nome": "wolz",
    "codigo": "W871"
  },
  {
    "nome": "wom",
    "codigo": "W872"
  },
  {
    "nome": "woo",
    "codigo": "W873"
  },
  {
    "nome": "wood c",
    "codigo": "W874"
  },
  {
    "nome": "wood f",
    "codigo": "W875"
  },
  {
    "nome": "wood j",
    "codigo": "W876"
  },
  {
    "nome": "wood m",
    "codigo": "W877"
  },
  {
    "nome": "wood p",
    "codigo": "W878"
  },
  {
    "nome": "wood s",
    "codigo": "W879"
  },
  {
    "nome": "wood w",
    "codigo": "W881"
  },
  {
    "nome": "woodbri",
    "codigo": "W882"
  },
  {
    "nome": "woodbridge m",
    "codigo": "W883"
  },
  {
    "nome": "woodbu",
    "codigo": "W884"
  },
  {
    "nome": "woodbury m",
    "codigo": "W885"
  },
  {
    "nome": "woodc",
    "codigo": "W886"
  },
  {
    "nome": "woodf",
    "codigo": "W887"
  },
  {
    "nome": "woodh",
    "codigo": "W888"
  },
  {
    "nome": "woodho",
    "codigo": "W889"
  },
  {
    "nome": "woodhu",
    "codigo": "W891"
  },
  {
    "nome": "woodm",
    "codigo": "W892"
  },
  {
    "nome": "woodr",
    "codigo": "W893"
  },
  {
    "nome": "woods",
    "codigo": "W894"
  },
  {
    "nome": "woods j",
    "codigo": "W895"
  },
  {
    "nome": "woods m",
    "codigo": "W896"
  },
  {
    "nome": "woods s",
    "codigo": "W897"
  },
  {
    "nome": "woods w",
    "codigo": "W898"
  },
  {
    "nome": "woodw",
    "codigo": "W899"
  },
  {
    "nome": "woodward j",
    "codigo": "W911"
  },
  {
    "nome": "woodward p",
    "codigo": "W912"
  },
  {
    "nome": "wool",
    "codigo": "W913"
  },
  {
    "nome": "woolm",
    "codigo": "W914"
  },
  {
    "nome": "woolr",
    "codigo": "W915"
  },
  {
    "nome": "wools",
    "codigo": "W916"
  },
  {
    "nome": "woolw",
    "codigo": "W917"
  },
  {
    "nome": "woot",
    "codigo": "W918"
  },
  {
    "nome": "wor",
    "codigo": "W919"
  },
  {
    "nome": "worcester g",
    "codigo": "W921"
  },
  {
    "nome": "worcester m",
    "codigo": "W922"
  },
  {
    "nome": "worcester s",
    "codigo": "W923"
  },
  {
    "nome": "word",
    "codigo": "W924"
  },
  {
    "nome": "wordsw",
    "codigo": "W925"
  },
  {
    "nome": "wordsworth m",
    "codigo": "W926"
  },
  {
    "nome": "worl",
    "codigo": "W927"
  },
  {
    "nome": "worm",
    "codigo": "W928"
  },
  {
    "nome": "woro",
    "codigo": "W929"
  },
  {
    "nome": "wors",
    "codigo": "W931"
  },
  {
    "nome": "wort",
    "codigo": "W932"
  },
  {
    "nome": "worthington",
    "codigo": "W933"
  },
  {
    "nome": "worthington m",
    "codigo": "W934"
  },
  {
    "nome": "wortl",
    "codigo": "W935"
  },
  {
    "nome": "wot",
    "codigo": "W936"
  },
  {
    "nome": "wott",
    "codigo": "W937"
  },
  {
    "nome": "wou",
    "codigo": "W938"
  },
  {
    "nome": "wr",
    "codigo": "W939"
  },
  {
    "nome": "wran",
    "codigo": "W941"
  },
  {
    "nome": "wrat",
    "codigo": "W942"
  },
  {
    "nome": "wrax",
    "codigo": "W943"
  },
  {
    "nome": "wre",
    "codigo": "W944"
  },
  {
    "nome": "wren",
    "codigo": "W945"
  },
  {
    "nome": "wri",
    "codigo": "W946"
  },
  {
    "nome": "wright",
    "codigo": "W947"
  },
  {
    "nome": "wright c",
    "codigo": "W948"
  },
  {
    "nome": "wright f",
    "codigo": "W949"
  },
  {
    "nome": "wright j",
    "codigo": "W951"
  },
  {
    "nome": "wright m",
    "codigo": "W952"
  },
  {
    "nome": "wright s",
    "codigo": "W953"
  },
  {
    "nome": "wright w",
    "codigo": "W954"
  },
  {
    "nome": "wris",
    "codigo": "W955"
  },
  {
    "nome": "writ",
    "codigo": "W956"
  },
  {
    "nome": "wro",
    "codigo": "W957"
  },
  {
    "nome": "wroth",
    "codigo": "W958"
  },
  {
    "nome": "wu",
    "codigo": "W959"
  },
  {
    "nome": "wul",
    "codigo": "W961"
  },
  {
    "nome": "wulfh",
    "codigo": "W962"
  },
  {
    "nome": "wulfr",
    "codigo": "W963"
  },
  {
    "nome": "wulfs",
    "codigo": "W964"
  },
  {
    "nome": "wun",
    "codigo": "W965"
  },
  {
    "nome": "wuns",
    "codigo": "W966"
  },
  {
    "nome": "wur",
    "codigo": "W967"
  },
  {
    "nome": "wurm",
    "codigo": "W968"
  },
  {
    "nome": "wurt",
    "codigo": "W969"
  },
  {
    "nome": "wurtz",
    "codigo": "W971"
  },
  {
    "nome": "wurz",
    "codigo": "W972"
  },
  {
    "nome": "wus",
    "codigo": "W973"
  },
  {
    "nome": "wy",
    "codigo": "W974"
  },
  {
    "nome": "wyatt",
    "codigo": "W975"
  },
  {
    "nome": "wyatt m",
    "codigo": "W976"
  },
  {
    "nome": "wyc",
    "codigo": "W977"
  },
  {
    "nome": "wyd",
    "codigo": "W978"
  },
  {
    "nome": "wye",
    "codigo": "W979"
  },
  {
    "nome": "wyk",
    "codigo": "W981"
  },
  {
    "nome": "wyl",
    "codigo": "W982"
  },
  {
    "nome": "wyle",
    "codigo": "W983"
  },
  {
    "nome": "wym",
    "codigo": "W984"
  },
  {
    "nome": "wyn",
    "codigo": "W985"
  },
  {
    "nome": "wynf",
    "codigo": "W986"
  },
  {
    "nome": "wyng",
    "codigo": "W987"
  },
  {
    "nome": "wynn",
    "codigo": "W988"
  },
  {
    "nome": "wynne m",
    "codigo": "W989"
  },
  {
    "nome": "wynt",
    "codigo": "W991"
  },
  {
    "nome": "wyo",
    "codigo": "W992"
  },
  {
    "nome": "wyr",
    "codigo": "W993"
  },
  {
    "nome": "wys",
    "codigo": "W994"
  },
  {
    "nome": "wyss",
    "codigo": "W995"
  },
  {
    "nome": "wyt",
    "codigo": "W996"
  },
  {
    "nome": "wytt",
    "codigo": "W997"
  },
  {
    "nome": "wyv",
    "codigo": "W998"
  },
  {
    "nome": "wz",
    "codigo": "W999"
  },
  {
    "nome": "x",
    "codigo": "X1"
  },
  {
    "nome": "xa",
    "codigo": "X1"
  },
  {
    "nome": "xan",
    "codigo": "X2"
  },
  {
    "nome": "xav",
    "codigo": "X3"
  },
  {
    "nome": "xe",
    "codigo": "X4"
  },
  {
    "nome": "xen",
    "codigo": "X5"
  },
  {
    "nome": "xer",
    "codigo": "X6"
  },
  {
    "nome": "xl",
    "codigo": "X7"
  },
  {
    "nome": "xn",
    "codigo": "X8"
  },
  {
    "nome": "xy",
    "codigo": "X9"
  },
  {
    "nome": "y",
    "codigo": "Y11"
  },
  {
    "nome": "ya",
    "codigo": "Y11"
  },
  {
    "nome": "yac",
    "codigo": "Y12"
  },
  {
    "nome": "yah",
    "codigo": "Y13"
  },
  {
    "nome": "yai",
    "codigo": "Y14"
  },
  {
    "nome": "yak",
    "codigo": "Y15"
  },
  {
    "nome": "yal",
    "codigo": "Y16"
  },
  {
    "nome": "yale",
    "codigo": "Y17"
  },
  {
    "nome": "yale m",
    "codigo": "Y18"
  },
  {
    "nome": "yales",
    "codigo": "Y19"
  },
  {
    "nome": "yan",
    "codigo": "Y21"
  },
  {
    "nome": "yane",
    "codigo": "Y22"
  },
  {
    "nome": "yani",
    "codigo": "Y23"
  },
  {
    "nome": "yann",
    "codigo": "Y24"
  },
  {
    "nome": "yao",
    "codigo": "Y25"
  },
  {
    "nome": "yar",
    "codigo": "Y26"
  },
  {
    "nome": "yard",
    "codigo": "Y27"
  },
  {
    "nome": "yarf",
    "codigo": "Y28"
  },
  {
    "nome": "yarr",
    "codigo": "Y29"
  },
  {
    "nome": "yat",
    "codigo": "Y31"
  },
  {
    "nome": "yates g",
    "codigo": "Y32"
  },
  {
    "nome": "yates m",
    "codigo": "Y33"
  },
  {
    "nome": "yates s",
    "codigo": "Y34"
  },
  {
    "nome": "yatm",
    "codigo": "Y35"
  },
  {
    "nome": "yb",
    "codigo": "Y36"
  },
  {
    "nome": "ye",
    "codigo": "Y37"
  },
  {
    "nome": "yeam",
    "codigo": "Y38"
  },
  {
    "nome": "year",
    "codigo": "Y39"
  },
  {
    "nome": "yeat",
    "codigo": "Y41"
  },
  {
    "nome": "yeb",
    "codigo": "Y42"
  },
  {
    "nome": "yef",
    "codigo": "Y43"
  },
  {
    "nome": "yem",
    "codigo": "Y44"
  },
  {
    "nome": "yen",
    "codigo": "Y45"
  },
  {
    "nome": "yeo",
    "codigo": "Y46"
  },
  {
    "nome": "yep",
    "codigo": "Y47"
  },
  {
    "nome": "yet",
    "codigo": "Y48"
  },
  {
    "nome": "yez",
    "codigo": "Y49"
  },
  {
    "nome": "yh",
    "codigo": "Y51"
  },
  {
    "nome": "yl",
    "codigo": "Y52"
  },
  {
    "nome": "yn",
    "codigo": "Y53"
  },
  {
    "nome": "yo",
    "codigo": "Y54"
  },
  {
    "nome": "yon",
    "codigo": "Y55"
  },
  {
    "nome": "yonge g",
    "codigo": "Y56"
  },
  {
    "nome": "yonge m",
    "codigo": "Y57"
  },
  {
    "nome": "yonge s",
    "codigo": "Y58"
  },
  {
    "nome": "yonge w",
    "codigo": "Y59"
  },
  {
    "nome": "yor",
    "codigo": "Y61"
  },
  {
    "nome": "york j",
    "codigo": "Y62"
  },
  {
    "nome": "york p",
    "codigo": "Y63"
  },
  {
    "nome": "yorke",
    "codigo": "Y64"
  },
  {
    "nome": "yorke m",
    "codigo": "Y65"
  },
  {
    "nome": "yot",
    "codigo": "Y66"
  },
  {
    "nome": "you",
    "codigo": "Y67"
  },
  {
    "nome": "young",
    "codigo": "Y68"
  },
  {
    "nome": "young c",
    "codigo": "Y69"
  },
  {
    "nome": "young e",
    "codigo": "Y71"
  },
  {
    "nome": "young g",
    "codigo": "Y72"
  },
  {
    "nome": "young j",
    "codigo": "Y73"
  },
  {
    "nome": "young m",
    "codigo": "Y74"
  },
  {
    "nome": "young p",
    "codigo": "Y75"
  },
  {
    "nome": "young s",
    "codigo": "Y76"
  },
  {
    "nome": "young t",
    "codigo": "Y77"
  },
  {
    "nome": "young w",
    "codigo": "Y78"
  },
  {
    "nome": "youngm",
    "codigo": "Y79"
  },
  {
    "nome": "youngs",
    "codigo": "Y81"
  },
  {
    "nome": "yous",
    "codigo": "Y82"
  },
  {
    "nome": "youss",
    "codigo": "Y83"
  },
  {
    "nome": "yoz",
    "codigo": "Y84"
  },
  {
    "nome": "yp",
    "codigo": "Y85"
  },
  {
    "nome": "yps",
    "codigo": "Y86"
  },
  {
    "nome": "yr",
    "codigo": "Y87"
  },
  {
    "nome": "yri",
    "codigo": "Y88"
  },
  {
    "nome": "yrie",
    "codigo": "Y89"
  },
  {
    "nome": "ys",
    "codigo": "Y91"
  },
  {
    "nome": "ysen",
    "codigo": "Y92"
  },
  {
    "nome": "yss",
    "codigo": "Y93"
  },
  {
    "nome": "yu",
    "codigo": "Y94"
  },
  {
    "nome": "yule",
    "codigo": "Y95"
  },
  {
    "nome": "yv",
    "codigo": "Y96"
  },
  {
    "nome": "yve",
    "codigo": "Y97"
  },
  {
    "nome": "yves",
    "codigo": "Y98"
  },
  {
    "nome": "yvo",
    "codigo": "Y99"
  },
  {
    "nome": "z",
    "codigo": "Z11"
  },
  {
    "nome": "za",
    "codigo": "Z11"
  },
  {
    "nome": "zab",
    "codigo": "Z12"
  },
  {
    "nome": "zac",
    "codigo": "Z13"
  },
  {
    "nome": "zacco",
    "codigo": "Z14"
  },
  {
    "nome": "zach",
    "codigo": "Z15"
  },
  {
    "nome": "zachar",
    "codigo": "Z16"
  },
  {
    "nome": "zacu",
    "codigo": "Z17"
  },
  {
    "nome": "zag",
    "codigo": "Z18"
  },
  {
    "nome": "zah",
    "codigo": "Z19"
  },
  {
    "nome": "zai",
    "codigo": "Z21"
  },
  {
    "nome": "zal",
    "codigo": "Z22"
  },
  {
    "nome": "zam",
    "codigo": "Z23"
  },
  {
    "nome": "zambo",
    "codigo": "Z24"
  },
  {
    "nome": "zamo",
    "codigo": "Z25"
  },
  {
    "nome": "zamp",
    "codigo": "Z26"
  },
  {
    "nome": "zan",
    "codigo": "Z27"
  },
  {
    "nome": "zane",
    "codigo": "Z28"
  },
  {
    "nome": "zang",
    "codigo": "Z29"
  },
  {
    "nome": "zani",
    "codigo": "Z31"
  },
  {
    "nome": "zann",
    "codigo": "Z32"
  },
  {
    "nome": "zano",
    "codigo": "Z33"
  },
  {
    "nome": "zant",
    "codigo": "Z34"
  },
  {
    "nome": "zap",
    "codigo": "Z35"
  },
  {
    "nome": "zar",
    "codigo": "Z36"
  },
  {
    "nome": "zari",
    "codigo": "Z37"
  },
  {
    "nome": "zaro",
    "codigo": "Z38"
  },
  {
    "nome": "zau",
    "codigo": "Z39"
  },
  {
    "nome": "ze",
    "codigo": "Z41"
  },
  {
    "nome": "zec",
    "codigo": "Z42"
  },
  {
    "nome": "zed",
    "codigo": "Z43"
  },
  {
    "nome": "zeg",
    "codigo": "Z44"
  },
  {
    "nome": "zei",
    "codigo": "Z45"
  },
  {
    "nome": "zeif",
    "codigo": "Z46"
  },
  {
    "nome": "zeis",
    "codigo": "Z47"
  },
  {
    "nome": "zeit",
    "codigo": "Z48"
  },
  {
    "nome": "zel",
    "codigo": "Z49"
  },
  {
    "nome": "zell",
    "codigo": "Z51"
  },
  {
    "nome": "zelo",
    "codigo": "Z52"
  },
  {
    "nome": "zelt",
    "codigo": "Z53"
  },
  {
    "nome": "zen",
    "codigo": "Z54"
  },
  {
    "nome": "zeno",
    "codigo": "Z55"
  },
  {
    "nome": "zent",
    "codigo": "Z56"
  },
  {
    "nome": "zep",
    "codigo": "Z57"
  },
  {
    "nome": "zer",
    "codigo": "Z58"
  },
  {
    "nome": "zes",
    "codigo": "Z59"
  },
  {
    "nome": "zet",
    "codigo": "Z61"
  },
  {
    "nome": "zeu",
    "codigo": "Z62"
  },
  {
    "nome": "zev",
    "codigo": "Z63"
  },
  {
    "nome": "zi",
    "codigo": "Z64"
  },
  {
    "nome": "zie",
    "codigo": "Z65"
  },
  {
    "nome": "zieg",
    "codigo": "Z66"
  },
  {
    "nome": "zies",
    "codigo": "Z67"
  },
  {
    "nome": "zif",
    "codigo": "Z68"
  },
  {
    "nome": "zil",
    "codigo": "Z69"
  },
  {
    "nome": "zim",
    "codigo": "Z71"
  },
  {
    "nome": "zimmer",
    "codigo": "Z72"
  },
  {
    "nome": "zimmermann",
    "codigo": "Z73"
  },
  {
    "nome": "zimmermann f",
    "codigo": "Z74"
  },
  {
    "nome": "zimmermann m",
    "codigo": "Z75"
  },
  {
    "nome": "zimmermann s",
    "codigo": "Z76"
  },
  {
    "nome": "zin",
    "codigo": "Z77"
  },
  {
    "nome": "zink",
    "codigo": "Z78"
  },
  {
    "nome": "zinz",
    "codigo": "Z79"
  },
  {
    "nome": "zir",
    "codigo": "Z81"
  },
  {
    "nome": "zit",
    "codigo": "Z82"
  },
  {
    "nome": "zo",
    "codigo": "Z83"
  },
  {
    "nome": "zoc",
    "codigo": "Z84"
  },
  {
    "nome": "zoe",
    "codigo": "Z85"
  },
  {
    "nome": "zol",
    "codigo": "Z86"
  },
  {
    "nome": "zon",
    "codigo": "Z87"
  },
  {
    "nome": "zop",
    "codigo": "Z88"
  },
  {
    "nome": "zot",
    "codigo": "Z89"
  },
  {
    "nome": "zou",
    "codigo": "Z91"
  },
  {
    "nome": "zs",
    "codigo": "Z92"
  },
  {
    "nome": "zu",
    "codigo": "Z93"
  },
  {
    "nome": "zuc",
    "codigo": "Z94"
  },
  {
    "nome": "zun",
    "codigo": "Z95"
  },
  {
    "nome": "zur",
    "codigo": "Z96"
  },
  {
    "nome": "zw",
    "codigo": "Z97"
  },
  {
    "nome": "zwi",
    "codigo": "Z98"
  },
  {
    "nome": "zy",
    "codigo": "Z99"
  },
  {
    "nome": "zz",
    "codigo": "Z99"
  }
],


 

output = "";


 output += '<table class="table table-striped"><tr><th>Nome</th><th>C�digo</th></tr>';
$.each(data, function(key, val){

  output += '<tr>';
  output += '<td class="value-codigo">' + val.nome + '</td>';
  output += '<td class="value-nome">' + val.codigo + '</td>'
  output += "</tr>";
});


$("#content").html(output);
  


/* SEEKER FUNCTION */
 if (!RegExp.escape) {
   RegExp.escape = function (s) {
     return s.replace(/[\-\[\]{}()*+?.,\\\^$|#\s]/g, "\\$&")
   };
 }
 

 jQuery(function(){

  var $rows = $('.values');
  $('#seeker').keydown(function () {
    var regex =  new RegExp(RegExp.escape($.trim(this.value).replace(/\s+/g, ' ')), 'i')
    $rows.hide().filter(function () {
      var text = $(this).children(".value-nome").text().replace(/\s+/g, ' ');
     return regex.test(text)

    }).show();

  });
});
